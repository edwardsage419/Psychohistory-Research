# Darwin measured CPU fallback after real native failure

Native macOS ARM64 run 44256389862 proved that RLIMIT_CPU=(1,2) alone did not force SIGKILL when SIGXCPU was ignored; the real worker exceeded its 8-second wall test deadline. This evidence supersedes the earlier unverified Darwin kernel hard-limit assumption.

Edited only owned `src/psychohistory/worker_lifecycle.py` and `tests/test_worker_v03.py`:
- Darwin still configures POSIX RLIMIT_CPU and installs a normal SIGXCPU handler that kills the owned group.
- An independent daemon watchdog measures native `time.process_time()` and sends SIGKILL to the owned group at `cpu_seconds+1`, even if SIGXCPU is ignored. The fixed trusted Python mechanisms yield the GIL; this is a process watchdog, not a kernel hard guarantee for arbitrary C extensions holding the GIL.
- Receipt: `cpu=DARWIN_PROCESS_CPU_WATCHDOG`, `cpu_kernel_limit=RLIMIT_CPU_CONFIGURED_ONLY`, `cpu_watchdog_clock=time.process_time`, `cpu_soft_action=SIGXCPU_KILLPG`, `cpu_hard_action=PROCESS_CPU_WATCHDOG_KILLPG`. Soft/hard numeric CPU budgets remain explicit. Darwin memory stays NOT_ENFORCED.
- Linux configuration and receipts are unchanged.
- The native CPU test still ignores SIGXCPU and demands actual SIGKILL; it now checks the honest platform-specific receipt. Sealed comparison integration checks the Darwin distinction as well.

TDD: new fallback helper test failed because watch_cpu was missing, then passed after implementation. It sleeps longer than its CPU deadline without being killed (process CPU, not wall), then burns CPU while ignoring SIGXCPU and proves worker and descendant group terminate by SIGKILL. This helper test executes on Linux without impersonating Darwin.

```bash
PYTHONPATH=src /workspace/.psychohistory-env/venv/bin/python -m pytest -q tests/test_worker_v03.py
# 17 PASS in 5.76s on Linux.
git diff --check -- src/psychohistory/worker_lifecycle.py tests/test_worker_v03.py
/workspace/.psychohistory-env/venv/bin/python -m py_compile src/psychohistory/worker_lifecycle.py tests/test_worker_v03.py
# PASS.
```

Root is rerunning the actual native matrix. Native Darwin success is not claimed by this Linux receipt. No commit or push by this worker.
