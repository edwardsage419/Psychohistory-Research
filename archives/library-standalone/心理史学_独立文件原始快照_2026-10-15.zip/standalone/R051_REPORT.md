# 心理史学 R051 正式研究记录

日期：2026-10-15。性质：来源准入审计、真实既有资料的新方法分析、数学不变量证明、零机制合成反例。

## 结论及研究等级

**R051 形成了可复核的时间口径代数耦合审计，且用R048已核验的作者原始CSV在连接器侧进行了896条真人行为转移的数值核验。** 另建立零惩罚效应的构造样本，展示即便没有群体影响，也会由于被解释变量和分组解释变量重叠而出现稳定回归斜率。R051 **未取得新的独立团队原始微观数据字节**，未形成新的真实跨研究预测分数。因而 `INDEPENDENT_EXTERNAL_VALIDATION=BLOCKED`，不得称“心理史学机制被验证”。

`PESEN_v0.1=FROZEN`；原创性 `UNVERIFIED`；独立社会惩罚心理因果机制 `UNIDENTIFIED`；历史尺度外推 `NOT_ESTABLISHED`。

## 1. 两个候选独立来源准入检查

**Abatayo & Lynham (2023)**，*Resource Booms and Group Punishment in a Coupled Social-Ecological System*，原作者公开数据集 DOI `10.17632/c2z95m5gty.1`，CC BY 4.0，网页确认3,060条、160名受试者、8场次、33字段和Stata数据及代码。R049冻结的B0~B3及λ=8、R050跨区块审计程序均已存在；本环境 `data.mendeley.com` 等域名解析失败，原始 `alldata.dta` 未取得，无法运行独立预测。

**Bone, Wallace, Bshary & Raihani (2016)**，*Power Asymmetries and Punishment in a Prisoner's Dilemma with Variable Cooperative Investment*，PLOS ONE，DOI `10.1371/journal.pone.0155773`。独立团队真人实验120人、6场次；每人两个连续投资实验（同型与异型伙伴各一次），每个50轮，有对定向伙伴惩罚及退出的选项，强弱惩罚影响比1:6与1:1。官方文章提供S5 Appendix原始CSV（约453.2KB）及S4 R分析代码，许可CC BY。网页点击S5时跳到临时签名的云存储文件，网络读取工具无法返回CSV字节；因此 `S5_RAW_BYTES=NOT_OBTAINED`，无该数据的具体分析、字段核验、预测结果。论文仅公开摘要/方法/分析样本数据，不能冒充源CSV复现。

**Herrmann, Thöni & Gächter**：2008 *Science*跨16个受试者池的反社会惩罚研究，Dryad DOI `10.5061/dryad.87301`，作者的数据及代码压缩包在官方页面可见；直接下载返回403。当前亦无字节可供复现。可能用于今后的跨制度机制压力测试，须先确认跨地点测量等值。

本轮未进行第三方写入、未请求作者发送资料、未邀请真人参与实验。

## 2. R048原始真实资料的新增精确代数审计

原始来源为`lrdegeest/InequalityCPR/data/data.csv`，Git blob SHA1 `73c02176bc9e060af987149594a85f9f7b591230`。作者CSV在GitHub连接器侧读取并独立于R048回归代码做数值核验。R051本地没有复制该原始CSV字节；本地脚本通过SHA1来源关口后才能对用户合法取得的文件重放。

对于个体i、当期t、组g，定义E为资源提取、D为相对组均值偏离：

\[
D_{it}=\overline E_{gt}-E_{it},\qquad \Delta E_{it}=E_{it}-E_{i,t-1}.
\]

**精确恒等式**：

\[
\Delta E_{it}=\Delta\overline E_{gt}-D_{it}+D_{i,t-1}.
\]

这是由变量定义得出的恒等式，不假设学习、惩罚或任何心理参数；无论假设为真还是假均成立。特别地，对当前D作为解释变量的模型，解释变量本身包含被解释变量当期E，构成直接代数耦合；只用滞后D则可避免把当期行为直接写入已知预测特征，但滞后D与个体当期行为变化仍有构造上的自相关关系。

R051在连接器侧对同一真实作者CSV重算：惩罚组64人、16组、15个正式轮次，896个相邻正式轮行为转移，224个组轮转移单元。对每次转移验证恒等式，最大计算误差为0（JS Number算术）；不含其他惩罚变量的全样本一元OLS：

- 当期偏离D(t) 的斜率：**-0.6566231994291495**。
- 前期偏离D(t-1) 的斜率：**+0.6655796921596555**。
- 前后偏离类别符号改变或涉及零类别的观察数为315。

这些斜率为**未经处理效应调整的描述性相关**。计算结果没有提供惩罚因果效应，也没有因事后来源复算变为预注册结果。原文Table4是分层随机效应多变量回归，不能拿这些全样本OLS斜率声称“精确复现Table4”。

## 3. 无任何惩罚或同伴影响的理论反例

考虑每人相互独立的平稳AR(1)过程：

\[
E_{i,t}=\rho E_{i,t-1}+\sqrt{1-\rho^2}\epsilon_{i,t},\quad \epsilon\stackrel{iid}{\sim}N(0,1), \quad |\rho|<1.
\]

各时刻群体由m个固定成员组成，随机创新彼此独立且没有惩罚决策。在无组别或日期选样限制的总体回归中，

\[
\operatorname{Cov}(D_{it},\Delta E_{it})
  =-\frac{m-1}{m}(1-\rho),\quad
\operatorname{Var}(D_{it})=\frac{m-1}{m},
\]

故带截距的一元OLS总体斜率：

\[
\beta_{D(t)}=\rho-1,\qquad \beta_{D(t-1)}=1-\rho.
\]

这两项系数源自变量构造和自身时间自相关，与惩罚或社会学习机制无关。结论仅在上述独立平稳AR(1)、无样本截断等假设下精确成立。它不能直接预测R048实际四个经条件筛选随机效应回归的系数值。

固定随机种子20261015的数值模拟：120个四人组、360期、每场景172,320个转移行为值。模拟结果：

| 自身持久性ρ | 理论当期D斜率 | 模拟当期D斜率 | 理论滞后D斜率 | 模拟滞后D斜率 |
|:---:|---:|---:|---:|---:|
| 0.0 | -1.0000 | -0.995505 | +1.0000 | +0.995504 |
| 0.5 | -0.5000 | -0.496626 | +0.5000 | +0.496394 |
| 0.8 | -0.2000 | -0.197308 | +0.2000 | +0.196973 |

**这是构造数据模拟，不含任何真实人物行为，更不是新独立实验实证结果。** 程序和原始输出在档案中。

## 4. 识别与预测方法要求

1. 模型审计应显式记录行为决策发生时间、他人行为披露时间、惩罚接受时间，以及任何相对位置分组依据的时间。不得使用t期行为构造t期选择之前的预测信息。
2. 对∆E与当期组相对位置的回归，先展示恒等式及无机制零基线；不能根据单个D系数推导行为学习、惩罚有效性或群体规范形成。
3. 对滞后D分析，仍应比较无需惩罚的个体自相关和群体环境基线。惩罚接受是既有行为的内生后果；预测增益不能替代惩罚随机化。
4. 行为转移跨伙伴重新匹配时，组均值滞后必须核对历史组成员；即便恒等式在错误配对下仍成立，结构一致性关口也必须独立执行。
5. 迁移到Bone研究时，结果是0至5秒连续合作与有惩罚选项的双人重复博弈；R049的二元高/低提取预测基线与R048四人公共资源模型不能原封不动使用。应先锁定可比较的目标事件和时间分割，再开展独立留出。

## 5. 复现与测试

- 独立脚本 `r051_temporal_audit.py` 包含严格原始Git blob准入、代数一致性检查、全样本一元OLS及3个零机制反例。
- 为确保归档独立运行，包含R048只读来源解析的冻结副本 `r048_source_reader_frozen.py`。
- 对脚本执行17项构造数学、错误输入与来源拒绝测试，17项通过，0项失败。
- **真实CSV SHA锁定模式未在本地运行**；真实样本的本轮新数值由连接器侧JS计算得到，来源Git blob核对与原始CSV直接读取已完成。合成数据测试只验证程序行为。

## 6. R051决策与下一轮

`R051_STATUS=COMPLETE_AS_TEMPORAL_METHOD_AUDIT`

`NEW_INDEPENDENT_MICRODATA_BYTES=NOT_OBTAINED`

`NEW_INDEPENDENT_NUMERIC_REPLICATION=NO`

`PESEN_v0.1=FROZEN`

R052优先尝试PLOS官方S5开放原始CSV的有效下载链路，次选Mendeley Abatayo原DTA，再次是Dryad可取得并有跨社会可比设计的资料。一旦取得源字节，先核验身份、字段、时间、暴露、独立分配单位，再锁定新的竞争模型比较，不得事后把已见数据标记为前瞻检验。

## 来源清单

- R048真实原始CSV：<https://github.com/lrdegeest/InequalityCPR/blob/master/data/data.csv>
- R048作者Stata脚本：<https://github.com/lrdegeest/InequalityCPR/blob/master/analysis/punishment_response.do>
- Bone等（2016）论文全文与S5数据链接：<https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0155773>
- Abatayo与Lynham原始档案：<https://data.mendeley.com/datasets/c2z95m5gty/1>
- Herrmann等跨社会惩罚数据：<https://datadryad.org/dataset/doi:10.5061/dryad.87301>
