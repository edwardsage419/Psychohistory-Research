#!/usr/bin/env python3
"""Psychohistory R051: mathematical temporal-coupling audit.

Python 3.10+, NumPy; no network requirement. There are two execution modes:

1) Null demonstration: python r051_temporal_audit.py --simulate
2) Original De Geest/Kingsley GitHub CSV, supplied separately:
   python r051_temporal_audit.py --csv /path/to/data.csv

No output in simulation mode is a real human experiment estimate. CSV mode uses
R048's frozen ingestion and hard-fails on an unexpected original Git blob SHA.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Iterable

import numpy as np

GROUP_N = 4
SOURCE_BLOB_SHA1 = '73c02176bc9e060af987149594a85f9f7b591230'


def ols_slope(x: np.ndarray, y: np.ndarray) -> float:
    """OLS slope with intercept; descriptive association only."""
    x = np.asarray(x, dtype=float).ravel()
    y = np.asarray(y, dtype=float).ravel()
    if x.shape != y.shape or x.size < 2 or not np.isfinite(x).all() or not np.isfinite(y).all():
        raise ValueError('Invalid finite vectors')
    xc, yc = x - x.mean(), y - y.mean()
    ss = float(xc @ xc)
    if ss <= 0:
        raise ValueError('Degenerate regressor')
    return float((xc @ yc) / ss)


def temporal_identity(
    now: np.ndarray, previous: np.ndarray, axis: int = -1
) -> dict[str, float | int]:
    """Audit delta E = delta group mean - D_now + D_prev.

    Inputs are aligned (group, time, person) arrays, where the same participants
    remain in each group. The identity holds regardless of behavioral mechanism.
    """
    now = np.asarray(now, dtype=float)
    previous = np.asarray(previous, dtype=float)
    if now.shape != previous.shape or now.ndim < 2 or now.size == 0:
        raise ValueError('Misaligned group by person arrays')
    if not np.isfinite(now).all() or not np.isfinite(previous).all():
        raise ValueError('Nonfinite extraction')
    now_mean = now.mean(axis=axis, keepdims=True)
    prev_mean = previous.mean(axis=axis, keepdims=True)
    d_now, d_prev = now_mean - now, prev_mean - previous
    y = now - previous
    reconstructed = (now_mean - prev_mean) - d_now + d_prev
    err = float(np.max(np.abs(y - reconstructed)))
    return {
        'rows': int(now.size),
        'group_person_count': int(now.shape[axis]),
        'max_identity_error': err,
        'ols_slope_current_deviation': ols_slope(d_now, y),
        'ols_slope_previous_deviation': ols_slope(d_prev, y),
    }


def null_simulation(
    rho: float, *, groups: int = 120, periods: int = 360,
    group_size: int = GROUP_N, seed: int = 20261015
) -> dict[str, float | int | str]:
    """Stationary Gaussian AR(1), no punishment, no cross-person influence.

    Under identical independent AR(1) agents, unconditional theoretical slopes
    for current and previous group-relative deviations are rho-1 and 1-rho.
    """
    if not (-1 < rho < 1) or groups < 2 or periods < 3 or group_size < 2:
        raise ValueError('Bad simulation parameters')
    rng = np.random.default_rng(seed)
    e = np.zeros((periods, groups, group_size), dtype=float)
    e[0] = rng.standard_normal((groups, group_size))
    scale = np.sqrt(1 - rho * rho)
    for t in range(1, periods):
        e[t] = rho * e[t-1] + scale * rng.standard_normal((groups, group_size))
    actual = temporal_identity(e[1:], e[:-1])
    return {
        'design': 'SIMULATION_ONLY_ZERO_PUNISHMENT',
        'rho': rho, 'groups': groups, 'group_size': group_size,
        'periods': periods,
        'theory_current': rho - 1,
        'theory_previous': 1 - rho,
        **actual,
    }


def audit_r048_csv(raw_path: Path) -> dict:
    """Reuse R048's SHA-locked author CSV parsing; no other raw accepted."""
    from r048_source_reader_frozen import read_source, git_blob_sha  # noqa: PLC0415

    b = raw_path.read_bytes()
    sha = git_blob_sha(b)
    if sha != SOURCE_BLOB_SHA1:
        raise ValueError('Original Git blob fingerprint mismatch; abort author-data mode')
    rows = read_source(b, require_sha=True)
    punishment = [r for r in rows if r['FF'] == 1 and r['RoundID'] > 1]
    cells = {}
    for row in punishment:
        key = (row['group'], row['RoundID'])
        cells.setdefault(key, []).append(row)
    if len(cells) != 16 * 15 or any(len(v) != 4 for v in cells.values()):
        raise ValueError('Unexpected balanced punishment group-round cells')
    people = {}
    for key, members in cells.items():
        mean = sum(x['Invest'] for x in members) / 4
        for x in members:
            x['dev_r051'] = mean - x['Invest']
            x['mean_r051'] = mean
            people.setdefault(x['ProfileID'], []).append(x)
    records = []
    for sid, seq in people.items():
        seq.sort(key=lambda r: r['RoundID'])
        if len(seq) != 15:
            raise ValueError('Unexpected subject history')
        for prev, now in zip(seq, seq[1:]):
            if now['RoundID'] != prev['RoundID'] + 1 or now['group'] != prev['group']:
                raise ValueError('History crosses group or time discontinuity')
            records.append((now['dev_r051'], prev['dev_r051'],
                            now['Invest'] - prev['Invest'],
                            now['mean_r051'] - prev['mean_r051']))
    a = np.asarray(records, dtype=float)
    err = np.max(np.abs(a[:, 2] - (a[:, 3] - a[:, 0] + a[:, 1])))
    if len(a) != 896 or err > 1e-10:
        raise ValueError('R048 row/time consistency failed')
    return {
        'data_kind': 'REAL_AUTHOR_CSV_SHA_LOCKED',
        'source_git_blob_sha1': sha,
        'subjects': len(people),
        'groups': len({k[0] for k in cells}),
        'group_round_transitions': 16 * 14,
        'rows': len(a),
        'max_identity_error': float(err),
        'ols_slope_current_deviation': ols_slope(a[:, 0], a[:, 2]),
        'ols_slope_previous_deviation': ols_slope(a[:, 1], a[:, 2]),
        'category_switches_including_ties': int(np.count_nonzero(np.sign(a[:, 0]) != np.sign(a[:, 1]))),
        'estimation_label': 'UNCONDITIONAL_DESCRIPTIVE_OLS_SLOPES_NOT_CAUSAL',
    }


def main() -> None:
    p = argparse.ArgumentParser()
    mode = p.add_mutually_exclusive_group(required=True)
    mode.add_argument('--simulate', action='store_true')
    mode.add_argument('--csv', type=Path)
    p.add_argument('--output', type=Path)
    args = p.parse_args()
    data = (
        {'simulations': [null_simulation(r) for r in (0., .5, .8)]}
        if args.simulate else audit_r048_csv(args.csv)
    )
    text = json.dumps(data, ensure_ascii=False, indent=2)
    if args.output:
        args.output.write_text(text + '\n', encoding='utf-8')
    print(text)


if __name__ == '__main__':
    main()
