#!/usr/bin/env python3
"""R017 group-level reanalysis of real political opinion expression.

Input contains only aggregates built in the GitHub connector from author CSV.
Use the authors' original full model for formal replication. Our permutation
assumes topic-stratified GROUP-label exchangeability which is not proven to be
the actual assignment mechanism, and our bootstrap captures cluster uncertainty
under a resampling model, not guaranteed randomization-based coverage.
"""
import csv
import json
import random
from collections import Counter, defaultdict
from pathlib import Path

CELL_ORDER = (("high", "high"), ("low", "high"),
              ("high", "low"), ("low", "low"))


def load(path):
    with open(path, newline="", encoding="utf-8") as f:
        r = list(csv.DictReader(f))
    seen = set()
    for g in r:
        if g['id'] in seen:
            raise ValueError(f"duplicate group {g['id']}")
        seen.add(g['id'])
        for k in ("n", "sum_expressions", "zeros", "cost_respondents",
                  "benefit_respondents"):
            g[k] = int(g[k])
        for k in ("cost_sum", "benefit_sum"):
            g[k] = float(g[k])
        if g['n'] <= 0 or not 0 <= g['zeros'] <= g['n']:
            raise ValueError('invalid count')
        if (g['anonymity'], g['persistence']) not in CELL_ORDER:
            raise ValueError('invalid treatment')
        g['mean'] = g['sum_expressions'] / g['n']
    return r


def validate_real_design(gs):
    if len(gs) != 48 or sum(g['n'] for g in gs) != 960:
        raise ValueError('expected 48 groups / 960 observations')
    if any(g['n'] != 20 for g in gs):
        raise ValueError('expected exactly 20 per group')
    n = Counter((g['topic'], g['anonymity'], g['persistence']) for g in gs)
    if len(n) != 12 or any(v != 4 for v in n.values()):
        raise ValueError('expected 3 topics x 4 conditions x 4 groups')
    if sum(g['zeros'] for g in gs) != 205 or sum(g['sum_expressions'] for g in gs) != 8902:
        raise ValueError('actual-data provenance check failed')
    return True


def stats(gs):
    c = {}
    for a, p in CELL_ORDER:
        xs = [g['mean'] for g in gs if g['anonymity'] == a and g['persistence'] == p]
        if not xs:
            raise ValueError('empty condition')
        c[f'{a}|{p}'] = sum(xs) / len(xs)
    hh, lh, hl, ll = [c['|'.join(z)] for z in CELL_ORDER]
    return {'condition_means':c,
            'anonymity_high_minus_low':(hh + hl - lh - ll)/2,
            'persistence_high_minus_low':(hh + lh - hl - ll)/2,
            'interaction':(hh - lh) - (hl - ll)}


KEYS = ('anonymity_high_minus_low', 'persistence_high_minus_low', 'interaction')


def permutation(gs, B=30000, seed=20261014):
    """Design-based *sensitivity* under hypothetical topic-stratified group relabeling."""
    rng = random.Random(seed)
    orig = stats(gs)
    tail = {k:0 for k in KEYS}
    topics = sorted({g['topic'] for g in gs})
    subsets = [[g for g in gs if g['topic'] == t] for t in topics]
    for _ in range(B):
        permuted=[]
        for sub in subsets:
            labels=[(g['anonymity'],g['persistence']) for g in sub]
            rng.shuffle(labels)
            permuted += [{**g,'anonymity':a,'persistence':p}
                         for g,(a,p) in zip(sub,labels)]
        s=stats(permuted)
        for k in KEYS:
            if abs(s[k]) >= abs(orig[k]) - 1e-12:
                tail[k] += 1
    return {k:(tail[k]+1)/(B+1) for k in KEYS}


def bootstrap(gs, B=18000, seed=20261014):
    """Resample entire discussion groups within each topic x condition."""
    rng = random.Random(seed)
    topics=sorted({g['topic'] for g in gs})
    sub = [[g for g in gs if g['topic']==t and
            (g['anonymity'],g['persistence'])==(a,p)]
           for t in topics for a,p in CELL_ORDER]
    draws={k:[] for k in KEYS}
    for _ in range(B):
        sample=[]
        for cells in sub:
            sample.extend(cells[rng.randrange(len(cells))] for _ in cells)
        d=stats(sample)
        for k in KEYS:draws[k].append(d[k])
    out={}
    for k,values in draws.items():
        z=sorted(values)
        out[k]=[z[int(.025*B)],z[int(.975*B)]]
    return out


def leave_one_group_out(gs):
    result=[]
    for omit in gs:
        rest=[g for g in gs if g['id']!=omit['id']]
        s=stats(rest)
        result.append({'omitted':omit['id'],**{k:s[k] for k in KEYS}})
    return result


def run(path, permutation_draws=30000, bootstrap_draws=18000, seed=20261014):
    gs=load(path)
    validate_real_design(gs)
    contrasts=stats(gs)
    lo=leave_one_group_out(gs)
    return {'source':'tdienlin/persistence_and_anonymity data/data.csv',
            'source_git_blob_sha1':'62166267c925c2bc6b8f9f1b87db59c28868b262',
            'unit_of_inference':'48 discussion groups, stratified by 3 topics',
            'participants':sum(g['n'] for g in gs),'groups':len(gs),
            'total_expressions':sum(g['sum_expressions'] for g in gs),
            'zero_expression_participants':sum(g['zeros'] for g in gs),
            'cost_survey_respondents':sum(g['cost_respondents'] for g in gs),
            'main':contrasts,
            'permutation_assumed_group_relabeling':permutation(gs,permutation_draws,seed),
            'bootstrap_group_strata_CI_95':bootstrap(gs,bootstrap_draws,seed),
            'LOO_ranges':{k:[min(v[k] for v in lo),max(v[k] for v in lo)] for k in KEYS},
            'LOO_group_details':lo,
            'limitations':['Synthetic resampling inference assumes within-topic group-label exchangeability; not proven randomization procedure',
                           'Within-group interference and between-group dependence not fully identified',
                           'Outcomes are counts; not matched private and public statements',
                           'Post-treatment perceived costs observed for 705/960 only; no causal mediation claim']}


if __name__ == '__main__':
    import argparse
    ap=argparse.ArgumentParser()
    ap.add_argument('--input',type=Path,default=Path(__file__).with_name('GROUP_STATS.csv'))
    ap.add_argument('--output',type=Path,default=Path(__file__).parent/'results/reanalysis.json')
    ap.add_argument('--permutations',type=int,default=30000)
    ap.add_argument('--bootstraps',type=int,default=18000)
    args=ap.parse_args()
    d=run(args.input,args.permutations,args.bootstraps)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f'R017: groups={d["groups"]}, participants={d["participants"]}, output={args.output}')
