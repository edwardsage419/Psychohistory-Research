#!/usr/bin/env python3
"""R047 source-locked replication of an exploratory OLS timing audit.

Requires Python 3.10+ and NumPy. The analysis is *not* Stata xtreg random effects.
Requires the author's original data.csv byte-identical to the stated Git blob.

Usage:
  python r047_replay.py --csv data.csv --output R047_REPLAY_OUTPUT.json
  python r047_replay.py --download --output R047_REPLAY_OUTPUT.json
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
from collections import Counter, defaultdict
from pathlib import Path
from urllib.request import urlopen

import numpy as np

REPOSITORY = 'lrdegeest/InequalityCPR'
SOURCE_URL = 'https://raw.githubusercontent.com/lrdegeest/InequalityCPR/master/data/data.csv'
GIT_BLOB_SHA1 = '73c02176bc9e060af987149594a85f9f7b591230'
NUM_SOURCE_ROWS = 2048
REFERENCE = {
    ('dev', 'dev', 'positive'): (451, (-0.781528, -0.122445, -0.063217)),
    ('dev', 'dev', 'negative'): (414, (-0.948363, -0.215243, -0.019401)),
    ('dev', 'lag_dev', 'positive'): (451, (0.921588, -0.033276, -0.038641)),
    ('dev', 'lag_dev', 'negative'): (414, (0.924367, 0.045809, 0.087930)),
    ('lag_dev', 'dev', 'positive'): (450, (-0.970237, 0.012548, 0.013925)),
    ('lag_dev', 'dev', 'negative'): (417, (-0.713965, -0.132913, -0.083045)),
    ('lag_dev', 'lag_dev', 'positive'): (450, (0.953291, -0.074466, 0.035830)),
    ('lag_dev', 'lag_dev', 'negative'): (417, (0.478391, -0.102326, -0.049463)),
}


def git_blob_sha1(content: bytes) -> str:
    """Compute git's blob identity, which differs from plain SHA1(content)."""
    prefix = f'blob {len(content)}\0'.encode('ascii')
    return hashlib.sha1(prefix + content).hexdigest()


def read_public_csv(content: bytes, strict: bool = True) -> list[dict]:
    if strict and git_blob_sha1(content) != GIT_BLOB_SHA1:
        raise ValueError('Git blob SHA mismatch. Source may have changed.')
    reader = csv.DictReader(io.StringIO(content.decode('utf-8-sig')))
    rows = []
    for r in reader:
        if len(rows) >= NUM_SOURCE_ROWS:
            break  # source Stata label script explicitly truncates to 2048 rows
        if not r.get('ProfileID'):
            raise ValueError('Unexpected blank row in the first 2048 source records')
        def number(name):
            v = r.get(name)
            return None if v is None or v.strip() in ('.', '') else float(v)
        rows.append({
            'subject': int(number('ProfileID')),
            'game': int(number('GameID')),
            'round': int(number('RoundID')),
            'invest': number('Invest'),
            'received': number('Received'),
            'session': int(number('Session')),
            'homo': int(number('Homo')),
            'ff': int(number('FF')),
            'token': int(number('Token')),
        })
    if strict and len(rows) != NUM_SOURCE_ROWS:
        raise ValueError(f'Unexpected source rows: {len(rows)}')
    return rows


def rebuild_transitions(rows: list[dict]) -> tuple[list[dict], list[dict]]:
    """Mirrors the source Stata script's practice-round removal and panel lag."""
    kept = []
    for record in rows:
        if record['ff'] != 1 or record['round'] <= 1:
            continue
        item = dict(record)
        item['period'] = record['round'] - 1
        item['group'] = 100 * record['homo'] + 10 * record['session'] + record['game']
        kept.append(item)

    by_cell = defaultdict(list)
    for r in kept:
        by_cell[r['group'], r['period']].append(r['invest'])
    if any(len(x) != 4 for x in by_cell.values()):
        raise ValueError('Each punishment group-period must have four observations')
    for r in kept:
        r['dev'] = (sum(by_cell[r['group'], r['period']]) / 4) - r['invest']

    by_subject = defaultdict(list)
    for r in kept:
        by_subject[r['subject']].append(r)

    transitions = []
    for subject, items in by_subject.items():
        items.sort(key=lambda r: r['period'])
        for prev, curr in zip(items, items[1:]):
            if curr['period'] != prev['period'] + 1:
                continue
            if prev['received'] is None:
                raise ValueError(f'Missing prior-round punishment for subject {subject}')
            t = dict(curr)
            t['lag_dev'] = prev['dev']
            t['lag_received'] = prev['received']
            t['y'] = curr['invest'] - prev['invest']
            transitions.append(t)
    return kept, transitions


def clustered_ols(rows: list[dict], dev_field: str) -> dict:
    """OLS with sandwich variance clustered by unique experiment group.

    Reproduces the R047 JS audit. SE correction is G/(G-1)*(N-1)/(N-K).
    Rows are not independent within groups. Treatment effects remain associational.
    """
    y = np.array([r['y'] for r in rows], dtype=float)
    X = np.array([
        [1.0, r[dev_field],
         r['lag_received'] if r['homo'] == 0 else 0.0,
         r['lag_received'] if r['homo'] == 1 else 0.0]
        for r in rows
    ], dtype=float)
    n, k = X.shape
    if np.linalg.matrix_rank(X) < k:
        raise ValueError('Design matrix lacks full rank')
    beta = np.linalg.solve(X.T @ X, X.T @ y)
    residual = y - X @ beta
    group_scores = defaultdict(lambda: np.zeros(k))
    for idx, r in enumerate(rows):
        group_scores[r['group']] += X[idx] * residual[idx]
    G = len(group_scores)
    if G < 2:
        raise ValueError('Too few distinct clusters')
    meat = sum((np.outer(score, score) for score in group_scores.values()), np.zeros((k, k)))
    bread = np.linalg.inv(X.T @ X)
    small_sample = (G / (G - 1)) * ((n - 1) / (n - k))
    covariance = small_sample * bread @ meat @ bread
    se = np.sqrt(np.maximum(np.diag(covariance), 0))
    delta = beta[3] - beta[2]  # equal minus unequal punishment slopes
    delta_se = math.sqrt(max(0, covariance[2, 2] + covariance[3, 3] - 2 * covariance[2, 3]))
    return {
        'n': n, 'clusters': G,
        'terms': ['intercept', 'deviation', 'punishment_unequal', 'punishment_equal'],
        'coefficient': [float(v) for v in beta],
        'group_clustered_se': [float(v) for v in se],
        'equal_minus_unequal': float(delta),
        'equal_minus_unequal_se': float(delta_se),
        'equal_minus_unequal_t': float(delta / delta_se) if delta_se > 0 else None,
        'inference_warning': 'No causal effect identification; 16 groups nested in 4 treatment-specific sessions.'
    }


def summarize(rows: list[dict], strict: bool = True) -> dict:
    kept, transitions = rebuild_transitions(rows)
    counts = Counter()
    sessions = defaultdict(lambda: {'subjects': set(), 'groups': set(), 'treatments': set()})
    for record in rows:
        s = sessions[record['session']]
        s['subjects'].add(record['subject'])
        s['groups'].add(record['game'])
        s['treatments'].add((record['homo'], record['ff']))
    for r in transitions:
        prior = 'below' if r['lag_dev'] > 0 else 'above' if r['lag_dev'] < 0 else 'tie'
        now = 'below' if r['dev'] > 0 else 'above' if r['dev'] < 0 else 'tie'
        counts[f'{prior}_to_{now}'] += 1
    changed = sum(np.sign(r['dev']) != np.sign(r['lag_dev']) for r in transitions)

    models = {}
    for split in ('dev', 'lag_dev'):
        for predictor in ('dev', 'lag_dev'):
            for side in ('positive', 'negative'):
                subset = [r for r in transitions if (r[split] > 0 if side == 'positive' else r[split] < 0)]
                result = clustered_ols(subset, predictor)
                models[f'{split}__{predictor}__{side}'] = result
                if strict:
                    expected_n, expected_beta = REFERENCE[(split, predictor, side)]
                    if result['n'] != expected_n or not np.allclose(result['coefficient'][1:], expected_beta, atol=1e-6, rtol=0):
                        raise ValueError(f'Regression golden check failed: {split} {predictor} {side}')

    above = [r for r in transitions if r['lag_dev'] < 0]
    groups = sorted({r['group'] for r in transitions})
    leave_group_out = {str(g): clustered_ols([r for r in above if r['group'] != g], 'lag_dev')['equal_minus_unequal'] for g in groups}
    if strict and (len(kept) != 960 or len(transitions) != 896 or changed != 315):
        raise ValueError('Golden sample-size/classification cross-check failed')
    return {
        'source': {'url': SOURCE_URL, 'git_blob_sha1': GIT_BLOB_SHA1},
        'status': 'direct CSV descriptive/OLS replay; Stata RE replication pending',
        'n_source': len(rows), 'n_punishment_after_practice': len(kept),
        'n_transitions': len(transitions), 'n_punishment_groups': len(groups),
        'n_classification_changes': int(changed),
        'classification_transitions': dict(sorted(counts.items())),
        'session_treatment_map': [
            {'session': session, 'subjects': len(d['subjects']), 'groups': len(d['groups']),
             'homo_ff': sorted([list(z) for z in d['treatments']])}
            for session, d in sorted(sessions.items())],
        'exploratory_ols': models,
        'leave_one_group_out_lagged_above': leave_group_out,
        'interpretation': 'Associations only. Confirm Stata random-effects and source-received corrections separately.'
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument('--csv', type=Path, help='Path to author-original data.csv')
    source.add_argument('--download', action='store_true', help='Explicitly fetch public source CSV')
    parser.add_argument('--output', type=Path, default=Path('R047_REPLAY_OUTPUT.json'))
    args = parser.parse_args()
    content = urlopen(SOURCE_URL, timeout=30).read() if args.download else args.csv.read_bytes()
    actual_sha = git_blob_sha1(content)
    if actual_sha != GIT_BLOB_SHA1:
        raise SystemExit(f'Source SHA mismatch: {actual_sha} expected {GIT_BLOB_SHA1}')
    summary = summarize(read_public_csv(content, strict=True), strict=True)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'PASS: 8 OLS specifications, {summary["n_transitions"]} transitions; output: {args.output}')


if __name__ == '__main__':
    main()
