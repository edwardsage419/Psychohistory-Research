#!/usr/bin/env python3
"""R022: group-level partial identification and selectivity audit.

Run offline:
  python r022_analysis.py --groups GROUP_COST_STATS.csv --out results/R022_RESULTS.json

Optional independently rerun from public original author CSV on a networked machine:
  python r022_analysis.py --fetch-original --out results/R022_RESULTS.json

This is NOT a causal mediation analysis. No person-level input is re-distributed.
"""
from __future__ import annotations
import argparse
import base64
import csv
import hashlib
import io
import json
import random
import urllib.request
from collections import Counter, defaultdict
from pathlib import Path

REPO = "tdienlin/persistence_and_anonymity"
BLOB_SHA = "62166267c925c2bc6b8f9f1b87db59c28868b262"
METRICS = {"neg": "c_negativejudgment", "attacks": "c_attacks", "diss": "c_dissolution", "zeroeffect": "c_zeroeffects"}
TOPICS = ("climate", "gender", "migration")
CELLS = (("high", "high"), ("low", "high"), ("high", "low"), ("low", "low"))


def git_blob_sha(data: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def fetch_original_blob() -> bytes:
    url = f"https://api.github.com/repos/{REPO}/git/blobs/{BLOB_SHA}"
    req = urllib.request.Request(url, headers={"Accept": "application/vnd.github+json", "User-Agent": "Psychohistory-R022/0.1"})
    with urllib.request.urlopen(req, timeout=40) as response:
        obj = json.loads(response.read())
    if obj["encoding"] != "base64":
        raise ValueError("Unexpected original blob encoding")
    body = base64.b64decode(obj["content"], validate=False)
    if git_blob_sha(body) != BLOB_SHA:
        raise ValueError("Original Git blob hash mismatch; stop instead of silently substituting")
    return body


def derive_groups(original: bytes) -> list[dict]:
    if git_blob_sha(original) != BLOB_SHA:
        raise ValueError("Source SHA does not match fixed original repository version")
    rows = csv.DictReader(io.StringIO(original.decode("utf-8-sig"), newline=""))
    grouped = {}
    for row in rows:
        gid = row["roles"]
        if gid not in grouped:
            g = {"id": gid, "topic": row["topic"], "anonymity": row["anonymity"],
                 "persistence": row["persistence"], "n": 0, "zeros": 0, "zeros_responded": 0}
            for m in METRICS:
                g[f"{m}_n"] = 0
                g[f"{m}_sum"] = 0.0
            grouped[gid] = g
        g = grouped[gid]
        if (g["topic"], g["anonymity"], g["persistence"]) != (row["topic"], row["anonymity"], row["persistence"]):
            raise ValueError(f"Group condition changed within {gid}")
        g["n"] += 1
        g["zeros"] += float(row["n_OE"]) == 0
        if float(row["n_OE"]) == 0 and row["c_negativejudgment"] not in ("NA", ""):
            g["zeros_responded"] += 1
        for key, col in METRICS.items():
            value = row[col]
            if value not in ("NA", ""):
                x = float(value)
                if not 1 <= x <= 5:
                    raise ValueError(f"{col} out of scale")
                g[f"{key}_n"] += 1
                g[f"{key}_sum"] += x
    return list(grouped.values())


def read_group_csv(path: Path) -> list[dict]:
    with path.open(encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    for g in rows:
        for field in ("n", "zeros", "zeros_responded", *(f"{m}_n" for m in METRICS)):
            g[field] = int(g[field])
        for field in (f"{m}_sum" for m in METRICS):
            g[field] = float(g[field])
    return rows


def validate_groups(gs, strict=True):
    if len(set(g["id"] for g in gs)) != len(gs):
        raise ValueError("Duplicate group label")
    if any(g["topic"] not in TOPICS or (g["anonymity"],g["persistence"]) not in CELLS for g in gs):
        raise ValueError("Unexpected group strata")
    for g in gs:
        n = g["n"]
        if n <= 0 or not 0 <= g["zeros"] <= n or not 0 <= g["zeros_responded"] <= min(g["zeros"],g["neg_n"]):
            raise ValueError("Invalid participant or zero-expression count")
        for m in METRICS:
            m_n = g[m+"_n"]
            if not 0 <= m_n <= n or not m_n-1e-4 <= g[m+"_sum"] <= 5*m_n+1e-4:
                raise ValueError("Invalid response count or score bounds")
    if strict:
        if len(gs) != 48 or sum(g["n"] for g in gs) != 960 or sum(g["zeros"] for g in gs) != 205:
            raise ValueError("Unexpected original experimental design")
        if any(g["n"] != 20 for g in gs):
            raise ValueError("Groups are not of equal size 20")
        ctr = Counter((g["topic"],g["anonymity"],g["persistence"]) for g in gs)
        if len(ctr) != 12 or any(v != 4 for v in ctr.values()):
            raise ValueError("Unexpected 3 topic x 4 conditions x 4 group layout")
        if sum(g["zeros_responded"] for g in gs) != 58:
            raise ValueError("Real data response-by-silence cross-tab mismatch")
        if any(sum(g[m+"_n"] for g in gs) != 705 for m in METRICS):
            raise ValueError("Not 705 observed scale respondents for all four measures")
    return True


def cell_summary(gs, m):
    bycell = {}
    for a, p in CELLS:
        sub = [g for g in gs if g["anonymity"] == a and g["persistence"] == p]
        n = sum(g["n"] for g in sub)
        obs = sum(g[m+"_n"] for g in sub)
        total = sum(g[m+"_sum"] for g in sub)
        if not n or not obs:
            raise ValueError("Empty randomized treatment cell or all responses missing")
        missing = n - obs
        bycell[f"{a}|{p}"] = {
            "assigned": n, "observed": obs, "missing": missing,
            "observed_mean": total / obs,
            "mean_lower_without_missing_assumption": (total+missing)/n,
            "mean_upper_without_missing_assumption": (total+5*missing)/n,
            "observed_score_sum": total,
        }
    return bycell


def effect(means):
    return (means["high|high"] - means["low|high"] +
            means["high|low"] - means["low|low"])/2


def effect_and_bounds(gs, m):
    cells = cell_summary(gs, m)
    ob = effect({k:v["observed_mean"] for k,v in cells.items()})
    # Sharp all-assigned bounds on differences of bounded means, holding the observed values fixed.
    lower = (cells["high|high"]["mean_lower_without_missing_assumption"] -
             cells["low|high"]["mean_upper_without_missing_assumption"] +
             cells["high|low"]["mean_lower_without_missing_assumption"] -
             cells["low|low"]["mean_upper_without_missing_assumption"])/2
    upper = (cells["high|high"]["mean_upper_without_missing_assumption"] -
             cells["low|high"]["mean_lower_without_missing_assumption"] +
             cells["high|low"]["mean_upper_without_missing_assumption"] -
             cells["low|low"]["mean_lower_without_missing_assumption"])/2
    return {"respondents_effect": ob, "missingness_bound": [lower, upper], "cells": cells}


def stratified_group_bootstrap(gs, B=5000, seed=20261014):
    rng=random.Random(seed)
    subsets = [[g for g in gs if g["topic"]==t and g["anonymity"]==a and g["persistence"]==p]
               for t in TOPICS for a,p in CELLS]
    if any(len(s)!=4 for s in subsets):
        raise ValueError("Requires four independent discussion clusters within each topic x condition")
    measures=list(METRICS)
    samples={m: [] for m in measures}
    samples["negative_judgment_minus_time_cost"] = []
    for _ in range(B):
        draw=[s[rng.randrange(len(s))] for s in subsets for _i in range(len(s))]
        e={m: effect_and_bounds(draw,m)["respondents_effect"] for m in measures}
        for m in measures: samples[m].append(e[m])
        samples["negative_judgment_minus_time_cost"].append(e["neg"]-e["zeroeffect"])
    return {k: [sorted(x)[int(.025*B)], sorted(x)[min(B-1,int(.975*B))]]
            for k,x in samples.items()}


def full_sample_tipping_point(high_obs_sum=563.5, low_obs_sum=711.75,
                               high_missing=133, low_missing=122, low_missing_mean=2.0):
    # Both anonymization margins have 480 originally randomized persons (balanced persistence).
    return (low_obs_sum-high_obs_sum + low_missing*low_missing_mean)/high_missing


def produce(gs,B=5000,seed=20261014):
    validate_groups(gs)
    effects={m:effect_and_bounds(gs,m) for m in METRICS}
    b=stratified_group_bootstrap(gs,B,seed)
    zero_total=sum(x["zeros"] for x in gs)
    count=sum(x["n"] for x in gs)
    outcome={
      "status":"REAL_SOURCE_CONNECTOR_AGGREGATES_OFFLINE_REANALYSIS",
      "source":{"repo":f"https://github.com/{REPO}","file":"data/data.csv","git_blob_sha1":BLOB_SHA,
                "original_person_rows_in_connector":960,"independent_groups":48,"local_original_csv_reexecution":False},
      "design":{"total":count,"zero_expression":zero_total,"questionnaire_respondents":sum(g["neg_n"] for g in gs),"missing":count-sum(g["neg_n"] for g in gs)},
      "metrics":effects,
      "bootstrap":{"stratification":"topic x randomized cell; resample groups of 20","draws":B,"seed":seed,
                   "approximate_percentile_95_intervals":b,
                   "warning":"Responder-only condition effects; does not fix missingness or prove network randomization protocol"},
      "specificity_contrast_respondents":effects["neg"]["respondents_effect"]-effects["zeroeffect"]["respondents_effect"],
      "selection_table_from_real_group_stats":{
        "no_expression":{"responded":sum(g["zeros_responded"] for g in gs),
                         "missing":sum(g["zeros"]-g["zeros_responded"] for g in gs)},
        "some_expression":{"responded":sum(g["neg_n"]-g["zeros_responded"] for g in gs),
                           "missing":sum(g["n"]-g["zeros"]-g["neg_n"]+g["zeros_responded"] for g in gs)},
      },
      "tipping_point":{"low_anonymity_missing_mean_assumed":2.0,
                       "high_anonymity_missing_mean_for_zero_itt":full_sample_tipping_point(),
                       "warning":"Diagnostic hypothetical values, not estimated unobserved scores"},
    }
    return outcome


def main():
    arg=argparse.ArgumentParser(description=__doc__)
    arg.add_argument("--groups",type=Path,default=Path(__file__).with_name("GROUP_COST_STATS.csv"))
    arg.add_argument("--fetch-original",action="store_true",help="Download and hash-check the author Git blob directly; internet needed")
    arg.add_argument("--bootstrap",type=int,default=5000)
    arg.add_argument("--seed",type=int,default=20261014)
    arg.add_argument("--out",type=Path,default=Path(__file__).parent/"results"/"R022_RESULTS.json")
    args=arg.parse_args()
    if args.fetch_original:
        gs=derive_groups(fetch_original_blob())
        # Independently confirm connector-derived group statistics, tolerate six-decimal rounding.
        existing={g["id"]:g for g in read_group_csv(args.groups)}
        for g in gs:
            h=existing[g["id"]]
            for m in METRICS:
                if g[m+"_n"]!=h[m+"_n"] or abs(g[m+"_sum"]-h[m+"_sum"])>2e-6 or g["zeros_responded"]!=h["zeros_responded"]:
                    raise ValueError(f"Public group summary differs from source: {g['id']} {m}")
    else:
        gs=read_group_csv(args.groups)
    out=produce(gs,args.bootstrap,args.seed)
    out["source"]["local_original_csv_reexecution"]=args.fetch_original
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(out,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(f"R022 groups={len(gs)}, participants={sum(x['n'] for x in gs)}, results={args.out}")

if __name__=="__main__":main()
