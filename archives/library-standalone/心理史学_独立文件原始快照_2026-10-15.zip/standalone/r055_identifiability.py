#!/usr/bin/env python3
"""R055: auditable session-level treatment/identifiability examination.

No external dependency. The default input is a *real-source-derived* aggregate file,
not independently obtained local original CSV bytes. Optional --raw-csv requires
an exact Git blob hash and confirms the derived session aggregates before analysis.
This is exploratory evidence. Permutation frequencies are conditional reference
calculations; not design-valid randomization p-values without verified allocation.
"""
from __future__ import annotations

import argparse
import csv
from fractions import Fraction
import hashlib
import itertools
import json
from pathlib import Path

EXPECTED_BLOB = '73c02176bc9e060af987149594a85f9f7b591230'
PAIR_CELL_COUNT = 2


def source_blob_sha(raw: bytes) -> str:
    return hashlib.sha1(b'blob ' + str(len(raw)).encode('ascii') + b'\0' + raw).hexdigest()


def validate_sessions(sessions: list[dict]) -> None:
    if len(sessions) != 8 or {s['session'] for s in sessions} != set(range(1, 9)):
        raise ValueError('Expected exactly 8 unique session IDs, 1..8')
    cell_sizes: dict[tuple[int, int], int] = {}
    for s in sessions:
        h, f = s['homo'], s['ff']
        if h not in (0, 1) or f not in (0, 1):
            raise ValueError('Invalid treatment labels')
        if (s['n'], s['subjects'], s['groups']) != (240, 16, 4):
            raise ValueError('Incorrect subject/session count')
        expected = {'50': 240} if h == 1 else {'40': 120, '60': 120}
        if set(s['by_token']) != set(expected):
            raise ValueError('Treatment-specific endowment counts mismatch')
        for token, n in expected.items():
            d = s['by_token'][token]
            if d['n'] != n or not isinstance(d['sumInvest'], int):
                raise ValueError('Token count or extraction total mismatch')
            if not 0 <= d['sumInvest'] <= n * int(token):
                raise ValueError('Impossible extraction total')
        cell_sizes[h, f] = cell_sizes.get((h, f), 0) + 1
    if set(cell_sizes.values()) != {PAIR_CELL_COUNT} or len(cell_sizes) != 4:
        raise ValueError('Expected 2 sessions per 2x2 design cell')


def mean_fraction(s: dict) -> Fraction:
    total = sum((Fraction(row['sumInvest'], int(token))
                 for token, row in s['by_token'].items()), Fraction())
    return total / s['n']


def source_summary_from_csv(path: Path) -> list[dict]:
    raw = path.read_bytes()
    if source_blob_sha(raw) != EXPECTED_BLOB:
        raise ValueError('Source Git blob hash mismatch: raw file not authenticated')
    from io import StringIO
    reader = csv.DictReader(StringIO(raw.decode('utf-8-sig')))
    recs = []
    for row in reader:
        if not row.get('ProfileID'):
            continue
        recs.append(row)
    if len(recs) != 2048:
        raise ValueError('Expected 2048 real raw participant-round rows')
    accum: dict[int, dict] = {}
    trackers: dict[int, tuple[set, set]] = {}
    for row in recs:
        if int(row['RoundID']) == 1:
            continue
        session = int(row['Session'])
        homo, ff = int(row['Homo']), int(row['FF'])
        subject = int(row['ProfileID'])
        group = int(row['GameID'])
        token = int(row['Token'])
        invest = int(row['Invest'])
        current = accum.setdefault(session, dict(session=session, homo=homo,
                                                  ff=ff, n=0, subjects=16,
                                                  groups=4, by_token={}))
        if (current['homo'], current['ff']) != (homo, ff):
            raise ValueError('Mixed treatment conditions within session')
        current['n'] += 1
        d = current['by_token'].setdefault(str(token), {'n': 0, 'sumInvest': 0})
        d['n'] += 1
        d['sumInvest'] += invest
        a, b = trackers.setdefault(session, (set(), set()))
        a.add(subject)
        b.add(group)
    sessions = list(sorted(accum.values(), key=lambda x: x['session']))
    for s in sessions:
        a, b = trackers[s['session']]
        s['subjects'], s['groups'] = len(a), len(b)
    validate_sessions(sessions)
    return sessions


def load_summary(path: Path, raw_csv: Path | None = None) -> tuple[list[dict], str]:
    obj = json.loads(path.read_text(encoding='utf-8'))
    if obj['provenance']['source_git_blob_sha1'] != EXPECTED_BLOB:
        raise ValueError('Aggregate source Git blob record mismatch')
    sessions = obj['sessions']
    validate_sessions(sessions)
    if raw_csv is None:
        return sessions, 'real_source_derived_connector_aggregates_only'
    recon = source_summary_from_csv(raw_csv)
    if recon != sessions:
        raise ValueError('Local source rows do not reproduce frozen aggregates')
    return sessions, 'source_raw_bytes_authenticated_locally'


def estimands(sessions: list[dict], labels: dict[int, tuple[int, int]]) -> dict:
    buckets = {(h, f): [] for h in (0, 1) for f in (0, 1)}
    for s in sessions:
        buckets[labels[s['session']]].append(mean_fraction(s))
    if any(len(v) != 2 for v in buckets.values()):
        raise ValueError('Unbalanced labels')
    means = {k: sum(v, Fraction()) / 2 for k, v in buckets.items()}
    f_effect = (means[0, 1] + means[1, 1] - means[0, 0] - means[1, 0]) / 2
    h_effect = (means[1, 0] + means[1, 1] - means[0, 0] - means[0, 1]) / 2
    interaction = means[1, 1] - means[1, 0] - means[0, 1] + means[0, 0]
    return {'cell_means': means, 'punishment': f_effect,
            'homo': h_effect, 'interaction': interaction}


def label_assignments(sessions: list[dict], stratified: bool):
    ids = [s['session'] for s in sessions]
    if stratified:
        for h in (0, 1):
            if sum(s['homo'] == h for s in sessions) != 4:
                raise ValueError('Expected four sessions in each Homo stratum')
        strata = [[s['session'] for s in sessions if s['homo'] == h] for h in (0, 1)]
        for a in itertools.combinations(strata[0], 2):
            for b in itertools.combinations(strata[1], 2):
                punished = set(a + b)
                yield {s['session']: (s['homo'], int(s['session'] in punished))
                       for s in sessions}
        return
    for cell00 in itertools.combinations(ids, 2):
        rem = [x for x in ids if x not in cell00]
        for cell01 in itertools.combinations(rem, 2):
            rem2 = [x for x in rem if x not in cell01]
            for cell10 in itertools.combinations(rem2, 2):
                cell11 = [x for x in rem2 if x not in cell10]
                assignment = {}
                for pair, cond in [(cell00, (0, 0)), (cell01, (0, 1)),
                                   (cell10, (1, 0)), (cell11, (1, 1))]:
                    assignment.update({x: cond for x in pair})
                yield assignment


def reference_count(sessions: list[dict], target: Fraction, key: str,
                    stratified: bool) -> tuple[int, int]:
    extreme = n = 0
    for assignment in label_assignments(sessions, stratified):
        n += 1
        val = estimands(sessions, assignment)[key]
        extreme += int(abs(val) >= abs(target))
    return extreme, n


def matrix_rank(mat: list[list[Fraction]]) -> int:
    a = [row[:] for row in mat]
    n, p = len(a), len(a[0])
    rank = 0
    for j in range(p):
        pivot = next((i for i in range(rank, n) if a[i][j]), None)
        if pivot is None:
            continue
        a[pivot], a[rank] = a[rank], a[pivot]
        scale = a[rank][j]
        a[rank] = [x / scale for x in a[rank]]
        for i in range(n):
            if i != rank and a[i][j]:
                mult = a[i][j]
                a[i] = [x - mult * y for x, y in zip(a[i], a[rank])]
        rank += 1
        if rank == n:
            break
    return rank


def analyze(sessions: list[dict], provenance: str) -> dict:
    sessions = sorted(sessions, key=lambda s: s['session'])
    original = {s['session']: (s['homo'], s['ff']) for s in sessions}
    obs = estimands(sessions, original)
    x = [[Fraction(int(i == j)) for j in range(8)] +
         [Fraction(s['homo']), Fraction(s['ff']), Fraction(s['homo'] * s['ff'])]
         for i, s in enumerate(sessions)]
    rank_fe = matrix_rank(x)
    assert rank_fe == 8 and matrix_rank([row[8:] for row in x]) == 3
    label_stats = {}
    for method in ('stratified', 'unrestricted'):
        c = {}
        for key in ('punishment', 'interaction'):
            k, n = reference_count(sessions, obs[key], key,
                                   stratified=method == 'stratified')
            c[key] = {'extreme': k, 'assignments': n, 'reference_fraction': k / n}
        label_stats[method] = c
    means = {f'h{h}_f{f}': float(val) for (h, f), val in obs['cell_means'].items()}
    return {
        'provenance_level': provenance,
        'new_independent_study': False,
        'outcome': 'subject Invest / assigned Token, averaged within session over 15 non-practice rounds',
        'session_summary': [{
            'session': s['session'], 'homo': s['homo'], 'ff': s['ff'],
            'n': s['n'], 'fraction': float(mean_fraction(s))
        } for s in sessions],
        'observed': {'cell_means': means,
                     'punishment_difference': float(obs['punishment']),
                     'homo_difference': float(obs['homo']),
                     'factorial_interaction': float(obs['interaction'])},
        'fixed_effect_rank': {'n_rows': 8, 'n_columns': 11, 'rank': rank_fe,
                              'added_treatment_columns': 3,
                              'additional_rank_from_treatment_columns': 0},
        'reference_enumeration': label_stats,
        'observational_equivalence_example': {
            'case_A': 'punishment coefficient = 0; session intercept equals observed session mean',
            'case_B': 'punishment coefficient equals the observed pooled difference; session intercept adjusts by minus that coefficient times FF',
            'max_prediction_difference': float(max(abs((mean_fraction(s)) -
                (mean_fraction(s) - obs['punishment'] * s['ff'] +
                 obs['punishment'] * s['ff'])) for s in sessions))
        },
        'illustrative_session_shock_sensitivity': [
            {'hypothetical_shock_difference': d,
             'implied_punishment_effect': float(obs['punishment']) - d}
            for d in [-0.07, -0.04, 0, 0.04, 0.07]
        ],
        'causal_identification_status': 'UNIDENTIFIED_UNDER_ARBITRARY_SESSION_FIXED_EFFECTS',
        'reference_warning': 'These assignment frequencies have no inferential validity until actual session-level randomization scheme and exchangeability are independently verified.'
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--summary', type=Path, default=Path(__file__).with_name('R055_SESSION_AGGREGATES.json'))
    parser.add_argument('--raw-csv', type=Path, help='Optional exact-author original byte file for local authentication')
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    sessions, provenance = load_summary(args.summary, args.raw_csv)
    output = json.dumps(analyze(sessions, provenance), ensure_ascii=False, indent=2) + '\n'
    if args.out:
        args.out.write_text(output, encoding='utf-8')
    else:
        print(output, end='')


if __name__ == '__main__':
    main()
