#!/usr/bin/env python3
"""R008 real-data sensitivity reanalysis; Python >= 3.10, standard library.

The original dataset remains with its authors; download explicitly when online.
Methods here are descriptive. Bootstrap/randomization inference are not asserted.
"""
from __future__ import annotations
import argparse
import csv
import json
import math
from collections import defaultdict
from pathlib import Path
from statistics import mean, median, stdev
from r007_analysis import read_records, fetch_public_dataset


def valid_number(x: str) -> bool:
    try:
        y = float(x)
        return math.isfinite(y) and y > 0
    except (TypeError, ValueError):
        return False


def valid(row: dict[str, str], trim: bool = False) -> bool:
    if row.get('experiment') != '1' or not valid_number(row.get('truth')):
        return False
    if not all(valid_number(row.get(f'response_{i}')) for i in (1, 2, 3)):
        return False
    return (not trim) or all(float(row[f'response_{i}']) <= 10 * float(row['truth']) for i in (1, 2, 3))


def avg(seq):
    return mean(seq)


def question_metrics(rows: list[dict[str,str]]) -> dict:
    t = math.log(float(rows[0]['truth']))
    vals = [[math.log(float(r[f'response_{i}'])) for r in rows] for i in (1,2,3)]
    outputs = {}
    for round_, v in ((1, vals[0]), (3, vals[2])):
        outputs[f'grp{round_}'] = abs(mean(v) - t)
        outputs[f'ind{round_}'] = mean(abs(x-t) for x in v)
        outputs[f'sd{round_}'] = stdev(v) if len(v) >= 2 else 0.0
        outputs[f'med{round_}'] = abs(median(v) - t)
    return outputs


def assess_missingness(records: list[dict]) -> dict:
    out = {}
    for condition in ('Social','Control'):
        rs = [r for r in records if r.get('experiment') == '1' and r.get('network') == condition]
        good = [r for r in rs if valid(r)]
        excluded = [r for r in rs if not valid(r)]
        def initial_error(v):
            return mean(abs(math.log(float(r['response_1']))-math.log(float(r['truth']))) for r in v) if v else None
        excluded_with_initial = [r for r in excluded if valid_number(r.get('response_1')) and valid_number(r.get('truth'))]
        out[condition] = {
            'raw': len(rs), 'retained': len(good), 'excluded': len(excluded),
            'retention': len(good) / len(rs) if rs else None,
            'invalid_by_round': {str(j):sum(not valid_number(r.get(f'response_{j}')) for r in rs) for j in (1,2,3)},
            'individual_initial_log_error_complete': initial_error(good),
            'individual_initial_log_error_excluded_with_valid_first': initial_error(excluded_with_initial),
            'excluded_with_valid_first_count': len(excluded_with_initial),
        }
    return out


def analyze(records: list[dict[str,str]], trim: bool = False) -> dict:
    selected = [r for r in records if valid(r, trim)]
    questions = defaultdict(list)
    for r in selected:
        key = (r['party'], r['set'], r['pair_id'], r['network'], r['q'])
        questions[key].append(r)
    trials = defaultdict(list)
    qs = []
    for (party, set_, pair, network, q), rows in questions.items():
        d = question_metrics(rows)
        trials[(party,set_,pair,network)].append((q,d,len(rows)))
        qs.append({'party':party,'set':set_,'pair':pair,'network':network,'q':q,'n':len(rows),**d})
    trial_rows = []
    for (party,set_,pair,network), items in trials.items():
        if len(items) != 4:
            raise ValueError('Expected four distinct questions per trial')
        x = {'party':party,'set':set_,'pair':pair,'network':network,'n':sum(i[2] for i in items)}
        for metric in ('grp','ind','sd','med'):
            for round_ in (1,3):
                x[f'{metric}{round_}'] = mean(z[1][f'{metric}{round_}'] for z in items)
            x[f'{metric}delta'] = x[f'{metric}3'] - x[f'{metric}1']
        trial_rows.append(x)
    out = {'rows_retained':len(selected),'question_groups':len(qs),'trial_count':len(trial_rows),'metrics':{},'by_question':{}}
    for metric in ('grp','ind','sd','med'):
        d = {}
        for condition in ('Social','Control'):
            tt = [r for r in trial_rows if r['network'] == condition]
            d[condition] = {'trials':len(tt), 'first':mean(x[f'{metric}1'] for x in tt),
                            'third':mean(x[f'{metric}3'] for x in tt),
                            'delta':mean(x[f'{metric}delta'] for x in tt)}
        blocks = []
        for party in ('Dem','Repub'):
            for set_ in ('A','B','C','D'):
                a = [r for r in trial_rows if r['party']==party and r['set']==set_]
                s = [r[f'{metric}delta'] for r in a if r['network']=='Social']
                c = [r[f'{metric}delta'] for r in a if r['network']=='Control']
                if len(s)!=3 or len(c)!=1:raise ValueError(f'Expected 3 social and 1 control in stratum {party} {set_}')
                blocks.append({'stratum':party+'|'+set_, 'difference':mean(s)-c[0]})
        estimate = mean(x['difference'] for x in blocks)
        d['contrast'] = estimate
        d['stratum_differences'] = blocks
        d['leave_one_stratum_out'] = {b['stratum']:(8*estimate-b['difference'])/7 for b in blocks}
        out['metrics'][metric] = d
    for q in sorted(set(x['q'] for x in qs)):
        d = {'q':q}
        for cond in ('Social','Control'):
            a = [r for r in qs if r['q']==q and r['network']==cond]
            d[cond] = mean(r['grp3']-r['grp1'] for r in a)
        d['contrast'] = d['Social']-d['Control']
        out['by_question'][q] = d
    return out


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--data',type=Path,default=Path('original_data.csv'))
    p.add_argument('--download',action='store_true')
    p.add_argument('--out',type=Path,default=Path('results'))
    args=p.parse_args()
    if args.download:fetch_public_dataset(args.data)
    if not args.data.exists():p.error('Provide --data or --download on a network-connected machine')
    rows,sha=read_records(args.data)
    out={'id':'R008','source_git_blob_sha':sha,'source_rows':len(rows),
         'complete_case_missingness':assess_missingness(rows),
         'main':analyze(rows),'sensitivity_10x_truth':analyze(rows,True),
         'status':'descriptive reanalysis; causal mechanism identification and author inferential replication not claimed'}
    args.out.mkdir(parents=True,exist_ok=True)
    (args.out/'r008_full_result.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'rows':len(rows),'main_retained':out['main']['rows_retained'],
                      'group_error_contrast':out['main']['metrics']['grp']['contrast'],
                      'individual_error_contrast':out['main']['metrics']['ind']['contrast'],
                      'sd_contrast':out['main']['metrics']['sd']['contrast']},indent=2))

if __name__=='__main__':main()
