#!/usr/bin/env python3
"""R052: source-gated observational analysis of two-player repeated games.

Uses only Python standard library. Does not download source data. Canonical input
requires an independently reviewed column map and explicit local provenance.
No model result is advertised as external validation without original source bytes.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import json
import math
from pathlib import Path
from typing import Any

CANONICAL = (
    "session", "subject", "game", "round", "partner", "cooperation",
    "partner_cooperation", "received_punishment", "gave_punishment",
    "opted_out", "partner_opted_out", "role", "game_type",
)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(65536), b""):
            h.update(block)
    return h.hexdigest()


def binary(value: Any, name: str) -> int:
    if str(value).strip() not in {"0", "1"}:
        raise ValueError(f"{name} must be encoded as 0 or 1")
    return int(value)


def row_to_canonical(row: dict[str, str], mapping: dict[str, str]) -> dict[str, Any]:
    if set(mapping) != set(CANONICAL) or len(set(mapping.values())) != len(CANONICAL):
        raise ValueError("schema must map every canonical column one-to-one")
    if not set(mapping.values()).issubset(row):
        raise ValueError("schema fields are missing from input CSV")
    parsed = {key: row[source] for key, source in mapping.items()}
    for field in ("session", "subject", "game", "round", "partner"):
        value = str(parsed[field]).strip()
        if not value:
            raise ValueError(f"missing {field}")
        parsed[field] = value
    round_id = int(parsed["round"])
    if not 1 <= round_id <= 50:
        raise ValueError("round must be between 1 and 50")
    parsed["round"] = round_id
    for field in ("opted_out", "partner_opted_out"):
        parsed[field] = binary(parsed[field], field)
    inactive = bool(parsed["opted_out"] or parsed["partner_opted_out"])
    for field in ("cooperation", "partner_cooperation"):
        raw = parsed[field]
        if str(raw).strip() == "" and inactive:
            parsed[field] = None
            continue
        parsed[field] = float(raw)
        if not math.isfinite(parsed[field]) or not 0 <= parsed[field] <= 5:
            raise ValueError(f"{field} must lie in [0,5]")
    for field in ("received_punishment", "gave_punishment"):
        raw = str(parsed[field]).strip()
        if raw == "" and inactive:
            parsed[field] = None
            continue
        parsed[field] = binary(raw, field)
    if parsed["role"] not in {"strong", "weak"}:
        raise ValueError("role must be strong or weak")
    if parsed["game_type"] not in {"symmetric", "asymmetric"}:
        raise ValueError("game_type must be symmetric or asymmetric")
    if parsed["subject"] == parsed["partner"]:
        raise ValueError("a player cannot be its own partner")
    return parsed


def validate_panel(rows: list[dict[str, Any]]) -> dict[str, Any]:
    """Validate recorded observations and boundary keys; no imputation."""
    if not rows:
        raise ValueError("empty dataset")
    keys: set[tuple] = set()
    groups: dict[tuple, list[dict]] = defaultdict(list)
    players: dict[tuple, list[dict]] = defaultdict(list)
    for r in rows:
        key = (r["session"], r["subject"], r["game"], r["round"])
        if key in keys:
            raise ValueError(f"duplicate individual game round {key}")
        keys.add(key)
        groups[(r["session"], r["game"], r["round"])].append(r)
        players[(r["session"], r["subject"], r["game"])].append(r)
        if r["round"] < 1 or r["round"] > 50:
            raise ValueError("invalid period")
        if r["subject"] == r["partner"]:
            raise ValueError("self partnership")
    # If both views of a dyadic interaction are present, require reciprocity.
    for r in rows:
        opposite_key = (r["session"], r["partner"], r["game"], r["round"])
        if opposite_key in keys:
            other = next((x for x in groups[(r["session"], r["game"], r["round"])]
                          if x["subject"] == r["partner"]), None)
            if other is None or other["partner"] != r["subject"]:
                raise ValueError("invalid reciprocal partnership")
            if not (r["opted_out"] or r["partner_opted_out"] or
                    other["opted_out"] or other["partner_opted_out"]):
                if abs(r["cooperation"] - other["partner_cooperation"]) > 1e-8:
                    raise ValueError("asymmetric partner cooperation mismatch")
    return {
        "rows": len(rows),
        "sessions": len({r["session"] for r in rows}),
        "players": len({(r["session"], r["subject"]) for r in rows}),
        "subject_games": len(players),
        "observed_rounds": len(groups),
        "full_120x2x50_panel": (len(rows) == 12000 and len(players) == 240),
    }


def build_transitions(rows: list[dict[str, Any]]) -> tuple[list[dict], Counter]:
    """Construct n -> n+1 eligibility from pre-action information only.

    Player must have invested less than their partner in round n and neither
    partner may opt out in either round. Current round partner exact amount is
    never used as a predictor. Groups are never connected across a new game.
    """
    people: dict[tuple, list[dict]] = defaultdict(list)
    for r in rows:
        people[(r["session"], r["subject"], r["game"])].append(r)
    events, rejected = [], Counter()
    for key, rs in people.items():
        ordered = sorted(rs, key=lambda r: r["round"])
        for previous, current in zip(ordered, ordered[1:]):
            if current["round"] != previous["round"] + 1:
                rejected["missing_consecutive_round"] += 1
                continue
            if previous["partner"] != current["partner"]:
                rejected["partner_change_within_game"] += 1
                continue
            if (previous["opted_out"] or previous["partner_opted_out"] or
                current["opted_out"] or current["partner_opted_out"]):
                rejected["opt_out_n_or_n_plus_1"] += 1
                continue
            if previous["cooperation"] is None or current["cooperation"] is None:
                raise ValueError("non-exit decision has missing cooperation")
            if previous["partner_cooperation"] is None:
                raise ValueError("non-exit decision has missing partner cooperation")
            if previous["cooperation"] >= previous["partner_cooperation"]:
                rejected["not_lower_cooperator_in_n"] += 1
                continue
            if previous["received_punishment"] is None:
                raise ValueError("non-exit decision has missing previous punishment")
            events.append({
                "session": previous["session"], "subject": previous["subject"],
                "game": previous["game"], "round_n": previous["round"],
                "role": previous["role"], "game_type": previous["game_type"],
                "cooperation_n": previous["cooperation"],
                "received_punishment_n": previous["received_punishment"],
                "increased_next_round": int(current["cooperation"] > previous["cooperation"]),
            })
    return events, rejected


def p_smoothed(table: Counter, key: tuple, base: float, alpha: float = 8) -> float:
    if alpha <= 0:
        raise ValueError("alpha must be > 0")
    positive, count = table.get(("y", key), 0), table.get(("n", key), 0)
    return (positive + alpha * base) / (count + alpha)


def evaluate_leave_one_session_out(events: list[dict], *, alpha: float = 8) -> dict:
    """Exploratory predictive performance, with session entirely held out.

    Inputs are known before choice at n+1. Separate game type, role and prior
    punishment. Never use current outcome to define prediction covariates.
    """
    sessions = sorted({r["session"] for r in events})
    if len(sessions) < 2:
        raise ValueError("at least two sessions are required for held-out evaluation")
    definitions = {
        "M0_pooled": (),
        "M1_role_game": ("role", "game_type"),
        "M2_add_received_punishment": ("role", "game_type", "received_punishment_n"),
        "M3_add_prior_cooperation": ("role", "game_type", "received_punishment_n", "cooperation_n"),
    }
    metrics: dict = {}
    for withheld in sessions:
        train = [x for x in events if x["session"] != withheld]
        test = [x for x in events if x["session"] == withheld]
        if not train or not test:
            raise ValueError("empty training or test fold")
        pooled = (sum(x["increased_next_round"] for x in train) + alpha * .5) / (len(train) + alpha)
        result = {"n_test": len(test), "empirical_rate": sum(x["increased_next_round"] for x in test) / len(test)}
        for model, fields in definitions.items():
            table: Counter = Counter()
            for o in train:
                k = tuple(o[c] for c in fields)
                table[("n", k)] += 1
                table[("y", k)] += o["increased_next_round"]
            losses = []
            for o in test:
                key = tuple(o[c] for c in fields)
                prob = p_smoothed(table, key, pooled, alpha)
                y = o["increased_next_round"]
                losses.append((-(y * math.log(prob) + (1-y) * math.log1p(-prob)), (y-prob)**2))
            result[model] = {
                "logloss": sum(x[0] for x in losses) / len(losses),
                "brier": sum(x[1] for x in losses) / len(losses),
            }
        metrics[withheld] = result
    return {"evidence": "exploratory_observational_holdout", "alpha": alpha, "by_session": metrics}


def worst_case_missing_bounds(n0: int, observed0: int, positive0: int,
                              n1: int, observed1: int, positive1: int) -> dict:
    """Sharp binary-outcome bounds for unobserved potential outcomes.

    Descriptive association only; these are NOT causal ATE bounds when
    receiving punishment was self-selected. Outcomes after withdrawal must be
    explicitly defined hypothetically for these bounds to have an estimand.
    """
    for n, obs, pos in ((n0, observed0, positive0), (n1, observed1, positive1)):
        if not isinstance(n, int) or not isinstance(obs, int) or not isinstance(pos, int):
            raise ValueError("counts must be integers")
        if not 0 <= pos <= obs <= n or n == 0:
            raise ValueError("invalid missingness table")
    bounds0 = (positive0/n0, (positive0+n0-observed0)/n0)
    bounds1 = (positive1/n1, (positive1+n1-observed1)/n1)
    return {
        "group_0": bounds0, "group_1": bounds1,
        "contrast_min": bounds1[0]-bounds0[1],
        "contrast_max": bounds1[1]-bounds0[0],
        "type": "binary_missing_outcome_descriptive_bounds_not_causal",
    }


def deterministic_colliding_selection() -> dict:
    """Constructed counterexample: equal true outcomes, 3% missing per arm."""
    # x=0: Y=0 all observed; Y=1 94% observed.
    # x=1: Y=0 94% observed; Y=1 all observed.
    n0 = n1 = 20000
    observed0 = observed1 = 19400
    positive0, positive1 = 9400, 10000
    b = worst_case_missing_bounds(n0, observed0, positive0, n1, observed1, positive1)
    return {
        "source": "synthetic_construction_not_human_data",
        "N": n0 + n1,
        "missing_fraction": (n0+n1-observed0-observed1)/(n0+n1),
        "true_y_rate_each_arm": .5,
        "observed_y_rate_unexposed": positive0/observed0,
        "observed_y_rate_exposed": positive1/observed1,
        "spurious_observed_difference": positive1/observed1-positive0/observed0,
        "sharp_bounds": b,
    }


def run_cli() -> None:
    a = argparse.ArgumentParser(description="R052: source-gated temporal and selection audit")
    a.add_argument("--null-example", action="store_true", help="print the synthetic censoring example")
    a.add_argument("--source-csv", type=Path)
    a.add_argument("--schema-map", type=Path, help="explicit mapping from canonical names to publisher CSV headers")
    a.add_argument("--expected-sha256", help="externally recorded exact SHA256; self-reported digest is not independent provenance")
    a.add_argument("--output", type=Path)
    ns = a.parse_args()
    if ns.null_example:
        print(json.dumps(deterministic_colliding_selection(), indent=2))
        return
    if not all((ns.source_csv, ns.schema_map, ns.expected_sha256, ns.output)):
        a.error("For real data all of --source-csv --schema-map --expected-sha256 --output are required; no invented schema")
    if not ns.source_csv.is_file():
        a.error("source CSV not available")
    actual_hash = sha256_file(ns.source_csv)
    if actual_hash.lower() != ns.expected_sha256.lower():
        raise ValueError("SOURCE_SHA256_MISMATCH")
    mapping = json.loads(ns.schema_map.read_text(encoding="utf-8"))
    with ns.source_csv.open("r", encoding="utf-8-sig", newline="") as stream:
        rows = [row_to_canonical(r, mapping) for r in csv.DictReader(stream)]
    audit = validate_panel(rows)
    events, exclusions = build_transitions(rows)
    if not events:
        raise ValueError("NO_ELIGIBLE_TRANSITIONS")
    result = {
        "source_sha256": actual_hash,
        "source_status": "local_digest_matched_user_supplied_digest; publisher_identity_requires_independent_audit",
        "data_audit": audit,
        "eligible_transition_count": len(events),
        "exclusions": dict(exclusions),
        "published_bone2016_eligibility_reference_N": 1655,
        "matches_published_risk_count": len(events) == 1655,
        "strict_warning": "Matching N alone is insufficient to prove a complete replication",
        "evaluation": evaluate_leave_one_session_out(events),
    }
    ns.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(ns.output), "eligible": len(events), "source_status": result["source_status"]}))


if __name__ == "__main__":
    run_cli()
