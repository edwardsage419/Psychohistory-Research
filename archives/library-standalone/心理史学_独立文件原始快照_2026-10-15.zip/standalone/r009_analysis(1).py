#!/usr/bin/env python3
"""R009: exploratory update-model analysis on author-data-derived sufficient statistics.

No dependency beyond Python >=3.10. A raw CSV can optionally be supplied to
regenerate sufficient statistics, validate its Git blob hash and compare totals.
The fitted slope describes association with full-group, leave-one-out average;
it does NOT identify the neighbor signal actually observed by participants.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import math
import random
from collections import defaultdict
from pathlib import Path
from statistics import mean

DATA = Path(__file__).with_name('trial_sufficient_statistics.csv')
SOURCE_GIT_BLOB = '2fc18cefd211727e560b05d60c1289f1f4891969'


def read_stats(path: Path = DATA):
    with open(path, encoding='utf-8', newline='') as stream:
        rows = list(csv.DictReader(stream))
    if not rows:
        raise ValueError('Empty trial statistics')
    for row in rows:
        row['n'] = int(row['n'])
        row['pair'] = int(row['pair'])
        for t in (1, 2):
            for name in ('d2', 'de', 'e2'):
                row[f'{name}_r{t}'] = float(row[f'{name}_r{t}'])
    return rows


def git_blob_sha(data: bytes) -> str:
    return hashlib.sha1(b'blob ' + str(len(data)).encode('ascii') + b'\0' + data).hexdigest()


def sufficient_from_raw(path: Path):
    """Recreate crossproducts from a locally supplied ORIGINAL author CSV.

    The file must have its expected exact Git blob SHA; this protects the
    provenance of the underlying observations.
    """
    raw = path.read_bytes()
    sha = git_blob_sha(raw)
    if sha != SOURCE_GIT_BLOB:
        raise ValueError(f'Git blob SHA mismatch: {sha}')
    import io
    original = list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig'))))
    groups = defaultdict(list)
    for row in original:
        if row['experiment'] != '1':
            continue
        try:
            vals = [float(row[f'response_{i}']) for i in (1, 2, 3)]
            truth = float(row['truth'])
        except (ValueError, TypeError):
            continue
        if not all(math.isfinite(v) and v > 0 for v in [truth] + vals):
            continue
        group_key = (row['party'], row['set'], int(row['pair_id']), row['network'], row['q'])
        groups[group_key].append(tuple(math.log(v) for v in vals))
    trials = {}
    for (party, set_, pair, cond, question), records in groups.items():
        if len(records) < 3:
            raise ValueError('Question group size too small')
        key = (party, set_, pair, cond)
        if key not in trials:
            trials[key] = {'party': party, 'set': set_, 'pair': pair, 'condition': cond,
                           'n': 0, **{f'{v}_r{t}': 0.0 for t in (1, 2) for v in ('d2','de','e2')}}
        trial = trials[key]
        trial['n'] += len(records)
        for t in (1, 2):
            x = [r[t-1] for r in records]
            y = [r[t] for r in records]
            sx = sum(x)
            for xi, yi in zip(x, y):
                delta_peer = (sx-xi)/(len(x)-1)-xi
                delta_answer = yi-xi
                trial[f'd2_r{t}'] += delta_peer**2
                trial[f'de_r{t}'] += delta_peer*delta_answer
                trial[f'e2_r{t}'] += delta_answer**2
    return list(trials.values()), len(original), sum(len(z) for z in groups.values()), sha


def fit(rows, condition, round_=None):
    selected = [z for z in rows if z['condition'] == condition]
    if not selected:
        raise ValueError('No trials for condition')
    rounds = [round_] if round_ is not None else (1, 2)
    d2 = sum(z[f'd2_r{t}'] for z in selected for t in rounds)
    de = sum(z[f'de_r{t}'] for z in selected for t in rounds)
    e2 = sum(z[f'e2_r{t}'] for z in selected for t in rounds)
    n = sum(z['n'] for z in selected)*len(rounds)
    if d2 <= 0 or n <= 0:
        raise ValueError('Predictor lacks variation')
    slope = de/d2
    return {'trials': len(selected), 'n_transitions': n, 'alpha': slope,
            'inertia_mse': e2/n, 'fitted_mse': (e2-de*de/d2)/n}


def trial_key(z):
    return (z['party'], z['set'], z['pair'], z['condition'])


def loocv(rows, condition, round_=None):
    subset = [z for z in rows if z['condition'] == condition]
    rounds = [round_] if round_ is not None else (1,2)
    total = 0
    n = 0
    for held in subset:
        train = [z for z in subset if trial_key(z) != trial_key(held)]
        slope = fit(train, condition, round_)['alpha']
        for t in rounds:
            total += (held[f'e2_r{t}'] - 2*slope*held[f'de_r{t}'] + slope*slope*held[f'd2_r{t}'])
            n += held['n']
    return total/n


def bootstrap(rows, iterations=10000, seed=20261014):
    rng = random.Random(seed)
    strata = []
    for party in ('Dem','Repub'):
        for set_ in ('A','B','C','D'):
            a = [z for z in rows if z['party']==party and z['set']==set_]
            if len(a) != 4 or sum(z['condition']=='Social' for z in a)!=3:
                raise ValueError(f'Invalid trial stratum {party}/{set_}')
            strata.append(a)
    diffs=[]
    for _ in range(iterations):
        resampled = [z for _ in range(8) for z in rng.choice(strata)]
        diffs.append(fit(resampled,'Social')['alpha']-fit(resampled,'Control')['alpha'])
    diffs.sort()
    return [diffs[int(iterations*0.025)], diffs[int(iterations*0.975)-1]]


def analyze(rows):
    if len(rows) != 32 or sum(z['condition']=='Social' for z in rows) != 24:
        raise ValueError('Expected 32 trials, 24 Social and 8 Control')
    if sum(z['n'] for z in rows) != 4019:
        raise ValueError('Unexpected valid response count')
    out = {'source_blob_sha':SOURCE_GIT_BLOB,
           'status':'Exploratory observational proxy regression; not mechanism identification',
           'n_trial_rows':len(rows), 'valid_records':sum(z['n'] for z in rows),
           'by_round':{}}
    for t in (1,2,None):
        label = 'all' if t is None else f'r{t}_to_r{t+1}'
        out['by_round'][label] = {}
        for cond in ('Social','Control'):
            val = fit(rows,cond,t)
            val['trial_holdout_mse'] = loocv(rows,cond,t)
            val['trial_holdout_gain_vs_inertia'] = 1-val['trial_holdout_mse']/val['inertia_mse']
            out['by_round'][label][cond]=val
    out['pooled_social_minus_control_slope']=(out['by_round']['all']['Social']['alpha']-
                                              out['by_round']['all']['Control']['alpha'])
    out['stratum_cluster_bootstrap_exploratory_95pct'] = bootstrap(rows)
    out['delete_one_stratum'] = {}
    for party in ('Dem','Repub'):
        for set_ in ('A','B','C','D'):
            sub=[z for z in rows if not (z['party']==party and z['set']==set_)]
            out['delete_one_stratum'][party+'_'+set_] = fit(sub,'Social')['alpha']-fit(sub,'Control')['alpha']
    return out


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--stats',type=Path,default=DATA)
    cli.add_argument('--raw',type=Path,help='Optional ORIGINAL author CSV for end-to-end verification')
    cli.add_argument('--output',type=Path,default=Path(__file__).with_name('r009_results.json'))
    args=cli.parse_args()
    rows=read_stats(args.stats)
    result=analyze(rows)
    if args.raw:
        orig,total,valid,sha=sufficient_from_raw(args.raw)
        ours={trial_key(z):z for z in rows}
        for row in orig:
            comp=ours[trial_key(row)]
            if row['n']!=comp['n']:
                raise ValueError(f'Count mismatch: {trial_key(row)}')
            for t in (1,2):
                for m in ('d2','de','e2'):
                    key=f'{m}_r{t}'
                    if not math.isclose(row[key],comp[key],abs_tol=0.000001,rel_tol=1e-9):
                        raise ValueError(f'Raw crossproduct mismatch: {trial_key(row)} {key}')
        result['raw_file_verification']={'git_blob_sha':sha,'total_rows':total,
                                         'experiment_1_valid_rows':valid,'crossproducts_match':True}
    else:
        result['raw_file_verification']='Not run: source CSV unavailable in local container'
    args.output.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps({key:result[key] for key in ('valid_records','pooled_social_minus_control_slope','stratum_cluster_bootstrap_exploratory_95pct')},indent=2))

if __name__=='__main__':
    main()
