#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""R001 教学演示：比较三种行为采纳规则，使用纯 Python 标准库。

注意：本脚本仅验证简化机制在人工网络中的行为，不提供社会规范、因果作用
或真实历史预测的经验证据。参数仅用于演示，并未从数据估计。

运行：
  python3 心理史学_R001_最小模型比较示范_v0.1.py
  python3 心理史学_R001_最小模型比较示范_v0.1.py --self-test
"""

from __future__ import annotations

import argparse
import csv
import json
import random
import statistics
from dataclasses import asdict, dataclass
from pathlib import Path


@dataclass(frozen=True)
class Config:
    population: int = 120
    mean_degree: int = 6
    rounds: int = 25
    replicates: int = 30
    initial_fraction: float = 0.10
    rewire_probability: float = 0.12
    spontaneous_probability: float = 0.02
    cascade_probability: float = 0.18
    threshold_fraction: float = 0.25
    seed: int = 20261014


def make_graph(n: int, degree: int, rewire_probability: float, rng: random.Random):
    """构造规则环网络或教学版 WS 式小世界网络（无向、无重边）。"""
    if n < 4 or degree < 2 or degree % 2 or degree >= n:
        raise ValueError("需要 n>=4、偶数 degree>=2 且 degree<n")
    if not 0 <= rewire_probability <= 1:
        raise ValueError("rewire_probability 必须位于 [0,1]")
    graph = [set() for _ in range(n)]
    # 初始无向环网络
    for i in range(n):
        for k in range(1, degree // 2 + 1):
            j = (i + k) % n
            graph[i].add(j)
            graph[j].add(i)
    # 从每条原始向前边出发，以指定概率重连；保持无自环和无重边
    if rewire_probability:
        for i in range(n):
            for k in range(1, degree // 2 + 1):
                j = (i + k) % n
                if j not in graph[i] or rng.random() >= rewire_probability:
                    continue
                candidates = [v for v in range(n) if v != i and v not in graph[i]]
                if not candidates:
                    continue
                new_j = rng.choice(candidates)
                graph[i].remove(j)
                graph[j].remove(i)
                graph[i].add(new_j)
                graph[new_j].add(i)
    return graph


def simulate(kind: str, graph, initial_adopters: set[int], rounds: int, rng: random.Random,
             p0: float, p_cascade: float, threshold: float):
    """统一机制接口：图与初始状态 → 每轮采用比例。

    independent: 每轮每位未采纳者有 p0 的自主采纳机会。
    cascade: 每位新采纳者只对各未采纳邻居尝试传播一次。
    threshold: 同步更新，已采纳邻居比例 >= threshold 时采用。
    所有规则都假设一旦采纳便不退出。
    """
    n = len(graph)
    active = set(initial_adopters)
    frontier = set(active)
    history = [len(active) / n]

    for _ in range(rounds):
        newly_active: set[int] = set()
        if kind == "independent":
            for i in range(n):
                if i not in active and rng.random() < p0:
                    newly_active.add(i)
        elif kind == "cascade":
            for j in sorted(frontier):
                for i in sorted(graph[j]):
                    if i not in active and rng.random() < p_cascade:
                        newly_active.add(i)
        elif kind == "threshold":
            for i in range(n):
                if i not in active and graph[i] and (len(graph[i] & active) / len(graph[i])) >= threshold:
                    newly_active.add(i)
        else:
            raise ValueError(f"未知机制类型：{kind}")
        # 同轮所有行为在统一时点生效。新采纳者不能影响本轮其他人的决策。
        active.update(newly_active)
        frontier = newly_active
        history.append(len(active) / n)
    return history, active


def time_to_half(history):
    return next((t for t, fraction in enumerate(history) if fraction >= 0.5), None)


def active_edge_fraction(graph, active):
    total = sum(len(neighbors) for neighbors in graph) // 2
    both = sum(sum(1 for j in neighbors if j > i and j in active)
               for i, neighbors in enumerate(graph) if i in active)
    return both / total if total else 0.0


def experiment(cfg: Config):
    records = []
    mechanism_ids = {"independent": 101, "cascade": 202, "threshold": 303}
    for graph_type, rewire_p in (("ring", 0.0), ("smallworld", cfg.rewire_probability)):
        for rep in range(cfg.replicates):
            base_seed = cfg.seed + rep * 1009 + (0 if graph_type == "ring" else 10000000)
            graph_rng = random.Random(base_seed)
            graph = make_graph(cfg.population, cfg.mean_degree, rewire_p, graph_rng)
            n_seed = max(1, min(cfg.population, round(cfg.population * cfg.initial_fraction)))
            initial = set(graph_rng.sample(range(cfg.population), n_seed))
            for kind, offset in mechanism_ids.items():
                history, active = simulate(
                    kind, graph, initial, cfg.rounds, random.Random(base_seed + offset),
                    cfg.spontaneous_probability, cfg.cascade_probability, cfg.threshold_fraction
                )
                records.append({
                    "network": graph_type, "replicate": rep, "model": kind,
                    "final_fraction": round(history[-1], 6),
                    "time_to_50pct": time_to_half(history),
                    "active_edge_fraction": round(active_edge_fraction(graph, active), 6),
                    "history": history,
                })
    return records


def self_test():
    cfg = Config(population=20, mean_degree=4, rounds=4, replicates=2)
    g = make_graph(20, 4, 0.1, random.Random(10))
    assert all(i not in g[i] for i in range(20)), "出现自环"
    assert all(i in g[j] for i in range(20) for j in g[i]), "出现非对称边"
    for kind in ("independent", "cascade", "threshold"):
        h, final = simulate(kind, g, set(), 4, random.Random(42), 0.0, 0.0, 0.5)
        assert h == [0.0] * 5 and not final, "空初始采纳者出现传播"
        h, final = simulate(kind, g, set(range(20)), 4, random.Random(42), 0, 0, 0.5)
        assert h == [1.0] * 5 and len(final) == 20, "全部采纳未保持"
    assert experiment(cfg) == experiment(cfg), "相同随机种子未重复运行"
    assert time_to_half([0.2, 0.4, 0.6]) == 2
    print("测试通过：网络约束、边界状态、可重复性与指标计算。")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--output-dir", default="r001_demo_results", help="结果输出目录")
    ap.add_argument("--self-test", action="store_true", help="只执行内置自检")
    args = ap.parse_args()
    if args.self_test:
        self_test()
        return
    cfg = Config()
    rows = experiment(cfg)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    with (output_dir / "per_run_metrics.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["network", "replicate", "model", "final_fraction", "time_to_50pct", "active_edge_fraction"])
        writer.writeheader()
        writer.writerows({k: v for k, v in row.items() if k != "history"} for row in rows)
    summaries = {}
    for network in ("ring", "smallworld"):
        summaries[network] = {}
        for model in ("independent", "cascade", "threshold"):
            subset = [r for r in rows if r["network"] == network and r["model"] == model]
            summaries[network][model] = {
                "mean_final_fraction": round(statistics.mean(r["final_fraction"] for r in subset), 4),
                "sd_final_fraction": round(statistics.stdev(r["final_fraction"] for r in subset), 4) if len(subset) > 1 else 0,
                "runs_reaching_half": sum(r["time_to_50pct"] is not None for r in subset),
            }
    with (output_dir / "summary.json").open("w", encoding="utf-8") as handle:
        json.dump({"experimental_status": "SIMULATION_ONLY_NO_EMPIRICAL_VALIDATION",
                   "config": asdict(cfg), "summary": summaries}, handle, ensure_ascii=False, indent=2)
    print(json.dumps(summaries, ensure_ascii=False, indent=2))
    print(f"结果已保存到：{output_dir.resolve()}")


if __name__ == "__main__":
    main()
