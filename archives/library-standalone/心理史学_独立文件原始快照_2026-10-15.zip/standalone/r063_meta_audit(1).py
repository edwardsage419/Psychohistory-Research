#!/usr/bin/env python3
"""R063 SOURCE-STRUCTURE AUDIT, not an independent validation of author metaVS.

Reference logic ported from hrl-team/mfree_imitation/models/VS/metaVS.m
Git blob: cc6e92af0945a2afe4c4f84dcd310a75b5de5a31.
The reference parser comes from R061; raw author CSVs are NOT distributed.

IMPORTANT: alpha_imit (metaVS) is the adaptation gain, not a constant
social update rate. Comparing equal numeric gains is not a fair model comparison.
Fixed parameters are *exploratory historical-data sensitivity settings*, not
parameters estimated from the author's work or pre-registered tests.
"""
import argparse
import csv
import json
import math
from collections import defaultdict
from pathlib import Path
from typing import Dict
import r061_replay_frozen as frozen

PARAMETERS = {
    1: {"alpha_private": 0.1, "beta": 2.0, "kappa": 0.4},
    2: {"alpha_private": 0.1, "beta": 2.0, "kappa": 0.15},
}
MODES = ("rw", "fixed003", "r062_gate003", "meta003", "meta01")
SOURCE_CODE_SHAS = {
    'RW2': 'ce4982374e429ccb771d80014ad929516295b26e',
    'VS2': '66c8f9638e97179ad9ab625c7b0b475a5d34906b',
    'metaVS': 'cc6e92af0945a2afe4c4f84dcd310a75b5de5a31',
}

def prefer(q):
    """MATLAB max([Q(action1),Q(action2)]) chooses first action at a tie."""
    return int(q[1] > q[0])


def meta_update(alpha, agree, gain):
    if not (0 <= alpha <= 1 and agree in (0, 1) and 0 <= gain <= 1):
        raise ValueError('out of range alpha/target/gain')
    return alpha + gain * (agree - alpha)


def softplus(x):
    return x + math.log1p(math.exp(-x)) if x > 0 else math.log1p(math.exp(x))


def predict_loss(logit, choice):
    return softplus(-logit if choice == 1 else logit)


def score(sessions: Dict, task: int, mode: str):
    """Strict predict-then-update; reset private state by session.

    All information read from e is past information except chosen private action
    and its reward, which are used only *after* prediction and scoring.
    Hidden reward of demonstrator is never available.
    """
    if task not in PARAMETERS or mode not in MODES:
        raise ValueError('unsupported task/model')
    p = PARAMETERS[task]
    losses = briers = n = 0.0
    condition = {k: [0., 0, 0.] for k in ('private','skilled','unskilled')}
    diag = {'demonstrations': 0, 'meta_adaptations': 0,
            'meta_before_private': 0, 'social_update_rate_sum': 0.0}
    for _, events in sorted(sessions.items()):
        Q = {}; Qprivate = {}; last = {}; gated = {}; obspriv = {}; meta_alpha = {}
        events = sorted(events, key=lambda z: z['trial'])
        for e in events:
            state, c = e['state'], e['choice']
            if c not in (0, 1) or state < 1:
                raise ValueError('invalid event state or action')
            if state not in Q:
                Q[state] = [0., 0.]; Qprivate[state] = [0., 0.]
                last[state] = None; gated[state] = [1., 1.]
                obspriv[state] = 0; meta_alpha[state] = 0.
            q, qp = Q[state], Qprivate[state]
            opposite = 1-c
            if e['demo']:
                if e['out'] is not None:
                    raise ValueError('demonstrator outcome cannot be visible')
                if mode == 'rw':
                    rate = 0.
                elif mode == 'fixed003':
                    rate = .03
                elif mode == 'r062_gate003':
                    a, b = gated[state]
                    rate = .03 * a / (a+b)
                else:
                    if last[state] is not None:
                        gain = .03 if mode == 'meta003' else .1
                        meta_alpha[state] = meta_update(meta_alpha[state], int(c == prefer(q)), gain)
                        diag['meta_adaptations'] += 1
                    else:
                        diag['meta_before_private'] += 1
                    rate = meta_alpha[state]
                diag['demonstrations'] += 1
                diag['social_update_rate_sum'] += rate
                q[c] += rate * (1. - q[c]); q[opposite] += rate * (-1. - q[opposite])
                if mode == 'r062_gate003' and obspriv[state] > 0 and abs(qp[1]-qp[0]) >= .1:
                    good = int(c == prefer(qp)); gated[state][0 if good else 1] += 1
                continue
            outcome = e['out']
            if outcome not in (-1, 1):
                raise ValueError('private outcome missing')
            prev = last[state]
            signed = 0 if prev is None else (1 if prev == 1 else -1)
            logit = p['beta']*(q[1]-q[0] + p['kappa']*signed)
            L = predict_loss(logit, c)
            prob = 1/(1+math.exp(-logit))
            B = (c-prob)**2
            losses += L; briers += B; n += 1
            cat = ('private' if e['condition'] == 'Private' else
                   'skilled' if e['skill'] == 'skilled.dem' else 'unskilled')
            z = condition[cat]; z[0] += L; z[1] += 1; z[2] += B
            rate = p['alpha_private']
            # Author RW2 uses symmetric counterfactual update.
            q[c] += rate*(outcome-q[c]); q[opposite] += rate*(-outcome-q[opposite])
            qp[c] += rate*(outcome-qp[c]); qp[opposite] += rate*(-outcome-qp[opposite])
            last[state] = c; obspriv[state] += 1
    if not n:
        raise ValueError('no choices to score')
    return {'loss': losses/n, 'brier': briers/n, 'n': int(n),
            'condition': condition, 'diagnostics': diag}


def replay_author(task1: bytes, task2: bytes):
    full = {}
    for task, raw in ((1,task1), (2,task2)):
        people, checks = frozen.parse_data(raw, task, check_provenance=True)
        participants = []
        for uid in sorted(people, key=int):
            row = {'id': uid}
            for mode in MODES:
                row[mode] = score(people[uid], task, mode)
            participants.append(row)
        avg = lambda key, sub='loss': sum(p[key][sub] for p in participants)/len(participants)
        full[str(task)] = {
            'source_sha': frozen.SOURCE[task]['sha'],
            'checks': checks,
            'participants': participants,
            'macro': {mode: {'logloss': avg(mode), 'brier': avg(mode, 'brier')} for mode in MODES},
        }
    return {'provenance': 'AUTHOR_ORIGINAL_BYTES_LOCALLY_AUTHENTICATED',
            'research_status': 'EXPLORATORY_NOT_ORIGINAL_MATLAB_PARAMETER_FIT',
            'reference_code_sha': SOURCE_CODE_SHAS, 'tasks': full}


def audit_derived_score_csv(path: Path):
    """Recalculate saved connection-side metaVS audit only, no raw verification."""
    grouped = defaultdict(list)
    with path.open(newline='', encoding='utf8') as f:
        for row in csv.DictReader(f):
            task = int(row['task'])
            if task not in (1, 2): raise ValueError('Unexpected experiment')
            for k in ('meta003_loss', 'meta003_brier', 'meta01_loss', 'meta01_brier'):
                row[k] = float(row[k])
                if not math.isfinite(row[k]): raise ValueError('Nonfinite score')
            grouped[task].append(row)
    if set(grouped) != {1,2} or [len(grouped[k]) for k in (1,2)] != [24,44]:
        raise ValueError('Subject counts do not match source')
    result = {}
    for task, rows in grouped.items():
        mean = lambda key: sum(z[key] for z in rows)/len(rows)
        expected = 240 if task==1 else 180
        if len({z['id'] for z in rows}) != len(rows):
            raise ValueError('Duplicate participant in derived results')
        result[task] = {'participants':len(rows), 'private_choices':len(rows)*expected,
            'mean_loss': {k:mean(k+'_loss') for k in ('meta003','meta01')},
            'mean_brier': {k:mean(k+'_brier') for k in ('meta003','meta01')},
        }
    return result


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--task1', type=Path)
    p.add_argument('--task2', type=Path)
    p.add_argument('--out', type=Path)
    p.add_argument('--derived', type=Path)
    args = p.parse_args()
    if args.task1 or args.task2:
        if not (args.task1 and args.task2 and args.out):
            p.error('raw replay requires --task1 --task2 --out')
        result = replay_author(args.task1.read_bytes(), args.task2.read_bytes())
        args.out.write_text(json.dumps(result, indent=2, ensure_ascii=False)+'\n',encoding='utf8')
        print(json.dumps({k:v['macro'] for k,v in result['tasks'].items()},indent=2))
    elif args.derived:
        print(json.dumps(audit_derived_score_csv(args.derived),indent=2))
    else:
        p.error('Provide --derived or both raw inputs plus --out')
if __name__=='__main__': main()
