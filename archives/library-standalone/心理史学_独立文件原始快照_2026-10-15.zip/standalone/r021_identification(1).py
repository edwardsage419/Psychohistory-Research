#!/usr/bin/env python3
"""R021 structural non-identification benchmark (NOT participant data).

Constructive equivalence on the SAME binary observable Y:
  direct decision propensity: p(A,V,C) = sigmoid(-0.1 + 0.36*A*V - 0.48*C + .12*V)
  researcher-added bridge for two-agent network b=(0,1), D_12=d:
       s_1=d/(1+d), Pr(Y=1|s_1)=sigmoid(-2+4*s_1).
For any direct p within sigmoid(-2),sigmoid(2), obtain d>=0 exactly:
  z=logit(p); s=(z+2)/4; d=s/(1-s).
This *bridge* is NOT contained in Anufriev et al.'s original continuous-s model.
Variable d(A,V,C) is an unrestricted nuisance response, not a measured mechanism.
The construction proves observational equivalence of one illustrative direct-cost
binary choice model and one augmented flexible-audience model; NOT a universal
nonidentification theorem about all psychological theories.
"""
from __future__ import annotations
import argparse
import csv
import itertools
import json
import math
from pathlib import Path


ALPHA = -2.0
KAPPA = 4.0


def sigmoid(x: float) -> float:
    if not math.isfinite(x):
        raise ValueError('input must be finite')
    if x >= 0:
        return 1.0/(1.0 + math.exp(-x))
    v = math.exp(x)
    return v/(1.0+v)


def logit(p: float) -> float:
    if not isinstance(p, (float,int)) or not (0 < p < 1):
        raise ValueError('p must be strictly between 0 and 1')
    return math.log(p/(1-p))


def direct_probability(evaluation: int, attributable: int, cost: int) -> float:
    if any(x not in (0,1) for x in (evaluation,attributable,cost)):
        raise ValueError('binary factors only')
    return sigmoid(-.1 + .36*evaluation*attributable - .48*cost + .12*attributable)


def speech_from_d(d: float) -> float:
    if not math.isfinite(d) or d < 0:
        raise ValueError('finite nonnegative audience weight required')
    return d / (1 + d)


def audience_probability(d: float, alpha: float=ALPHA, kappa: float=KAPPA) -> float:
    if not math.isfinite(alpha) or not math.isfinite(kappa) or kappa <= 0:
        raise ValueError('finite link with positive slope required')
    return sigmoid(alpha+kappa*speech_from_d(d))


def inverse_audience_weight(p: float, alpha:float=ALPHA,kappa:float=KAPPA) -> float:
    if not (math.isfinite(alpha) and math.isfinite(kappa) and kappa>0):
        raise ValueError('invalid bridge parameters')
    s=(logit(p)-alpha)/kappa
    if s<0 or s>=1:
        raise ValueError('probability is outside the two-agent model bridge range')
    return s/(1-s)


def contrast(cells: dict[str,dict]) -> dict[str,float]:
    def p(a,v,c):
        z=cells[f'{a}{v}{c}']['direct_p']
        return z
    cost=sum(p(a,v,1)-p(a,v,0) for a in (0,1) for v in (0,1))/4
    eval_visibility=(sum(p(1,1,c)-p(0,1,c) for c in (0,1))
                    -sum(p(1,0,c)-p(0,0,c) for c in (0,1)))/2
    cost_visibility=(sum(p(a,1,1)-p(a,1,0) for a in (0,1))
                     -sum(p(a,0,1)-p(a,0,0) for a in (0,1)))/2
    return {'cost_main_ITT':cost,'evaluation_by_visibility_ITT':eval_visibility,
            'cost_by_visibility_ITT':cost_visibility,
            'evaluation_effect_when_anonymous':sum(p(1,0,c)-p(0,0,c) for c in (0,1))/2}


def proof_table() -> dict:
    cells={}
    for a,v,c in itertools.product((0,1),repeat=3):
        p=direct_probability(a,v,c)
        d=inverse_audience_weight(p)
        q=audience_probability(d)
        cells[f'{a}{v}{c}']={'evaluation':a,'attributable':v,'cost':c,
                             'direct_p':p,'flexible_d':d,'speech_s':speech_from_d(d),
                             'flexible_p':q,'residual':q-p}
    delta_by_a_v={}
    for a,v in itertools.product((0,1),repeat=2):
        d0=cells[f'{a}{v}0']['flexible_d']
        d1=cells[f'{a}{v}1']['flexible_d']
        delta_by_a_v[f'{a}{v}']= {'delta_d_cost1_minus_cost0':d1-d0,
                                   'delta_p_cost1_minus_cost0':cells[f'{a}{v}1']['direct_p']-cells[f'{a}{v}0']['direct_p']}
    max_need=max(abs(v['delta_d_cost1_minus_cost0']) for v in delta_by_a_v.values())
    global_L=KAPPA/4  # |dp/dd| <= (kappa/4)/(1+d)^2 <= kappa/4.
    output={
      'label':'PURELY_STRUCTURAL_TOY_EXAMPLE_NO_HUMAN_DATA',
      'source_theory':'Anufriev et al. (2026) two-node equilibrium s_1=d/(1+d), b=(0,1)',
      'author_added_binary_link':'P(Y=1)=logistic(-2+4*s), not a source-paper equation',
      'direct_binary_model':'P(Y=1)=logistic(-0.1+0.36*evaluation*attributable-0.48*cost+0.12*attributable)',
      'cells':cells,
      'contrasts':contrast(cells),
      'max_absolute_cell_prediction_gap':max(abs(x['residual']) for x in cells.values()),
      'cost_shift_sensitivity':{
        'pairwise_delta_D':delta_by_a_v,
        'max_abs_delta_D_needed_at_fixed_bridge':max_need,
        'global_slope_bound_on_prob_change_per_unit_D':global_L,
        'meaning':'If independently justified |D(cost=1)-D(cost=0)| < max_abs_delta_D_needed AND this link is calibrated, this particular no-direct-cost reconstruction fails. No such bound has been established empirically.'},
      'decision':'Randomization identifies treatment contrasts, but absent restrictions on D(A,V,C) does not uniquely identify direct cost/sanction utility.'}
    return output


def save(out:Path,csvpath:Path) -> dict:
    z=proof_table()
    out.parent.mkdir(parents=True,exist_ok=True)
    csvpath.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(z,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    fields=['evaluation','attributable','cost','direct_p','flexible_d','speech_s','flexible_p','residual']
    with csvpath.open('w',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=fields)
        writer.writeheader()
        for key in sorted(z['cells']):writer.writerow(z['cells'][key])
    return z


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--out',type=Path,default=Path('results/equivalence.json'))
    p.add_argument('--csv',type=Path,default=Path('results/experimental_cells.csv'))
    a=p.parse_args()
    v=save(a.out,a.csv)
    print(json.dumps({'cells':len(v['cells']),'max_prediction_gap':v['max_absolute_cell_prediction_gap'],
                      'cost_itt':v['contrasts']['cost_main_ITT'],
                      'evaluation_visibility_interaction':v['contrasts']['evaluation_by_visibility_ITT'],
                      'D_change_needed':v['cost_shift_sensitivity']['max_abs_delta_D_needed_at_fixed_bridge']},ensure_ascii=False))
if __name__=='__main__':main()
