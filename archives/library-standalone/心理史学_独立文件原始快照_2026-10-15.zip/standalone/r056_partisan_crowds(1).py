#!/usr/bin/env python3
"""R056: Original-source gated group-level reanalysis of Becker et al. (2019).

Usage:
  python r056_partisan_crowds.py --trial-csv R056_TRIAL_AGGREGATES.csv
  python r056_partisan_crowds.py --raw-csv ORIGINAL.csv --output-trials output.csv

The --raw-csv mode checks the Git blob hash of the *raw bytes* by default.
Never interpret synthetic tests as a replication of the original source.
"""
import argparse
import csv
import hashlib
import io
import json
import math
from collections import defaultdict
from pathlib import Path

ORIGINAL_GIT_BLOB = "2fc18cefd211727e560b05d60c1289f1f4891969"
INPUT_COLUMNS = {"q", "user_id", "party", "response_1", "response_2", "response_3", "truth", "set", "network", "pair_id", "experiment", "remove_extreme"}
TRIAL_COLUMNS = ["experiment", "set", "pair_id", "party", "network", "n", "err1", "err3", "change"]


def git_blob_sha(raw: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def parse_source_bytes(raw: bytes, expected_blob: str = ORIGINAL_GIT_BLOB, locked: bool = True):
    observed = git_blob_sha(raw)
    if locked and observed != expected_blob:
        raise ValueError(f"Original data bytes not authenticated: expected {expected_blob}, observed {observed}")
    text = raw.decode("utf-8-sig")
    reader = csv.DictReader(io.StringIO(text, newline=""))
    missing = INPUT_COLUMNS - set(reader.fieldnames or [])
    if missing:
        raise ValueError(f"Source schema missing: {sorted(missing)}")
    rows = list(reader)
    if locked and len(rows) != 8821:
        raise ValueError(f"Unexpected source row count: {len(rows)}")
    return rows, observed


def valid_number(value):
    if value is None or value.strip().upper() == "NA" or value.strip() == "":
        return None
    try:
        x = float(value)
    except ValueError:
        return None
    return x if math.isfinite(x) else None


def aggregate_original(rows):
    # One individual answer on each of four questions appears in a subject's trial.
    cells = defaultdict(list)
    eligibility = {"1": 0, "2": 0}
    source_counts = {"1": 0, "2": 0}
    for r in rows:
        exp = r["experiment"]
        if exp not in ("1", "2"):
            raise ValueError(f"Unknown experiment: {exp!r}")
        source_counts[exp] += 1
        if exp == "2" and r["remove_extreme"] != "":
            continue
        v = [valid_number(r[k]) for k in ("response_1", "response_2", "response_3", "truth")]
        if any(x is None for x in v):
            continue
        if exp == "1" and any(x <= 0 for x in v):
            continue
        if r["network"] not in ("Social", "Control") or r["party"] not in ("Dem", "Repub"):
            raise ValueError("Unknown group labels")
        eligibility[exp] += 1
        vals = [math.log(x) for x in v] if exp == "1" else [x / v[3] for x in v]
        cell = (exp, r["set"], int(r["pair_id"]), r["party"], r["network"], r["q"])
        cells[cell].append(vals)
    trial_questions = defaultdict(list)
    for (exp, s, pid, party, network, question), vs in cells.items():
        errors = [abs(sum(row[k] for row in vs) / len(vs) - vs[0][3]) for k in (0, 2)]
        trial_questions[(exp, s, pid, party, network)].append((len(vs), *errors))
    trials = []
    for (exp, s, pid, party, network), qvals in trial_questions.items():
        if len(qvals) != 4:
            raise ValueError("Expected four questions per trial")
        e1 = sum(x[1] for x in qvals) / 4
        e3 = sum(x[2] for x in qvals) / 4
        trials.append({"experiment": int(exp), "set": s, "pair_id": pid, "party": party,
                       "network": network, "n": sum(x[0] for x in qvals),
                       "err1": e1, "err3": e3, "change": e3 - e1})
    trials.sort(key=lambda o: (o["experiment"], o["set"], o["party"], o["network"], o["pair_id"]))
    return trials, source_counts, eligibility


def import_trial_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    if not rows or any(not set(TRIAL_COLUMNS).issubset(r) for r in rows):
        raise ValueError("Missing trial fields")
    for r in rows:
        for key in ("experiment", "pair_id", "n"):
            r[key] = int(r[key])
        for key in ("err1", "err3", "change"):
            r[key] = float(r[key])
        if abs(r["err3"] - r["err1"] - r["change"]) > 2e-9:
            raise ValueError("Invalid trial error change")
    return rows


def export_trial_csv(path, trials):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=TRIAL_COLUMNS)
        w.writeheader()
        for r in trials:
            w.writerow(r)


def trial_statistics(trials, iterations=20000):
    if iterations < 1:
        raise ValueError("Bootstrap iterations must be positive")
    summary = {}
    for exp in (1, 2):
        t = [r for r in trials if r["experiment"] == exp]
        if len(t) != 32 or len({(r["set"], r["party"], r["network"], r["pair_id"]) for r in t}) != 32:
            raise ValueError(f"Experiment {exp}: need 32 distinct trials")
        group = {}
        for condition, expected in (("Social", 24), ("Control", 8)):
            a = [r for r in t if r["network"] == condition]
            if len(a) != expected:
                raise ValueError(f"Experiment {exp} has unexpected {condition} count")
            m = lambda f: sum(z[f] for z in a) / len(a)
            group[condition] = {"n": len(a), "mean_baseline_error": m("err1"),
                                "mean_final_error": m("err3"), "mean_change": m("change"),
                                "trials_improved": sum(z["change"] < 0 for z in a)}
        social = [r["change"] for r in t if r["network"] == "Social"]
        control = [r["change"] for r in t if r["network"] == "Control"]
        observed = sum(social) / len(social) - sum(control) / len(control)
        # Reproduce the original connector-side seeded 32-bit LCG bootstrap.
        state = (5601 + exp) & 0xffffffff
        def rand():
            nonlocal state
            state = (1664525 * state + 1013904223) & 0xffffffff
            return state / (2 ** 32)
        def draw(a):
            return sum(a[int(rand() * len(a))] for _ in a) / len(a)
        bs = sorted(draw(social) - draw(control) for _ in range(iterations))
        lo = bs[int(.025 * iterations) - 1]
        hi = bs[int(.975 * iterations) - 1]
        summary[str(exp)] = {"trials": len(t), "social": group["Social"],
                             "control": group["Control"], "social_minus_control": observed,
                             "exploratory_trial_bootstrap95": [lo, hi],
                             "bootstrap_draws": iterations}
    return summary


def main():
    a = argparse.ArgumentParser()
    g = a.add_mutually_exclusive_group(required=True)
    g.add_argument("--raw-csv", type=Path)
    g.add_argument("--trial-csv", type=Path)
    a.add_argument("--output-trials", type=Path)
    a.add_argument("--output-json", type=Path)
    a.add_argument("--allow-synthetic", action="store_true", help="For software tests ONLY, permits alternate raw bytes")
    args = a.parse_args()
    if args.raw_csv:
        rows, sha = parse_source_bytes(args.raw_csv.read_bytes(), locked=not args.allow_synthetic)
        trial, source_counts, eligible = aggregate_original(rows)
        provenance = {"source": str(args.raw_csv), "git_blob": sha,
                      "authenticated_original": sha == ORIGINAL_GIT_BLOB,
                      "raw_rows_by_experiment": source_counts,
                      "eligible_rows_by_experiment": eligible}
        if args.output_trials:
            export_trial_csv(args.output_trials, trial)
    else:
        trial = import_trial_csv(args.trial_csv)
        provenance = {"source": str(args.trial_csv),
                      "authenticated_original": False,
                      "note": "Anonymous source-derived trial summary; no local original byte authentication"}
    results = {"provenance": provenance, "results": trial_statistics(trial)}
    s = json.dumps(results, ensure_ascii=False, indent=2)
    if args.output_json:
        args.output_json.write_text(s + "\n", encoding="utf-8")
    print(s)


if __name__ == "__main__":
    main()
