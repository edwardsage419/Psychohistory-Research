#!/usr/bin/env python3
"""R012: independent audit of Lu et al. (2022), experiment 2.

No raw study data are bundled. Obtain the two author CSVs separately or use
--fetch on an internet-connected machine. Refuse unexpected Git blob SHAs.

Usage:
  python3 r012_analysis.py --fetch --source-dir source
  python3 r012_analysis.py --social source/experimentTwoWithInfluenceIndividualLevelRes.csv \
      --independent source/experimentTwoNoInfluenceIndividualLevelRes.csv --output results.json
"""
import argparse
import csv
import hashlib
import json
import random
import urllib.request
from collections import defaultdict, Counter
from pathlib import Path

SOURCE_REPO = "https://github.com/ZhuoranLu/Misinformation"
FILES = {
    "social": ("experimentTwoWithInfluenceIndividualLevelRes.csv",
               "1c00c215d1c65436f52baaf7b5ddd98e450833bb"),
    "independent": ("experimentTwoNoInfluenceIndividualLevelRes.csv",
                    "e32926e78a1e7698cb5d070d52f57e078b3864be")
}
ARM_ORDER = [(s,t) for s in ("social","independent") for t in range(3)]

def git_blob_sha(data: bytes) -> str:
    return hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()

def fetch_files(directory):
    """Fetch author-hosted CSVs, refuse changed source versions."""
    directory.mkdir(parents=True,exist_ok=True)
    for key, (name, sha) in FILES.items():
        url=f"https://raw.githubusercontent.com/ZhuoranLu/Misinformation/main/{name}"
        with urllib.request.urlopen(urllib.request.Request(
            url, headers={"User-Agent":"Psychohistory-R012/0.1"}), timeout=30) as r:
            data=r.read()
        found=git_blob_sha(data)
        if found!=sha:
            raise RuntimeError(f"{name}: unexpected Git blob: {found}; expected {sha}")
        (directory/name).write_bytes(data)
    return {key: str(directory/name) for key,(name,_) in FILES.items()}

def parse_source(path: Path, condition: str, enforce_hash=True):
    b=path.read_bytes()
    expected=FILES[condition][1]
    if enforce_hash and git_blob_sha(b)!=expected:
        raise ValueError(f"{path}: source blob mismatch; no silent dataset substitution")
    rows=[]
    raw=list(csv.DictReader(b.decode("utf-8-sig").splitlines()))
    for line_no,x in enumerate(raw,2):
        if not x or None in x:
            raise ValueError(f"Malformed CSV at {path}:{line_no}")
        try:
            treatment=int(float(x["treatment"]))
            worker=str(x["workerId"])
            news=int(float(x["newsIndex"]))
            label=int(x["label"])
            initial=int(x["initialDecision"])
            final=int(x["finalDecision"])
        except (ValueError, TypeError) as exc:
            raise ValueError(f"Malformed values {path}:{line_no}: {exc}") from exc
        if treatment not in (0,1,2) or news not in range(40) or label not in (-1,1) or initial not in (-1,1) or final not in (-1,1):
            raise ValueError(f"Out of range {path}:{line_no}")
        if x["finalCorrectness"] not in ("True","False"):
            raise ValueError(f"Missing correctness {path}:{line_no}")
        y=int(final==label)
        if y!=int(x["finalCorrectness"]=="True"):
            raise ValueError(f"Contradictory correctness {path}:{line_no}")
        rows.append(dict(condition=condition,treatment=treatment,worker=worker,news=news,
                         label=label,initial=initial,final=final,correct=y,
                         record=str(x.get("", "")),line_no=line_no))
    return rows

def audit(rows):
    key_counts=Counter((r["condition"],r["treatment"],r["worker"],r["news"]) for r in rows)
    worker_arms=defaultdict(set)
    for r in rows: worker_arms[(r["condition"],r["worker"])].add(r["treatment"])
    dup_keys={k for k,v in key_counts.items() if v>1}
    ambiguous={k for k,arms in worker_arms.items() if len(arms)>1}
    counts={}
    for condition,treatment in ARM_ORDER:
        z=[r for r in rows if r["condition"]==condition and r["treatment"]==treatment]
        counts[f"{condition}|{treatment}"]={
           "records":len(z),"worker_treatment_units":len(set(x["worker"] for x in z)),
           "raw_accuracy":sum(x["correct"] for x in z)/len(z) if z else None,
           "fraction_real_news":sum(x["label"]==1 for x in z)/len(z) if z else None
        }
    return {
      "rows":len(rows),"distinct_composite_worker_news":len(key_counts),
      "duplicate_composite_key_extra_rows":sum(v-1 for v in key_counts.values() if v>1),
      "ambiguous_workers_within_file":len(ambiguous),
      "file_scoped_worker_ids":len(worker_arms),
      "cells":counts
    }

def variants(rows, policy):
    """Keep raw rows; or first repeated worker/news; optionally exclude ambiguous workers.
    This is a sensitivity analysis, not an assertion that first row is correct.
    """
    if policy=="all": return rows
    x=[];keys=set()
    for r in rows:
        key=(r["condition"],r["treatment"],r["worker"],r["news"])
        if key not in keys:
            x.append(r); keys.add(key)
    if policy=="first_per_worker_news":return x
    if policy!="exclude_ambiguous_and_first":raise ValueError(policy)
    arms=defaultdict(set)
    for r in x:arms[(r["condition"],r["worker"])].add(r["treatment"])
    bad={k for k,ts in arms.items() if len(ts)>1}
    return [r for r in x if (r["condition"],r["worker"]) not in bad]

def equal_item_accuracy(rows, news_ids=range(40)):
    output={}
    for cond,treat in ARM_ORDER:
        r=[x for x in rows if x["condition"]==cond and x["treatment"]==treat]
        counts=Counter(x["news"] for x in r)
        correct=Counter()
        for x in r:correct[x["news"]]+=x["correct"]
        if any(counts[n]==0 for n in news_ids):
            raise ValueError(f"Empty news item in {cond}|{treat}")
        equal=sum(correct[n]/counts[n] for n in news_ids)/len(news_ids)
        output[f"{cond}|{treat}"]=equal
    return output

def contrasts(a):
    s=lambda i:a[f"social|{i}"]
    n=lambda i:a[f"independent|{i}"]
    return {
      "no_AI_social_minus_independent":s(0)-n(0),
      "AI_before_gain_social":s(1)-s(0),
      "AI_after_gain_social":s(2)-s(0),
      "AI_before_gain_independent":n(1)-n(0),
      "AI_after_gain_independent":n(2)-n(0),
      "AI_before_interaction":(s(1)-s(0))-(n(1)-n(0)),
      "AI_after_interaction":(s(2)-s(0))-(n(2)-n(0))
    }

def cluster_bootstrap(rows, b=1000, seed=20261014, news_ids=range(40)):
    """Exploratory person-arm cluster bootstrap.
    Does not capture social-cascade spillovers across participants.
    """
    rng=random.Random(seed)
    grouped={arm:defaultdict(list) for arm in ARM_ORDER}
    for r in rows:grouped[(r["condition"],r["treatment"])][r["worker"]].append(r)
    people={arm:list(g.values()) for arm,g in grouped.items()}
    draws=defaultdict(list)
    for _ in range(b):
        v={}
        for arm,participants in people.items():
            totals=Counter();success=Counter()
            for i in range(len(participants)):
                group=participants[rng.randrange(len(participants))]
                for r in group:
                    totals[r["news"]]+=1;success[r["news"]]+=r["correct"]
            if any(totals[n]==0 for n in news_ids):
                raise ValueError("Bootstrap arm missing an item; insufficient data")
            v[f"{arm[0]}|{arm[1]}"]=sum(success[n]/totals[n] for n in news_ids)/len(news_ids)
        for k,val in contrasts(v).items():draws[k].append(val)
    def ci(arr):
        z=sorted(arr);return [z[int(.025*b)],z[min(b-1,int(.975*b))]]
    return {k:ci(v) for k,v in draws.items()}

def run(social_path, independent_path, enforce_hash=True, bootstrap=1000, seed=20261014):
    rows=parse_source(social_path,"social",enforce_hash)+parse_source(independent_path,"independent",enforce_hash)
    results={
      "research":"R012","status":"AUTHOR_REAL_DATA_REANALYSIS",
      "provenance":{"repo":SOURCE_REPO,"data_blobs":{k:v[1] for k,v in FILES.items()},
       "sha256":{ "social":hashlib.sha256(social_path.read_bytes()).hexdigest(),
       "independent":hashlib.sha256(independent_path.read_bytes()).hexdigest()}},
      "audit":audit(rows),"variants":{},
      "method_note":"News-equal-weight descriptive standardization; exploratory person-arm cluster bootstrap; NOT randomization inference or proof of contagion."
    }
    for policy in ("all","first_per_worker_news","exclude_ambiguous_and_first"):
        v=variants(rows,policy)
        a=equal_item_accuracy(v)
        results["variants"][policy]={"records":len(v),"news_equal_accuracy":a,"contrasts":contrasts(a)}
    if bootstrap:
        results["exploratory_cluster_bootstrap"]={
         "n_replicates":bootstrap,"seed":seed,
         "intervals":cluster_bootstrap(rows,bootstrap,seed)}
    return results

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--social",type=Path)
    p.add_argument("--independent",type=Path)
    p.add_argument("--fetch",action="store_true")
    p.add_argument("--source-dir",type=Path,default=Path("source"))
    p.add_argument("--no-hash-check",action="store_true",
                   help="Only for local diagnostics; never label changed files as original.")
    p.add_argument("--bootstrap",type=int,default=1000)
    p.add_argument("--seed",type=int,default=20261014)
    p.add_argument("--output",type=Path,default=Path("r012_results.json"))
    args=p.parse_args()
    if args.fetch:fetch_files(args.source_dir)
    a=args.social or args.source_dir/FILES["social"][0]
    b=args.independent or args.source_dir/FILES["independent"][0]
    result=run(a,b,not args.no_hash_check,args.bootstrap,args.seed)
    args.output.write_text(json.dumps(result,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    print(f"R012: {result['audit']['rows']} records; saved {args.output}")

if __name__=="__main__":main()
