#!/usr/bin/env python3
"""R023: independent 10-topic reanalysis from real author-derived aggregate values.

Unit: 10 selected *topics*, not 1,031 independent treatment units.
No source-level identifying/session/browser data are bundled.

Source: Watts-Lab/topic_choice study_data.csv
Git blob: 3156725101f0880277cdb85d775be01cd16d1a9b

Run: python3 r023_analysis.py --input TOPIC_AGGREGATES.csv --output results/R023_RESULTS.json
"""
import argparse
import csv
import itertools
import json
import math
from pathlib import Path

MISSING = ('', 'NA', 'missing')
OUTCOMES = {'outparty_attitude_change': 'affect_mean',
            'discussion_tension': 'tension_mean',
            'speech_words_wave_1_only': 'words_mean',
            'felt_judged_wave_2_only': 'selfjudged_mean'}


def load_topics(file):
    rows = []
    with Path(file).open(encoding='utf-8', newline='') as handle:
        for r in csv.DictReader(handle):
            z = dict(r)
            for key in r:
                if key == 'topic':
                    continue
                if key in ('wave', 'rows', 'dyads', 'pretest_count', 'words_n',
                           'selfjudged_n', 'affect_n', 'tension_n', 'listen_n'):
                    z[key] = int(r[key]) if r[key] not in MISSING else None
                else:
                    z[key] = float(r[key]) if r[key] not in MISSING else None
            rows.append(z)
    return rows


def mean(x):
    return sum(x) / len(x)


def correlation(x, y):
    if len(x) != len(y) or len(x) < 3:
        raise ValueError('correlation requires matching n>=3')
    mx, my = mean(x), mean(y)
    numer = sum((a - mx) * (b - my) for a, b in zip(x, y))
    d1 = sum((a - mx) ** 2 for a in x)
    d2 = sum((b - my) ** 2 for b in y)
    if d1 <= 0 or d2 <= 0:
        raise ValueError('constant variable')
    return numer / math.sqrt(d1 * d2)


def wave_center(rows, x):
    output = list(x)
    for wave in set(r['wave'] for r in rows):
        idx = [i for i, r in enumerate(rows) if r['wave'] == wave]
        m = mean([x[i] for i in idx])
        for i in idx:
            output[i] -= m
    return output


def exact_permutation_test(rows, outcome, stratified=True):
    """Exploratory topic-label exchangeability calibration, NOT design randomization inference."""
    a = [r for r in rows if r['risk'] is not None and r[outcome] is not None]
    x = [r['risk'] for r in a]
    y = [r[outcome] for r in a]
    ystat = wave_center(a, y) if stratified else y
    score = lambda zz: correlation(wave_center(a, zz) if stratified else zz, ystat)
    observed = score(x)
    if stratified:
        groups = [[i for i, r in enumerate(a) if r['wave'] == w]
                  for w in sorted(set(r['wave'] for r in a))]
    else:
        groups = [list(range(len(a)))]
    # The intended analysis is exactly five topics per wave (5! x 5! = 14,400).
    permutations = [list(itertools.permutations(g)) for g in groups]
    count, tail = 0, 0
    for choice in itertools.product(*permutations):
        z = list(x)
        for old_indices, new_indices in zip(groups, choice):
            for target, source in zip(old_indices, new_indices):
                z[target] = x[source]
        value = score(z)
        count += 1
        if abs(value) >= abs(observed) - 1e-12:
            tail += 1
    return dict(n_topics=len(a), observed_r=observed, n_permutations=count,
                n_extreme=tail, tail_fraction=tail / count, stratified=stratified,
                inference='descriptive label-permutation only; not trial randomization p-value')


def solve(A, b):
    """Gaussian elimination with pivoting for a tiny topic-level OLS model."""
    n = len(b)
    mat = [list(map(float, row)) + [float(value)] for row, value in zip(A, b)]
    for j in range(n):
        pivot = max(range(j, n), key=lambda i: abs(mat[i][j]))
        if abs(mat[pivot][j]) < 1e-12:
            raise ValueError('rank deficient topic design')
        mat[j], mat[pivot] = mat[pivot], mat[j]
        k = mat[j][j]
        for c in range(j, n + 1):
            mat[j][c] /= k
        for i in range(n):
            if i != j:
                factor = mat[i][j]
                for c in range(j, n + 1):
                    mat[i][c] -= factor * mat[j][c]
    return [mat[j][-1] for j in range(n)]


def fit_ols(x, y):
    if len(x) <= len(x[0]):
        raise ValueError('insufficient degrees of freedom')
    dim = len(x[0])
    if any(len(row) != dim for row in x):
        raise ValueError('unequal design widths')
    xtx = [[sum(r[i] * r[j] for r in x) for j in range(dim)] for i in range(dim)]
    xty = [sum(r[i] * yy for r, yy in zip(x, y)) for i in range(dim)]
    return solve(xtx, xty)


def design(row):
    return [1.0, 1.0 if row['wave'] == 2 else 0.0,
            row['risk'], row['polarization'], row['contentiousness']]


def adjusted_estimate(rows):
    a = [r for r in rows if all(r[k] is not None for k in
                                ('risk', 'polarization', 'contentiousness', 'affect_mean'))]
    X = [design(r) for r in a]
    Y = [r['affect_mean'] for r in a]
    coefs = fit_ols(X, Y)
    leave_one_out = {}
    for omitted in range(len(a)):
        xx = [v for i, v in enumerate(X) if i != omitted]
        yy = [v for i, v in enumerate(Y) if i != omitted]
        leave_one_out[a[omitted]['topic']] = fit_ols(xx, yy)[2]
    # Residualized Pearson partial r controlling wave, polarization, contentiousness
    Z = [[row[0],row[1],row[3],row[4]] for row in X]
    cx = fit_ols(Z, [r['risk'] for r in a])
    cy = fit_ols(Z, Y)
    rx = [r['risk'] - sum(z*c for z,c in zip(zz,cx)) for r,zz in zip(a,Z)]
    ry = [y - sum(z*c for z,c in zip(zz,cy)) for y,zz in zip(Y,Z)]
    return dict(n_topics=len(a), coefficients=dict(zip(
                    ['intercept','wave2','risk','polarization','contentiousness'],coefs)),
                effect_per_0p1_risk=coefs[2]*.1,
                partial_r=correlation(rx,ry),
                leave_one_topic_out_risk_coefficients=leave_one_out,
                leave_one_topic_out_range=[min(leave_one_out.values()),
                                           max(leave_one_out.values())],
                caveat='exploratory, 10 selected topics, 5 fitted coefficients, no causal identification')


def holm(values):
    """Holm adjusted exploratory fractions; a descriptive safeguard."""
    ordered = sorted(values, key=lambda k: values[k]);m=len(ordered)
    corrected = {};running=0
    for pos,k in enumerate(ordered):
        running=max(running, min(1.0, (m-pos)*values[k]))
        corrected[k]=running
    return corrected


def analyze(rows):
    if len(rows) != 10 or sorted(r['wave'] for r in rows) != [1]*5 + [2]*5:
        raise ValueError('unexpected topic/wave structure')
    if len({r['topic'] for r in rows}) != len(rows):
        raise ValueError('duplicate topic')
    if sum(r['rows'] for r in rows) != 1031 or sum(r['dyads'] for r in rows) != 516:
        raise ValueError('source aggregate row/dyad mismatch')
    if any((r['wave']==1 and r['selfjudged_n']!=0) or
           (r['wave']==2 and r['words_n']!=0) for r in rows):
        raise ValueError('wave-specific missingness assumption changed')
    tests = {
        'attitude_change': exact_permutation_test(rows,'affect_mean',True),
        'discussion_tension': exact_permutation_test(rows,'tension_mean',True),
        'words_wave1': exact_permutation_test(rows,'words_mean',False),
        'felt_judged_wave2': exact_permutation_test(rows,'selfjudged_mean',False),
    }
    p={k:v['tail_fraction'] for k,v in tests.items()}
    for k,v in holm(p).items():
        tests[k]['four_endpoint_holm_adjusted_fraction']=v
    totals = dict(topics=len(rows), participants=sum(r['rows'] for r in rows),
                dyads=sum(r['dyads'] for r in rows),
                participants_wave1=sum(r['rows'] for r in rows if r['wave']==1),
                participants_wave2=sum(r['rows'] for r in rows if r['wave']==2),
                words_measured=sum(r['words_n'] for r in rows),
                judged_measured=sum(r['selfjudged_n'] for r in rows),
                attitude_change_measured=sum(r['affect_n'] for r in rows),
                tension_measured=sum(r['tension_n'] for r in rows))
    return {'round':'R023','source_git_blob_sha':'3156725101f0880277cdb85d775be01cd16d1a9b',
            'source_retrieval':'full raw 1031-person CSV read via GitHub connector; Python recomputes derived 10-topic aggregates only',
            'unit':'selected topic', 'totals':totals,
            'four_exploratory_tests':tests,
            'adjusted_attitude_model':adjusted_estimate(rows),
            'safety':'no participant IDs, raw questionnaires, IPs or device strings included',
            'caveats':['independent pretest sample: not person-level fear',
                       'topic assignment wave confounded; wave labels stratified',
                       'speech counts only first wave; felt-judged only second',
                       'topic selection was purposive; permutation labels are not randomized assignment test',
                       'source raw CSV was not ingested locally; no causal mechanism confirmation']}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,default=Path('TOPIC_AGGREGATES.csv'))
    parser.add_argument('--output',type=Path,default=Path('results/R023_RESULTS.json'))
    args=parser.parse_args()
    result=analyze(load_topics(args.input))
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f"R023: {result['totals']['topics']} topics; {result['totals']['participants']} people; results={args.output}")

if __name__=='__main__':main()
