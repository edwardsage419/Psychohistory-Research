# 心理史学正式研究轮次 R043

研究：De Geest/Kingsley (2021) 在资源不均等及有无惩罚的公共资源实验。首次从独立真人实验公开源文件中完整核验2,880条有向惩罚机会并开展来源一致性与实验场次层级审计。**本地保存的是32组去身份统计，不保存原始CSV。**

运行：`python r043_analysis.py`; `python -m unittest discover -s tests -v`。

文件：`R043_EVIDENCE_AUDIT.md`结论与限制；`R043_SOURCE_DERIVED_32_GROUPS.csv`无个人ID的真实来源聚合；`R043_RESULTS.json`离线复算；`R043_SOURCE_LEDGER.json`原始来源与可复现级别；`r043_analysis.py`离线复算/原始指纹核验；`tests/test_r043.py`42项软件测试；`R044_RESEARCH_GATE.md`下一关；`MASTER_CONTROLLER_v3.4.md`主控台继承版；`CHECKSUMS.sha256`文件清单。

严格限定：不计入第三项独立真人C/D外推实验。因实际随机化日志未取得，以场次为分配单位的置换计算只是额外假设的敏感性审计。PESEN v0.1仍冻结。
