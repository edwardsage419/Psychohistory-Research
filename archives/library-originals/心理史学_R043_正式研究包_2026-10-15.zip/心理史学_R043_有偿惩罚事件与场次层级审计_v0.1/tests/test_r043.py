from __future__ import annotations
import csv
import hashlib
import importlib.util
import tempfile
import unittest
from copy import deepcopy
from pathlib import Path
from unittest.mock import patch

HERE=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('r043_analysis',HERE/'r043_analysis.py')
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
ORIG=a.load_derived(HERE/'R043_SOURCE_DERIVED_32_GROUPS.csv')

class R043Tests(unittest.TestCase):
    def test_shape(self):self.assertEqual(len(ORIG),32)
    def test_arm_counts(self):self.assertEqual({c:sum(x['group'][:2]==c for x in ORIG) for c in ['00','01','10','11']},{c:8 for c in ['00','01','10','11']})
    def test_session_counts(self):self.assertEqual(len(set(r['session'] for r in ORIG)),8)
    def test_source_sha_shape(self):self.assertEqual(len(a.BLOB),40)
    def test_git_hash(self):self.assertEqual(a.sha1_git_blob(b'hello'),hashlib.sha1(b'blob 5\0hello').hexdigest())
    def test_extra_unit_keys(self):self.assertEqual(len(a.HEAD),15)
    def test_read_derived(self):self.assertEqual(a.load_derived(HERE/'R043_SOURCE_DERIVED_32_GROUPS.csv'),ORIG)
    def test_group_count_fails(self):
        with self.assertRaisesRegex(ValueError,'BAD_GROUP_COUNT'):a.validate_derived(ORIG[:-1])
    def test_duplicate_fails(self):
        r=deepcopy(ORIG);r[-1]=r[0]
        with self.assertRaisesRegex(ValueError,'BAD_GROUP_COUNT'):a.validate_derived(r)
    def test_session_collision(self):
        r=deepcopy(ORIG);r[-1]['session']=1;r[-1]['group']='11_1_8'
        with self.assertRaises(ValueError):a.validate_derived(r)
    def test_wrong_window_sum(self):
        r=deepcopy(ORIG);r[0]['early_sum']+=1
        with self.assertRaisesRegex(ValueError,'BAD_WINDOW_SUM'):a.validate_derived(r)
    def test_pun_links(self):
        r=deepcopy(ORIG);j=next(i for i,x in enumerate(r) if x['group'][:2]=='01');r[j]['possible_directed_links']=181
        with self.assertRaisesRegex(ValueError,'BAD_DIRECTED_LINKS'):a.validate_derived(r)
    def test_control_punishment(self):
        r=deepcopy(ORIG);r[0]['punishment_paid']=1
        with self.assertRaisesRegex(ValueError,'CONTROL_HAS_PUNISHMENT'):a.validate_derived(r)
    def test_positive_exceeds_possible(self):
        r=deepcopy(ORIG);j=next(i for i,x in enumerate(r) if x['group'][:2]=='01');r[j]['positive_directed_links']=181
        with self.assertRaisesRegex(ValueError,'BAD_EVENT_COUNT'):a.validate_derived(r)
    def test_overall_people(self):self.assertEqual(a.summarize(ORIG)['sample']['participants'],128)
    def test_overall_links(self):self.assertEqual(a.summarize(ORIG)['sample']['directed_punishment_opportunities'],2880)
    def test_unequal_control(self):self.assertAlmostEqual(a.summarize(ORIG)['arms']['00']['mean_extraction'],15263/480)
    def test_unequal_punishment(self):self.assertAlmostEqual(a.summarize(ORIG)['arms']['01']['mean_extraction'],13833/480)
    def test_equal_control(self):self.assertAlmostEqual(a.summarize(ORIG)['arms']['10']['mean_extraction'],15934/480)
    def test_equal_punishment(self):self.assertAlmostEqual(a.summarize(ORIG)['arms']['11']['mean_extraction'],14158/480)
    def test_unequal_effect(self):self.assertAlmostEqual(a.diff_punishment(ORIG,'0')['punishment_minus_no_punishment'],-1430/480)
    def test_equal_effect(self):self.assertAlmostEqual(a.diff_punishment(ORIG,'1')['punishment_minus_no_punishment'],-1776/480)
    def test_exact_allocation_number(self):self.assertEqual(a.conditional_permutation_4_sessions(ORIG,'0')['permutations'],6)
    def test_exact_p_unequal(self):self.assertAlmostEqual(a.conditional_permutation_4_sessions(ORIG,'0')['hypothetical_two_sided_p'],1/3)
    def test_exact_p_equal(self):self.assertAlmostEqual(a.conditional_permutation_4_sessions(ORIG,'1')['hypothetical_two_sided_p'],1/3)
    def test_session_unit_flag(self):self.assertTrue(a.summarize(ORIG)['session_sensitivity']['equal']['not_actual_randomization_p'])
    def test_data_source_status(self):self.assertFalse(a.summarize(ORIG)['decisions']['causal_mechanism_isolated'])
    def test_frozen(self):self.assertEqual(a.summarize(ORIG)['decisions']['PESEN_v0_1'],'FROZEN')
    def test_received_anomaly_count(self):self.assertEqual(a.summarize(ORIG)['arms']['11']['recipient_discrepancies'],80)
    def test_bad_rounds(self):self.assertEqual(a.summarize(ORIG)['arms']['11']['nonconserving_rounds'],28)
    def test_equal_without_anomalies_unequal(self):self.assertEqual(a.summarize(ORIG)['arms']['01']['recipient_discrepancies'],0)
    def test_total_paid_control_zero(self):self.assertEqual(a.summarize(ORIG)['arms']['00']['sent_cost'],0)
    def test_spent_rule_unequal(self):self.assertEqual(a.summarize(ORIG)['arms']['01']['damage_minus_expected'],0)
    def test_spent_rule_equal_data_anomaly(self):self.assertEqual(a.summarize(ORIG)['arms']['11']['damage_minus_expected'],408)
    def test_target_events(self):self.assertEqual(a.summarize(ORIG)['arms']['11']['positive_targeted_events']+a.summarize(ORIG)['arms']['01']['positive_targeted_events'],853)
    def test_above_below_rate(self):self.assertGreater(a.summarize(ORIG)['arms']['11']['above_target_rate'],a.summarize(ORIG)['arms']['11']['below_target_rate'])
    def test_expected_origin_count(self):self.assertEqual(a.summarize(ORIG)['data_quality']['source_n_implied_by_32_groups'],128)
    def test_group_sessions_distinct(self):
        out=a.session_rows(ORIG);self.assertEqual(len(out),8);self.assertEqual([v['group_count'] for v in out],[4]*8)
    def test_blob_mismatch_fail_closed(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'data.csv';p.write_text('x\ny\n',encoding='utf-8')
            with self.assertRaisesRegex(ValueError,'SOURCE_GIT_BLOB_MISMATCH'):a.parse_source_raw(p)
    def test_synthetic_raw_reordered_self_slots(self):
        # Positive test: complete synthetic 128-person panel, 32 groups, changing self slot each round.
        # This tests parser behavior only, NOT real-source bytes or empirical claims.
        columns=['ProfileID','RoundID','Homo','FF','Session','GameID','Invest','Paid','Received','Seq1','Seq2','Seq3','Seq4']
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'synthetic.csv'
            with p.open('w',encoding='utf-8',newline='') as out:
                w=csv.writer(out);w.writerow(columns)
                for hom,ff,session in [(0,0,1),(0,0,2),(1,0,3),(1,0,4),(0,1,5),(0,1,6),(1,1,7),(1,1,8)]:
                    for grp in range(1,5):
                        for rnd in range(1,17):
                            for j in range(4):
                                seq=['0']*4
                                if ff:seq[(j+rnd)%4]='.'
                                else:seq=['.']*4
                                w.writerow([f'{session}_{grp}_{j}',rnd,hom,ff,session,grp,20+j,0 if ff else '.',0 if ff else '.',*seq])
            with patch.object(a,'sha1_git_blob',return_value=a.BLOB):
                records=a.parse_source_raw(p)
            self.assertEqual(len(records),32)
            self.assertEqual(sum(x['mismatched_recipient_rows'] for x in records),0)
            self.assertEqual(sum(x['possible_directed_links'] for x in records),2880)
            self.assertEqual(sum(x['positive_directed_links'] for x in records),0)
            self.assertEqual(sum(x['extraction_sum'] for x in records),sum((4*20+6)*15 for _ in range(32)))

    def test_synthetic_raw_rejects_fake_sent_cost(self):
        columns=['ProfileID','RoundID','Homo','FF','Session','GameID','Invest','Paid','Received','Seq1','Seq2','Seq3','Seq4']
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'synthetic.csv'
            with p.open('w',encoding='utf-8',newline='') as out:
                w=csv.writer(out);w.writerow(columns)
                for hom,ff,session in [(0,0,1),(0,0,2),(1,0,3),(1,0,4),(0,1,5),(0,1,6),(1,1,7),(1,1,8)]:
                    for grp in range(1,5):
                        for rnd in range(1,17):
                            for j in range(4):
                                seq=['0']*4
                                if ff:seq[(j+rnd)%4]='.'
                                else:seq=['.']*4
                                corrupt = 1 if (session==5 and grp==1 and rnd==2 and j==0) else 0
                                w.writerow([f'{session}_{grp}_{j}',rnd,hom,ff,session,grp,20+j,corrupt if ff else '.',0 if ff else '.',*seq])
            with patch.object(a,'sha1_git_blob',return_value=a.BLOB):
                with self.assertRaisesRegex(ValueError,'SENT_COST_DID_NOT_RECONCILE'):
                    a.parse_source_raw(p)

    def test_bad_derived_schema(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'derived.csv';p.write_text('group,n\nx,1\n')
            with self.assertRaisesRegex(ValueError,'INVALID_DERIVED_SCHEMA'):a.load_derived(p)

if __name__=='__main__':unittest.main()
