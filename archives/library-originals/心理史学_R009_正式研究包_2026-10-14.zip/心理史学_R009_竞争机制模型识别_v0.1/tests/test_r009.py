import sys
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import r009_analysis as m

class TestR009(unittest.TestCase):
    def setUp(self):
        self.rows=m.read_stats()

    def test_trial_counts(self):
        self.assertEqual(len(self.rows),32)
        self.assertEqual(sum(z['n'] for z in self.rows),4019)

    def test_pooled_coefficients(self):
        self.assertAlmostEqual(m.fit(self.rows,'Social')['alpha'],0.5781557740823636,places=8)
        self.assertAlmostEqual(m.fit(self.rows,'Control')['alpha'],0.2872978836888329,places=8)

    def test_round_coefficients(self):
        self.assertAlmostEqual(m.fit(self.rows,'Social',1)['alpha'],0.5881250298793116,places=8)
        self.assertAlmostEqual(m.fit(self.rows,'Control',2)['alpha'],0.1997183526833885,places=8)

    def test_cv_real(self):
        self.assertAlmostEqual(m.loocv(self.rows,'Social'),0.2309094333662928,places=8)
        self.assertAlmostEqual(m.loocv(self.rows,'Control'),0.22031618436775047,places=8)

    def test_leave_stratum(self):
        d=m.analyze(self.rows)['delete_one_stratum']
        self.assertEqual(len(d),8)
        self.assertTrue(all(x>0 for x in d.values()))

    def test_git_blob(self):
        data=b'hello\n'
        import hashlib
        self.assertEqual(m.git_blob_sha(data),hashlib.sha1(b'blob 6\0hello\n').hexdigest())

    def test_no_variation(self):
        with self.assertRaises(ValueError):
            m.fit([{'condition':'Control','n':2,'d2_r1':0.,'de_r1':0.,'e2_r1':1.,'d2_r2':0.,'de_r2':0.,'e2_r2':1.}], 'Control')

if __name__=='__main__':unittest.main()
