#!/usr/bin/env python3
"""R040 external transport test. Run fully offline on source-derived session counts.

By default this reproduces session-level model loss/Brier and sensitivity analysis
WITHOUT pretending to own raw GitHub or Dryad bytes. Supplying --raw FIX RAND
checks Git blob SHA-1, payoff/partner/time integrity and the derived session counts.
"""
import argparse
import csv
import hashlib
import io
import json
import math
import random
from collections import defaultdict
from pathlib import Path

BASE = Path(__file__).resolve().parent
SOURCE_FILE = BASE / 'R040_SOURCE_DERIVED_SESSION_COUNTS.json'
MODELS = ('coin50','frozen_own','frozen_joint','local_own','local_joint','local_arm_joint')
STATES = ('00','01','10','11')


def posterior(n, y):
    if not (isinstance(n, int) and isinstance(y, int) and 0 <= y <= n):
        raise ValueError('invalid binomial sufficient statistics')
    return (y + 0.5) / (n + 1)


def git_blob_sha1(b):
    return hashlib.sha1(b'blob ' + str(len(b)).encode('ascii') + b'\0' + b).hexdigest()


def read_source(path=SOURCE_FILE):
    d = json.loads(Path(path).read_text('utf-8'))
    validate_source(d)
    return d


def add_states(a, b):
    return [[a[i][0] + b[i][0], a[i][1] + b[i][1]] for i in range(4)]


def zeros():
    return [[0,0] for _ in range(4)]


def get_train(sessions):
    return sum_states(x['train'] for x in sessions)


def sum_states(items):
    state=zeros()
    for x in items:
        state=add_states(state,x)
    return state


def collapse_self(data):
    return [[sum(data[i][0] for i in (0,1)),sum(data[i][1] for i in (0,1))],
            [sum(data[i][0] for i in (2,3)),sum(data[i][1] for i in (2,3))]]


def validate_source(d):
    if d['schema'] != 'R040_SESSION_COUNTS_v1':
        raise ValueError('bad schema')
    sessions=d['sessions']
    if len(sessions) != 12 or len({s['id'] for s in sessions}) != 12:
        raise ValueError('not twelve distinct experimental sessions')
    for arm, expected in (('fix',(6,92)),('rand',(6,96))):
        sub=[s for s in sessions if s['arm']==arm]
        if len(sub)!=expected[0] or sum(s['people'] for s in sub)!=expected[1]:
            raise ValueError('arm/session/people count mismatch')
    for s in sessions:
        p=s['people']
        if p<=0 or len(s['train'])!=4 or len(s['test'])!=4:
            raise ValueError('invalid session')
        for field,n in [('train',24*p),('test',25*p)]:
            a=s[field]
            for x in a:
                if len(x)!=2 or not all(isinstance(y,int) for y in x) or not 0<=x[1]<=x[0]:
                    raise ValueError('invalid cell')
            if sum(x[0] for x in a)!=n:
                raise ValueError('rounds/units do not reconcile')
            # Both players in every observed PD pair: marginal joint self/peer state symmetry.
            if a[1][0]!=a[2][0]:
                raise ValueError('each session must contain reciprocal partner state exposures')
    if d['source_checks']['reciprocal_pair_action_matches']!=18800:
        raise ValueError('reciprocity coverage source ledger inconsistent')
    if sum(s['people'] for s in sessions)!=188:
        raise ValueError('missing people')
    if sum(sum(v[0] for v in s['test']) for s in sessions)!=4700:
        raise ValueError('missing tests')
    return True


def parameters(d):
    src=d['source_train_counts']['joint']
    own=d['source_train_counts']['own']
    for state,i in zip(STATES, range(4)):
        if not 0 <= src[state][1] <= src[state][0]:
            raise ValueError('bad frozen data')
    if [sum(src[k][i] for k in ('00','01')) for i in (0,1)]!=own['0']:
        raise ValueError('frozen own0 counts mismatch')
    if [sum(src[k][i] for k in ('10','11')) for i in (0,1)]!=own['1']:
        raise ValueError('frozen own1 counts mismatch')
    fixed_own=[posterior(*own['0'])]*2+[posterior(*own['1'])]*2
    fixed_joint=[posterior(*src[k]) for k in STATES]
    local=get_train(d['sessions'])
    local_own=collapse_self(local)
    arms={k:get_train([s for s in d['sessions'] if s['arm']==k]) for k in ('fix','rand')}
    return {
        'coin50':[.5]*4,
        'frozen_own':fixed_own,'frozen_joint':fixed_joint,
        'local_own':[posterior(*local_own[0])]*2+[posterior(*local_own[1])]*2,
        'local_joint':[posterior(*k) for k in local],
        'local_arm_joint':{arm:[posterior(*k) for k in armtrain] for arm,armtrain in arms.items()},
    }


def score_cells(cells, prob):
    if len(cells)!=4 or len(prob)!=4:
        raise ValueError('bad state dimensions')
    n=y=0; loss=brier=pred=0.0
    for (m,k),p in zip(cells,prob):
        if not 0<p<1: raise ValueError('probability must be interior')
        n+=m;y+=k
        loss+=-k*math.log(p)-(m-k)*math.log1p(-p)
        brier+=k*(1-p)**2+(m-k)*p**2
        pred+=m*p
    if n==0:raise ValueError('no observations')
    return {'n':n,'cooperations':y,'loss_sum':loss,'brier_sum':brier,'pred_sum':pred,
            'logloss':loss/n,'brier':brier/n,'pred_rate':pred/n,'actual_rate':y/n}


def score_all(d):
    probs=parameters(d)
    rows=[]
    for s in d['sessions']:
        models={m:score_cells(s['test'],probs[m][s['arm']] if m=='local_arm_joint' else probs[m]) for m in MODELS}
        rows.append({'session':s['id'],'arm':s['arm'],'people':s['people'], 'models':models})
    def aggregate(xs):
        total=sum(x['models']['coin50']['n'] for x in xs)
        y=sum(x['models']['coin50']['cooperations'] for x in xs)
        out={'n':total,'cooperations':y,'observed_rate':y/total,'models':{}}
        for m in MODELS:
            out['models'][m]={
                'logloss':sum(x['models'][m]['loss_sum'] for x in xs)/total,
                'brier':sum(x['models'][m]['brier_sum'] for x in xs)/total,
                'pred_rate':sum(x['models'][m]['pred_sum'] for x in xs)/total,
            }
        return out
    return {'pooled':aggregate(rows),'by_arm':{k:aggregate([s for s in rows if s['arm']==k]) for k in ('fix','rand')},'by_session':rows,'parameters':probs}


def session_bootstrap(rows, repeats=25000, seed=4040):
    if repeats<100 or len(rows)!=12:raise ValueError('invalid resampling specification')
    arms={k:[x for x in rows if x['arm']==k] for k in ('fix','rand')}
    if any(len(v)!=6 for v in arms.values()):raise ValueError('not six sessions per arm')
    def weighted(rows):
        num=sum(x['models']['frozen_joint']['loss_sum']-x['models']['frozen_own']['loss_sum'] for x in rows)
        n=sum(x['models']['frozen_joint']['n'] for x in rows)
        return num/n
    r=random.Random(seed)
    values={'fix':[],'rand':[],'interaction_fix_minus_rand':[]}
    for i in range(repeats):
        results={}
        for arm,xs in arms.items():
            resampled=[xs[r.randrange(len(xs))] for _ in xs]
            results[arm]=weighted(resampled)
            values[arm].append(results[arm])
        values['interaction_fix_minus_rand'].append(results['fix']-results['rand'])
    out={}
    for key,arr in values.items():
        arr.sort()
        out[key]={'ci95':[arr[int(.025*repeats)],arr[int(.975*repeats)]]}
    out['fix']['observed']=weighted(arms['fix'])
    out['rand']['observed']=weighted(arms['rand'])
    out['interaction_fix_minus_rand']['observed']=out['fix']['observed']-out['rand']['observed']
    return out


def verify_raw_pair(fix,rand,d):
    """Strict opt-in byte-verified source audit, including reciprocal pair and payoff."""
    outputs={};derived={}
    for label,path in [('fix',fix),('rand',rand)]:
        b=Path(path).read_bytes()
        info=next(x for x in d['source']['files'] if x['name']==label+'.csv')
        if git_blob_sha1(b)!=info['blob_sha1'] or len(b)!=info['bytes']:
            raise ValueError('raw bytes do not match frozen author GitHub blob')
        rows=list(csv.DictReader(io.StringIO(b.decode('utf-8-sig'))))
        for col in ('round','player','action_player','opponent','action_opponent','session','payoff','prev','treatment'):
            if col not in rows[0]:raise ValueError('required raw field missing '+col)
        if len(rows)!=info['rows']:raise ValueError('raw row count mismatch')
        byid=defaultdict(list);bykey={};
        for z in rows:
            rnd=int(z['round']);who=z['player'];sess=z['session'];x=z['action_player'];y=z['action_opponent'];peer=z['opponent']
            if x not in ('C','D') or y not in ('C','D') or z['treatment']!=label:
                raise ValueError('invalid action/treatment')
            exp={("C","C"):3,("C","D"):0,("D","C"):4,("D","D"):1}[(x,y)]
            if int(z['payoff'])!=exp:raise ValueError('payoff violation')
            byid[who].append(z)
            if (sess,rnd,who) in bykey:raise ValueError('duplicate participant/round')
            bykey[(sess,rnd,who)]=z
        nrec=0
        for (sess,rnd,who),z in bykey.items():
            other=bykey.get((sess,rnd,z['opponent']))
            if other is None or other['opponent']!=who or other['action_player']!=z['action_opponent'] or other['action_opponent']!=z['action_player']:
                raise ValueError('reciprocal partnership/choice inconsistent')
            nrec+=1
        sessions={}
        for pid,sequence in byid.items():
            sequence.sort(key=lambda z:int(z['round']))
            if len(sequence)!=100 or [int(z['round']) for z in sequence]!=list(range(1,101)):
                raise ValueError('missing per-person rounds')
            sess=sequence[0]['session'];x=sessions.setdefault(sess,{'people':0,'train':zeros(),'test':zeros()})
            x['people']+=1
            for i in range(1,100):
                prior=sequence[i-1];cur=sequence[i]
                if cur['prev'] != prior['action_player']+prior['action_opponent']:
                    raise ValueError('claimed lag state mismatch')
                st=(prior['action_player']=='C')*2+(prior['action_opponent']=='C')
                y=int(cur['action_player']=='C')
                if i<=24:
                    x['train'][st][0]+=1;x['train'][st][1]+=y
                if i>=75:
                    x['test'][st][0]+=1;x['test'][st][1]+=y
        for sid,computed in sessions.items():
            stored=next((s for s in d['sessions'] if s['id']==sid and s['arm']==label),None)
            if stored is None or any(stored[k]!=computed[k] for k in ('people','train','test')):
                raise ValueError('local raw CSV does not reproduce source session sufficient counts')
        if len(sessions)!=6 or len(byid)!=info['players']:
            raise ValueError('session/player count mismatch')
        outputs[label]={'bytes':len(b),'rows':len(rows),'players':len(byid),'sessions':len(sessions),'reciprocal_rows':nrec,'sha1':info['blob_sha1']}
    return outputs


def main(argv=None):
    p=argparse.ArgumentParser()
    p.add_argument('--raw',nargs=2,metavar=('FIX_CSV','RAND_CSV'))
    p.add_argument('--output',type=Path)
    args=p.parse_args(argv)
    d=read_source()
    results=score_all(d)
    results['session_bootstrap_exploratory_95']=session_bootstrap(results['by_session'])
    results['raw_author_github_byte_verified']=False
    if args.raw:
        results['raw_verification']=verify_raw_pair(*args.raw,d)
        results['raw_author_github_byte_verified']=True
    results['dryad_original_byte_verified']=False
    results['notes']=['GitHub author processed CSV; original Dryad file bytes NOT obtained',
        'R039 frozen model transport is the primary cross-study comparison',
        'Local fitted models use early target-study training periods and are secondary',
        'Mixed dyad dependence; session bootstrap is exploratory with only 6 sessions/arm',
        'No independent social punishment pressure measurement or causal mechanism identification']
    target=args.output
    payload=json.dumps(results,ensure_ascii=False,indent=2,sort_keys=True)
    if target:target.write_text(payload+'\n',encoding='utf-8')
    else:
        agg=results['pooled']; fix=results['by_arm']['fix'];rand=results['by_arm']['rand'];boot=results['session_bootstrap_exploratory_95']
        print(f"R040_COMPLETED: n={agg['n']} pooled_own={agg['models']['frozen_own']['logloss']:.6f} pooled_joint={agg['models']['frozen_joint']['logloss']:.6f}")
        print(f"FIX Δ={boot['fix']['observed']:.6f} RAND Δ={boot['rand']['observed']:.6f} interaction CI={boot['interaction_fix_minus_rand']['ci95']}")
        print('AUTHOR_GITHUB_RAW_BYTES_LOCAL='+('YES' if args.raw else 'NO'))

if __name__=='__main__':main()
