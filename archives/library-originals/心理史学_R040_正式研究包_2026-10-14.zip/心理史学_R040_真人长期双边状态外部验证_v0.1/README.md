# 心理史学 R040 正式研究包

研究主题：**已冻结上一轮行为状态模型在另一组真人—真人100轮囚徒困境实验中的跨研究迁移，区分固定与更换对手环境。**

## 文件

- `R040_EVIDENCE_AUDIT.md`：正式实证、识别、测量等值和限制审计。
- `R040_SOURCE_LEDGER.json`：作者GitHub文件哈希、处理/原始来源级别。
- `R040_SOURCE_DERIVED_SESSION_COUNTS.json`：源文件连接器实际读取后形成的**12个场次**无个人标识训练/测试充分统计。
- `r040_analysis.py`：纯标准库Python分析与原始字节准入校验。
- `R040_RESULTS.json`：可离线复算的数值、每场次预测指标和bootstrap。
- `tests/test_r040.py`：40项本地测试。
- `R041_RESEARCH_GATE.md`：下轮证据关口。
- `CHECKSUMS.sha256`：本包内容摘要（不含自身）。

## 运行

```bash
python r040_analysis.py
python r040_analysis.py --output my_results.json
python -m unittest discover -s tests -v
```

如另行从作者 GitHub 获取准确的 `fix.csv`、`rand.csv` 文件，可以严格核对 Git blob SHA1、字节数、实验字段、双方配对及汇总：

```bash
python r040_analysis.py --raw /path/to/fix.csv /path/to/rand.csv
```

**不要把Dryad另一版本的同名文件直接传给此哈希校验器并在失败时推断伪造。** GitHub CSV含额外预处理列，两处版本的原始字节一致性未确认。

研究未改变PESEN v0.1。软件测试通过不代表行为因果机制得到识别，也不代表已本地取得原始CSV全部字节。真正的新外部样本为188人，**不是**新增188名研究志愿者的招募。
