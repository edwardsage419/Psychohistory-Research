import copy
import json
import math
import tempfile
import unittest
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import r040_analysis as m

class TestR040Source(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.src=m.read_source()
        cls.scored=m.score_all(cls.src)
    def test_01_schema(self):self.assertTrue(m.validate_source(self.src))
    def test_02_sessions(self):self.assertEqual(len(self.src['sessions']),12)
    def test_03_participants(self):self.assertEqual(sum(s['people'] for s in self.src['sessions']),188)
    def test_04_arm_counts(self):self.assertEqual([sum(s['people'] for s in self.src['sessions'] if s['arm']==a) for a in ('fix','rand')],[92,96])
    def test_05_train_transitions(self):self.assertEqual(sum(x[0] for x in m.get_train(self.src['sessions'])),4512)
    def test_06_test_units(self):self.assertEqual(self.scored['pooled']['n'],4700)
    def test_07_real_test_cooperation(self):self.assertEqual(self.scored['pooled']['cooperations'],2034)
    def test_08_fix_test(self):self.assertEqual(self.scored['by_arm']['fix']['n'],2300)
    def test_09_rand_test(self):self.assertEqual(self.scored['by_arm']['rand']['n'],2400)
    def test_10_missing_session_reject(self):
        d=copy.deepcopy(self.src);d['sessions'].pop()
        with self.assertRaises(ValueError):m.validate_source(d)
    def test_11_swap_arm_reject(self):
        d=copy.deepcopy(self.src);d['sessions'][0]['arm']='rand'
        with self.assertRaises(ValueError):m.validate_source(d)
    def test_12_wrong_test_units_reject(self):
        d=copy.deepcopy(self.src);d['sessions'][0]['test'][0][0]+=1
        with self.assertRaises(ValueError):m.validate_source(d)
    def test_13_wrong_partner_exposures_reject(self):
        d=copy.deepcopy(self.src);d['sessions'][0]['test'][1][0]+=1;d['sessions'][0]['test'][0][0]-=1
        with self.assertRaises(ValueError):m.validate_source(d)
    def test_14_binomial_bound_reject(self):
        d=copy.deepcopy(self.src);d['sessions'][0]['test'][0][1]=999
        with self.assertRaises(ValueError):m.validate_source(d)
    def test_15_frozen_source_counts_check(self):
        d=copy.deepcopy(self.src);d['source_train_counts']['joint']['00'][0]+=1
        with self.assertRaises(ValueError):m.parameters(d)

class TestR040Calculations(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.d=m.read_source();cls.results=m.score_all(cls.d)
    def test_16_posterior_halves(self):self.assertAlmostEqual(m.posterior(0,0),.5)
    def test_17_posterior_invalid(self):
        for a,b in ((-1,0),(1,2),(1,-1),(1.2,0)):
            with self.assertRaises(ValueError):m.posterior(a,b)
    def test_18_frozen_joint_probs(self):self.assertAlmostEqual(m.parameters(self.d)['frozen_joint'][3],436.5/480)
    def test_19_frozen_own_probs(self):self.assertAlmostEqual(m.parameters(self.d)['frozen_own'][0],135.5/558)
    def test_20_source_fixed(self):
        a=self.results['by_arm']['fix']['models'];self.assertAlmostEqual(a['frozen_joint']['logloss'],0.29738426207131935,places=12)
    def test_21_source_rand(self):
        a=self.results['by_arm']['rand']['models'];self.assertAlmostEqual(a['frozen_joint']['logloss'],0.4966557841233571,places=12)
    def test_22_frozen_own(self):self.assertAlmostEqual(self.results['pooled']['models']['frozen_own']['logloss'],0.40623371546452697,places=12)
    def test_23_frozen_joint(self):self.assertAlmostEqual(self.results['pooled']['models']['frozen_joint']['logloss'],0.39913993290640243,places=12)
    def test_24_late_local_joint(self):self.assertAlmostEqual(self.results['pooled']['models']['local_joint']['logloss'],0.370309559865203,places=12)
    def test_25_local_arm(self):self.assertAlmostEqual(self.results['pooled']['models']['local_arm_joint']['logloss'],0.3589849419204514,places=12)
    def test_26_source_Brier_switch(self):
        b=self.results['pooled']['models'];self.assertGreater(b['frozen_joint']['brier'],b['frozen_own']['brier'])
    def test_27_arm_direction(self):
        a=self.results['by_arm'];self.assertLess(a['fix']['models']['frozen_joint']['logloss'],a['fix']['models']['frozen_own']['logloss']);self.assertGreater(a['rand']['models']['frozen_joint']['logloss'],a['rand']['models']['frozen_own']['logloss'])
    def test_28_score_cooperation(self):self.assertAlmostEqual(self.results['pooled']['observed_rate'],2034/4700)
    def test_29_logloss_manual(self):self.assertAlmostEqual(m.score_cells([[1,1],[0,0],[0,0],[0,0]],[.8,.5,.5,.5])['logloss'],-math.log(.8))
    def test_30_logloss_reject_zero(self):
        with self.assertRaises(ValueError):m.score_cells([[1,1],[0,0],[0,0],[0,0]],[0,.5,.5,.5])
    def test_31_session_resample_repeat(self):
        r=m.session_bootstrap(self.results['by_session'],repeats=500,seed=40)
        q=m.session_bootstrap(self.results['by_session'],repeats=500,seed=40)
        self.assertEqual(r,q)
    def test_32_session_resample_interval(self):
        r=m.session_bootstrap(self.results['by_session'],repeats=500,seed=40)
        self.assertLess(r['fix']['ci95'][1],0)
        self.assertGreater(r['rand']['ci95'][0],-0.1)
    def test_33_blob_sha(self):self.assertEqual(m.git_blob_sha1(b'hello'),'b6fc4c620b67d95f953a5c1c1230aaab5db5a1b0')
    def test_34_modified_raw_reject(self):
        with tempfile.TemporaryDirectory() as td:
            f=Path(td)/'fix.csv';g=Path(td)/'rand.csv';f.write_bytes(b'no');g.write_bytes(b'no')
            with self.assertRaises(ValueError):m.verify_raw_pair(f,g,self.d)
    def test_35_missing_raw_reject(self):
        with self.assertRaises(FileNotFoundError):m.verify_raw_pair('/bad/nofile','/bad/no2',self.d)
    def test_36_blank_schema_reject(self):
        d=copy.deepcopy(self.d);d['schema']='unknown'
        with self.assertRaises(ValueError):m.validate_source(d)
    def test_37_zeros_state(self):self.assertEqual(m.zeros(),[[0,0]]*4)
    def test_38_local_own(self):self.assertAlmostEqual(self.results['pooled']['models']['local_own']['logloss'],0.42230952759034734,places=12)
    def test_39_valid_sessions(self):self.assertEqual({x['session'] for x in self.results['by_session']},{s['id'] for s in self.d['sessions']})
    def test_40_source_has_local_bytes_false_default(self):self.assertEqual(self.d['source']['status'],'AUTHOR_GITHUB_PROCESSED_CSV_NOT_DRYAD_BYTE_VERIFIED')

if __name__=='__main__':unittest.main()
