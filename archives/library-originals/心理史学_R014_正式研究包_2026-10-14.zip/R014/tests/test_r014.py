import unittest
from datetime import datetime, timezone
from pathlib import Path
from tempfile import TemporaryDirectory
from r014_audit import audit_condition, quantile, analyze
from r013_analysis import parse_exp_time, PREREG_UTC, SOURCES

class R014Tests(unittest.TestCase):
    def make(self,worker,arm,news,stamp,condition='social',initial=1,final=1):
        return dict(condition=condition,worker=worker,arm=arm,news=news,time=stamp,initial=initial,final=final)
    def test_local_timezone(self):
        t=parse_exp_time('Fri Dec 24 2021 10:39:20 GMT-0500 (EST)')
        self.assertEqual(t.isoformat(),'2021-12-24T15:39:20+00:00')
    def test_positive_offset(self):
        t=parse_exp_time('Fri Dec 24 2021 18:39:20 GMT+0800 (CST)')
        self.assertEqual(t.isoformat(),'2021-12-24T10:39:20+00:00')
    def test_prereg_cutoff(self):
        self.assertEqual(PREREG_UTC.isoformat(),'2021-12-27T03:59:00+00:00')
    def test_quantile(self):
        self.assertEqual(quantile([3,4,5,1,2],.5),3)
        self.assertIsNone(quantile([],.5))
    def test_pre_post(self):
        r=[self.make('a',0,1,'Fri Dec 24 2021 10:39:20 GMT-0500 (EST)'),
           self.make('a',0,2,'Fri Dec 24 2021 10:40:20 GMT-0500 (EST)'),
           self.make('b',1,1,'Tue Dec 28 2021 10:39:20 GMT-0500 (EST)')]
        x=audit_condition(r,'social')
        self.assertEqual((x['before_preregistration'],x['after_preregistration']),(2,1))
        self.assertEqual(x['before_by_treatment']['0'],2)
    def test_crossing_and_ambiguous(self):
        r=[self.make('a',0,1,'Fri Dec 24 2021 10:39:20 GMT-0500 (EST)'),
           self.make('a',1,2,'Tue Dec 28 2021 10:39:20 GMT-0500 (EST)')]
        x=audit_condition(r,'social')
        self.assertEqual(x['n_worker_ids_in_multiple_treatments'],1)
        self.assertEqual(x['n_workers_crossing_registration_time'],1)
        self.assertEqual(x['multiple_treatment_and_registration_crossing_overlap'],1)
    def test_duplicate_conflict(self):
        a=self.make('a',0,1,'Fri Dec 24 2021 10:39:20 GMT-0500 (EST)')
        b={**a,'final':-1}
        x=audit_condition([a,b],'social')
        self.assertEqual(x['n_duplicate_composite_extra_rows'],1)
        self.assertEqual(x['n_duplicate_composite_discordant_behavior_keys'],1)
    def test_independent_ids_separate(self):
        r=[self.make('a',0,1,'Fri Dec 24 2021 10:39:20 GMT-0500 (EST)',condition='independent')]
        x=audit_condition(r,'independent')
        self.assertEqual(x['n_unique_worker_ids'],1)
    def test_no_source_no_success(self):
        with TemporaryDirectory() as d:
            with self.assertRaises(FileNotFoundError):analyze(Path(d))
    def test_bad_time_fails(self):
        with self.assertRaises(ValueError):audit_condition([self.make('a',0,1,'not a time')],'social')
    def test_clock_order_not_lexical(self):
        t1=parse_exp_time('Fri Dec 24 2021 12:00:00 GMT+0800 (CST)')
        t2=parse_exp_time('Fri Dec 24 2021 01:00:00 GMT-0500 (EST)')
        self.assertLess(t1,t2)

if __name__=='__main__':unittest.main()
