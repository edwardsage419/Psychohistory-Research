"""R014 provenance/time audit. Requires R013 parser + original author CSVs.

Run from this folder:
  python r014_audit.py --source-dir source --output results.json
  python r013_analysis.py --fetch --source-dir source   # on a networked machine
No source data is redistributed here. Do not interpret an anomaly as misconduct.
"""
from collections import defaultdict, Counter
from datetime import timezone
from pathlib import Path
from statistics import median
import argparse, json, hashlib
from r013_analysis import SOURCES, read_csv, git_sha, parse_exp_time, PREREG_UTC

PAPER_N = {'social':622,'independent':476}
PINNED_DATA_COMMIT = 'de9b7714a7084f9891bbb41c644e3bc936554405'


def quantile(values,p):
    x=sorted(values)
    return x[min(len(x)-1,int(p*len(x)))] if x else None


def audit_condition(rows, condition):
    rs=[r for r in rows if r['condition']==condition]
    if not rs: raise ValueError('no rows for '+condition)
    per_person=defaultdict(list)
    keys=defaultdict(list)
    for r in rs:
        stamp=parse_exp_time(r['time'])
        if stamp is None: raise ValueError('unparseable time: '+str(r['time']))
        r['_utc']=stamp
        per_person[r['worker']].append(r)
        keys[(r['worker'],r['arm'],r['news'])].append(r)
    early=[r for r in rs if r['_utc']<PREREG_UTC]
    late=[r for r in rs if r['_utc']>=PREREG_UTC]
    ambiguous={w for w,x in per_person.items() if len(set(r['arm'] for r in x))>1}
    crossover={w for w,x in per_person.items() if any(r['_utc']<PREREG_UTC for r in x) and any(r['_utc']>=PREREG_UTC for r in x)}
    spans=[]; gaps=[]
    for x in per_person.values():
        times=sorted(r['_utc'] for r in x)
        spans.append((times[-1]-times[0]).total_seconds()/60)
        if len(times)>=4:
            gaps.append(median((times[i]-times[i-1]).total_seconds()/60 for i in range(1,len(times))))
    stamps=sorted(r['_utc'] for r in rs)
    return {
        'n_records':len(rs), 'first_timestamp_utc':stamps[0].isoformat(), 'last_timestamp_utc':stamps[-1].isoformat(),
        'before_preregistration':len(early),'after_preregistration':len(late),
        'before_percent':100*len(early)/len(rs),
        'before_by_treatment':{str(t):sum(r['arm']==t for r in early) for t in (0,1,2)},
        'after_by_treatment':{str(t):sum(r['arm']==t for r in late) for t in (0,1,2)},
        'n_unique_worker_ids':len(per_person), 'matches_paper_subject_count':len(per_person)==PAPER_N[condition],
        'n_worker_ids_with_early_records':sum(any(r['_utc']<PREREG_UTC for r in x) for x in per_person.values()),
        'n_worker_ids_with_late_records':sum(any(r['_utc']>=PREREG_UTC for r in x) for x in per_person.values()),
        'n_workers_crossing_registration_time':len(crossover),
        'n_worker_ids_in_multiple_treatments':len(ambiguous),
        'multiple_treatment_and_registration_crossing_overlap':len(crossover&ambiguous),
        'ambiguous_worker_ids':sorted(ambiguous),
        'n_duplicate_composite_extra_rows':sum(len(x)-1 for x in keys.values()),
        'n_duplicate_composite_discordant_behavior_keys':sum(len(set((r['initial'],r['final']) for r in x))>1 for x in keys.values()),
        'worker_task_span_minutes_p10_p50_p90':[quantile(spans,p) for p in (.1,.5,.9)],
        'within_worker_median_gap_minutes_p10_p50_p90':[quantile(gaps,p) for p in (.1,.5,.9)],
    }


def analyze(root,verify=True):
    output={
      'study':'Lu et al. (2022), Experiment 2',
      'preregistration':'https://aspredicted.org/rh32h.pdf',
      'pre_registration_time_utc':PREREG_UTC.isoformat(),
      'commit_that_first_uploaded_both_csv':'https://github.com/ZhuoranLu/Misinformation/commit/'+PINNED_DATA_COMMIT,
      'commit_created_at_utc':'2023-09-03T00:42:47Z',
      'source_checksums':{},'data':{},
      'evidence_level':'public raw files accessed; chronology/identity concerns unresolved, no formal causal or mechanism inference'
    }
    rs=[]
    for condition,(name,pinned) in SOURCES.items():
        raw=(root/name).read_bytes()
        sha=git_sha(raw)
        if verify and sha!=pinned:raise ValueError('SOURCE_BLOB_MISMATCH: '+name)
        output['source_checksums'][condition]={'git_blob_sha1':sha,'sha256':hashlib.sha256(raw).hexdigest()}
        rs+=read_csv(root/name,condition,verify=verify)
    for condition in SOURCES:output['data'][condition]=audit_condition(rs,condition)
    a,b=(output['data'][x] for x in ('social','independent'))
    output['combined']={'n_records':a['n_records']+b['n_records'],'before_registration':a['before_preregistration']+b['before_preregistration']}
    output['combined']['fraction_before_registration']=output['combined']['before_registration']/output['combined']['n_records']
    return output


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source-dir',type=Path,default=Path('source'))
    p.add_argument('--output',type=Path,default=Path('results.json'))
    p.add_argument('--allow-changed-source',action='store_true',help='diagnostics only; removes published data provenance guarantee')
    a=p.parse_args()
    result=analyze(a.source_dir,not a.allow_changed_source)
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print('R014',result['combined'])

if __name__=='__main__':main()
