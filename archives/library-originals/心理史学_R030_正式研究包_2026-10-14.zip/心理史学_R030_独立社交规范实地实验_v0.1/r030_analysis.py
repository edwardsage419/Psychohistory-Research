#!/usr/bin/env python3
"""R030: Author-source-locked reanalysis of Munger 2017 subject-level aggregated RCT data.

No participant text or handles are ingested. Offline by default. To download public
anonymized CSVs from author GitHub, pass --download. All incoming bytes are checked
against the source Git blob hashes before analytical use. This is exploratory auditing;
it does not identify psychological sanction mechanisms or certify the original RCT.
"""
import argparse
import csv
import hashlib
import io
import json
import math
import os
import pathlib
import tempfile
from urllib.request import urlopen

import numpy as np
import statsmodels.api as sm
from scipy import stats
from statsmodels.stats.multitest import multipletests

ROOT = pathlib.Path(__file__).resolve().parent
REPO = 'kmunger/Replication-Materials-for-Tweetment-Effects-on-the-Tweeted'
SOURCE = {
    'standard': {
        'filename': 'data_anonymized_standard_assumption.csv',
        'git_blob': 'fee75567431840cd0b69014899413475ee424eaf',
    },
    'conservative': {
        'filename': 'data_anonymized_conservative_assumption.csv',
        'git_blob': '38610107dad072c1369d5ad997a24fff4f07bb7e',
    },
}
HORIZONS = {'week_1': 'racism.scores.post.1wk',
            'week_2': 'racism.scores.post.2wk',
            'month_1': 'racism.scores.post.1mon',
            'month_2': 'racism.scores.post.2mon'}
BASELINE = 'racism.scores.pre.2mon'
FOLLOWERS = 'log.followers'
# The treatment mapping is verified against both In_group and high_followers
# rather than silently trusting an integer code in the source file.
ARM_CODES = {
    0: (0, 0, 'control'),
    1: (1, 0, 'ingroup_low'),
    2: (0, 0, 'outgroup_low'),
    3: (1, 1, 'ingroup_high'),
    4: (0, 1, 'outgroup_high'),
}
REQUIRED = {'X', 'treat.f', 'In_group', 'high_followers', 'anonymity',
            FOLLOWERS, BASELINE, *HORIZONS.values()}


def git_blob_sha(data: bytes) -> str:
    return hashlib.sha1(b'blob ' + str(len(data)).encode('ascii') + b'\0' + data).hexdigest()


def verify_source(data: bytes, expected_git_blob: str) -> None:
    actual = git_blob_sha(data)
    if actual != expected_git_blob:
        raise ValueError('Source integrity mismatch: expected Git blob %s, found %s' %
                         (expected_git_blob, actual))


def parse_rows(data: bytes):
    reader = csv.DictReader(io.StringIO(data.decode('utf-8-sig')))
    if not REQUIRED.issubset(reader.fieldnames or []):
        raise ValueError('Required source columns missing: %s' %
                         sorted(REQUIRED - set(reader.fieldnames or [])))
    rows = list(reader)
    if not rows:
        raise ValueError('Empty analytic source')
    ids = []
    for x in rows:
        t = int(x['treat.f'])
        if t not in ARM_CODES:
            raise ValueError('Unexpected treatment %s' % t)
        ingroup, high, _ = ARM_CODES[t]
        if int(x['In_group']) != ingroup or int(x['high_followers']) != high:
            raise ValueError('Treatment encoding inconsistent with factorial flags')
        anonymous = int(x['anonymity'])
        if anonymous not in (0, 1, 2):
            raise ValueError('Unexpected anonymity score')
        ids.append(x['X'])
        for c in (FOLLOWERS, *HORIZONS.values()):
            v = float(x[c])
            if not math.isfinite(v):
                raise ValueError('Nonfinite measured value: %s' % c)
        b = x[BASELINE]
        if b not in ('NA', '') and not math.isfinite(float(b)):
            raise ValueError('Unexpected baseline')
    if len(set(ids)) != len(ids):
        raise ValueError('Duplicated source row keys')
    return rows


def complete_rows(rows):
    return [r for r in rows if r[BASELINE] not in ('', 'NA')]


def group_counts(rows):
    return {str(t): sum(int(x['treat.f']) == t for x in rows) for t in ARM_CODES}


def make_x(rows):
    return np.asarray([[1.0] + [float(int(r['treat.f']) == t) for t in (1, 2, 3, 4)]
                       + [float(r[FOLLOWERS]), float(r[BASELINE])] for r in rows])


def fit_arms(rows, outcome, winsor_q=None):
    good = complete_rows(rows)
    if len(good) < 10:
        raise ValueError('Insufficient complete rows')
    x = make_x(good)
    y = np.asarray([float(r[outcome]) for r in good])
    cutoff = None
    if winsor_q is not None:
        cutoff = float(np.quantile(y, winsor_q, method='lower'))
        y = np.minimum(y, cutoff)
    model = sm.OLS(y, x).fit()
    robust = model.get_robustcov_results(cov_type='HC3', use_t=True)
    return {'n': len(good), 'df_resid': int(model.df_resid),
            'coefficients': [float(v) for v in model.params],
            'se_classical': [float(v) for v in model.bse],
            'se_HC3': [float(v) for v in robust.bse],
            'p_classical': [float(v) for v in model.pvalues],
            'p_HC3_t': [float(v) for v in robust.pvalues],
            'treatment_3_95ci_classical': [float(v) for v in model.conf_int()[3]],
            'treatment_3_95ci_HC3': [float(v) for v in robust.conf_int()[3]],
            'winsor_threshold': cutoff}


def fit_treated_factorial(rows, outcome):
    good = [r for r in complete_rows(rows) if int(r['treat.f']) in (1, 2, 3, 4)]
    x = np.asarray([[1.0, float(r['In_group']), float(r['high_followers']),
                     float(r['In_group']) * float(r['high_followers']),
                     float(r[FOLLOWERS]), float(r[BASELINE])] for r in good])
    y = np.asarray([float(r[outcome]) for r in good])
    model = sm.OLS(y, x).fit()
    hc3 = model.get_robustcov_results(cov_type='HC3', use_t=True)
    return {'n': len(good), 'interaction': float(model.params[3]),
            'se_classical': float(model.bse[3]), 'se_HC3': float(hc3.bse[3]),
            'p_interaction_classical': float(model.pvalues[3]),
            'p_interaction_HC3': float(hc3.pvalues[3])}


def fit_group(rows, outcome, group):
    return fit_arms([r for r in rows if (int(r['anonymity']) == 2) == (group == 'anonymous')], outcome)


def analyze(rows, name):
    eligible = complete_rows(rows)
    horizons = {name2: fit_arms(rows, column) for name2, column in HORIZONS.items()}
    four_wk_p = [horizons['week_1']['p_classical'][i] for i in (1, 2, 3, 4)]
    sixteen = [horizons[h]['p_classical'][i] for h in HORIZONS for i in (1, 2, 3, 4)]
    return {'source_assumption': name, 'raw_n': len(rows), 'complete_n': len(eligible),
            'raw_treatment_counts': group_counts(rows),
            'complete_treatment_counts': group_counts(eligible),
            'missing_baseline': [r['X'] for r in rows if r[BASELINE] in ('NA', '')],
            'horizons': horizons,
            'multiple_comparisons_exploratory': {
                'week1_four_arms_classical_Holm': [float(v) for v in multipletests(four_wk_p, method='holm')[1]],
                'all_16_classical_Holm_min': float(min(multipletests(sixteen, method='holm')[1]))},
            'treated_only_factorial_week1': fit_treated_factorial(rows, HORIZONS['week_1']),
            'anonymous_week1': fit_group(rows, HORIZONS['week_1'], 'anonymous'),
            'identified_week1': fit_group(rows, HORIZONS['week_1'], 'identified'),
            'winsor_99pct_week1': fit_arms(rows, HORIZONS['week_1'], .99),
            'winsor_99pct_month1': fit_arms(rows, HORIZONS['month_1'], .99)}


def fetch_and_lock(dirname: pathlib.Path):
    dirname.mkdir(parents=True, exist_ok=True)
    for variant, info in SOURCE.items():
        url = ('https://raw.githubusercontent.com/' + REPO + '/master/data/' + info['filename'])
        with urlopen(url, timeout=25) as response:
            raw = response.read()
        verify_source(raw, info['git_blob'])
        target = dirname / info['filename']
        with tempfile.NamedTemporaryFile(dir=str(dirname), delete=False) as t:
            t.write(raw)
            tempfile_path = pathlib.Path(t.name)
        os.replace(tempfile_path, target)


def main():
    arg = argparse.ArgumentParser()
    arg.add_argument('--data-dir', default=str(ROOT / 'data'))
    arg.add_argument('--download', action='store_true', help='Explicitly fetch author GitHub CSVs')
    arg.add_argument('--output', default=str(ROOT / 'R030_RECOMPUTED.json'))
    args = arg.parse_args()
    dirname = pathlib.Path(args.data_dir)
    if args.download:
        fetch_and_lock(dirname)
    out = {}
    for variant, info in SOURCE.items():
        path = dirname / info['filename']
        if not path.exists():
            raise SystemExit('SOURCE_MISSING: %s; download original CSVs or run --download' % path)
        raw = path.read_bytes()
        verify_source(raw, info['git_blob'])
        out[variant] = analyze(parse_rows(raw), variant)
        out[variant]['git_blob_verified'] = info['git_blob']
    pathlib.Path(args.output).write_text(json.dumps(out, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print('R030 complete; source Git blob identities verified; outputs:', args.output)

if __name__ == '__main__':
    main()
