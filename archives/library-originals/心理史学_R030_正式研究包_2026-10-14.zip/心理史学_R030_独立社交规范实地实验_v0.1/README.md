# 心理史学 R030 正式研究包 v0.1

**日期**：2026-10-14。研究对象为 Kevin Munger 2017《Tweetment Effects on the Tweeted》，DOI `10.1007/s11109-016-9373-5`。项目范围为社会规范与真实发言行为的独立对照。PESEN v0.1 保持冻结。

## 本轮做到的工作

已通过已连接的 GitHub 工具分别读取作者公布的两份去标识化**个体汇总分析数据**及 R 脚本，核验两个 Git blob 指纹。对243行数据进行完整基线筛选，N=242，独立计算 OLS、HC3、99% 截尾和探索性二因素交互；已生成 `R030_CONNECTOR_COMPUTED_RESULTS.json`。论文图4第1周结果 −0.26 得到约 −0.259 的数值对应。

**关键限定**：当前容器的 DNS 无法从 GitHub 直接下载原始 CSV，正式包不内嵌源文件字节，也不包含任何原始社交媒体文本。离线 `r030_analysis.py` 已实现源字节 Git blob 校验、数据准入和重算，但这一脚本在本环境仅完成12项构造数据测试。真实来源数字来自**连接器读取与独立 JS 数值计算**。不能称 Python 在本地对两份真实 CSV 做了端到端复现。

## 如何在有 GitHub 网络的计算机上复算

```bash
python -m pip install numpy scipy statsmodels
python r030_analysis.py --download
python -m unittest discover -s tests -v
```

显式 `--download` 才访问公共仓库，只会在 Git blob 与已核验指纹相符时存入 `data/`。也可自行下载两份 CSV 并放入 `data/` 后离线执行 `python r030_analysis.py`。默认脚本遇到缺失源数据将**失败退出**，不会使用伪造或合成结果替代。

## 结果解释

处理3代表同群体身份与高关注者数量的规范劝诫账户，相对无劝诫对照组。处理组系数和探索性校正详见报告与 JSON。四种处理间的差异以及任何潜在的身份与影响力交互不能自动确定为独立心理机制。作者的已发表随机实验本身遵循特定伦理审批；本项目未接触受试者，也无真实在线干预。

文件：`R030_EVIDENCE_AUDIT.md`、`SOURCE_EVIDENCE_LEDGER.json`、`R030_CONNECTOR_COMPUTED_RESULTS.json`、`r030_analysis.py`、`tests/test_r030.py`。
