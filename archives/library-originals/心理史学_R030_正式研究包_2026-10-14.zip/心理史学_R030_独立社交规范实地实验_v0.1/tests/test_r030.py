import os
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import r030_analysis as a

class SourceAndAnalysisTests(unittest.TestCase):
    def setUp(self):
        self.rows = []
        k = 1
        for t in range(5):
            for v in range(12):
                ing, high, _ = a.ARM_CODES[t]
                b = float(v % 5 + 1) / 62
                self.rows.append({'X': str(k), 'treat.f': str(t),
                     'In_group': str(ing), 'high_followers': str(high),
                     'anonymity': str(v % 3), 'log.followers': str(1.0 + v * .2 + t * .09),
                     a.BASELINE: str(b),
                     a.HORIZONS['week_1']: str(1 + .12*v + .6*b + .1*t),
                     a.HORIZONS['week_2']: str(.5+.06*v+.05*t),
                     a.HORIZONS['month_1']: str(.2+.03*v+.02*t),
                     a.HORIZONS['month_2']: str(.1+.02*v+.01*t)})
                k += 1

    def test_git_blob(self):
        self.assertEqual(a.git_blob_sha(b'hello'), 'b6fc4c620b67d95f953a5c1c1230aaab5db5a1b0')

    def test_verify_mismatch(self):
        with self.assertRaisesRegex(ValueError, 'mismatch'):
            a.verify_source(b'hello', '0'*40)

    def test_expected_treatments(self):
        self.assertEqual([a.ARM_CODES[k][2] for k in range(5)],
            ['control', 'ingroup_low', 'outgroup_low', 'ingroup_high', 'outgroup_high'])

    def test_arm_counts(self):
        self.assertEqual(a.group_counts(self.rows), {str(k):12 for k in range(5)})

    def test_baseline_complete(self):
        self.rows[0][a.BASELINE] = 'NA'
        self.assertEqual(len(a.complete_rows(self.rows)), 59)

    def test_validate_treatment_flags(self):
        self.rows[0]['In_group'] = '1'
        import csv,io
        out=io.StringIO();w=csv.DictWriter(out,fieldnames=list(self.rows[0]));w.writeheader();w.writerows(self.rows)
        with self.assertRaisesRegex(ValueError, 'inconsistent'):
            a.parse_rows(out.getvalue().encode())

    def test_duplicates_rejected(self):
        self.rows[1]['X']=self.rows[0]['X']
        import csv,io
        out=io.StringIO();w=csv.DictWriter(out,fieldnames=list(self.rows[0]));w.writeheader();w.writerows(self.rows)
        with self.assertRaisesRegex(ValueError, 'Duplicated'):
            a.parse_rows(out.getvalue().encode())

    def test_fit(self):
        v = a.fit_arms(self.rows, a.HORIZONS['week_1'])
        self.assertEqual(v['n'],60)
        self.assertEqual(len(v['coefficients']),7)
        self.assertTrue(all(__import__('math').isfinite(z) for z in v['coefficients']))

    def test_factorial(self):
        v=a.fit_treated_factorial(self.rows,a.HORIZONS['week_1'])
        self.assertEqual(v['n'],48)

    def test_subgroups(self):
        self.assertEqual(a.fit_group(self.rows,a.HORIZONS['week_1'],'anonymous')['n'],20)
        self.assertEqual(a.fit_group(self.rows,a.HORIZONS['week_1'],'identified')['n'],40)

    def test_winsor_threshold(self):
        v=a.fit_arms(self.rows,a.HORIZONS['week_1'],.99)
        self.assertIsNotNone(v['winsor_threshold'])

    def test_multiple_testing(self):
        v=a.analyze(self.rows,'synthetic')
        self.assertEqual(len(v['multiple_comparisons_exploratory']['week1_four_arms_classical_Holm']),4)

if __name__ == '__main__': unittest.main()
