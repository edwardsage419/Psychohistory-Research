# 心理史学R059研究包

公开研究、归档版：2026-10-15。主报告 `R059_REPORT.md`；连续状态 `PROJECT_STATE_R059.md`；下轮研究关口 `R060_RESEARCH_GATE.md`。

可复算文件：
- `r059_online.py`：线上个人历史、奖励条件以及网络重抽样，完整Git blob身份检验入口。
- `r058_replay.py`：继承R058源计数与Git blob检验器，随包提供供原始数据重放使用。
- `R058_CONNECTOR_COUNTS.tsv`：26个网络的冻结来源blob SHA与逐轮派生计数。
- `R058_RESULTS.json`：作为前轮静态网络LOO模型参考。
- `R059_CONNECTOR_ONLINE.tsv`：本轮真实来源计算的个人在线基线各网对数损失。
- `R059_REWARD_CONDITIONAL.tsv`：本轮真实来源计算的奖励条件预测各网对数损失。
- `R059_RESULTS.json`：加权聚合和网络级不确定性；末尾逐网络指标。
- `test_r059.py`, `TEST_OUTPUT.txt`：39项本地自动化测试及输出（构造数据及衍生结果核查）。

离线运行：进入目录执行 `python r059_online.py` 及 `python -m unittest -v test_r059.py`。

原始数据完全重放：从作者仓库得到全部26个匹配字节的CSV并平铺命名为`f20h1.csv`等，执行 `python r059_online.py --raw-dir /your/folder`。失败即拒绝来源层成功主张。

此包不包含原始真人实验CSV字节，也不宣称已本地源级复现。PESEN v0.1冻结。
