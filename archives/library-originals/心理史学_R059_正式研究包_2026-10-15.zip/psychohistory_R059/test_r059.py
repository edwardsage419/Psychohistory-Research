#!/usr/bin/env python3
"""Unit and derived-reference tests only; not raw GitHub data replay."""
import csv, hashlib, io, json, math, tempfile, unittest
from pathlib import Path
import r059_online as m

class OnlineTests(unittest.TestCase):
    @staticmethod
    def fixture():
        # Realize two streams, with previous partner response and previous Points
        # always anchored to t-1; the trial's current partner and Points are audit-only.
        out=[]
        for user,ys,peers in [('a',['red','blue','blue','blue','green'],['red','blue','green','blue','green']),
                              ('b',['gray','gray','silver','silver','silver'],['blue','gray','silver','gray','silver'])]:
            for i,y in enumerate(ys):
                prior=ys[i-1] if i else 'nan';prior_peer=peers[i-1] if i else ''
                out.append({'id':user,'TrialNumber':str(i+1),'Response':y,'prev_response':prior,
                            'partner_prev_response':prior_peer,'partner_response':peers[i],
                            'Points':str(float(y==peers[i]))})
        return out

    def test_01_baseline_initial(self): self.assertEqual(m.predict_person([],0.5)['beta2'],0.5)
    def test_02_history_beta2(self):self.assertAlmostEqual(m.predict_person([1,1,0],0.2)['beta2'],3/5)
    def test_03_history_beta8(self):self.assertAlmostEqual(m.predict_person([1,1,0],0.2)['beta8'],6/11)
    def test_04_history_beta20(self):self.assertAlmostEqual(m.predict_person([1,1,0],0.2)['beta20'],12/23)
    def test_05_last5_not_long_history(self):self.assertAlmostEqual(m.predict_person([0]*7+[1]*5,.4)['last5'],6/7)
    def test_06_reward_prior(self):self.assertEqual(m.conditional_probability(.3,{0:[0,0],1:[0,0]},1,4),.3)
    def test_07_reward_update(self):self.assertAlmostEqual(m.conditional_probability(.3,{0:[3,2],1:[4,1]},0,4),3.2/7)
    def test_08_binary_logloss_good(self): self.assertAlmostEqual(m.loss(1,.8),-math.log(.8))
    def test_09_binary_logloss_bad(self):self.assertAlmostEqual(m.loss(0,.8),-math.log(.2))
    def test_10_loss_reject_zero(self):
        with self.assertRaises(ValueError):m.loss(1,0)
    def test_11_loss_reject_bad_y(self):
        with self.assertRaises(ValueError):m.loss(2,.4)
    def test_12_two_users(self):self.assertEqual(m.online_rows(self.fixture())['checks']['ids'],2)
    def test_13_score_count(self):self.assertEqual(m.online_rows(self.fixture())['checks']['eligible'],6)
    def test_14_t2_used_as_history(self):
        d=m.online_rows(self.fixture(),True)['predictions']
        self.assertEqual(d[0]['t'],3)
        self.assertEqual(d[0]['ewma20'],.4) # first t2 decision differs from t1
    def test_15_reward_audit_matches(self):
        d=m.online_rows(self.fixture())['checks'];self.assertEqual(d['reward_mismatch'],0)
        self.assertEqual(d['reward_compared'],6)
    def test_16_incorrect_previous_reward_detected(self):
        v=self.fixture();v[1]['Points']='1.0' if v[1]['Points']=='0.0' else '0.0'
        self.assertEqual(m.online_rows(v)['checks']['reward_mismatch'],1)
    def test_17_current_points_not_predictive(self):
        v=self.fixture();a=m.online_rows(v,True)
        for r in v:
            if r['TrialNumber']=='5':r['Points']='0.0'
        b=m.online_rows(v,True)
        self.assertEqual(a['predictions'],b['predictions'])
    def test_18_future_response_not_predictive_of_early(self):
        v=self.fixture();a=m.online_rows(v,True)
        for r in v:
            if r['id']=='a' and r['TrialNumber']=='5':r['Response']='different_future'
        b=m.online_rows(v,True)
        self.assertEqual(a['predictions'][:2],b['predictions'][:2])
    def test_19_order_invariance(self):
        v=self.fixture();x=m.online_rows(v)['metrics'];y=m.online_rows(list(reversed(v)))['metrics']
        for k in x:self.assertAlmostEqual(x[k],y[k],places=13)
    def test_20_duplicate_rejected(self):
        a=self.fixture();a.append(dict(a[0]));
        with self.assertRaises(ValueError):m.online_rows(a)
    def test_21_missing_fields_rejected(self):
        with self.assertRaises(ValueError):m.online_rows([{'TrialNumber':'1'}])
    def test_22_audit_self_lag_corruption(self):
        a=self.fixture();a[2]['prev_response']='wrong';self.assertEqual(m.online_rows(a)['checks']['self_mismatch'],1)
    def test_23_audit_peer_lag_corruption(self):
        a=self.fixture();a[2]['partner_prev_response']='wrong';self.assertEqual(m.online_rows(a)['checks']['peer_mismatch'],1)
    def test_24_missing_eligibility(self):
        a=self.fixture();a[3]['partner_prev_response']='nan';self.assertEqual(m.online_rows(a)['checks']['eligible'],5)
    def test_25_sha_expected(self):
        self.assertEqual(m.git_sha(b'test'),hashlib.sha1(b'blob 4\0test').hexdigest())
    def test_26_bad_sha_refused(self):
        online=m.read_connector_online();cond=m.read_reward_conditional()
        ref=next(z for z in m.read_counts(m.ROOT/'R058_CONNECTOR_COUNTS.tsv') if z['name']=='f20h1')
        with tempfile.TemporaryDirectory() as tmp:
            f=Path(tmp)/'f20h1.csv';f.write_text('invalid',encoding='utf-8')
            with self.assertRaisesRegex(ValueError,'Git blob mismatch'):m.verify_raw_file(f,ref,{},online,cond)
    def test_27_data_source_count(self):
        d=m.run_main();self.assertEqual(d['source_status']['eligible'],36780)
    def test_28_no_local_false_claim(self):self.assertFalse(m.run_main()['source_status']['local_original_bytes_verified'])
    def test_29_global_old_reference(self):
        d=m.run_main();self.assertAlmostEqual(d['weighted_logloss']['m3'],.5562473852567796)
    def test_30_full_score_baseline(self):
        d=m.run_main();self.assertAlmostEqual(d['weighted_logloss']['ewma20'],.4183965122125553)
    def test_31_reward_model_worse(self):
        d=m.run_main();self.assertGreater(d['weighted_logloss']['reward_condition4'],d['weighted_logloss']['ewma20'])
    def test_32_full_net_signs(self):
        d=m.run_main();self.assertEqual(d['contrasts']['ewma20_vs_m3']['networks_improved'],26)
    def test_33_raw_subset_identity(self):
        a=m.read_connector_online();b=m.read_reward_conditional();self.assertEqual(set(a),set(b))
    def test_34_duplicate_file_ref_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            f=Path(tmp)/'dupe.tsv';f.write_text('run|n|beta2\na|1|.4\na|2|.5\n')
            with self.assertRaises(ValueError):m.read_pipe(f,['beta2'])
    def test_35_tampered_network_mismatch(self):
        with tempfile.TemporaryDirectory() as tmp:
            f=Path(tmp)/'bad.tsv';data=(m.ROOT/'R059_CONNECTOR_ONLINE.tsv').read_text();
            f.write_text(data.replace('f20h1|795|756|','f20h1|795|999|'),encoding='utf-8')
            with self.assertRaises(ValueError):m.run_main(personal_path=f)
    def test_36_missing_reward_ref_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            f=Path(tmp)/'bad.tsv';data=(m.ROOT/'R059_REWARD_CONDITIONAL.tsv').read_text();f.write_text(data.replace('f20h1|756|','f20h1|777|'),encoding='utf-8')
            with self.assertRaises(ValueError):m.run_main(conditional_path=f)

    def test_37_current_partner_response_not_predictive(self):
        a=self.fixture();x=m.online_rows(a,True)['predictions']
        for row in a:
            if row['TrialNumber']=='5':row['partner_response']='arbitrary_new_answer'
        y=m.online_rows(a,True)['predictions']
        self.assertEqual(x,y)
    def test_38_valid_constructed_raw_roundtrip(self):
        rows=self.fixture()
        with tempfile.TemporaryDirectory() as tmp:
            f=Path(tmp)/'unit.csv'
            fields=list(rows[0]);out=io.StringIO();writer=csv.DictWriter(out,fieldnames=fields,lineterminator='\n')
            writer.writeheader();writer.writerows(rows);f.write_bytes(out.getvalue().encode())
            ref=m.recount_raw_bytes(f.read_bytes());z=m.online_rows(rows)
            meta={'name':'unit','sha':m.git_sha(f.read_bytes()),'raw_rows':ref['rows'],
                  'ids':ref['ids'],'cells':ref['cells']}
            personal={'unit':{'rows':ref['rows'],'n':z['checks']['eligible'],**{k:z['metrics'][k] for k in ('beta2','beta8','beta20','last5','ewma20')}}}
            conditional={'unit':{'n':z['checks']['eligible'],**{k:z['metrics'][k] for k in ('reward_condition4','reward_condition12')}}}
            r=m.verify_raw_file(f,meta,{},personal,conditional)
            self.assertEqual(r['checks']['reward_mismatch'],0)
    def test_39_constructed_reward_mismatch_refused(self):
        rows=self.fixture();rows[1]['Points']='1.0' if rows[1]['Points']=='0.0' else '0.0'
        with tempfile.TemporaryDirectory() as tmp:
            f=Path(tmp)/'unit.csv'
            fields=list(rows[0]);out=io.StringIO();writer=csv.DictWriter(out,fieldnames=fields,lineterminator='\n')
            writer.writeheader();writer.writerows(rows);f.write_bytes(out.getvalue().encode())
            ref=m.recount_raw_bytes(f.read_bytes());z=m.online_rows(rows)
            meta={'name':'unit','sha':m.git_sha(f.read_bytes()),'raw_rows':ref['rows'],
                  'ids':ref['ids'],'cells':ref['cells']}
            personal={'unit':{'rows':ref['rows'],'n':z['checks']['eligible'],**{k:z['metrics'][k] for k in ('beta2','beta8','beta20','last5','ewma20')}}}
            conditional={'unit':{'n':z['checks']['eligible'],**{k:z['metrics'][k] for k in ('reward_condition4','reward_condition12')}}}
            with self.assertRaisesRegex(ValueError,'timing or reward mismatch'):
                m.verify_raw_file(f,meta,{},personal,conditional)

if __name__=='__main__':unittest.main(verbosity=2)
