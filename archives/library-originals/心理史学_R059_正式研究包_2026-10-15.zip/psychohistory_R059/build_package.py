from pathlib import Path
from datetime import datetime
from hashlib import sha256
import json,zipfile
root=Path(__file__).resolve().parent
files=[p for p in sorted(root.iterdir()) if p.is_file() and p.name not in {'SHA256SUMS.txt','MANIFEST.json'}]
ledger={p.name:sha256(p.read_bytes()).hexdigest() for p in files}
(root/'SHA256SUMS.txt').write_text(''.join(f'{digest}  {name}\n' for name,digest in ledger.items()),encoding='utf-8')
manifest={'project':'心理史学','round':'R059','date':'2026-10-15','PESEN_v0_1':'FROZEN',
          'original_source':'jpriniski/NetCom 26 per-run Git blobs, original full bytes not locally mounted',
          'local_genuine_raw_full_replay':False,'tests_passed':39,
          'files_sha256':{**ledger,'SHA256SUMS.txt':sha256((root/'SHA256SUMS.txt').read_bytes()).hexdigest()}}
(root/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
archive=root.parent/'心理史学_R059_正式研究包_2026-10-15.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name in [*manifest['files_sha256'],'MANIFEST.json']:
        z.write(root/name,arcname='psychohistory_R059/'+name)
with zipfile.ZipFile(archive) as z:
    bad=z.testzip()
    if bad:raise RuntimeError('zip mismatch: '+bad)
    for file,digest in manifest['files_sha256'].items():
        if sha256(z.read('psychohistory_R059/'+file)).hexdigest()!=digest:raise RuntimeError('sha failure '+file)
print('ZIP',archive,'bytes',archive.stat().st_size,'files',len(manifest['files_sha256'])+1,
      'sha256',sha256(archive.read_bytes()).hexdigest())
