# R037 可离线复算的研究包

## 研究对象

独立团队 Andreozzi、Ploner、Saral (2020) 在6个场次134人10轮社会困境实验中，考察 **`isCC`条件合作策略分类** 是否能由上一轮真实状态与当轮决策前信念预测。此包只保存了源数据衍生的70个无个人标识聚合单元，没有原始个人记录。

## 基础运行

```bash
python r037_analysis.py --save R037_RESULT.json
python -m unittest discover -s tests -v
```

程序只依赖Python标准库，默认不访问网络。严格来源测试通过才会产生结果；70条CSV派生统计受固定 SHA256 限定。

若另行依法下载原始 `subjects.csv`，可执行：

```bash
python r037_analysis.py --original-raw /absolute/path/to/subjects.csv
```

这一路径要求源Git blob SHA与本地构造的全部70个派生单元严格一致。不能用从聚合数据模拟的伪原始CSV冒充本地端到端复现。

## 四个基准

- B0：训练场次总体概率。
- B4-R037：上一轮实际 `isCC` 条件下的滚动一步马尔可夫模型，Beta(0.5,0.5)平滑。
- B5：当轮事前对对手无条件转移的粗分箱预期，Beta(0.5,0.5)平滑。
- B6：上一轮策略状态与当轮事前信念联合，信念分箱条件概率向状态父概率平滑α=12。

训练轮2-7，目标轮8-10；每折完整留出一个**场次**。B4和B6均在第9、10轮读取已实现的第8、9轮策略，是逐轮滚动一步预测，勿与R036固定第7轮起点的三步预报直接比较。

结论、限制与后续证据关口详见 `R037_EVIDENCE_AUDIT.md` 和 `R038_RESEARCH_GATE.md`。
