import unittest
import sys
import tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import r037_analysis as a

class TestDataProvenance(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rows=a.read_data()

    def test_source_git_sha(self):
        self.assertEqual(len(a.SOURCE_SHA),40)
        self.assertEqual(a.SOURCE_SHA,'bd4c1550002621bee7dfb50e0d15d317764d1ea9')

    def test_derivative_hashed(self):
        self.assertEqual(len(a.SOURCE_DERIVATIVE_SHA256),64)
        self.assertTrue(a.read_data())

    def test_bad_derivative_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/'copy.csv';f.write_bytes(a.CSV_PATH.read_bytes()+b'\n')
            with self.assertRaisesRegex(ValueError,'SHA256'):a.read_data(f)

    def test_count_marginals(self):self.assertTrue(a.validate(self.rows))

    def test_n70_cells(self):self.assertEqual(len(self.rows),70)

    def test_reject_duplicate(self):
        with self.assertRaises(ValueError):a.validate(self.rows+[self.rows[0]])

    def test_reject_corrupted_successes(self):
        bad=list(self.rows);b=list(bad[0]);b[-1]=b[-2]+1;bad[0]=tuple(b)
        with self.assertRaises(ValueError):a.validate(bad)

    def test_no_unidentifiable_user_id(self):
        self.assertEqual(set(self.rows[0]),set(('10001','test',0,0,29,3)))

    def test_expected_probability_bins(self):
        self.assertEqual(a.bin_of_expected('1','0','0'),0)
        self.assertEqual(a.bin_of_expected('0','1','0'),1)
        self.assertEqual(a.bin_of_expected('0','0','1'),2)

    def test_reject_bad_beliefs(self):
        with self.assertRaises(ValueError):a.bin_of_expected(.3,.3,.3)
        with self.assertRaises(ValueError):a.bin_of_expected(-.1,.1,1)

    def test_git_blob_known(self):
        self.assertEqual(a.original_git_sha(b'hello'),'b6fc4c620b67d95f953a5c1c1230aaab5db5a1b0')

    def test_fail_closed_original_raw(self):
        with self.assertRaisesRegex(ValueError,'Git blob'):a.derive_from_original_csv(b'not the original source')

class TestModels(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.rows=a.read_data();cls.result=a.evaluate(cls.rows)

    def test_posterior(self):self.assertAlmostEqual(a.posterior(5,10,alpha=2,center=.5),.5)

    def test_posterior_empty(self):self.assertAlmostEqual(a.posterior(0,0,alpha=12,center=.75),.75)

    def test_bad_posterior_rejected(self):
        with self.assertRaises(ValueError):a.posterior(8,5)

    def test_bad_probs_rejected(self):
        for p in (0,1,-.1,1.1,float('nan')):
            with self.assertRaises(ValueError):a.logloss(10,4,p)

    def test_pooled_loss(self):self.assertAlmostEqual(a.logloss(10,5,.5)/10,mathlogtwo(),places=12)

    def test_brier(self):self.assertAlmostEqual(a.brier(10,4,.5)/10,.25,places=12)

    def test_six_folds(self):self.assertEqual(len(self.result['folds']),6)

    def test_holdout_training_n(self):
        for f in self.result['folds']:
            m=a.train_models(self.rows,f['session'])
            self.assertEqual(m['training_n'],804-6*(f['n']//3))
            self.assertEqual(f['n'],{'10004':60,'10005':72,'20006':72}.get(f['session'],66))

    def test_holdout_unknown_fails(self):
        with self.assertRaises(ValueError):a.train_models(self.rows,'99999')

    def test_weights_sum(self):self.assertEqual(sum(f['n'] for f in self.result['folds']),402)

    def test_belief_state_delta(self):
        self.assertAlmostEqual(self.result['delta_B6_minus_B4_logloss'],-.007638542869648823,places=10)

    def test_state_predictive(self):
        s=self.result['scores'];self.assertLess(s['B4_rolling_state']['logloss'],s['B0_pooled']['logloss'])

    def test_belief_incremental_but_small(self):
        s=self.result['scores'];self.assertLess(s['B6_state_plus_prechoice_belief']['logloss'],s['B4_rolling_state']['logloss'])

    def test_belief_only_not_better_than_state(self):
        s=self.result['scores'];self.assertGreater(s['B5_belief_only']['logloss'],s['B4_rolling_state']['logloss'])

    def test_stability_shrinkage(self):
        for a0 in (2,6,12,30,100):
            d=a.evaluate(self.rows,shrink=a0)['delta_B6_minus_B4_logloss']
            self.assertTrue(-.02<d<0)

    def test_bootstrap_seed_reproducible(self):
        self.assertEqual(a.bootstrap_folds(self.result['folds'],seed=27,draws=100),a.bootstrap_folds(self.result['folds'],seed=27,draws=100))

    def test_bootstrap_contains_zero(self):
        lo,hi=a.bootstrap_folds(self.result['folds'])
        self.assertLess(lo,0);self.assertGreater(hi,0)

    def test_no_raw_claim(self):self.assertFalse(a.output()['source']['original_raw_local_end_to_end_verified'])

    def test_counterexample_stable_type_not_learning(self):
        # Latent stable type theta in {.1,.9}, equal weights, independent decisions
        # conditional on theta. Strong observed transition persistence, without
        # any causal effect from one's previous choice on next choice.
        theta=(.1,.9)
        mu=sum(theta)/2
        ey2=sum(x*x for x in theta)/2
        p11=ey2/mu
        p01=(mu-ey2)/(1-mu)
        self.assertAlmostEqual(p11,.82)
        self.assertAlmostEqual(p01,.18)
        self.assertGreater(p11-p01,.6)

def mathlogtwo():
    import math
    return math.log(2)

if __name__=='__main__':unittest.main()
