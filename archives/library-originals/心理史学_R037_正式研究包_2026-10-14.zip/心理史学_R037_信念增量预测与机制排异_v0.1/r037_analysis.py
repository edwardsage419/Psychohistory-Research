#!/usr/bin/env python3
"""R037 belief incremental predictive audit. No network or individual data needed.

An ex-ante elicited unconditional-opponent belief index, H+0.5*M, is
categorized into fixed thirds. The outcome is observed conditional-strategy
classification isCC, not actual cooperation, punishment or latent preferences.

All comparisons are post hoc and predict same-person future rounds in a held-out
experimental session. The binned source aggregates are public-data derivatives.
"""
import argparse
import collections
import csv
import hashlib
import json
import math
import random
from pathlib import Path

ROOT=Path(__file__).resolve().parent
SOURCE_SHA='bd4c1550002621bee7dfb50e0d15d317764d1ea9'
SESSION_IDS=('10001','10004','10005','20002','20003','20006')
ARM_BY_SESSION={s:('CondInfo' if s.startswith('1') else 'NoCondInfo') for s in SESSION_IDS}
CSV_PATH=ROOT/'SESSION_BELIEF_DERIVED_CELLS.csv'
SOURCE_DERIVATIVE_SHA256='5c8ab1a376372a2d13979f5815d8d30c9b2d061c946c34ce811ea38eecb1f4b5'


def original_git_sha(raw:bytes)->str:
    return hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()


def bin_of_expected(buc_l,buc_m,buc_h):
    ps=(float(buc_l),float(buc_m),float(buc_h))
    if not all(math.isfinite(x) and 0<=x<=1 for x in ps):
        raise ValueError('invalid belief probability')
    if abs(sum(ps)-1)>1e-8:raise ValueError('beliefs do not sum to one')
    expected=ps[2]+ps[1]/2
    return 0 if expected<1/3 else 1 if expected<2/3 else 2


def read_data(path=CSV_PATH,require_sha=True):
    raw=Path(path).read_bytes()
    if require_sha and hashlib.sha256(raw).hexdigest()!=SOURCE_DERIVATIVE_SHA256:
        raise ValueError('derived data SHA256 mismatch')
    records=[]
    for x in csv.DictReader(raw.decode('utf-8-sig').splitlines()):
        row=(x['session'],x['phase'],int(x['previous_cc']),int(x['belief_bin']),int(x['n']),int(x['cc']))
        records.append(row)
    return records


def validate(rows):
    if len(rows)!=70:raise ValueError('unexpected number of source cells')
    seen=set();sessions=collections.defaultdict(lambda:collections.Counter())
    prev=collections.Counter();total=collections.Counter();belief=collections.Counter()
    for ses,phase,last,b, n,y in rows:
        key=(ses,phase,last,b)
        if key in seen:raise ValueError('duplicate cell')
        seen.add(key)
        if ses not in SESSION_IDS or phase not in ('train','test') or last not in (0,1) or b not in (0,1,2):
            raise ValueError('invalid group label')
        if n<=0 or not 0<=y<=n:raise ValueError('invalid count')
        sessions[(ses,phase)]['n']+=n;sessions[(ses,phase)]['cc']+=y
        prev[(phase,last)]+=n;prev[(phase,last,'y')]+=y
        belief[(phase,b)]+=n;belief[(phase,b,'y')]+=y
        total[phase]+=n;total[phase+'_y']+=y
    if dict(total)!={'train':804,'train_y':440,'test':402,'test_y':170}:
        raise ValueError('marginal totals conflict with GitHub source')
    if [(prev[('train',i)],prev[('train',i,'y')]) for i in [0,1]]!=[(345,50),(459,390)]:
        raise ValueError('R036 transition checkpoint mismatch')
    if [(belief[('train',i)],belief[('train',i,'y')]) for i in [0,1,2]]!=[(306,118),(390,245),(108,77)]:
        raise ValueError('belief train source mismatch')
    if [(belief[('test',i)],belief[('test',i,'y')]) for i in [0,1,2]]!=[(204,59),(167,93),(31,18)]:
        raise ValueError('belief test source mismatch')
    for ses in SESSION_IDS:
        n=22 if ses in ('10001','20002','20003') else 20 if ses=='10004' else 24
        if sessions[(ses,'train')]['n']!=6*n or sessions[(ses,'test')]['n']!=3*n:
            raise ValueError('session N mismatch')
    return True


def logloss(n,y,p):
    if not math.isfinite(p) or p<=0 or p>=1:raise ValueError('invalid forecast p')
    return -(y*math.log(p)+(n-y)*math.log1p(-p))


def brier(n,y,p):
    return y*(1-p)**2+(n-y)*p*p


def posterior(y,n,alpha=0.5,center=0.5):
    if n<0 or not 0<=y<=n or alpha<=0 or not 0<center<1:raise ValueError('invalid smoothing args')
    return (y+alpha*center)/(n+alpha)


def train_models(rows,hold,shrink=12):
    if hold not in SESSION_IDS or shrink<0:raise ValueError('bad hold or shrink')
    train=[x for x in rows if x[0]!=hold and x[1]=='train']
    def accum(selected):return sum(z[4] for z in selected),sum(z[5] for z in selected)
    alln,ally=accum(train);p0=posterior(ally,alln,alpha=1)
    parent={}
    for state in (0,1):
        nn,yy=accum([z for z in train if z[2]==state]);parent[state]=posterior(yy,nn,alpha=1)
    belief={}
    for b in (0,1,2):
        nn,yy=accum([z for z in train if z[3]==b]);belief[b]=posterior(yy,nn,alpha=1)
    combined={}
    for state in (0,1):
        for b in (0,1,2):
            nn,yy=accum([z for z in train if z[2]==state and z[3]==b]);
            combined[(state,b)]=posterior(yy,nn,alpha=max(1e-9,shrink),center=parent[state])
    return {'pooled':p0,'state':parent,'belief':belief,'combined':combined,'training_n':alln}


def evaluate(rows,shrink=12):
    validate(rows)
    folds=[];losses=collections.defaultdict(float);briers=collections.defaultdict(float)
    for held in SESSION_IDS:
        m=train_models(rows,held,shrink)
        fold={'session':held,'arm':ARM_BY_SESSION[held], 'n':0,'training_n':m['training_n']}
        for name in ('B0_pooled','B4_rolling_state','B5_belief_only','B6_state_plus_prechoice_belief'):
            fold[name]={'logloss':0.,'brier':0.}
        for ses,phase,last,b,n,y in rows:
            if ses!=held or phase!='test':continue
            fold['n']+=n
            probs={'B0_pooled':m['pooled'],
                   'B4_rolling_state':m['state'][last],
                   'B5_belief_only':m['belief'][b],
                   'B6_state_plus_prechoice_belief':m['combined'][(last,b)]}
            for name,p in probs.items():
                fold[name]['logloss']+=logloss(n,y,p);fold[name]['brier']+=brier(n,y,p)
                losses[name]+=logloss(n,y,p);briers[name]+=brier(n,y,p)
        for name in ('B0_pooled','B4_rolling_state','B5_belief_only','B6_state_plus_prechoice_belief'):
            fold[name]['logloss']/=fold['n'];fold[name]['brier']/=fold['n']
        fold['difference_B6_minus_B4']=fold['B6_state_plus_prechoice_belief']['logloss']-fold['B4_rolling_state']['logloss']
        folds.append(fold)
    scores={name:{'logloss':losses[name]/402,'brier':briers[name]/402} for name in losses}
    diff=scores['B6_state_plus_prechoice_belief']['logloss']-scores['B4_rolling_state']['logloss']
    return {'n_test':402,'training_n_depends_on_held_session':True,'alpha_for_belief_cell_shrink_to_parent':shrink,
            'scores':scores,'folds':folds,'delta_B6_minus_B4_logloss':diff,
            'fold_wins_B6':sum(f['difference_B6_minus_B4']<0 for f in folds)}


def bootstrap_folds(folds,seed=37037,draws=20000):
    r=random.Random(seed);vals=[]
    for _ in range(draws):
        group=[folds[r.randrange(len(folds))] for __ in folds]
        total=sum(z['n'] for z in group)
        val=sum(z['n']*z['difference_B6_minus_B4'] for z in group)/total
        vals.append(val)
    vals.sort();return [vals[int(0.025*draws)],vals[int(0.975*draws)-1]]


def derive_from_original_csv(raw):
    """Independently rebuild all 70 aggregates from original byte-identical file."""
    if original_git_sha(raw)!=SOURCE_SHA:raise ValueError('raw Git blob SHA mismatch')
    records=list(csv.DictReader(raw.decode('utf-8-sig').splitlines()))
    people=collections.defaultdict(list)
    for x in records:
        if x['isCC'] not in ('TRUE','FALSE'):raise ValueError('nonbinary strategy')
        people[x['subject_unq']].append(x)
    if len(records)!=1340 or len(people)!=134:raise ValueError('unexpected source n')
    cells=collections.Counter()
    for person,xx in people.items():
        xx.sort(key=lambda x:int(x['period']))
        if [int(q['period']) for q in xx]!=list(range(1,11)):
            raise ValueError('missing or repeated period')
        if len({q['session_unq'] for q in xx})!=1:raise ValueError('session drift')
        for i in range(1,10):
            row=xx[i];state=int(xx[i-1]['isCC']=='TRUE')
            bin_val=bin_of_expected(row['buc_L'],row['buc_M'],row['buc_H'])
            key=(row['session_unq'],'train' if i<7 else 'test',state,bin_val)
            cells[(key,'n')]+=1;cells[(key,'y')]+=int(row['isCC']=='TRUE')
    actual=[]
    for key in sorted({k for k,metric in cells}):
        actual.append((*key,cells[(key,'n')],cells[(key,'y')]))
    validate(actual)
    return actual


def output(raw_path=None):
    rows=read_data();validate(rows)
    if raw_path:
        derived=derive_from_original_csv(Path(raw_path).read_bytes())
        if set(derived)!=set(rows):raise ValueError('raw aggregation mismatch')
    result=evaluate(rows);result['bootstrap_session_95pct']=bootstrap_folds(result['folds'])
    result['sensitivity']={str(a):evaluate(rows,shrink=a)['delta_B6_minus_B4_logloss'] for a in (2,6,12,30,100)}
    result['source']={'git_blob_sha1':SOURCE_SHA,'derived_sha256':SOURCE_DERIVATIVE_SHA256,
                      'original_raw_local_end_to_end_verified':bool(raw_path)}
    return result

if __name__=='__main__':
    arg=argparse.ArgumentParser();arg.add_argument('--original-raw',type=Path);arg.add_argument('--save',type=Path)
    ns=arg.parse_args();v=output(ns.original_raw)
    msg=json.dumps(v,ensure_ascii=False,indent=2)
    if ns.save:ns.save.write_text(msg+'\n',encoding='utf-8')
    print(msg)
