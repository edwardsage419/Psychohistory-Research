import importlib.util
import math
import tempfile
import csv
import unittest
from pathlib import Path
SRC=Path(__file__).resolve().parents[1]/'r011_analysis.py'
spec=importlib.util.spec_from_file_location('r011_analysis',SRC)
m=importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

class TestR011(unittest.TestCase):
    def sample(self):
        data=[]
        for p in ['Dem','Repub']:
            for arm,npairs in [('Social',3),('Control',1)]:
                for set_id in ['A','B']:
                    for pair in range(1,npairs+1):
                        for q in ['Q1','Q2','Q3','Q4']:
                            for i in range(6):
                                a=1.2+i*.13+(p=='Repub')*.15+pair*.05
                                data.append({'party':p,'set':set_id,'pair':str(pair),'condition':arm,'question':q,
                                             'x':[a,a+.12*(2.2-a),a+.16*(2.2-a)],'truth':2.2})
        return data
    def test_gitblob_signature(self):
        self.assertEqual(m.blob_sha(b'test'),'30d74d258442c7c65512eafab474568dd706c430')
    def test_observation_counts(self):
        records,unmatched=m.observations(self.sample())
        self.assertEqual(len(records),len(self.sample())*2)
        self.assertEqual(unmatched,0)
    def test_self_is_excluded_from_mean(self):
        records,_=m.observations(self.sample())
        self.assertTrue(any(abs(x['same']-x['other'])>.001 for x in records))
    def test_placebo_is_opposite_party(self):
        c=self.sample(); rec,_=m.observations(c)
        self.assertTrue(all(math.isfinite(x['other']) for x in rec))
    def test_pair_holdout_folds(self):
        r,_=m.observations(self.sample())
        so=m.heldout_score(r,'Social','same','both')
        self.assertEqual(so['n_holdout_pairs'],6)
        self.assertEqual(so['n_person_rounds'],len([x for x in r if x['arm']=='Social']))
    def test_comparison_all_models(self):
        r=m.analyze(self.sample())
        self.assertIn('M_opposite_party_PLACEBO',r['comparisons']['Social']['both'])
    def test_missing_other_arm_is_detected(self):
        c=[x for x in self.sample() if x['party']=='Dem']
        with self.assertRaises(ValueError):m.analyze(c)
    def test_bad_zero_variation_guard(self):
        self.assertEqual(m.slope([{'same':0,'y':1}],'same'),0.0)
    def test_csv_positive_case_filter(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'input.csv'
            with p.open('w',newline='') as f:
                out=csv.DictWriter(f,fieldnames=['experiment','truth','response_1','response_2','response_3','party','network','set','pair_id','q'])
                out.writeheader();out.writerow(dict(experiment='1',truth='10',response_1='2',response_2='4',response_3='8',party='Dem',network='Social',set='A',pair_id='1',q='Q1'))
                out.writerow(dict(experiment='1',truth='10',response_1='NA',response_2='4',response_3='8',party='Dem',network='Social',set='A',pair_id='1',q='Q1'))
            items,ex,src=m.read_cases(p)
            self.assertEqual(len(items),1);self.assertEqual(ex['missing_or_non_numeric'],1)
            self.assertEqual(src['raw_records'],2)

if __name__=='__main__':unittest.main()
