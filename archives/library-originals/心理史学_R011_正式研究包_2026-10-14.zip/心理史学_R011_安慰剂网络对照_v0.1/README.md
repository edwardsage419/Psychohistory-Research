# 心理史学 R011：真实社会影响中的跨组安慰剂信号检验

**日期：2026-10-14；性质：真实数据的探索性负对照 + 本地可复现程序 + Jayles 数据获取方案。**

## 核心发现

借助 GitHub 连接器重新读取 Becker、Porter 和 Centola（2019）的作者原始 CSV，保留实验一三个回合均为正且可用的 4,019 条个人-题目记录。构建两个判断更新代理变量：

- `same`：同一实验组其他所有人的当轮对数判断平均数，减去本人当轮判断。
- `other`：**同题目、同 set、同 pair_id、同 treatment、但政治立场相反的另一个独立实验组**的当轮对数均值，减去本人当轮判断。两组没有社会网络连接，这是一个未曝光的安慰剂信号。

被解释变量 `y = log(response_{t+1}) - log(response_t)`。分别估计 `y=beta * same`、`y=beta * other` 和不变模型 `y=0`。每次同时留出给定 `(set, pair_id, treatment)` 的两组，不参与该折系数拟合，再用这些组的既有当轮回答作预测。分 1→2、2→3 和合并更新计算均方预测误差（MSE）。

### 结果，合并两个相邻轮次

| 实验条件 | 基线不变 MSE | 同实验组均值代理 MSE | 另一独立实验组安慰剂 MSE | 独立匹配对折数 |
|---|---:|---:|---:|---:|
| Social | 0.395134 | 0.230777 | 0.235174 | 12 |
| Control | 0.261948 | 0.216739 | 0.221234 | 4 |

这说明不曾被呈现的安慰剂信号，也能获得接近同实验组均值代理信号的预测能力。同组均值与安慰剂信号的预测差距很小，且无同伴信息的对照组也存在。这进一步削弱了把 R009 的靠拢系数当作真实同伴学习权重的依据。

**关键边界**：原论文每位 Social 参与者实际看到的是四个网络邻居的平均值。公开 CSV 没有逐人邻接矩阵和展示值。因此，`same` 是研究者计算的全组代理，`other` 是设计的安慰剂；两者都不代表实际展示给人的社会信息。还需注意不同政党间的真实先验分布可能不同，两个代理信号具有共同的 `-log(response_t)` 项；安慰剂预测能力可能源自测量误差和回归均值，不能解释为虚假曝光。结果仅描述模型预测，没有随机化推断/严格机制识别，不表示实验中的社会影响不存在。

### 来源和证据分级

- 原论文：Joshua Becker, Ethan Porter, Damon Centola (2019), *The wisdom of partisan crowds*, *PNAS*, DOI https://doi.org/10.1073/pnas.1817195116 。实验设计和真正的四邻居反馈以原文为准。
- 作者完整 CSV 和 R 代码：https://github.com/joshua-a-becker/wisdom-of-partisan-crowds 。分析使用的 CSV 的 **Git blob SHA1**：`2fc18cefd211727e560b05d60c1289f1f4891969`（这是 Git blob 哈希，不是原文件字节 SHA1）。
- 本轮实际经 GitHub 连接器取得 CSV 内容并计算 4,019 条完整记录的数值，产出 `REAL_SOURCE_TOOL_CALCULATIONS.json`。
- **仍未在本地容器保存原始 CSV 字节。因此提供的本地 Python 程序只进行了手写与合成样本的测试，本轮不宣称完成完整原始 CSV 的本地端到端重跑。**
- Jayles et al. (2020), *The impact of incorrect social information on collective wisdom in human groups*, DOI https://doi.org/10.1098/rsif.2020.0496 ，数据 https://doi.org/10.6084/m9.figshare.12522527 ，CC BY 4.0。R011 再次尝试直接网络下载，容器 DNS 阻断；此数据的真实 CSV、MD5/SHA256 和实证系数均 **未取得/未计算**。可用 `figshare_fetch.py` 在网络可用时按 Figshare API 获取并核验两个文件。

## 独立复现

在网络可用的 Linux Mint 终端，先从 GitHub 作者仓库下载 CSV，不要重新编辑 CSV。将其放在本目录或把路径传入：

```bash
python3 -m unittest discover -s tests -v
python3 r011_analysis.py '/path/to/Becker Centola Porter - Wisdom of Partisan Crowds - Supplementary Dataset.csv' --output r011_full_recompute.json
```

程序拒绝与本轮计算所用 Git blob SHA 不同的文件，以避免静默混用更新版本。查看 `REAL_SOURCE_TOOL_CALCULATIONS.json` 与本地复跑输出的汇总值是否在浮点舍入下相符。

Jayles 数据的后续接入：

```bash
python3 figshare_fetch.py --output-dir jayles_source
python3 ../心理史学_R010_真实信息暴露研究_v0.1/r010_analysis.py --main jayles_source/Data_Main.csv --isolated jayles_source/Data_Isolated.csv --output jayles_r010_real_results.json
```

此工作流还不能自动满足因果识别。需先审阅 Jayles 论文的虚拟影响者生成机制、会话与题目分层结构，并明确哪些变量可能是外生处理、哪些是通过前人判断内生生成的信号。

## 数学上的失败模式

设 `x` 是初始观测，`x'` 是下一轮观测，`m` 是某个参考人群的均值。研究者使用的回归变量：

`d=m-x`, `y=x'-x`。

两者均包含同一个 `-x`。当 `x` 含误差，即使 `m` 与真实的因果暴露无关，`Cov(d,y)` 仍可能为正。这是为什么本研究不以回归斜率、预测误差或自助抽样区间作为社会学习机制成立的证据。

## 研究决策

1. PESEN 维持 v0.1；不将 R009 系数解释为心理社会学习强度。
2. 增加并保留 `UNEXPOSED_PEER_PROXY_PLACEBO_PREDICTS_UPDATES` 作为必须排除的机制识别风险。
3. 下一轮 R012 优先取得 Jayles 原始数据，并在设计上审查真实随机操纵的可识别作用；若获取继续受阻，选择其他可直接下载且记录实际同伴曝光值的研究，避免反复进行同类人工模拟。
4. 本轮结果是一项观察数据后的探索性检验，不能当作原研究的预注册分析或因果效应估计。
