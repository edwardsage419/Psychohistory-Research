#!/usr/bin/env python3
"""Fetch Jayles et al. (2020) public Figshare data with checksums.

Usage: python figshare_fetch.py --output-dir jayles_source
Requires internet; does nothing if the remote API cannot be reached.
"""
import argparse
import hashlib
import json
import urllib.request
from pathlib import Path

ARTICLE_ID = 12522527
API = f'https://api.figshare.com/v2/articles/{ARTICLE_ID}'
ALLOWED = {'Data_Main.csv', 'Data_Isolated.csv'}

def fetch(outdir):
    req=urllib.request.Request(API,headers={'User-Agent':'Psychohistory-R011-research/1.0'})
    with urllib.request.urlopen(req,timeout=25) as resp: metadata=json.load(resp)
    files={f['name']:f for f in metadata.get('files',[]) if f.get('name') in ALLOWED and not f.get('is_link_only')}
    if set(files)!=ALLOWED: raise RuntimeError('Expected the two original CSV files; check article version and names before proceeding')
    outdir.mkdir(parents=True,exist_ok=True)
    manifest={'article_id':ARTICLE_ID,'article_url':metadata.get('url_public_html'),'version':metadata.get('version'), 'license':metadata.get('license'),'files':[]}
    for name in sorted(files):
        entry=files[name];url=entry['download_url']
        if not url.startswith(('https://ndownloader.figshare.com/','https://figshare.com/')):raise RuntimeError('Unexpected host')
        req=urllib.request.Request(url,headers={'User-Agent':'Psychohistory-R011-research/1.0'})
        with urllib.request.urlopen(req,timeout=45) as r: raw=r.read()
        md5=hashlib.md5(raw).hexdigest()
        declared=entry.get('computed_md5') or entry.get('supplied_md5')
        if declared and md5.lower()!=declared.lower():raise RuntimeError(f'MD5 mismatch for {name}')
        (outdir/name).write_bytes(raw)
        manifest['files'].append({'name':name,'file_id':entry['id'],'n_bytes':len(raw), 'sha256':hashlib.sha256(raw).hexdigest(),'md5':md5,'figshare_md5':declared})
    (outdir/'DATA_PROVENANCE.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    return manifest

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output-dir',type=Path,default=Path('jayles_source'))
    args=p.parse_args()
    print(json.dumps(fetch(args.output_dir),indent=2,ensure_ascii=False))
if __name__=='__main__': main()
