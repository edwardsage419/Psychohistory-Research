# R062心理史学研究包

2026-10-15。独立人类社会学习实验，可靠性自适应社会学习的竞争模型排异。

读取 `R062_REPORT.md`（报告）和 `R063_RESEARCH_GATE.md`（下一研究准入）。`SOURCE_LEDGER.json`提供原始公开来源/指纹。`R062_CV_BY_PERSON.csv`与`R062_GATE_BY_PERSON.csv`为GitHub连接器侧真实CSV分析产生的**匿名参与者汇总，不是作者原始CSV**。

验证：

```bash
python build_results.py
python -m unittest -v test_r062.py
```

执行原始来源端到端复算，必须自行取得原作者未经修改的两个文件：

```bash
python r062_adaptive.py --task1 /absolute/path/task1.csv --task2 /absolute/path/task2.csv --out /absolute/path/replay.json
```

`r061_replay_frozen.py`为R061冻结基线的独立打包副本；`r062_adaptive.py`是本轮三家族参数留一复算程序。数据的Git blob SHA1不符合锁定值时，原始复算拒绝运行。

测试仅证明程序边界及本地派生结果，不可代表对真正作者原始CSV的本地运行；当前缺少原始CSV字节。

PESEN v0.1保持冻结。R062候选模型未通过晋升关口。
