#!/usr/bin/env python3
"""Generate manifest of all files except manifest and zip; verify packed archive."""
import hashlib
import json
import zipfile
from pathlib import Path
ROOT = Path(__file__).resolve().parent
ARCHIVE = ROOT.parent / '心理史学_R062_正式研究包_2026-10-15.zip'


def digest(data):
    return hashlib.sha256(data).hexdigest()


if __name__ == '__main__':
    ignore = {'MANIFEST.json','SHA256SUMS.txt'}
    files = sorted(p for p in ROOT.iterdir() if p.is_file() and p.name not in ignore)
    manifest = {'round':'R062','date':'2026-10-15','frozen':'PESEN v0.1',
                'local_original_bytes':'NOT_PRESENT',
                'n_tests_new':35,'n_tests_inherited_R061':27,
                'files':[{'path':p.name,'size':p.stat().st_size,'sha256':digest(p.read_bytes())} for p in files]}
    (ROOT/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    full=files+[ROOT/'MANIFEST.json']
    (ROOT/'SHA256SUMS.txt').write_text(''.join(digest(p.read_bytes())+'  '+p.name+'\n' for p in full),encoding='utf8')
    full+=[ROOT/'SHA256SUMS.txt']
    with zipfile.ZipFile(ARCHIVE,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for f in full:
            z.write(f,arcname=f'psychohistory_R062/{f.name}')
    with zipfile.ZipFile(ARCHIVE) as z:
        assert z.testzip() is None
        assert len(z.namelist())==len(full)
        for f in full:
            assert z.read('psychohistory_R062/'+f.name)==f.read_bytes()
    print(json.dumps({'zip_path':str(ARCHIVE),'zip_bytes':ARCHIVE.stat().st_size,
                      'zip_sha256':digest(ARCHIVE.read_bytes()),'files':len(full),'status':'PASS'},ensure_ascii=False))
