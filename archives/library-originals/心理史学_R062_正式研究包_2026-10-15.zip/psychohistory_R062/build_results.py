#!/usr/bin/env python3
"""Recompute derived uncertainty; no author raw bytes are asserted locally."""
import csv
import json
import random
from pathlib import Path
ROOT=Path(__file__).resolve().parent
rows=list(csv.DictReader((ROOT/'R062_CV_BY_PERSON.csv').open(encoding='utf-8')))
gates=list(csv.DictReader((ROOT/'R062_GATE_BY_PERSON.csv').open(encoding='utf-8')))
source={
 '1':{'git_blob_sha1':'6f90784a49c26c92806b4876cb0ce4b446f810b1','bytes':652938,'raw_rows':9600,'participants':24,'private_decisions':5760,'demo_rows':3840},
 '2':{'git_blob_sha1':'5239155f233d42e4dbbe3f986865d5459a3e9cee','bytes':905163,'raw_rows':13200,'participants':44,'private_decisions':7920,'demo_rows':5280}}
expected={1:(.47395591903316253,.47395591903316253,.4731690398633052),2:(.6042948357827496,.6093700681348669,.6071787192866966)}
result={'round':'R062','research_date':'2026-10-15','data_provenance':'GITHUB_CONNECTOR_ORIGINAL_AUTHOR_CSV','local_raw_replay':'NOT_VERIFIED','source':source,'grid':{'private_alpha':[.05,.1,.3,.6],'inverse_temperature':[.5,1,2,4],'perseveration':[0,.15,.4],'social_alpha':[0,.03,.1,.3],'reliability_q_difference_threshold':.1,'reliability_beta_prior':[1,1]},'experiments':{}}
for t in (1,2):
 r=[x for x in rows if int(x['task'])==t]
 assert len(r)==source[str(t)]['participants']
 assert len({x['id'] for x in r})==len(r)
 for col,e in zip(('rw_loss','fixed_loss','adaptive_loss'),expected[t]):
  assert abs(sum(float(x[col]) for x in r)/len(r)-e)<1e-12,col
 rng=random.Random(62000+t)
 delta_rw=[float(x['adaptive_loss'])-float(x['rw_loss']) for x in r]
 delta_fixed=[float(x['adaptive_loss'])-float(x['fixed_loss']) for x in r]
 boot=[]
 for b in range(20000):
  sample=[r[rng.randrange(len(r))] for _ in r]
  boot.append((sum(float(z['adaptive_loss'])-float(z['rw_loss']) for z in sample)/len(r),sum(float(z['adaptive_loss'])-float(z['fixed_loss']) for z in sample)/len(r)))
 def ci(col):
  a=sorted(x[col] for x in boot)
  return [a[499],a[19499]]
 gating=[x for x in gates if int(x['task'])==t]
 assert len(gating)==len(r)
 skilled=[float(z['skilled_gate']) for z in gating if z['skilled_gate']]
 unskilled=[float(z['unskilled_gate']) for z in gating if z['unskilled_gate']]
 assert (len(skilled),len(unskilled))==((24,24) if t==1 else (22,22))
 gboot=[]
 for _ in range(20000):
  if t==1:
   sample=[gating[rng.randrange(len(gating))] for __ in gating]
   gboot.append(sum(float(z['skilled_gate'])-float(z['unskilled_gate']) for z in sample)/len(sample))
  else:
   gboot.append(sum(skilled[rng.randrange(len(skilled))] for __ in skilled)/len(skilled) - sum(unskilled[rng.randrange(len(unskilled))] for __ in unskilled)/len(unskilled))
 gboot.sort()
 result['experiments'][str(t)]={'participants':len(r),'n':source[str(t)]['private_decisions'],'mean_logloss':{m:sum(float(x[f'{m}_loss']) for x in r)/len(r) for m in ('rw','fixed','adaptive')},'delta_adaptive_minus_rw':sum(delta_rw)/len(r),'delta_adaptive_minus_fixed':sum(delta_fixed)/len(r),'improved_vs_rw':sum(x < -1e-12 for x in delta_rw),'improved_vs_fixed':sum(x < -1e-12 for x in delta_fixed),'bootstrap_95_adaptive_minus_rw':ci(0),'bootstrap_95_adaptive_minus_fixed':ci(1),'reliability_diagnostic':{'fixed_private_alpha':.1,'threshold':.1,'skilled_mean':sum(skilled)/len(skilled),'unskilled_mean':sum(unskilled)/len(unskilled),'difference':sum(skilled)/len(skilled)-sum(unskilled)/len(unskilled),'bootstrap_95_difference':[gboot[499],gboot[19499]],'status':'POSTHOC_SKILL_LABEL_AUDIT_NOT_INPUT_FEATURE'}}
(ROOT/'R062_RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result['experiments'],ensure_ascii=False,indent=2))
