"""R062 synthetic tests; do not present constructed records as original participants."""
import copy
import csv
import io
import json
import math
import unittest
from pathlib import Path
import r062_adaptive as r


def row(t, state, choice, demo=False, outcome=1, skill='skilled.dem', cond=None):
    return {'trial':t,'state':state,'choice':choice,'demo':demo,
            'out':None if demo else outcome,
            'condition':cond or ('Choice' if demo else 'Choice'),
            'skill':skill}


def sample():
    return {1:[
        row(1,1,1,False,1),
        row(2,1,0,True),
        row(3,1,1,False,-1),
        row(4,1,1,True),
        row(5,1,0,False,1),
        row(6,2,0,True),
        row(7,2,1,False,1),
        row(8,2,1,True),
        row(9,2,0,False,-1),
    ]}


def fixture_raw(task=1, subs=('3',), adulterate=None):
    cols=['expid','id','session','trial',
          'condition.demskill' if task==1 else 'group.demskill',
          'condition.obs','state','p1','p2','ctrial','clr','cgb','rtime','rgb','out']
    f=io.StringIO(newline=''); w=csv.DictWriter(f,fieldnames=cols);w.writeheader()
    for sub in subs:
        for session in range(1,r.SOURCE[task]['sessions']+1):
            for t in range(1,101):
                demo=t%5==0 and session%2==1
                act=int((t//7)%2==0)
                skill='skilled.dem' if int(sub)%2 else 'unskilled.dem'
                z={'expid':sub,'id':'dem' if demo else sub,'session':session,
                   'trial':t,'condition.obs':'Choice' if session%2==1 else 'Private',
                   'state':session,'p1':'.7' if task==1 else '.6',
                   'p2':'.3' if task==1 else '.4', 'ctrial':t,'clr':-1 if act else 1,
                   'cgb':act,'rtime':'.9','rgb':'NA' if demo else act,
                   'out':'NA' if demo else 1 if act else -1}
                z[cols[4]]=skill if task==2 or session%2 else 'private'
                if adulterate: adulterate(z)
                w.writerow(z)
    return f.getvalue().encode()


class Gate(unittest.TestCase):
    def setUp(self): self.par=(.1,2,.15,.1)
    def test_baseline_zero_social_identical(self):
        for mode in ('rw','fixed','adaptive'):
            got=r.score_subject(sample(),(.1,2,.15,0),mode)
            self.assertAlmostEqual(got['loss'],r.score_subject(sample(),(.1,2,.15,0),'rw')['loss'])
    def test_fixed_agrees_frozen(self):
        a=r.score_subject(sample(),self.par,'fixed')['loss']
        b=r.old.score_subject(sample(),self.par)['loss'];self.assertAlmostEqual(a,b,places=12)
    def test_rw_agrees_frozen(self):
        a=r.score_subject(sample(),(.1,2,.15,0),'rw')['loss']
        b=r.old.score_subject(sample(),(.1,2,.15,0))['loss'];self.assertAlmostEqual(a,b)
    def test_rewards_not_on_demo(self):
        for rec in sample()[1]:
            if rec['demo']:self.assertIsNone(rec['out'])
    def test_invalid_family(self):
        with self.assertRaisesRegex(ValueError,'family'):r.score_subject(sample(),self.par,'unsupported')
    def test_no_private(self):
        with self.assertRaisesRegex(ValueError,'No private'):r.score_subject({1:[row(1,1,1,True)]},self.par)
    def test_gate_bounded_rate(self):
        o=r.score_subject(sample(),self.par)
        self.assertGreater(o['diagnostics']['gates'],0)
        self.assertGreaterEqual(o['diagnostics']['rate_sum'],0)
        self.assertLessEqual(o['diagnostics']['rate_sum'],self.par[3]*o['diagnostics']['gates'])
    def test_ignore_true_skill_label_predictive(self):
        a=sample();b=copy.deepcopy(a)
        for v in b[1]:v['skill']='unskilled.dem'
        # Metrics use label only for aggregation, not prediction.
        self.assertAlmostEqual(r.score_subject(a,self.par)['loss'],r.score_subject(b,self.par)['loss'])
    def test_ignore_motor_response(self):
        a=sample();b=copy.deepcopy(a)
        for v in b[1]:v['clr']=-999
        self.assertEqual(r.score_subject(a,self.par)['loss'],r.score_subject(b,self.par)['loss'])
    def test_demo_current_unobserved_reward_not_used(self):
        a=sample();b=copy.deepcopy(a)
        for v in b[1]:
            if v['demo']:v['out']=987654321
        self.assertEqual(r.score_subject(a,self.par)['loss'],r.score_subject(b,self.par)['loss'])
    def test_future_demo_cannot_change_past(self):
        a=sample();b=copy.deepcopy(a)
        b[1].append(row(10,2,0,True))
        # Extra demonstration after last observed private choice cannot alter earlier scores.
        self.assertAlmostEqual(r.score_subject(a,self.par)['loss'],r.score_subject(b,self.par)['loss'])
    def test_future_private_cannot_change_prior_loss_sum(self):
        a=sample();b=copy.deepcopy(a)
        b[1].append(row(10,2,0,False,1))
        x=r.score_subject(a,self.par);y=r.score_subject(b,self.par)
        self.assertGreaterEqual(y['loss']*y['n'],x['loss']*x['n'])
    def test_reward_update_only_after_prediction(self):
        a={1:[row(1,1,1,False,1)]};b={1:[row(1,1,1,False,-1)]}
        self.assertAlmostEqual(r.score_subject(a,self.par)['loss'],r.score_subject(b,self.par)['loss'])
    def test_post_reward_can_change_future(self):
        a={1:[row(1,1,1,False,1),row(2,1,1,False,-1)]}
        b={1:[row(1,1,1,False,-1),row(2,1,1,False,-1)]}
        self.assertNotAlmostEqual(r.score_subject(a,self.par)['loss'],r.score_subject(b,self.par)['loss'])
    def test_private_warmup_gate_skips(self):
        a={1:[row(1,1,1,True),row(2,1,1,True),row(3,1,0,False,1)]}
        x=r.score_subject(a,self.par)
        self.assertEqual(x['diagnostics'].get('updates',0),0)
        self.assertEqual(x['diagnostics']['skips'],2)
    def test_confidence_threshold_gates_updates(self):
        a={1:[row(1,1,1,False,1),row(2,1,1,True),row(3,1,1,False,1)]}
        with_gate=r.score_subject(a,self.par,gate_threshold=0)['diagnostics']['updates']
        without_gate=r.score_subject(a,self.par,gate_threshold=999)['diagnostics'].get('updates',0)
        self.assertEqual((with_gate,without_gate),(1,0))
    def test_separate_private_q_prevents_self_validation(self):
        a={1:[row(1,1,0,False,1)]+[row(t,1,1,True) for t in range(2,7)]+[row(7,1,0,False,1)]}
        b=copy.deepcopy(a)
        # VS counterfactual models may amplify demonstrated option but the private-Q
        # evaluator remains identical, so reliability diagnostic counts agree.
        x=r.score_subject(a,self.par,'adaptive');y=r.score_subject(b,(.1,2,.15,.3),'adaptive')
        self.assertEqual(x['diagnostics']['updates'],y['diagnostics']['updates'])
    def test_reset_between_sessions(self):
        a={1:[row(1,1,1,False,1)],2:[row(1,1,1,False,1)]}
        b={1:[row(1,1,1,False,1),row(2,1,1,False,1)]}
        self.assertNotAlmostEqual(r.score_subject(a,self.par)['loss'],r.score_subject(b,self.par)['loss'])
    def test_state_specific(self):
        a={1:[row(1,1,1,False,1),row(2,2,1,False,-1)]}
        b={1:[row(1,1,1,False,-1),row(2,2,1,False,-1)]}
        self.assertEqual(r.score_subject(a,self.par)['loss'],r.score_subject(b,self.par)['loss'])
    def test_brier_range(self):
        for mode in ('rw','fixed','adaptive'):
            v=r.score_subject(sample(),self.par,mode)
            self.assertGreaterEqual(v['brier'],0);self.assertLessEqual(v['brier'],1)
    def test_strata_sum(self):
        o=r.score_subject(sample(),self.par)
        self.assertAlmostEqual(sum(v[0] for v in o['strata'].values()),o['loss']*o['n'])
        self.assertEqual(sum(v[1] for v in o['strata'].values()),o['n'])
    def test_three_models_equal_on_all_private(self):
        a={1:[row(t,1,t%2,False,1 if t%2 else -1,cond='Private') for t in range(1,12)]}
        z=[r.score_subject(a,self.par,mode)['loss'] for mode in ('rw','fixed','adaptive')]
        self.assertAlmostEqual(max(z),min(z))
    def test_grid_length(self): self.assertEqual(len(r.GRID),192)
    def test_data_sha_provenance(self):
        with self.assertRaisesRegex(ValueError,'SHA1 mismatch'):
            r.parse_data(fixture_raw(1),1,True)
    def test_author_known_sha(self):
        self.assertEqual(r.SOURCE[1]['sha'],'6f90784a49c26c92806b4876cb0ce4b446f810b1')
    def test_source_schema(self):
        people,checks=r.parse_data(fixture_raw(1,('3','4')),1,False)
        self.assertEqual((len(people),checks['dem'],checks['private']),(2,80,720))
    def test_source_duplicate(self):
        txt=fixture_raw().decode().splitlines();txt[4]=txt[3]
        with self.assertRaisesRegex(ValueError,'Duplicate'):
            r.parse_data(('\n'.join(txt)+'\n').encode(),1,False)
    def test_source_outcome_rejection(self):
        with self.assertRaisesRegex(ValueError,'Demonstrator'):
            r.parse_data(fixture_raw(adulterate=lambda z:z.update(out='1') if z['id']=='dem' else None),1,False)
    def test_nested_cv_holds_out_all_sessions(self):
        people,_=r.parse_data(fixture_raw(2,('3','4')),2,False)
        cv=r.cross_validate(people)
        self.assertEqual(len(cv),2)
        for z in cv:
            self.assertEqual(z['rw']['n'],260)
            self.assertEqual(z['fixed']['n'],260)
            self.assertEqual(z['adaptive']['n'],260)
    def test_summary_invariant(self):
        people,_=r.parse_data(fixture_raw(2,('3','4')),2,False)
        cv=r.cross_validate(people)
        x=r.summarize(2,cv)
        self.assertEqual(x['participants'],2)
        self.assertEqual(x['observations'],520)
    def test_derived_source_counts(self):
        f=Path(__file__).with_name('R062_CV_BY_PERSON.csv')
        rows=list(csv.DictReader(f.open(encoding='utf8')))
        self.assertEqual(len(rows),68)
        for task, n, means in ((1,24,(.47395591903316253,.47395591903316253,.4731690398633052)),
                               (2,44,(.6042948357827496,.6093700681348669,.6071787192866966))):
            a=[x for x in rows if int(x['task'])==task]
            self.assertEqual(len(a),n)
            for col,expect in zip(('rw_loss','fixed_loss','adaptive_loss'),means):
                self.assertAlmostEqual(sum(float(x[col]) for x in a)/n,expect,places=12)
    def test_real_derived_reliability_count(self):
        q=list(csv.DictReader(Path(__file__).with_name('R062_GATE_BY_PERSON.csv').open(encoding='utf8')))
        self.assertEqual(len(q),68)
        t1=[z for z in q if z['task']=='1']
        self.assertAlmostEqual(sum(float(z['skilled_gate'])-float(z['unskilled_gate']) for z in t1)/24,.26095278836535117,places=12)
    def test_real_derived_reliability_task2(self):
        q=list(csv.DictReader(Path(__file__).with_name('R062_GATE_BY_PERSON.csv').open(encoding='utf8')))
        t2=[z for z in q if z['task']=='2']
        self.assertEqual(len([x for x in t2 if x['skilled_gate']]),22)
        self.assertEqual(len([x for x in t2 if x['unskilled_gate']]),22)
        a=sum(float(z['skilled_gate']) for z in t2 if z['skilled_gate'])/22
        b=sum(float(z['unskilled_gate']) for z in t2 if z['unskilled_gate'])/22
        self.assertAlmostEqual(a-b,.1646251302879943,places=12)
    def test_aggregate_ci_zero_crossing(self):
        data=json.loads(Path(__file__).with_name('R062_RESULTS.json').read_text(encoding='utf8'))
        for task in ('1','2'):
            z=data['experiments'][task]['bootstrap_95_adaptive_minus_rw']
            self.assertLess(z[0],0)
            self.assertGreater(z[1],0)
    def test_no_reward_on_demo_from_real_schema(self):
        sample_data,_=r.parse_data(fixture_raw(1),1,False)
        self.assertTrue(all(z['out'] is None for sess in sample_data['3'].values() for z in sess if z['demo']))

if __name__=='__main__':
    unittest.main(verbosity=2)
