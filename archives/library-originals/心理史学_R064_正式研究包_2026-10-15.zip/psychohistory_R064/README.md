# 心理史学 R064 正式研究包

主报告：`R064_REPORT.md`。先验分析冻结记录：`R064_PROTOCOL_PRECOMMIT.md`。完整来源：`SOURCE_LEDGER.json`。

## 不联网复算（有295人匿名来源派生计数）

```bash
cd psychohistory_R064
python r064_external_stakes.py --derived R064_DERIVED_COUNTS.txt --out local_replay.json
python -m unittest -v test_r064
```

该复算覆盖226人的筛选、主要复制率差、两套LOPO模型的logloss/Brier、所有参与者的敏感性及两套重抽样区间。不等于作者源文件本地字节认证。

## 获得原始作者CSV时

```bash
python r064_external_stakes.py --derived R064_DERIVED_COUNTS.txt \
  --raw /path/to/unified_data_2025-01-16_00.csv --out raw_replay.json
```

代码将验证文件的 Git blob SHA1，以及从完整原始记录重新建立的所有295人匿名计数。如果不匹配则失败关闭；不会将错误来源输入当作结果。

`R064_CONNECTOR_CRITICAL_RESULTS.json`属于**事后关键试次敏感性**，目前仅在GitHub连接器侧计算，未提供关键试次逐人匿名计数；不得标成本地完整验证。

所有结果属历史数据的探索性重新计算。`PESEN v0.1` FROZEN。
