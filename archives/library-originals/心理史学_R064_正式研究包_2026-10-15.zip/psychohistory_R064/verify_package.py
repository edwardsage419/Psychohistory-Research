#!/usr/bin/env python3
"""Verify local R064 per-file SHA256 manifest (zip verification separate)."""
from pathlib import Path
import hashlib

root=Path(__file__).resolve().parent
linefile=root/'SHA256SUMS.txt'
if not linefile.exists(): raise SystemExit('no SHA256SUMS')
items=[]
for line in linefile.read_text().splitlines():
    expected,sep,name=line.partition('  ')
    if not sep or not expected or '/' in name or '..' in name or not (root/name).is_file():
        raise SystemExit(f'invalid path or file missing: {line}')
    actual=hashlib.sha256((root/name).read_bytes()).hexdigest()
    if expected!=actual:raise SystemExit(f'hash mismatch: {name}')
    items.append(name)
assert len(items)==len(set(items)), 'duplicate names'
assert len(items)>=10,'incomplete manifest'
print(f'PASS: {len(items)} files SHA256 validated')
