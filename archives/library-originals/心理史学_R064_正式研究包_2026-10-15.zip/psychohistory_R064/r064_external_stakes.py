#!/usr/bin/env python3
"""R064: retrospective independent-author stake/copying evaluation.

Strict precommit: R064_PROTOCOL_PRECOMMIT.md, SHA256
  a64a204a05e071fa2717f4df56b93a6b3367fdc57229fb99d392b0ed6fa20418
Raw source: arielevy8/obs-learning-fishing Git blob
  01bf211468abe093618dfa5e5c39e883230c9c03

Without --raw this audits anonymized connector-derived participant counts. It
must NEVER claim that derived count replay is raw-byte source authentication.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import io
import json
import math
from collections import defaultdict
from pathlib import Path

BLOB_SHA1 = '01bf211468abe093618dfa5e5c39e883230c9c03'
PRECOMMIT_SHA256 = 'a64a204a05e071fa2717f4df56b93a6b3367fdc57229fb99d392b0ed6fa20418'
DATA_FIELDS = ('participant_id', 'stakes', 'copied', 'accurate', 'comprehension_check_repetitions')
RESAMPLE_COUNT = 20000
SEED = 64064


def git_sha1(raw: bytes) -> str:
    return hashlib.sha1(b'blob ' + str(len(raw)).encode('ascii') + b'\0' + raw).hexdigest()


def validate_counts(rows):
    for a in rows:
        if len(a) != 6 or any(type(x) is not int for x in a):
            raise ValueError('six integer columns required')
        nh, yh, nl, yl, excl_acc, excl_checks = a
        if nh < 1 or nl < 1 or yh < 0 or yl < 0 or yh > nh or yl > nl:
            raise ValueError('invalid copied counts or missing stake condition')
        if excl_acc not in (0, 1) or excl_checks not in (0, 1):
            raise ValueError('binary exclusion flags required')
    if not rows:
        raise ValueError('no subject counts')
    return rows


def load_derived(path: Path):
    s = path.read_text(encoding='utf8').strip()
    a = [tuple(map(int, token.split(','))) for token in s.split(';')]
    return validate_counts(a)


def parse_author_raw(raw: bytes, expected_sha: str = BLOB_SHA1):
    if git_sha1(raw) != expected_sha:
        raise ValueError('FAIL_CLOSED: author Git blob SHA1 does not match')
    content = raw.decode('utf-8-sig')
    reader = csv.DictReader(io.StringIO(content, newline=''))
    if reader.fieldnames is None or not set(DATA_FIELDS).issubset(reader.fieldnames):
        raise ValueError('required author fields absent')
    grouped = defaultdict(lambda: {'nh': 0, 'yh': 0, 'nl': 0, 'yl': 0,
                                   'nacc': 0, 'sumacc': 0., 'nchecks': 0, 'sumchecks': 0.})
    seen = 0
    for row in reader:
        seen += 1
        if not all(row.get(k) not in (None, '') for k in DATA_FIELDS):
            raise ValueError('missing prespecified field; no imputation')
        uid, stakes = row['participant_id'], row['stakes']
        if stakes not in ('low', 'high'):
            raise ValueError('unknown stakes semantics')
        if row['copied'] not in ('0.0', '1.0') or row['accurate'] not in ('0.0', '1.0'):
            raise ValueError('nonbinary copied/accurate')
        try:
            cc = float(row['comprehension_check_repetitions'])
        except ValueError as e:
            raise ValueError('invalid comprehension repeats') from e
        if not math.isfinite(cc):
            raise ValueError('invalid comprehension repeats')
        g = grouped[uid]
        if stakes == 'high':
            g['nh'] += 1; g['yh'] += int(float(row['copied']))
        else:
            g['nl'] += 1; g['yl'] += int(float(row['copied']))
        g['nacc'] += 1; g['sumacc'] += float(row['accurate'])
        g['nchecks'] += 1; g['sumchecks'] += cc
    if not grouped:
        raise ValueError('no rows')
    rows = []
    for uid in sorted(grouped):
        x = grouped[uid]
        rows.append((x['nh'], x['yh'], x['nl'], x['yl'],
                     int(x['sumacc'] / x['nacc'] < 0.45),
                     int(x['sumchecks'] / x['nchecks'] > 2)))
    return validate_counts(rows), {'records': seen, 'participants': len(grouped), 'source_git_sha1': expected_sha}


def lcg(seed=SEED):
    # JS Math.imul / >>>0 algorithm used in connector-side 20k bootstrap.
    state = seed
    while True:
        state = (1664525 * state + 1013904223) & 0xffffffff
        yield state / 4294967296


def prediction_for_holdout(subjects, i):
    # No label from subject i is allowed to influence any fitted probability.
    train = [r for j, r in enumerate(subjects) if j != i]
    total_n = sum(r[0] + r[2] for r in train)
    total_y = sum(r[1] + r[3] for r in train)
    nh = sum(r[0] for r in train); yh = sum(r[1] for r in train)
    nl = sum(r[2] for r in train); yl = sum(r[3] for r in train)
    return ((total_y + 4) / (total_n + 8), (yh + 4) / (nh + 8), (yl + 4) / (nl + 8))


def mean_ci(rows, n=RESAMPLE_COUNT):
    rng = lcg()
    means = []
    pred_diffs = []
    L = len(rows)
    for _ in range(n):
        s1 = s2 = 0.
        for j in range(L):
            z = rows[int(next(rng) * L)]
            s1 += z['contrast']
            s2 += z['loss1'] - z['loss0']
        means.append(s1 / L)
        pred_diffs.append(s2 / L)
    means.sort(); pred_diffs.sort()
    return [means[499], means[19499]], [pred_diffs[499], pred_diffs[19499]]


def analyze(rows, excluded=True, bootstrap=True):
    rows = validate_counts(rows)
    arr = [x for x in rows if not excluded or not (x[4] or x[5])]
    if len(arr) < 10:
        raise ValueError('fewer than 10 eligible participants')
    hi = [sum(r[0] for r in arr), sum(r[1] for r in arr)]
    lo = [sum(r[2] for r in arr), sum(r[3] for r in arr)]
    pts = []
    for i, r in enumerate(arr):
        nh, yh, nl, yl = r[:4]
        p0, ph, pl = prediction_for_holdout(arr, i)
        L0 = -((yh + yl) * math.log(p0) + (nh + nl - yh - yl) * math.log1p(-p0))
        L1 = -(yh * math.log(ph) + (nh-yh) * math.log1p(-ph) +
               yl * math.log(pl) + (nl-yl) * math.log1p(-pl))
        B0 = (yh+yl) * (1-p0)**2 + (nh+nl-yh-yl) * p0**2
        B1 = yh*(1-ph)**2+(nh-yh)*ph**2 + yl*(1-pl)**2+(nl-yl)*pl**2
        pts.append({'contrast': yh/nh - yl/nl, 'loss0': L0/(nh+nl),
                    'loss1': L1/(nh+nl), 'brier0': B0/(nh+nl),
                    'brier1': B1/(nh+nl)})
    mean = lambda key: sum(p[key] for p in pts) / len(pts)
    result = {
        'n_participants': len(arr),
        'high': {'n':hi[0], 'copied':hi[1], 'rate':hi[1]/hi[0]},
        'low': {'n':lo[0], 'copied':lo[1], 'rate':lo[1]/lo[0]},
        'paired_difference':mean('contrast'),
        'pooled_difference':hi[1]/hi[0] - lo[1]/lo[0],
        'logloss_m0':mean('loss0'),'logloss_m1':mean('loss1'),
        'logloss_difference_m1_minus_m0':mean('loss1')-mean('loss0'),
        'brier_m0':mean('brier0'),'brier_m1':mean('brier1'),
        'm1_wins':sum(p['loss1']<p['loss0'] for p in pts),
    }
    if bootstrap:
        result['ci_paired_95'],result['ci_logloss_difference_95'] = mean_ci(pts)
    return result


def run(count_path, raw_path=None):
    protocol_path = Path(__file__).with_name('R064_PROTOCOL_PRECOMMIT.md')
    if hashlib.sha256(protocol_path.read_bytes()).hexdigest() != PRECOMMIT_SHA256:
        raise ValueError('FAIL_CLOSED: preregistered protocol bytes changed')
    derived = load_derived(count_path)
    if len(derived) != 295 or sum(r[0]+r[2] for r in derived) != 16103:
        raise ValueError('derived rows fail independent total check')
    provenance='CONNECTOR_DERIVED_ANONYMIZED_COUNTS_NOT_RAW_BYTES'
    if raw_path is not None:
        raw_rows, source = parse_author_raw(raw_path.read_bytes())
        if raw_rows != derived:
            raise ValueError('authenticated raw bytes disagree with derived counts')
        provenance='AUTHOR_BYTES_LOCALLY_AUTHENTICATED'
    return {
        'source_file_git_blob_sha1': BLOB_SHA1,
        'prespecified_protocol_sha256':PRECOMMIT_SHA256,
        'source_authentication':provenance,
        'participants_total':len(derived),
        'exclusion_reasons':{
            'accuracy_only':sum(r[4] and not r[5] for r in derived),
            'checks_only':sum(r[5] and not r[4] for r in derived),
            'both':sum(r[4] and r[5] for r in derived)},
        'after_exclusion':analyze(derived),
        'all_valid_sensitivity':analyze(derived, excluded=False),
        'PESEN_v0_1':'FROZEN',
        'interpretation':'retrospective independent authors; not external prospective validation',
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--derived',type=Path,default=Path(__file__).with_name('R064_DERIVED_COUNTS.txt'))
    p.add_argument('--raw',type=Path,default=None)
    p.add_argument('--out',type=Path)
    args=p.parse_args()
    result=run(args.derived,args.raw)
    s=json.dumps(result,ensure_ascii=False,indent=2)+'\n'
    if args.out:args.out.write_text(s,encoding='utf-8')
    print(s)

if __name__=='__main__':main()
