import hashlib
import json
import math
import tempfile
import unittest
from pathlib import Path
import r064_external_stakes as m

ROOT = Path(__file__).resolve().parent

class ProvenanceTests(unittest.TestCase):
    def test_protocol_hash_stable(self):
        self.assertEqual(hashlib.sha256((ROOT/'R064_PROTOCOL_PRECOMMIT.md').read_bytes()).hexdigest(),m.PRECOMMIT_SHA256)
    def test_original_source_blob_expected(self):
        self.assertEqual(len(m.BLOB_SHA1),40)
        self.assertEqual(m.BLOB_SHA1,'01bf211468abe093618dfa5e5c39e883230c9c03')
    def test_git_blob_hash_uses_size_header(self):
        self.assertEqual(m.git_sha1(b'hello'),hashlib.sha1(b'blob 5\0hello').hexdigest())
    def test_no_bytes_no_raw_authentication(self):
        self.assertEqual(m.run(ROOT/'R064_DERIVED_COUNTS.txt')['source_authentication'], 'CONNECTOR_DERIVED_ANONYMIZED_COUNTS_NOT_RAW_BYTES')
    def test_invalid_blob_rejected(self):
        with self.assertRaisesRegex(ValueError,'SHA1'):
            m.parse_author_raw(b'other csv')
    def test_corrupt_derived_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'a.txt';p.write_text('4,2,4,1,0,0;bad')
            with self.assertRaises(ValueError):m.load_derived(p)
    def test_author_parser_including_multiline_field(self):
        raw=('participant_id,stakes,copied,accurate,comprehension_check_repetitions,note\n'
             'p,high,1.0,1.0,1,"hello\nthere"\n'
             'p,low,0.0,1.0,1,bye\n').encode()
        rows,stats=m.parse_author_raw(raw,expected_sha=m.git_sha1(raw))
        self.assertEqual(rows,[(1,1,1,0,0,0)])
        self.assertEqual(stats['records'],2)
    def test_author_parser_no_outcome_imputation(self):
        raw=b'participant_id,stakes,copied,accurate,comprehension_check_repetitions\np,high,,1.0,1\n'
        with self.assertRaisesRegex(ValueError,'missing'):
            m.parse_author_raw(raw,expected_sha=m.git_sha1(raw))
    def test_author_parser_bad_stakes(self):
        raw=b'participant_id,stakes,copied,accurate,comprehension_check_repetitions\np,HIGH,1.0,1.0,1\n'
        with self.assertRaisesRegex(ValueError,'stakes'):
            m.parse_author_raw(raw,expected_sha=m.git_sha1(raw))
    def test_author_parser_non_binary(self):
        raw=b'participant_id,stakes,copied,accurate,comprehension_check_repetitions\np,high,0.5,1.0,1\n'
        with self.assertRaisesRegex(ValueError,'nonbinary'):
            m.parse_author_raw(raw,expected_sha=m.git_sha1(raw))
    def test_author_parser_missing_field(self):
        raw=b'participant_id,stakes,copied,accurate\np,high,1.0,1.0\n'
        with self.assertRaisesRegex(ValueError,'fields'):
            m.parse_author_raw(raw,expected_sha=m.git_sha1(raw))
    def test_exclusion_threshold_strict_boundary(self):
        raw=('participant_id,stakes,copied,accurate,comprehension_check_repetitions\n'
             'p,high,1.0,0.0,2\np,low,0.0,1.0,2\n'
             'q,high,1.0,1.0,3\nq,low,0.0,1.0,2\n').encode()
        z,_=m.parse_author_raw(raw,expected_sha=m.git_sha1(raw))
        self.assertEqual(z,[(1,1,1,0,0,0),(1,1,1,0,0,1)])

class MethodTests(unittest.TestCase):
    def test_invalid_counts(self):
        for row in [(1,2,3,2,0,0),(0,0,3,1,0,0),(1,0,1,0,2,0),(1,0,1,0,False,0)]:
            with self.subTest(row=row),self.assertRaises(ValueError):m.validate_counts([row])
    def test_empty(self):
        with self.assertRaises(ValueError):m.validate_counts([])
    def test_under_10(self):
        with self.assertRaisesRegex(ValueError,'fewer'):
            m.analyze([(5,2,5,3,0,0)]*9,bootstrap=False)
    def test_holdout_not_in_fit(self):
        x=[(10,3,10,2,0,0)]*10
        pp=m.prediction_for_holdout(x,0)
        x[0]=(10,8,10,9,0,0)
        self.assertEqual(pp,m.prediction_for_holdout(x,0))
    def test_stake_specific_fits_ignore_holdout(self):
        x=[(10,3,10,2,0,0)]*10
        pp=m.prediction_for_holdout(x,5)
        x[5]=(10,9,10,9,1,0)
        self.assertEqual(pp,m.prediction_for_holdout(x,5))
    def test_p0_equals_stake_probs_equal_rate(self):
        x=[(10,5,10,5,0,0)]*11
        p0,ph,pl=m.prediction_for_holdout(x,0)
        self.assertAlmostEqual(ph,pl)
        self.assertAlmostEqual(p0,ph)
    def test_beta_smoothing_finite_under_all_zeros(self):
        x=[(10,0,10,0,0,0)]*10
        v=m.analyze(x,bootstrap=False)
        self.assertTrue(math.isfinite(v['logloss_m0']))
        self.assertTrue(math.isfinite(v['logloss_m1']))
    def test_beta_smoothing_finite_under_all_ones(self):
        x=[(10,10,10,10,0,0)]*10
        v=m.analyze(x,bootstrap=False)
        self.assertTrue(math.isfinite(v['logloss_m0']))
    def test_sign_of_paired_contrast(self):
        x=[(10,8,10,2,0,0)]*10
        self.assertAlmostEqual(m.analyze(x,bootstrap=False)['paired_difference'],0.6)
    def test_exclusion_is_applied_before_training(self):
        x=[(10,8,10,2,0,0)]*10+[(10,0,10,10,1,0)]
        a=m.analyze(x,bootstrap=False)
        b=m.analyze(x,excluded=False,bootstrap=False)
        self.assertEqual(a['n_participants'],10)
        self.assertNotEqual(a['paired_difference'],b['paired_difference'])
    def test_lcg_known_step(self):
        r=m.lcg(1)
        self.assertAlmostEqual(next(r),1015568748/2**32)
    def test_reproducible_intervals(self):
        x=[(10+i%2,4,9,3,0,0) for i in range(13)]
        self.assertEqual(m.analyze(x)['ci_paired_95'],m.analyze(x)['ci_paired_95'])

class GenuineDerivedReplayTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.result=m.run(ROOT/'R064_DERIVED_COUNTS.txt')
    def test_exact_295_people(self):self.assertEqual(self.result['participants_total'],295)
    def test_source_row_sum_16103(self):
        a=m.load_derived(ROOT/'R064_DERIVED_COUNTS.txt')
        self.assertEqual(sum(z[0]+z[2] for z in a),16103)
    def test_total_copied_5792(self):
        a=m.load_derived(ROOT/'R064_DERIVED_COUNTS.txt')
        self.assertEqual(sum(z[1]+z[3] for z in a),5792)
    def test_exclusion_reasons(self):
        self.assertEqual(self.result['exclusion_reasons'],{'accuracy_only':19,'checks_only':44,'both':6})
    def test_226_eligible(self):
        a=self.result['after_exclusion']
        self.assertEqual((a['n_participants'],a['high']['n'],a['high']['copied'],a['low']['n'],a['low']['copied']),(226,6162,2260,6161,2228))
    def test_difference_close_to_connector(self):
        self.assertAlmostEqual(self.result['after_exclusion']['paired_difference'],.005829972225598637,places=14)
    def test_cross_validation_numerics(self):
        r=self.result['after_exclusion']
        self.assertAlmostEqual(r['logloss_m0'],.655893162112318,places=13)
        self.assertAlmostEqual(r['logloss_m1'],.6559589089766914,places=13)
        self.assertEqual(r['m1_wins'],111)
    def test_ci_matches_original_lcg(self):
        r=self.result['after_exclusion']
        self.assertAlmostEqual(r['ci_paired_95'][0],-.011046608004954047,places=14)
        self.assertAlmostEqual(r['ci_paired_95'][1],.022694205794897823,places=14)
    def test_sensitivity_sample_size(self):self.assertEqual(self.result['all_valid_sensitivity']['n_participants'],295)
    def test_results_json_matches_replay(self):
        b=json.loads((ROOT/'R064_DERIVED_RESULTS.json').read_text())
        self.assertEqual(b,self.result)

if __name__ == '__main__':unittest.main()
