# R042 正式研究包 | 2026-10-15

**研究主题**：有偿惩罚结果噪声实验的证据准入；16组实验后排除的方向敏感性；内生惩罚的非识别反例；拒绝将人机数据冒充真人—真人第三方验证。

**级别**：PLOS论文已发表汇总统计的条件性复算，官方Dryad数据源定位但获取403；没有真实微观数据字节、实验分配日志或正式预注册原文。未调整R039二元行动预测参数；PESEN v0.1 FROZEN。

### 运行

```bash
python r042_sensitivity.py --out R042_RESULTS.json
python -m unittest discover -s tests -v
```

`--canonical some_file.csv`仅接受事先完成**来源核验及字段映射**的标准化记录，不能直接假定作者 `noisy-PGG.csv` 就是这个schema。数据许可、原始文件SHA256、处理前后排除清单需单独归档。

### 文件清单

- `R042_EVIDENCE_AUDIT.md`：审计全文，已知与未知、模型机制边界。
- `R042_SOURCE_LEDGER.json`：来源URL及Git blob固定身份、可复现缺口。
- `R042_RESULTS.json`：可由分析程序确定性重现的数学结果。
- `r042_sensitivity.py`：标准库分析程序和规范化数据严格准入。
- `tests/test_r042.py`、`R042_TEST_LOG.txt`：35项合成测试。
- `R043_RESEARCH_GATE.md`：下一轮明确证据要求。
- `CHECKSUMS.sha256`：归档前对正式内容文件的校验。

作者数据不随包提供，项目没有修改任何外部GitHub仓库。
