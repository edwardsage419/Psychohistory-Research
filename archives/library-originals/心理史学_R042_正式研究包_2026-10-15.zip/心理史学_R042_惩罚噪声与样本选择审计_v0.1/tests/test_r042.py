import io
import json
import math
import sys
import unittest
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from r042_sensitivity import (selection_bounds,reversal_threshold_single_arm,
                              competing_scms,canonical_summarize,run_published)


def fixture(num_groups=2, size=4, rounds=20):
    data=[]
    for g in range(num_groups):
        for s in range(size):
            for r in range(1,rounds+1):
                did=int(r%3==0)
                data.append({'group_id':str(g),'subject_id':f'{g}:{s}',
                             'arm':'control' if g==0 else 'high',
                             'round':r,'contribution':8 if s%2==0 else 3,
                             'did_punish':did,'punishment_spent':did*2,
                             'antisocial_spent':did*1})
    return data

class TestR042(unittest.TestCase):
    def test_zero_exclusion(self):
        z=selection_bounds(21,.35,19,.53,0)
        self.assertAlmostEqual(z['lower'],.18)
        self.assertAlmostEqual(z['upper'],.18)
    def test_observed_exact(self):
        self.assertAlmostEqual(selection_bounds(21,.35,19,.53,16)['observed_treat_minus_control'],.18)
    def test_bounds_cross_zero(self):
        z=selection_bounds(21,.35,19,.53,16)
        self.assertLess(z['lower'],0);self.assertGreater(z['upper'],0)
    def test_published_lower_range(self):
        self.assertAlmostEqual(selection_bounds(21,.35,19,.53,16)['lower'],-.15769230769230774)
    def test_published_upper_range(self):
        self.assertAlmostEqual(selection_bounds(21,.35,19,.53,16)['upper'],.4198467432950192)
    def test_allocations(self):
        self.assertEqual(selection_bounds(21,.35,19,.53,16)['enumerated_allocations'],153)
    def test_contribution(self):
        s=selection_bounds(21,.62,19,.31,16)
        self.assertLess(s['lower'],-.5);self.assertGreater(s['upper'],0)
    def test_threshold_control(self):
        self.assertEqual(reversal_threshold_single_arm(21,.35,19,.53,16)['all_high_rate_missing_in_control'],9)
    def test_threshold_treat(self):
        self.assertEqual(reversal_threshold_single_arm(21,.35,19,.53,16)['all_zero_rate_missing_in_treatment'],10)
    def test_reject_bad_counts(self):
        for x in (0,-1,1.5,True):
            with self.assertRaises(ValueError):selection_bounds(x,.3,19,.5,16)
    def test_reject_bad_missing(self):
        for x in (-1,1.5,True):
            with self.assertRaises(ValueError):selection_bounds(21,.3,19,.5,x)
    def test_reject_bad_rates(self):
        for x in (-.1,1.1,float('nan')):
            with self.assertRaises(ValueError):selection_bounds(21,x,19,.5,16)
    def test_reversal_input(self):
        with self.assertRaises(ValueError):reversal_threshold_single_arm(21,.7,19,.3)
    def test_scm_observable_equal(self):
        x=competing_scms(.2)
        self.assertTrue(x['identical_observational_distribution'])
    def test_scm_different_intervention(self):
        x=competing_scms(.2)
        self.assertAlmostEqual(x['ace_do_p_model_A'],.6)
        self.assertEqual(x['ace_do_p_model_B'],0)
    def test_scm_valid_probability(self):
        for x in (-.1,1.1):
            with self.assertRaises(ValueError):competing_scms(x)
    def test_scm_probs_sum_to_one(self):
        self.assertAlmostEqual(sum(z['prob'] for z in competing_scms(.2)['observational_joint']),1)
    def test_canonical_valid(self):
        x=canonical_summarize(fixture());self.assertEqual((x['groups'],x['subjects'],x['paid_rounds']),(2,8,20))
    def test_canonical_rate(self):
        x=canonical_summarize(fixture());self.assertAlmostEqual(x['arm_averages']['control']['punish_rate'],6/20)
    def test_canonical_contrib(self):
        x=canonical_summarize(fixture());self.assertEqual(x['arm_averages']['control']['high_cooperation_rate'],.5)
    def test_missing_records_rejected(self):
        with self.assertRaises(ValueError):canonical_summarize([])
    def test_duplicate_round_rejected(self):
        f=fixture();f.append(f[0].copy())
        with self.assertRaises(ValueError):canonical_summarize(f)
    def test_missing_round_rejected(self):
        with self.assertRaises(ValueError):canonical_summarize(fixture()[:-1])
    def test_missing_column_rejected(self):
        f=fixture();f[0].pop('arm')
        with self.assertRaises(ValueError):canonical_summarize(f)
    def test_bad_arm_rejected(self):
        f=fixture();f[0]['arm']='other'
        with self.assertRaises(ValueError):canonical_summarize(f)
    def test_bad_contribution_rejected(self):
        f=fixture();f[0]['contribution']=11
        with self.assertRaises(ValueError):canonical_summarize(f)
    def test_total_punishment_up_to_three_targets(self):
        f=fixture();f[0]['did_punish']=1;f[0]['punishment_spent']=30;f[0]['antisocial_spent']=20
        self.assertEqual(canonical_summarize(f)['groups'],2)
    def test_total_punishment_above_three_targets_rejected(self):
        f=fixture();f[0]['did_punish']=1;f[0]['punishment_spent']=31
        with self.assertRaises(ValueError):canonical_summarize(f)
    def test_bad_antisocial_spent_rejected(self):
        f=fixture();f[0]['antisocial_spent']=12
        with self.assertRaises(ValueError):canonical_summarize(f)
    def test_bad_punish_binary_rejected(self):
        f=fixture();f[0]['did_punish']=2
        with self.assertRaises(ValueError):canonical_summarize(f)
    def test_bad_punish_mapping_rejected(self):
        f=fixture();f[0]['did_punish']=1
        with self.assertRaises(ValueError):canonical_summarize(f)
    def test_changed_arm_rejected(self):
        f=fixture();f[0]['arm']='high'
        with self.assertRaises(ValueError):canonical_summarize(f)
    def test_cross_group_person_rejected(self):
        f=fixture();f[-1]['subject_id']='0:0'
        with self.assertRaises(ValueError):canonical_summarize(f)
    def test_invalid_round_rejected(self):
        f=fixture();f[0]['round']=0
        with self.assertRaises(ValueError):canonical_summarize(f)
    def test_published_output_contract(self):
        x=run_published();self.assertEqual(x['excluded_groups'],16)
        self.assertIn('identification_counterexample',x)

if __name__=='__main__':unittest.main()
