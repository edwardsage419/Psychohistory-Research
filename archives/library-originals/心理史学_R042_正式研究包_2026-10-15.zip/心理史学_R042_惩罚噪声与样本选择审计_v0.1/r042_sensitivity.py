#!/usr/bin/env python3
"""R042: selection uncertainty & mechanism-identification guardrails.

No underlying noisy-PGG.csv is bundled. Published aggregate percentages are rounded.
This script does not estimate the published experimental effect independently.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
from collections import defaultdict
from dataclasses import dataclass
from math import isclose
from pathlib import Path

ARM_NAMES = ('control', 'low', 'medium', 'high')
EXPECTED_RETAINED_GROUPS = {'control':21, 'low':20, 'medium':20, 'high':19}
CANONICAL_COLUMNS = ('group_id','subject_id','arm','round','contribution','did_punish','punishment_spent','antisocial_spent')


def selection_bounds(n_control:int, p_control:float, n_treat:int, p_treat:float,
                     excluded_groups:int)->dict:
    """Extremize treated minus control over unknown excluded groups.

    Both groups have equal cluster weight; excluded proportions unconstrained in [0,1].
    Groups not allocated to two arms can belong to other conditions.
    """
    if not all(isinstance(x,int) and not isinstance(x,bool) and x>0 for x in (n_control,n_treat)):
        raise ValueError('retained group counts must be positive integers')
    if isinstance(excluded_groups,bool) or not isinstance(excluded_groups,int) or excluded_groups < 0:
        raise ValueError('excluded_groups must be nonnegative integer')
    if not all(isinstance(p,(int,float)) and not isinstance(p,bool) and 0<=p<=1 for p in (p_control,p_treat)):
        raise ValueError('rates must be in [0,1]')
    candidates=[]
    for missing_control in range(excluded_groups+1):
        for missing_treat in range(excluded_groups-missing_control+1):
            control_den=n_control+missing_control
            treat_den=n_treat+missing_treat
            lower=n_treat*p_treat/treat_den-(n_control*p_control+missing_control)/control_den
            upper=(n_treat*p_treat+missing_treat)/treat_den-n_control*p_control/control_den
            candidates.append((lower,upper,missing_control,missing_treat))
    worst_lower=min(candidates,key=lambda x:x[0])
    worst_upper=max(candidates,key=lambda x:x[1])
    return {
        'observed_treat_minus_control':p_treat-p_control,
        'lower':worst_lower[0], 'upper':worst_upper[1],
        'lower_missing_control':worst_lower[2], 'lower_missing_treat':worst_lower[3],
        'upper_missing_control':worst_upper[2], 'upper_missing_treat':worst_upper[3],
        'enumerated_allocations':len(candidates),
        'assumptions':'equal-weight complete groups; rates of missing groups 0..1; unknown allocation of excluded groups across 4 arms; published rates are rounded'
    }


def reversal_threshold_single_arm(n0: int,p0:float,n1:int,p1:float,max_missing:int=100)->dict:
    """Minimum excluded groups in one arm (only) which could reverse original sign."""
    if p1<=p0: raise ValueError('expected positive treated-control difference')
    return {
        'all_high_rate_missing_in_control':next((m for m in range(max_missing+1) if (n0*p0+m)/(n0+m)>=p1),None),
        'all_zero_rate_missing_in_treatment':next((m for m in range(max_missing+1) if n1*p1/(n1+m)<=p0),None),
    }


def competing_scms(noise_probability:float=.2)->dict:
    """Construct two observationally identical SCMs with different punishment effects.

    Z independent fair Bernoulli; U independent Bernoulli(q).
    P=Z xor U; Model A: Y=P xor U; Model B: Y=Z.
    Observations match exactly but do(P) effects differ.
    Synthetic mathematical counterexample, not an empirical fit.
    """
    q=noise_probability
    if not isinstance(q,(int,float)) or isinstance(q,bool) or not 0<=q<=1:raise ValueError('bad probability')
    a,b=defaultdict(float),defaultdict(float)
    for z in (0,1):
        for u,prob_u in ((0,1-q),(1,q)):
            p=z^u
            a[(z,p,p^u)]+=.5*prob_u
            b[(z,p,z)]+=.5*prob_u
    if dict(a)!=dict(b):raise AssertionError('observation must be equivalent')
    return {'observational_joint':[{'Z':z,'P':p,'Y':y,'prob':mass} for (z,p,y),mass in sorted(a.items())],
            'identical_observational_distribution':dict(a)==dict(b),
            'ace_do_p_model_A':1-2*q,'ace_do_p_model_B':0.,
            'identification':'FAILED: observation of Z,P,Y and randomized Z alone does not fix effect of endogenous P on Y'}


def _to_int(value,name):
    try: v=int(str(value))
    except (ValueError,TypeError):raise ValueError(f'{name} not integer') from None
    if str(value).strip()!=str(v):raise ValueError(f'{name} not strict integer')
    return v


def canonical_summarize(records:list[dict],expected_rounds=20,expected_group_size=4)->dict:
    """Analyze deliberately normalized rows only, never assume author original schema.

    A normalized record = one group member in one *paid* round; no personal IDs exported.
    Reject incomplete groups rather than silently dropping them.
    """
    if not records:raise ValueError('missing records')
    groups=defaultdict(list); subject_groups={}; group_arm={};seen=set()
    for rec in records:
        absent=set(CANONICAL_COLUMNS)-rec.keys()
        if absent:raise ValueError('missing columns: '+','.join(sorted(absent)))
        gid=str(rec['group_id']); sid=str(rec['subject_id']); arm=str(rec['arm'])
        if not gid or not sid or arm not in ARM_NAMES:raise ValueError('bad identifier or arm')
        rd=_to_int(rec['round'],'round')
        if not 1<=rd<=expected_rounds:raise ValueError('round outside paid study windows')
        key=(gid,sid,rd)
        if key in seen:raise ValueError('duplicate participant round')
        seen.add(key)
        if sid in subject_groups and subject_groups[sid]!=gid:raise ValueError('subject in multiple groups')
        subject_groups[sid]=gid
        if gid in group_arm and group_arm[gid]!=arm:raise ValueError('arm changes in group')
        group_arm[gid]=arm
        contribution=float(rec['contribution'])
        spent=float(rec['punishment_spent'])
        anti=float(rec['antisocial_spent'])
        did=_to_int(rec['did_punish'],'did_punish')
        if not (0 <= contribution <= 10 and 0 <= spent <= 30 and 0 <= anti <= spent):
            raise ValueError('invalid action/cost fields')
        if did not in (0,1) or ((spent>0) != (did==1)):
            raise ValueError('punishment choice inconsistent with paid cost')
        groups[gid].append((sid,rd,contribution,did,spent,anti))
    out=[]
    for gid,rs in groups.items():
        subjects={s for s,*_ in rs}
        if len(subjects)!=expected_group_size or len(rs)!=expected_group_size*expected_rounds:
            raise ValueError('incomplete group')
        for sid in subjects:
            if {round for subj,round,*_ in rs if subj==sid}!=set(range(1,expected_rounds+1)):
                raise ValueError('incomplete subject')
        n=len(rs)
        out.append({'group_id':gid,'arm':group_arm[gid],
                    'punish_rate':sum(v[3] for v in rs)/n,
                    'high_cooperation_rate':sum(v[2]>=8 for v in rs)/n,
                    'mean_contribution':sum(v[2] for v in rs)/n,
                    'mean_punishment_spent':sum(v[4] for v in rs)/n,
                    'mean_antisocial_spent':sum(v[5] for v in rs)/n})
    counts={arm:sum(v['arm']==arm for v in out) for arm in ARM_NAMES}
    byarm={}
    for arm in ARM_NAMES:
        grp=[v for v in out if v['arm']==arm]
        if grp:
            byarm[arm]={k:sum(v[k] for v in grp)/len(grp) for k in ('punish_rate','high_cooperation_rate','mean_contribution','mean_punishment_spent','mean_antisocial_spent')}
            byarm[arm]['groups']=len(grp)
    return {'groups':len(out),'subjects':len(subject_groups),'paid_rounds':expected_rounds,
            'counts':counts,'arm_averages':byarm,'state':'DESCRIPTIVE ONLY; original raw schema / allocation logs separately required'}


def canonical_csv(path: Path)->dict:
    with path.open('r',encoding='utf-8',newline='') as f:
        reader=csv.DictReader(f)
        result=canonical_summarize(list(reader))
    result['normalized_input_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
    return result


def run_published()->dict:
    return {'evidence':'rounded published aggregate rates ONLY; not real-data replication',
            'retained_groups':EXPECTED_RETAINED_GROUPS, 'original_groups':96, 'excluded_groups':16,
            'punish_any_control_vs_high':selection_bounds(21,.35,19,.53,16),
            'punish_any_reversal':reversal_threshold_single_arm(21,.35,19,.53,16),
            'high_contrib_control_vs_high':selection_bounds(21,.62,19,.31,16),
            'identification_counterexample':competing_scms(.2)}


def main():
    a=argparse.ArgumentParser(description=__doc__)
    a.add_argument('--canonical',type=Path,help='EXPLICITLY MAPPED group/member/paid-round CSV; not author raw schema')
    a.add_argument('--out',type=Path)
    args=a.parse_args()
    results=run_published()
    if args.canonical:
        results['mapped_data']=canonical_csv(args.canonical)
        results['mapped_data']['warning']='Requires documented external raw→canonical mapping and original source identity; do not treat normalized CSV as original data.'
    output=json.dumps(results,ensure_ascii=False,indent=2,sort_keys=True)
    if args.out:args.out.write_text(output+'\n',encoding='utf-8')
    else:print(output)

if __name__=='__main__':main()
