"""R006 unit tests of missingness rules and logical contrast bounds."""
import random
import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from missing_schools import (School, generate_schools, select_missing,
                             observed_contrast, full_contrast, bounded_full_contrast,
                             run, SCENARIOS)

class TestR006(unittest.TestCase):
    def test_randomization(self):
        schools = generate_schools(random.Random(3))
        self.assertEqual(len(schools), 56)
        self.assertEqual(sum(s.treated for s in schools), 28)
        for block in range(14):
            self.assertEqual(sum(s.treated for s in schools if s.block == block), 2)

    def test_missing_size_and_arm(self):
        schools = generate_schools(random.Random(6))
        for mechanism in SCENARIOS:
            missing = select_missing(schools, mechanism, random.Random(7))
            self.assertEqual(len(missing), 7)
            if mechanism == "MNAR_T":
                self.assertTrue(all(schools[i].treated for i in missing))
            if mechanism == "MNAR_C":
                self.assertTrue(all(not schools[i].treated for i in missing))
            if mechanism == "MNAR_MIX":
                self.assertEqual(sum(schools[i].treated for i in missing), 4)

    def test_no_missing_identifies_full(self):
        schools = generate_schools(random.Random(5))
        d = full_contrast(schools)
        self.assertAlmostEqual(observed_contrast(schools, set()), d)
        lo, hi = bounded_full_contrast(schools, set())
        self.assertAlmostEqual(lo, d)
        self.assertAlmostEqual(hi, d)

    def test_bounds_are_sharp(self):
        schools = [School(0, True, 0.8), School(0, True, 0.3),
                   School(0, False, 0.2), School(0, False, 0.6)]
        missing = {0, 2}
        lo, hi = bounded_full_contrast(schools, missing)
        # For min, missing treated outcome 0, missing control outcome 1.
        self.assertAlmostEqual(lo, (0.3 + 0)/2 - (0.6 + 1)/2)
        self.assertAlmostEqual(hi, (0.3 + 1)/2 - (0.6 + 0)/2)
        self.assertTrue(lo <= full_contrast(schools) <= hi)

    def test_width_7_over_28(self):
        schools = generate_schools(random.Random(3))
        for m in SCENARIOS:
            missing = select_missing(schools, m, random.Random(4))
            lo, hi = bounded_full_contrast(schools, missing)
            self.assertAlmostEqual(hi-lo, 0.25)

    def test_reproducibility(self):
        self.assertEqual(run(3, 42), run(3, 42))

    def test_known_zero_inside_simple_example(self):
        s = [School(0, True, 0.2), School(0, False, 0.2)]
        a, b = bounded_full_contrast(s, set())
        self.assertAlmostEqual(a, 0.0)
        self.assertAlmostEqual(b, 0.0)

    def test_reject_unbounded_observed_outcome(self):
        s = [School(0, True, 1.2), School(0, False, 0.2)]
        with self.assertRaises(ValueError):
            bounded_full_contrast(s, set(), 0.0, 1.0)

    def test_reject_bad_missing_index(self):
        s = [School(0, True, 0.2), School(0, False, 0.2)]
        with self.assertRaises(ValueError):
            bounded_full_contrast(s, {2})

    def test_invalid_mechanism(self):
        s = generate_schools(random.Random(13))
        with self.assertRaises(ValueError):
            select_missing(s, "NOPE", random.Random(42))

if __name__ == '__main__':
    unittest.main()
