#!/usr/bin/env python3
"""R006: Synthetic cluster-outcome missingness stress test.

Only Python standard library is required. Run after reviewing PROTOCOL.md.
This code does not access or analyze any ICPSR individual records.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import math
import random
import statistics
from dataclasses import dataclass
from pathlib import Path

N_BLOCKS = 14
BLOCK_SIZE = 4
N_ARM = N_BLOCKS * BLOCK_SIZE // 2
N_MISSING = 7
EFFECT = -0.04
SCENARIOS = ("MCAR", "MNAR_T", "MNAR_C", "MNAR_MIX")

@dataclass(frozen=True)
class School:
    block: int
    treated: bool
    outcome: float


def logistic(value: float) -> float:
    if value >= 0:
        return 1.0 / (1.0 + math.exp(-value))
    val = math.exp(value)
    return val / (1 + val)


def generate_schools(rng: random.Random) -> list[School]:
    schools: list[School] = []
    for block in range(N_BLOCKS):
        block_effect = rng.gauss(0, 0.40)
        treatment_indices = set(rng.sample(range(BLOCK_SIZE), 2))
        for k in range(BLOCK_SIZE):
            treated = k in treatment_indices
            untreated = logistic(-0.8 + block_effect + rng.gauss(0, 0.55))
            outcome = min(1.0, max(0.0, untreated + EFFECT if treated else untreated))
            schools.append(School(block, treated, outcome))
    assert sum(s.treated for s in schools) == N_ARM
    return schools


def select_missing(schools: list[School], mechanism: str, rng: random.Random) -> set[int]:
    treated = [i for i, s in enumerate(schools) if s.treated]
    control = [i for i, s in enumerate(schools) if not s.treated]
    if mechanism == "MCAR":
        return set(rng.sample(range(len(schools)), N_MISSING))
    if mechanism == "MNAR_T":
        return set(sorted(treated, key=lambda i: schools[i].outcome, reverse=True)[:N_MISSING])
    if mechanism == "MNAR_C":
        return set(sorted(control, key=lambda i: schools[i].outcome)[:N_MISSING])
    if mechanism == "MNAR_MIX":
        return set(sorted(treated, key=lambda i: schools[i].outcome, reverse=True)[:4] +
                   sorted(control, key=lambda i: schools[i].outcome)[:3])
    raise ValueError(f"Unknown mechanism: {mechanism}")


def observed_contrast(schools: list[School], missing: set[int]) -> float:
    t = [s.outcome for i, s in enumerate(schools) if i not in missing and s.treated]
    c = [s.outcome for i, s in enumerate(schools) if i not in missing and not s.treated]
    if not t or not c:
        raise ValueError("Both arms need at least one observed outcome")
    return statistics.mean(t) - statistics.mean(c)


def full_contrast(schools: list[School]) -> float:
    return observed_contrast(schools, set())


def bounded_full_contrast(schools: list[School], missing: set[int], low: float=0.0, high: float=1.0) -> tuple[float, float]:
    """Sharp logical bounds for *complete observed-arm contrast*, not an ATE CI."""
    if not (low < high):
        raise ValueError("Invalid bounds")
    if any(i < 0 or i >= len(schools) for i in missing):
        raise ValueError("Missing school index outside assigned units")
    if any(not (low <= s.outcome <= high) for i, s in enumerate(schools) if i not in missing):
        raise ValueError("Observed outcome outside declared measurement bounds")
    n_t = sum(s.treated for s in schools)
    n_c = len(schools) - n_t
    if n_t == 0 or n_c == 0:
        raise ValueError("Both arms need assigned schools")
    obs_t = sum(s.outcome for i, s in enumerate(schools) if i not in missing and s.treated)
    obs_c = sum(s.outcome for i, s in enumerate(schools) if i not in missing and not s.treated)
    m_t = sum(schools[i].treated for i in missing)
    m_c = len(missing) - m_t
    return ((obs_t + m_t * low) / n_t - (obs_c + m_c * high) / n_c,
            (obs_t + m_t * high) / n_t - (obs_c + m_c * low) / n_c)


def trial(rng: random.Random, scenario: str) -> dict[str, float | str | int | bool]:
    schools = generate_schools(rng)
    missing = select_missing(schools, scenario, rng)
    assert len(missing) == N_MISSING
    full = full_contrast(schools)
    cc = observed_contrast(schools, missing)
    lo, hi = bounded_full_contrast(schools, missing)
    assert lo - 1e-12 <= full <= hi + 1e-12
    return {"scenario": scenario,
            "missing_treated": sum(schools[i].treated for i in missing),
            "missing_control": sum(not schools[i].treated for i in missing),
            "full_assigned_contrast": full,
            "complete_case_contrast": cc,
            "cc_minus_full_bias": cc - full,
            "lower_bound": lo, "upper_bound": hi, "width": hi - lo,
            "covers_full": lo - 1e-12 <= full <= hi + 1e-12,
            "contains_zero": lo <= 0 <= hi}


def summarize(rows: list[dict]) -> dict:
    summary: dict[str, object] = {}
    for scenario in SCENARIOS:
        part = [r for r in rows if r["scenario"] == scenario]
        biases = [float(r["cc_minus_full_bias"]) for r in part]
        summary[scenario] = {
            "trials": len(part),
            "mean_full_contrast": statistics.mean(float(r["full_assigned_contrast"]) for r in part),
            "mean_complete_case_contrast": statistics.mean(float(r["complete_case_contrast"]) for r in part),
            "mean_bias": statistics.mean(biases),
            "mean_absolute_bias": statistics.mean(abs(b) for b in biases),
            "bias_negative_rate": sum(b < 0 for b in biases) / len(biases),
            "mean_width": statistics.mean(float(r["width"]) for r in part),
            "bound_coverage_full_assigned": sum(r["covers_full"] for r in part) / len(part),
            "bound_contains_zero_rate": sum(r["contains_zero"] for r in part) / len(part),
            "mean_missing_treatment_schools": statistics.mean(float(r["missing_treated"]) for r in part),
        }
    return summary


def run(trials: int=400, seed: int=20261014) -> tuple[list[dict], dict]:
    if trials < 1:
        raise ValueError("trials must be positive")
    # Mechanisms have independent streams, preserving deterministic replicability.
    rows: list[dict] = []
    for j, scenario in enumerate(SCENARIOS):
        rng = random.Random(seed + (j * 1_000_003))
        for k in range(trials):
            record = trial(rng, scenario)
            record["trial"] = k + 1
            rows.append(record)
    return rows, summarize(rows)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--trials", type=int, default=400)
    parser.add_argument("--seed", type=int, default=20261014)
    parser.add_argument("--out", type=Path, default=Path("results"))
    args = parser.parse_args()
    records, results = run(args.trials, args.seed)
    args.out.mkdir(parents=True, exist_ok=True)
    with (args.out / "per_trial.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)
    payload = {"research": "R006", "status": "SYNTHETIC_ONLY", "seed": args.seed,
               "trials_per_scenario": args.trials,
               "scenario_order": SCENARIOS,
               "generation": {"n_blocks": N_BLOCKS, "block_size": BLOCK_SIZE,
                              "n_treated": N_ARM, "n_controls": N_ARM,
                              "n_missing": N_MISSING, "tau": EFFECT,
                              "block_sigma": 0.40, "school_sigma": 0.55,
                              "outcome_scale": [0, 1]},
               "estimand": "complete assigned-arm contrast; NOT an average treatment effect confidence interval",
               "summary": results}
    output = args.out / "summary.json"
    output.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(results, ensure_ascii=False, indent=2))
    print("SHA256 summary.json:", hashlib.sha256(output.read_bytes()).hexdigest())

if __name__ == "__main__":
    main()
