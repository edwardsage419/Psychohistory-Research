# 心理史学 R023：社区意见不一致与自报发言可能性

研究日期：2026-10-14。状态：**公开真人数据，GitHub 连接器端原始字节分析；本地 Python 原始数据端到端复现尚未完成**。

## 数据与谱系
作者：Zhao, Yang & Bernstein (CHI 2026), *Mapping the Spiral of Silence: Surveying Unspoken Opinions in Online Communities*。
仓库：https://github.com/StanfordHCI/spiral-of-silence
数据：https://github.com/StanfordHCI/spiral-of-silence/blob/main/data.csv
Git blob SHA1: `11c4ccb53944a79b1f1def49d358e04c944e42f1`。
以 GitHub fetch_blob 完整读取 65,256 字符、439 条记录、58 名参与者、12 社区。源码与分析公开，未提交任何账号信息或私人可识别数据。

## 本轮预定问题与结果
`Agreement` 是对陈述的个人认同，`Sub_Agree` 是感知社区认同，`Incongruency` 为二元不一致指标，`Comment_Likelihood` 为 1–7 级自报发表评论可能性。数据中 `Agreement` 仅5、6、7，样本不是完整政治立场分布。这里沿用作者现成的 `Incongruency`，尚未独立核实其算法阈值，不能称其为实验随机化。

* 一致类 335 条，平均意愿 4.14627；不一致类 104 条，平均意愿 3.00962。
* 58 人中42人同时评价两类；每人分别对两类项目求平均，再对42个人的差等权求均值，得到 -0.9040155；按人重抽样10,000次探索性区间约[-1.3503,-0.4745]。
* 不一致类的感知社区认同均值3.038，而一致类5.875，符合分组含义但不意味着随机分配。
* 另外16人只评价一种类别，不纳入同人对比；缺失配对不是随机缺失，需审计。

## 证据边界
未记录真实发帖行为、独立受众惩罚、事前测得评价风险，也没有现场随机操纵受众网络。不能从自报可能性推断实际发表概率或PESEN机制成立。同人对比减少稳定个体差异，但不同项目/议题的混淆仍存在。R022提示，事后问卷可能对沉默者存在严重选择偏差；两个研究不能视作同一批人。

## 复现
在联网机器下载上述data.csv，确认 Git blob SHA1，再运行：
`python r023_analysis.py data.csv --output result.json`
本地执行 `python -m unittest discover -s tests -v` 已通过8项构造样本测试。当前包不重分发原始人级数据；未在本地容器对其端到端运行。

## 对项目的意义
提供对“个人观点-感知社群意见不一致→较低表达意愿”关系的观察性证据；既非新理论，也非真正的私人回答/实际公开发言逐题配对，不升级PESEN。R024应优先严格核验作者 `Incongruency` 定义及话题/观点固定效应，或取得同时含前测风险和真实发表行为的外部随机化研究。
