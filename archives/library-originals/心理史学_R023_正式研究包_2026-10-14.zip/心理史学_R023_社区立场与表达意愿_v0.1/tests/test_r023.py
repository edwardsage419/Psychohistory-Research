import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from r023_analysis import analyze,blob_sha
H='Participant,Incongruency,Agreement,Comment_Likelihood\n'
class Audit(unittest.TestCase):
 def test_paired(self):
  r=analyze(H+'A,0,6,5\nA,1,6,3\nB,0,7,4\nB,1,5,2\n',0)
  self.assertEqual(r['n_people_with_both'],2);self.assertAlmostEqual(r['paired_difference'],-2)
 def test_weight_each_participant(self):
  r=analyze(H+'A,0,6,7\nA,0,6,7\nA,1,6,5\nB,0,6,5\nB,1,6,5\n',0)
  self.assertAlmostEqual(r['paired_difference'],-1)
 def test_exclude_unpaired(self):
  r=analyze(H+'A,0,6,4\nA,1,6,3\nB,0,6,7\n',0)
  self.assertEqual(r['n_people_with_both'],1)
 def test_range(self):
  with self.assertRaises(ValueError):analyze(H+'A,0,8,3\n',0)
 def test_no_paired(self):
  with self.assertRaises(ValueError):analyze(H+'A,0,6,3\n',0)
 def test_empty(self):
  with self.assertRaises(ValueError):analyze(H,0)
 def test_bootstrap_deterministic(self):
  inp=H+'A,0,6,5\nA,1,6,3\nB,0,6,4\nB,1,6,3\n'
  self.assertEqual(analyze(inp,100,2),analyze(inp,100,2))
 def test_git_sha(self):
  self.assertEqual(blob_sha(b'test'),'30d74d258442c7c65512eafab474568dd706c430')
if __name__=='__main__':unittest.main()
