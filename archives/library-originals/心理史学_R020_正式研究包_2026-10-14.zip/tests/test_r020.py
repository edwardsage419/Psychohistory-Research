import math
import unittest
from r020_design import (CELLS, SyntheticParameters,generate, estimate, design_rank,
                         contrast_weights, audience_only_can_mimic,monte_carlo,validate,gaussian_rank,logistic)
class Tests(unittest.TestCase):
    def test_cell_balance(self): self.assertEqual(len(CELLS),16)
    def test_rank(self): self.assertEqual(design_rank(),6)
    def test_rank_deficient(self): self.assertEqual(gaussian_rank([[1,2],[2,4],[3,6]]),1)
    def test_weight_sum_zero(self):
        for n in ['evidence_to_private','cost_to_public','approval_x_visibility_on_public']:
            self.assertAlmostEqual(sum(contrast_weights(n).values()),0)
    def test_evidence_not_confound(self):
        w=contrast_weights('evidence_to_private');self.assertAlmostEqual(sum(v for k,v in w.items() if k[0]==1),1)
        self.assertAlmostEqual(sum(v for k,v in w.items() if k[0]==0),-1)
    def test_cost_not_confound(self):
        w=contrast_weights('cost_to_public');self.assertAlmostEqual(sum(v for k,v in w.items() if k[3]==1),1)
        self.assertAlmostEqual(sum(v for k,v in w.items() if k[3]==0),-1)
    def test_audience_visibility_interaction(self):
        w=contrast_weights('approval_x_visibility_on_public')
        self.assertEqual(w[(0,1,1,0)],.25)
        self.assertEqual(w[(0,0,0,0)],.25)
    def test_reproducible_generation(self):
        a=generate(SyntheticParameters(),3)
        self.assertEqual(a,generate(SyntheticParameters(),3))
    def test_samples_per_cell(self):
        a=generate(SyntheticParameters(),17)
        self.assertEqual(sum(map(len,a.values())),272)
    def test_estimate_finite(self):
        a=generate(SyntheticParameters(),32)
        for n in ['evidence_to_private','cost_to_public','approval_x_visibility_on_public']:
            e=estimate(a,n);self.assertTrue(math.isfinite(e['estimate']))
            self.assertGreaterEqual(e['se'],0)
    def test_invalid_n(self):
        with self.assertRaises(ValueError):generate(SyntheticParameters(),1)
    def test_negative_noise(self):
        with self.assertRaises(ValueError):validate(SyntheticParameters(private_noise=-1),12)
    def test_invalid_name(self):
        with self.assertRaises(ValueError):contrast_weights('unknown')
    def test_audience_equivalence(self):
        for s in [.2,.4,.5,.8]:
            d=audience_only_can_mimic(s)
            self.assertAlmostEqual(d/(1+d),s)
    def test_audience_out_of_range(self):
        with self.assertRaises(ValueError):audience_only_can_mimic(1)
    def test_monte_carlo_smoke(self):
        x=monte_carlo(per_cell=10,replications=3)
        self.assertEqual(len(x['results']),3)
        self.assertEqual(x['design_matrix_rank'],6)
    def test_logistic(self):
        self.assertEqual(logistic(0),.5)
        self.assertAlmostEqual(logistic(100),1)
        self.assertGreater(logistic(-100),0)
if __name__=='__main__': unittest.main()
