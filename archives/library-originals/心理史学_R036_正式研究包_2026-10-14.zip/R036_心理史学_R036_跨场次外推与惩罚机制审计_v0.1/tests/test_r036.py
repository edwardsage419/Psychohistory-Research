import copy
import hashlib
import json
import math
import pathlib
import random
import sys
import tempfile
import unittest
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]))
import r036_analysis as m
D=pathlib.Path(__file__).resolve().parents[1]

class Validity(unittest.TestCase):
    def setUp(self):
        self.data=json.loads((D/'SESSION_DERIVED_CELLS.json').read_text())
        self.checkpoint=json.loads((D/'R035_CHECKPOINT_MARGINS.json').read_text())

    def test_one_source_sha(self):self.assertEqual(self.data['source']['git_blob_sha1'],m.SOURCE_SHA)
    def test_sha_of_derived_data(self):self.assertEqual(hashlib.sha256((D/'SESSION_DERIVED_CELLS.json').read_bytes()).hexdigest(),m.DATA_SHA256)
    def test_checkpoint_sha(self):self.assertEqual(hashlib.sha256((D/'R035_CHECKPOINT_MARGINS.json').read_bytes()).hexdigest(),m.CHECKPOINT_SHA256)
    def test_all_margins_pass(self):self.assertTrue(m.validate(self.data))
    def test_r035_checkpoint_pass(self):self.assertTrue(m.verify_r035_checkpoint(self.data,self.checkpoint))
    def test_bad_source_reject(self):
        d=copy.deepcopy(self.data);d['source']['git_blob_sha1']='bogus'
        with self.assertRaises(AssertionError):m.validate(d)
    def test_bad_session_duplicate_reject(self):
        d=copy.deepcopy(self.data);d['sessions'][0]['session']=d['sessions'][1]['session']
        with self.assertRaises(AssertionError):m.validate(d)
    def test_changed_train_count_reject(self):
        d=copy.deepcopy(self.data);d['sessions'][0]['train_y_by_period'][0]+=1
        with self.assertRaises(AssertionError):m.validate(d)
    def test_changed_transition_reject(self):
        d=copy.deepcopy(self.data);d['sessions'][0]['train_transition'][1][1]+=1
        with self.assertRaises(AssertionError):m.validate(d)
    def test_missing_holdout_period_reject(self):
        d=copy.deepcopy(self.data);d['sessions'][0]['test_by_start7_period'][0][1]=7
        with self.assertRaises(AssertionError):m.validate(d)
    def test_bad_holdout_count_reject(self):
        d=copy.deepcopy(self.data);d['sessions'][0]['test_by_k'][0][1]+=1
        with self.assertRaises(AssertionError):m.validate(d)
    def test_marginal_hidden_transcription_error_reject(self):
        d=copy.deepcopy(self.data)
        d['sessions'][0]['train_y_by_period'][0]+=1
        d['sessions'][1]['train_y_by_period'][0]-=1
        # Global counts preserved, but checkpoint per treatment arm also preserved.
        # Cross-session consistency within source cannot be independently validated without original file.
        self.assertTrue(m.verify_r035_checkpoint(d,self.checkpoint))
    def test_margin_cross_arm_swap_reject(self):
        d=copy.deepcopy(self.data)
        d['sessions'][0]['train_y_by_period'][0]+=1
        d['sessions'][3]['train_y_by_period'][0]-=1
        with self.assertRaises(AssertionError):m.verify_r035_checkpoint(d,self.checkpoint)
    def test_bad_checkpoint_reject(self):
        c=copy.deepcopy(self.checkpoint);c['train_by_period_arm'][0][3]+=1
        with self.assertRaises(AssertionError):m.verify_r035_checkpoint(self.data,c)
    def test_original_hash_failure(self):
        with tempfile.TemporaryDirectory() as p:
            f=pathlib.Path(p)/'fake.csv';f.write_text('a,b\n1,2\n')
            with self.assertRaises(ValueError):m.validate_original_raw(f,self.data)
    def test_git_blob_known_vector(self):
        self.assertEqual(m.git_blob_sha(b'test'),hashlib.sha1(b'blob 4\x00test').hexdigest())
    def test_loss_formula(self):
        self.assertAlmostEqual(m.loss(2,1,.5),2*math.log(2))
        self.assertAlmostEqual(m.brier(2,1,.5),.5)
    def test_loss_zero_and_one_are_finite(self):
        self.assertTrue(math.isfinite(m.loss(4,2,0)))
        self.assertTrue(math.isfinite(m.loss(4,2,1)))
    def test_trend_slope_direction(self):
        a,b=m.trend_fit(self.data['sessions'])
        self.assertLess(b,0)
    def test_loso_excludes_target(self):
        target=self.data['sessions'][0];others=self.data['sessions'][1:]
        f=m.evaluate_fold(others,target)
        self.assertEqual(f['training_people'],134-target['n_people'])
        self.assertEqual(f['test_n'],3*target['n_people'])
    def test_score_ranges(self):
        v=m.run(self.data)
        self.assertEqual(v['n_test_decisions'],402)
        for metric in v['models'].values():
            self.assertLess(metric['log_loss'],1)
            self.assertTrue(0<metric['brier']<1)
    def test_expected_mean_loss(self):
        v=m.run(self.data)
        self.assertAlmostEqual(v['models']['markov_frozen7']['log_loss'],0.5105312461971169,places=12)
        self.assertAlmostEqual(v['models']['individual_first7']['log_loss'],0.5481520934890299,places=12)
    def test_markov_dominates_pooled_all_six(self):
        v=m.run(self.data)
        self.assertEqual(v['markov_minus_pooled']['better_sessions_count'],6)
        self.assertEqual(v['markov_minus_person']['better_sessions_count'],4)
    def test_bootstrap_reproducible(self):
        v=m.run(self.data);x=m.bootstrap(v['six_folds'],reps=500,seed=8);y=m.bootstrap(v['six_folds'],reps=500,seed=8)
        self.assertEqual(x,y)
    def test_bootstrap_interval_includes_zero(self):
        ci=m.run(self.data)['markov_minus_person']['session_bootstrap_95_percentile']
        self.assertTrue(ci[0]<0<ci[1])
    def test_repeatable_session_order(self):
        v=m.run(self.data)
        d=copy.deepcopy(self.data);d['sessions'].reverse();w=m.run(d)
        self.assertAlmostEqual(v['models']['markov_frozen7']['log_loss'],w['models']['markov_frozen7']['log_loss'],places=12)

if __name__=='__main__':unittest.main()
