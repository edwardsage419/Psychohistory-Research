#!/usr/bin/env python3
"""R036 cross-session holdout for conditional cooperation classifications.

Original study: Andreozzi, Ploner & Saral (2020) Scientific Reports 10:13610.
Inputs: verifiable, non-identifying session-level derivatives from 1340 source rows.
No claim of strict preregistration; all model development post-dates viewing data.
This file never contacts the network and never writes any external service.
"""
import argparse
import csv
import hashlib
import json
import math
import random
from pathlib import Path

HERE=Path(__file__).resolve().parent
SOURCE_SHA='bd4c1550002621bee7dfb50e0d15d317764d1ea9'
DATA_SHA256='d92eef812d71d61068b67c064949a45133ea3413f281460fd6c3943b91cb2222'
CHECKPOINT_SHA256='26fcf8788c79c397847f4711a24c4849c38ee2777520328d3b74c144c207ef4d' 


def git_blob_sha(data: bytes) -> str:
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()


def validate(data):
    assert data['source']['git_blob_sha1']==SOURCE_SHA
    s=data['sessions']; assert len(s)==6
    assert sorted(x['session'] for x in s)==['10001','10004','10005','20002','20003','20006']
    assert sum(x['n_people'] for x in s)==134
    assert sorted({x['arm'] for x in s})==['CondInfo','NoCondInfo']
    assert {arm:sum(x['arm']==arm for x in s) for arm in ('CondInfo','NoCondInfo')} == {'CondInfo':3,'NoCondInfo':3}
    assert sum(sum(x['train_y_by_period']) for x in s)==527
    assert sum(x['n_people']*7 for x in s)==938
    assert sum(x['n_people']*3 for x in s)==402
    sums=[0,0];trans=[[0,0],[0,0]]
    for x in s:
        n=x['n_people'];assert len(x['train_y_by_period'])==7
        assert all(0<=v<=n for v in x['train_y_by_period'])
        assert len(x['train_transition'])==2
        assert sum(q[0] for q in x['train_transition'])==6*n
        for z in (0,1):
            q=x['train_transition'][z];assert 0<=q[1]<=q[0]
            trans[z][0]+=q[0];trans[z][1]+=q[1]
        assert sum(q[1] for q in x['test_by_k'])==3*n
        assert sum(q[2] for q in x['test_by_start7_period'])==3*n
        assert {q[1] for q in x['test_by_start7_period']}=={8,9,10}
        assert all(0<=q[-1]<=q[-2] for q in x['test_by_k']+x['test_by_start7_period'])
        assert all(0<=q[0]<=7 for q in x['test_by_k'])
        assert all(q[0] in (0,1) for q in x['test_by_start7_period'])
        assert all(sum(q[2] for q in x['test_by_start7_period'] if q[1]==t)==n for t in (8,9,10))
        assert sum(q[2] for q in x['test_by_k'])==sum(q[3] for q in x['test_by_start7_period'])
        sums[0]+=sum(q[-1] for q in x['test_by_k'])
        sums[1]+=sum(q[-1] for q in x['test_by_start7_period'])
        # constant initial state count across 3 target rounds
        assert sum(q[2] for q in x['test_by_start7_period'] if q[0]==0 and q[1]==8)==sum(q[2] for q in x['test_by_start7_period'] if q[0]==0 and q[1]==10)
    assert sums==[170,170]
    assert trans==[[345,50],[459,390]]
    # every person contributes a single binary classification each round
    return True


def verify_r035_checkpoint(data, checkpoint):
    """Every prior R035 aggregate margin must agree with independent session disaggregation."""
    assert checkpoint['git_blob_sha1']==SOURCE_SHA
    by_period={}
    transitions=[[0,0],[0,0]]
    test_by_period={}
    test_by_last={}
    for s in data['sessions']:
        arm=s['arm'];n=s['n_people']
        for j,y in enumerate(s['train_y_by_period']):
            k=(arm,j+1);a=by_period.setdefault(k,[0,0]);a[0]+=n;a[1]+=y
        for last in (0,1):
            q=s['train_transition'][last]
            for j in (0,1):transitions[last][j]+=q[j]
        for start,t,n_test,y in s['test_by_start7_period']:
            key=(arm,t);a=test_by_period.setdefault(key,[0,0]);a[0]+=n_test;a[1]+=y
            k=(start,t,arm);a=test_by_last.setdefault(k,[0,0]);a[0]+=n_test;a[1]+=y
    assert sorted([[*k,*v] for k,v in by_period.items()])==sorted(checkpoint['train_by_period_arm'])
    assert [[i,*q] for i,q in enumerate(transitions)]==checkpoint['train_transitions']
    assert sorted([[*k,*v] for k,v in test_by_period.items()])==sorted(checkpoint['test_arm_period'])
    assert sorted([[*k,*v] for k,v in test_by_last.items()])==sorted(checkpoint['test_by_period7_state'])
    return True


def validate_original_raw(path,derived):
    raw=Path(path).read_bytes();actual=git_blob_sha(raw)
    if actual!=SOURCE_SHA:raise ValueError(f'original Git SHA mismatch {actual}')
    rows=list(csv.DictReader(raw.decode('utf-8-sig').splitlines()))
    people={}
    for x in rows:
        if x['isCC'] not in ('TRUE','FALSE'):raise ValueError('missing original classification')
        key=x['subject_unq'];people.setdefault(key,[]).append((x['session_unq'],x['treatment'],int(x['period']),int(x['isCC']=='TRUE')))
    if len(rows)!=1340 or len(people)!=134:raise ValueError('source record count mismatch')
    observed={}
    for person,rs in people.items():
        rs.sort(key=lambda z:z[2]);sid=rs[0][0]
        if [z[2] for z in rs]!=list(range(1,11)) or any(z[0]!=sid or z[1]!=rs[0][1] for z in rs):raise ValueError('invalid subject timeline')
        if sid not in observed: observed[sid]={'n':0,'p':[0]*7,'tr':[[0,0],[0,0]],'k':{},'f':{}}
        s=observed[sid];s['n']+=1
        for i in range(7):s['p'][i]+=rs[i][3]
        for i in range(1,7):s['tr'][rs[i-1][3]][0]+=1;s['tr'][rs[i-1][3]][1]+=rs[i][3]
        k=sum(z[3] for z in rs[:7]);start=rs[6][3]
        for i in range(7,10):
            item=s['k'].setdefault(k,[0,0]);item[0]+=1;item[1]+=rs[i][3]
            item=s['f'].setdefault((start,rs[i][2]),[0,0]);item[0]+=1;item[1]+=rs[i][3]
    for exp in derived['sessions']:
        s=observed[exp['session']]
        assert s['n']==exp['n_people'] and s['p']==exp['train_y_by_period'] and s['tr']==exp['train_transition']
        assert sorted([[k,*v] for k,v in s['k'].items()])==sorted(exp['test_by_k'])
        assert sorted([[a,b,*v] for (a,b),v in s['f'].items()])==sorted(exp['test_by_start7_period'])
    return {'rows':len(rows),'participants':len(people),'git_blob_sha1':actual}


def loss(n,y,prob):
    p=max(1e-12,min(1-1e-12,prob))
    return -y*math.log(p)-(n-y)*math.log1p(-p)


def brier(n,y,prob):
    return y*(1-prob)**2+(n-y)*prob**2


def expit(z):
    return 1/(1+math.exp(-z)) if z>=0 else math.exp(z)/(1+math.exp(z))


def trend_fit(sessions):
    n=sum(s['n_people'] for s in sessions)
    y=[sum(s['train_y_by_period'][j] for s in sessions) for j in range(7)]
    p=sum(y)/(7*n)
    a=math.log(p/(1-p));b=0.0
    for _ in range(50):
        g0=g1=h00=h01=h11=0.0
        for j,v in enumerate(y):
            x=j-3; pr=expit(a+b*x);err=v-n*pr;w=n*pr*(1-pr)
            g0+=err;g1+=x*err;h00+=w;h01+=x*w;h11+=x*x*w
        d=h00*h11-h01*h01
        if d<1e-10:raise ValueError('singular trend')
        da=(h11*g0-h01*g1)/d;db=(-h01*g0+h00*g1)/d
        a+=da;b+=db
        if max(abs(da),abs(db))<1e-12:break
    return a,b


def evaluate_fold(source,target):
    m=sum(x['n_people'] for x in source);yy=sum(sum(x['train_y_by_period']) for x in source)
    # Jeffreys half successes and failures smoothing, same as R035
    pooled=(yy+0.5)/(7*m+1)
    a=[x for x in source if x['arm']==target['arm']]
    m_arm=sum(x['n_people'] for x in a);y_arm=sum(sum(x['train_y_by_period']) for x in a)
    arm=(y_arm+.5)/(7*m_arm+1)
    trans=[]
    for z in (0,1):
        n=sum(x['train_transition'][z][0] for x in source);s=sum(x['train_transition'][z][1] for x in source)
        trans.append((s+0.5)/(n+1))
    intercept,slope=trend_fit(source)
    probs={0:0,1:1};rollout={}
    for t in (8,9,10):
        probs={start:trans[0]+(trans[1]-trans[0])*value for start,value in probs.items()}
        rollout[t]=probs.copy()
    fits={k:{'total_loss':0.0,'total_brier':0.0,'n':0} for k in ('pooled','arm','trend','individual_first7','markov_frozen7')}
    def push(key,n,y,p):
        q=fits[key];q['total_loss']+=loss(n,y,p);q['total_brier']+=brier(n,y,p);q['n']+=n
    for k,n,y in target['test_by_k']:
        push('individual_first7',n,y,(k+.5)/8)
    for start,t,n,y in target['test_by_start7_period']:
        push('pooled',n,y,pooled);push('arm',n,y,arm)
        push('trend',n,y,expit(intercept+slope*(t-4)))
        push('markov_frozen7',n,y,rollout[t][start])
    assert all(q['n']==target['n_people']*3 for q in fits.values())
    return {'session':target['session'],'arm':target['arm'],'test_n':target['n_people']*3,
            'test_y':sum(q[2] for q in target['test_by_k']),
            'training_people':m,'training_people_in_same_arm':m_arm,
            'markov_transition_p':trans,'trend_slope':slope,
            'scores':{k:{**v,'mean_log_loss':v['total_loss']/v['n'],'mean_brier':v['total_brier']/v['n']} for k,v in fits.items()}}


def bootstrap(folds,model_a='markov_frozen7',model_b='individual_first7',reps=20000,seed=20261014):
    randomizer=random.Random(seed)
    def contrast(sample):
        n=sum(z['test_n'] for z in sample)
        return sum(z['scores'][model_a]['total_loss']-z['scores'][model_b]['total_loss'] for z in sample)/n
    observed=contrast(folds);sample=[]
    for _ in range(reps):sample.append(contrast([folds[randomizer.randrange(len(folds))] for _ in folds]))
    sample.sort();ci=[sample[int(.025*reps)],sample[min(reps-1,int(.975*reps))]]
    return {'session_bootstrap_95_percentile':ci,'observed_logloss_difference':observed,
            'n_session_clusters':6,'reps':reps,'seed':seed,
            'better_sessions_count':sum(f['scores'][model_a]['mean_log_loss']<f['scores'][model_b]['mean_log_loss'] for f in folds)}


def run(data,original_csv=None):
    validate(data)
    checkpoint_path=HERE/'R035_CHECKPOINT_MARGINS.json'
    if hashlib.sha256(checkpoint_path.read_bytes()).hexdigest()!=CHECKPOINT_SHA256:
        raise ValueError('R035 checkpoint mismatch')
    verify_r035_checkpoint(data,json.loads(checkpoint_path.read_text(encoding='utf8')))
    validation={'mode':'DERIVED_ONLY','raw_original_verified':False}
    if original_csv:
        validation={'mode':'ORIGINAL_CSV_GIT_BLOB_VERIFIED','raw_original_verified':True,
                    **validate_original_raw(original_csv,data)}
    folds=[evaluate_fold([s for s in data['sessions'] if s['session']!=h['session']],h) for h in data['sessions']]
    n=sum(x['test_n'] for x in folds)
    totals={k:{'log_loss':sum(f['scores'][k]['total_loss'] for f in folds)/n,
               'brier':sum(f['scores'][k]['total_brier'] for f in folds)/n} for k in folds[0]['scores']}
    return {'study_round':'R036','design':'leave-one-session-out fit first 7 rounds on five OTHER sessions; test rounds 8..10 on excluded session',
      'source_validation':validation,'source':data['source'],'analysis_label':'POSTHOC_EXPLORATORY_NOT_PREREGISTERED',
      'six_folds':folds,'n_test_decisions':n,'n_test_sessions':6,'models':totals,
      'markov_minus_person':bootstrap(folds),
      'markov_minus_pooled':bootstrap(folds,'markov_frozen7','pooled',seed=20261015),
      'identification':'PREDICTION_ONLY_NOT_EVIDENCE_FOR_CAUSAL_SOCIAL_SANCTION',
      'pesen':'V0.1_FROZEN'}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--derived',type=Path,default=HERE/'SESSION_DERIVED_CELLS.json')
    p.add_argument('--original-raw',type=Path,help='verify original raw bytes and derived counts, optional')
    p.add_argument('--require-original',action='store_true')
    p.add_argument('--out',type=Path,default=HERE/'R036_RESULT.json')
    args=p.parse_args()
    if args.require_original and not args.original_raw:raise SystemExit('original CSV required but absent')
    if hashlib.sha256(args.derived.read_bytes()).hexdigest()!=DATA_SHA256:
        raise SystemExit('derived data SHA256 mismatch; original source ledger gate failed')
    data=json.loads(args.derived.read_text(encoding='utf8'))
    out=run(data,args.original_raw)
    args.out.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
    print(json.dumps({'mode':out['source_validation']['mode'],'n':out['n_test_decisions'],
           'models':out['models'],'markov_minus_person':out['markov_minus_person']},indent=2,ensure_ascii=False))

if __name__=='__main__':main()
