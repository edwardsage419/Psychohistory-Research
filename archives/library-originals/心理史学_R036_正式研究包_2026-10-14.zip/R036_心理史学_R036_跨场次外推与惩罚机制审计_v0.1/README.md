# 心理史学 R036 正式研究包

时间：2026-10-14。继承 R035，研究基线更新到 R036。

本包包含：`R036_EVIDENCE_AUDIT.md`（研究审计）、`R036_SOURCE_LEDGER.json`（来源边界）、`SESSION_DERIVED_CELLS.json`（真实公开源数据经过连接器解析的六场次无个人标识汇总）、`R035_CHECKPOINT_MARGINS.json`（R035已核验边际）、`r036_analysis.py`（只依赖Python标准库）、`R036_RESULT.json`（复算结果）、`tests/test_r036.py`（26项测试）、`R037_RESEARCH_GATE.md`（下一研究关口）。

最小复现：在本目录执行 `python r036_analysis.py`，然后 `python -m unittest discover -s tests -v`。程序计算留一场次的五模型平均对数损失、Brier分数、六场次明细与预置20,000次场次重抽样。

取得作者源CSV后，可运行 `python r036_analysis.py --original-raw /path/to/subjects.csv` 验证Git blob SHA和所有派生计数。也可加 `--require-original` 强制拒绝只有派生文件的模式。作者原始 CSV 未包含在研究包内；不能把本地派生数据再运行称为原始字节端到端复现。

实验1/2的Mieth惩罚研究仍仅完成论文设计审计；没有获取其OSF原始CSV，不能声称已复算作者行为效应。PESEN v0.1维持冻结。
