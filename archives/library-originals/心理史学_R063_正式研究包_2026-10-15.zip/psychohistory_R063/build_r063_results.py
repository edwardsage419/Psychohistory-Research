"""Build a local-only report from connector-derived subject measurements."""
import json
from pathlib import Path
from r063_meta_audit import audit_derived_score_csv, SOURCE_CODE_SHAS
ROOT=Path(__file__).resolve().parent
macro=audit_derived_score_csv(ROOT/'R063_CONNECTOR_META_BY_PERSON.csv')
real={
'1':{'rw':(0.47395591903316253,0.1524331643625474),'fixed003':(0.47820925586540414,0.15391851143005642),'r062_gate003':(0.4731690398633052,0.15210776004267937),'meta003':(0.5235996363729848,0.16962941933101994),'meta01':(0.6606576455808747,0.21146635404342104)},
'2':{'rw':(0.6015918613762252,0.20670590748387238),'fixed003':(0.6042144166903316,0.20771239772485534),'r062_gate003':(0.5994093435239708,0.2056363517107693),'meta003':(0.6751997925240529,0.23172986683391905),'meta01':(0.8213891082914572,0.26727913451943486)},}
for task in (1,2):
 z=macro[task]
 for v in ('meta003','meta01'):
  assert abs(real[str(task)][v][0]-z['mean_loss'][v])<1e-12
  assert abs(real[str(task)][v][1]-z['mean_brier'][v])<1e-12
out={
 'round':'R063','research_date':'2026-10-15',
 'research_type':'mechanism_implementation_audit_and_fixed_parameter_posthoc_sensitivity',
 'source_computation':'AUTHOR_CSV_FETCHED_BY_GITHUB_CONNECTOR_NOT_LOCAL_ORIGINAL_BYTES',
 'raw_author_files_in_local_archive':False,
 'source_blobs':{
  'data/task1.csv':'6f90784a49c26c92806b4876cb0ce4b446f810b1',
  'data/task2.csv':'5239155f233d42e4dbbe3f986865d5459a3e9cee'},
 'original_model_source_git_blob_sha1':SOURCE_CODE_SHAS,
 'parameters':{'common_alpha_private':.1,'common_beta':2,'kappa_by_task':{'1':.4,'2':.15},'fixed_vs_rate':.03,'r062_gate_max_rate':.03,'author_meta_rate_adaptation_speed':[.03,.1]},
 'source_audit':{
  '1':{'participants':24,'all_rows':9600,'private_choice_rows':5760,'demo_no_visible_reward_rows':3840,'meta_eligibility_updates':3729,'demo_before_first_private':111},
  '2':{'participants':44,'all_rows':13200,'private_choice_rows':7920,'demo_no_visible_reward_rows':5280,'meta_eligibility_updates':5138,'demo_before_first_private':142}},
 'macro_scores':{task:{k:{'logloss':v[0],'brier':v[1]}for k,v in modes.items()}for task,modes in real.items()},
 'connector_subject_derived_audit':macro,
 'sensitivity_bootstrap':json.loads((ROOT/'R063_BOOTSTRAP_DIAGNOSTIC.json').read_text()),
 'critical_caveats':['Fixed numeric .03 denotes rate for R062 but adaptation gain for metaVS; not comparable mechanisms','Original authors fitted params and used additional models; this is not their fitted-paper reproduction','All model choices set after examining related data; these numbers are exploratory','Original author CSV bytes not present locally; local software tests and connector side source calculations are distinct evidence', 'metaVS Q is influenced by prior demonstrations; R062 private Q is not'],
 'model_promotion':'REJECTED_NO_NEW_EXTERNAL_VALIDATION',
 'PESEN_v0_1':'FROZEN'
}
(ROOT/'R063_RESULTS.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print(json.dumps({'passed_recalculation':True,'participants':sum(v['participants'] for v in macro.values()),'meta003_macro':[macro[t]['mean_loss']['meta003'] for t in (1,2)]}))
