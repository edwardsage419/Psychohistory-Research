"""R063 structural tests. Synthetic trace tests are NOT empirical replication."""
import csv
import math
import tempfile
import unittest
from pathlib import Path
import r063_meta_audit as m
import r061_replay_frozen as upstream

ROOT = Path(__file__).resolve().parent

def E(t, c=1, demo=False, out=1, state=1, cond='Choice', skill='skilled.dem'):
    return {'trial':t, 'state':state, 'choice':c, 'demo':demo,
            'out':None if demo else out, 'condition':cond, 'skill':skill}

class DynamicsTests(unittest.TestCase):
    def test_meta_zero_gain(self): self.assertEqual(m.meta_update(0,1,0),0)
    def test_meta_one_gain(self): self.assertEqual(m.meta_update(.1,1,1),1)
    def test_meta_one_disagree(self): self.assertEqual(m.meta_update(.8,0,1),0)
    def test_meta_bounded(self):
        for x in (0,.01,.5,.99,1):
            for y in (0,1):
                for eta in (0,.03,.1,.9,1):
                    self.assertGreaterEqual(m.meta_update(x,y,eta),0)
                    self.assertLessEqual(m.meta_update(x,y,eta),1)
    def test_meta_recurrence_ten(self):
        x=0
        for _ in range(10):x=m.meta_update(x,1,.03)
        self.assertAlmostEqual(x,1-.97**10,places=14)
    def test_meta_recurrence_fifty(self):
        x=0
        for _ in range(50):x=m.meta_update(x,1,.1)
        self.assertAlmostEqual(x,1-.9**50,places=13)
    def test_meta_disagreement_exponential(self):
        x=1
        for _ in range(10):x=m.meta_update(x,0,.1)
        self.assertAlmostEqual(x,.9**10)
    def test_tie_break_first(self):
        self.assertEqual(m.prefer([0,0]),0)
        self.assertEqual(m.prefer([.1,.1]),0)
        self.assertEqual(m.prefer([.1,.3]),1)
        self.assertEqual(m.prefer([.4,.3]),0)
    def test_bad_gain(self):
        for args in [(-1,1,.1),(.2,2,.1),(.2,1,1.1),(.2,-1,.1)]:
            with self.assertRaises(ValueError):m.meta_update(*args)
    def test_stable_losses(self):
        self.assertAlmostEqual(m.predict_loss(0,1),math.log(2))
        self.assertAlmostEqual(m.predict_loss(0,0),math.log(2))
        self.assertLess(m.predict_loss(10,1),m.predict_loss(0,1))
        self.assertGreater(m.predict_loss(10,0),m.predict_loss(0,0))
        self.assertTrue(math.isfinite(m.predict_loss(1000,0)))

class MechanismTests(unittest.TestCase):
    def test_before_first_private_zero_author(self):
        seq={1:[E(1,demo=True),E(2)]}
        meta=m.score(seq,1,'meta003');rw=m.score(seq,1,'rw');fixed=m.score(seq,1,'fixed003')
        self.assertAlmostEqual(meta['loss'],math.log(2))
        self.assertAlmostEqual(meta['loss'],rw['loss'])
        self.assertLess(fixed['loss'],rw['loss'])
        self.assertEqual(meta['diagnostics']['meta_before_private'],1)
    def test_first_demo_nonzero_r062_gate(self):
        seq={1:[E(1,demo=True),E(2)]}
        gated=m.score(seq,1,'r062_gate003')
        self.assertLess(gated['loss'],math.log(2))
        self.assertAlmostEqual(gated['diagnostics']['social_update_rate_sum'], .015)
    def test_meta_agreement_after_private(self):
        seq={1:[E(1,c=1,out=1),E(2,c=1,demo=True),E(3,c=1,out=1)]}
        meta=m.score(seq,1,'meta003')
        self.assertEqual(meta['diagnostics']['meta_adaptations'],1)
        self.assertAlmostEqual(meta['diagnostics']['social_update_rate_sum'], .03)
    def test_meta_disagreement_after_private(self):
        seq={1:[E(1,c=1,out=1),E(2,c=0,demo=True),E(3,c=1,out=1)]}
        meta=m.score(seq,1,'meta003')
        self.assertAlmostEqual(meta['diagnostics']['social_update_rate_sum'],0)
    def test_private_outcome_leakage_blocked(self):
        a=m.score({1:[E(1,c=1,out=1)]},1,'rw')
        b=m.score({1:[E(1,c=1,out=-1)]},1,'rw')
        self.assertEqual(a['loss'],b['loss'])
        self.assertEqual(a['brier'],b['brier'])
    def test_private_future_changes_future_not_past(self):
        a=m.score({1:[E(1,c=1,out=1),E(2,c=1,out=1)]},1,'rw')
        b=m.score({1:[E(1,c=1,out=-1),E(2,c=1,out=1)]},1,'rw')
        self.assertNotEqual(a['loss'],b['loss'])
    def test_demo_reward_disallowed(self):
        ev=E(1,demo=True);ev['out']=1
        with self.assertRaises(ValueError):m.score({1:[ev,E(2)]},1,'meta003')
    def test_absent_private_reward_disallowed(self):
        ev=E(1);ev['out']=None
        with self.assertRaises(ValueError):m.score({1:[ev]},1,'rw')
    def test_invalid_choice(self):
        ev=E(1,c=2)
        with self.assertRaises(ValueError):m.score({1:[ev]},1,'rw')
    def test_bad_mode(self):
        with self.assertRaises(ValueError):m.score({1:[E(1)]},1,'magic')
    def test_zero_private_rejected(self):
        with self.assertRaises(ValueError):m.score({1:[E(1,demo=True)]},1,'rw')
    def test_unknown_task_rejected(self):
        with self.assertRaises(ValueError):m.score({1:[E(1)]},3,'rw')
    def test_skill_label_not_used_in_prediction(self):
        a=m.score({1:[E(1,skill='skilled.dem'),E(2,demo=True),E(3,skill='skilled.dem')]},1,'meta003')
        b=m.score({1:[E(1,skill='unskilled.dem'),E(2,demo=True),E(3,skill='unskilled.dem')]},1,'meta003')
        self.assertEqual(a['loss'],b['loss'])
        self.assertNotEqual(a['condition'],b['condition'])
    def test_independent_state_isolation(self):
        a=m.score({1:[E(1),E(2,demo=True,state=2),E(3)]},1,'meta003')
        b=m.score({1:[E(1),E(3)]},1,'meta003')
        self.assertAlmostEqual(a['loss'],b['loss'])
    def test_session_resets(self):
        a=m.score({1:[E(1,c=1)],2:[E(1,c=1)]},1,'rw')
        self.assertAlmostEqual(a['loss'],math.log(2))
    def test_meta_zero_equals_rw_when_no_demos(self):
        s={1:[E(1),E(2,c=0,out=-1),E(3)]}
        self.assertAlmostEqual(m.score(s,1,'meta003')['loss'],m.score(s,1,'rw')['loss'])
    def test_fixed_zero_diff_private_only(self):
        s={1:[E(1),E(2,c=0,out=-1)]}
        self.assertAlmostEqual(m.score(s,1,'fixed003')['loss'],m.score(s,1,'rw')['loss'])
    def test_stimulus_not_motor_key(self):
        # Only choice is consumed, never extraneous 'clr' motor key.
        s={1:[{**E(1), 'clr':-1}, {**E(2), 'clr':1}]}
        b={1:[{**E(1), 'clr':1}, {**E(2), 'clr':-1}]}
        self.assertAlmostEqual(m.score(s,1,'rw')['loss'],m.score(b,1,'rw')['loss'])
    def test_raw_sha_rejects_invalid(self):
        self.assertNotEqual(upstream.git_blob_sha(b'invalid'),upstream.SOURCE[1]['sha'])
        with self.assertRaisesRegex(ValueError,'SHA1 mismatch'):
            m.replay_author(b'invalid',b'invalid')

class DerivedAuditTests(unittest.TestCase):
    def test_exact_derived_means(self):
        got=m.audit_derived_score_csv(ROOT/'R063_CONNECTOR_META_BY_PERSON.csv')
        self.assertEqual(got[1]['participants'],24)
        self.assertEqual(got[2]['participants'],44)
        self.assertAlmostEqual(got[1]['mean_loss']['meta003'],.5235996363729848,places=12)
        self.assertAlmostEqual(got[2]['mean_loss']['meta003'],.6751997925240529,places=12)
        self.assertAlmostEqual(got[1]['mean_brier']['meta01'],.21146635404342104,places=12)
        self.assertAlmostEqual(got[2]['mean_brier']['meta01'],.26727913451943486,places=12)
    def test_duplicate_detected(self):
        with open(ROOT/'R063_CONNECTOR_META_BY_PERSON.csv',newline='') as f:rows=list(csv.DictReader(f))
        rows[1]['id']=rows[0]['id']
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'data.csv'
            with path.open('w',newline='') as f:
                w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
            with self.assertRaises(ValueError):m.audit_derived_score_csv(path)
    def test_bad_counts_rejected(self):
        with open(ROOT/'R063_CONNECTOR_META_BY_PERSON.csv',newline='') as f:rows=list(csv.DictReader(f))
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'bad.csv'
            with path.open('w',newline='') as f:
                w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows[:-1])
            with self.assertRaises(ValueError):m.audit_derived_score_csv(path)

if __name__=='__main__': unittest.main(verbosity=2)
