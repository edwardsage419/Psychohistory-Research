# R063: Original metaVS structural audit (not paper model-fit replication)

This ZIP includes an independently coded interpreter of selected published model dynamics, synthetic trace tests, provenance gate, 68 real-sourced anonymous connector-derived scores, and source ledger. **Original task1.csv/task2.csv raw bytes are NOT in the ZIP and cannot be claimed locally verified.**

Recalculate the locally stored anonymized results:

```bash
python r063_meta_audit.py --derived R063_CONNECTOR_META_BY_PERSON.csv
python build_r063_results.py
python -m unittest -v test_r063.py
```

To reproduce using author-original byte-authenticated data once the exact files are legitimately obtained:

```bash
python r063_meta_audit.py --task1 /path/to/task1.csv --task2 /path/to/task2.csv --out author_replay.json
```

The code will fail closed on wrong Git blob source fingerprints. Reference model is source-mechanism interpreter with fixed exploratory parameters, not reproduction of original fitted paper results. See R063_REPORT.md, SOURCE_LEDGER.json, and R064_RESEARCH_GATE.md.
