#!/usr/bin/env python3
"""Validate R063 immutable source-independent package evidence."""
import csv,hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
EXPECTED={1:(24,.5235996363729848,.6606576455808747),2:(44,.6751997925240529,.8213891082914572)}
r=json.loads((ROOT/'R063_RESULTS.json').read_text())
assert r['round']=='R063' and not r['raw_author_files_in_local_archive']
with (ROOT/'R063_CONNECTOR_META_BY_PERSON.csv').open() as f:
 rows=list(csv.DictReader(f))
assert len(rows)==68
for task,(n,l1,l2) in EXPECTED.items():
 subset=[z for z in rows if int(z['task'])==task]
 assert len(subset)==n and len({z['id'] for z in subset})==n
 assert abs(sum(float(z['meta003_loss']) for z in subset)/n-l1)<1e-12
 assert abs(sum(float(z['meta01_loss']) for z in subset)/n-l2)<1e-12
assert (ROOT/'r061_replay_frozen.py').exists()
assert not (ROOT/'task1.csv').exists() and not (ROOT/'task2.csv').exists()
manifest=ROOT/'SHA256SUMS.txt'
if manifest.exists():
 for line in manifest.read_text().splitlines():
  hexdigest,rel=line.split('  ',1)
  assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==hexdigest,rel
print('R063_PACKAGE_VERIFICATION_PASS: 68 distinct participant source-derived rows, aggregate checks, raw-file absence, hashes')
