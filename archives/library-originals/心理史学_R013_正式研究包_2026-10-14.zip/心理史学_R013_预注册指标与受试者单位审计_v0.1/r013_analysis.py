#!/usr/bin/env python3
"""R013: provisional subject-level replication of prespecified endpoints.

Source: ZhuoranLu/Misinformation experiment-two CSVs, known Git blobs.
Requires raw author CSV (not bundled). Use --fetch on a network-enabled machine.
Treat social cascades / sequence-level dependencies as unresolved. No formal p-values.

  python r013_analysis.py --fetch
  python r013_analysis.py --source-dir source --output r013_results.json
"""
from __future__ import annotations
import argparse
from collections import defaultdict, Counter
import csv
import hashlib
import json
import math
import re
from datetime import datetime, timezone, timedelta
from pathlib import Path
import urllib.request

SOURCES = {
    'social': ('experimentTwoWithInfluenceIndividualLevelRes.csv', '1c00c215d1c65436f52baaf7b5ddd98e450833bb'),
    'independent': ('experimentTwoNoInfluenceIndividualLevelRes.csv', 'e32926e78a1e7698cb5d070d52f57e078b3864be')
}
REPO = 'https://github.com/ZhuoranLu/Misinformation'
PREREG = 'https://aspredicted.org/rh32h.pdf'
PREREG_UTC = datetime(2021,12,27,3,59, tzinfo=timezone.utc)  # Dec 26 19:59 PST

def parse_exp_time(stamp: str):
    # The public CSV records contain a local timestamp with an explicit GMT offset.
    # Do not use the human-readable timezone name in parentheses: it is inconsistent.
    m=re.match(r'^(.*) GMT([+-])(\d{2})(\d{2})(?: |$)',stamp)
    if not m: return None
    try: local=datetime.strptime(m.group(1),'%a %b %d %Y %H:%M:%S')
    except ValueError: return None
    minutes=(1 if m.group(2)=='+' else -1)*(60*int(m.group(3))+int(m.group(4)))
    return local.replace(tzinfo=timezone(timedelta(minutes=minutes))).astimezone(timezone.utc)


def git_sha(b: bytes) -> str:
    return hashlib.sha1(b'blob ' + str(len(b)).encode('ascii') + b'\x00' + b).hexdigest()

def acquire(folder: Path) -> None:
    folder.mkdir(exist_ok=True, parents=True)
    for name, expected in SOURCES.values():
        url=f'https://raw.githubusercontent.com/ZhuoranLu/Misinformation/main/{name}'
        with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Psychohistory-R013-v0.1'}),timeout=25) as request:
            b=request.read()
        observed=git_sha(b)
        if observed!=expected:
            raise RuntimeError(f'UNEXPECTED_SOURCE_BLOB {name}: {observed}; expected {expected}')
        (folder/name).write_bytes(b)

def read_csv(path: Path, condition: str, verify=True) -> list[dict]:
    data=path.read_bytes()
    expected=SOURCES[condition][1]
    if verify and git_sha(data)!=expected:
        raise ValueError(f'Source drift: expected Git blob {expected}, actual {git_sha(data)}')
    rows=[]
    for line_no,r in enumerate(csv.DictReader(data.decode('utf-8-sig').splitlines()),2):
        if None in r or not r or not r.get('workerId'):
            raise ValueError(f'Bad row {path}:{line_no}')
        x={
            'condition':condition,
            'worker':str(r['workerId']),
            'arm':int(float(r['treatment'])),
            'news':int(float(r['newsIndex'])),
            'initial':int(r['initialDecision']),
            'final':int(r['finalDecision']),
            'label':int(r['label']),
            'share':float(r['shareWillingness']),
            'provided_correctness':r['finalCorrectness'],
            'ai_correctness':r['mlCorrectness'],
            'time':r.get('time','')
        }
        if not (x['arm'] in (0,1,2) and 0<=x['news']<40 and x['final'] in (-1,1) and x['initial'] in (-1,1) and x['label'] in (-1,1)):
            raise ValueError(f'Invalid treatment/news/decision/label at {path}:{line_no}')
        if x['provided_correctness'] not in ('True','False'):
            raise ValueError(f'Invalid finalCorrectness at {path}:{line_no}')
        if (x['final']==x['label']) != (x['provided_correctness']=='True'):
            raise ValueError(f'Wrong final correctness at {path}:{line_no}')
        rows.append(x)
    return rows

def audit(rows):
    keys=Counter((r['condition'],r['arm'],r['worker'],r['news']) for r in rows)
    workers=defaultdict(set)
    for r in rows:workers[(r['condition'],r['worker'])].add(r['arm'])
    ambiguous={k for k,v in workers.items() if len(v)>1}
    dated=[parse_exp_time(r.get('time','')) for r in rows]
    before=sum(d is not None and d<PREREG_UTC for d in dated)
    after=sum(d is not None and d>=PREREG_UTC for d in dated)
    return {'records':len(rows),
            'timestamp_audit':{'pre_registration':before,'at_or_post_registration':after,
               'unparseable':len(rows)-before-after,
               'claimed_registration_utc':PREREG_UTC.isoformat(),
               'status':'TIME_FIELD_SEMANTICS_UNVERIFIED'},
            'file_scoped_worker_ids':len(workers),
            'provisional_subject_arm_units':len(set((r['condition'],r['arm'],r['worker']) for r in rows)),
            'duplicate_key_extra_records':sum(x-1 for x in keys.values() if x>1),
            'ambiguous_file_scoped_worker_ids':len(ambiguous),
            'ambiguous_ids':sorted([f'{c}|{w}' for c,w in ambiguous])}

def row_variants(rows,variant):
    if variant=='as_published':return list(rows)
    if variant not in ('first_composite_key','exclude_ambiguous_workers'):
        raise ValueError(variant)
    first=[];seen=set()
    for r in rows:
        k=(r['condition'],r['arm'],r['worker'],r['news'])
        if k not in seen:seen.add(k);first.append(r)
    if variant=='first_composite_key':return first
    worker_arms=defaultdict(set)
    for r in first:worker_arms[(r['condition'],r['worker'])].add(r['arm'])
    ambiguous={k for k,v in worker_arms.items() if len(v)>1}
    return [r for r in first if (r['condition'],r['worker']) not in ambiguous]

def subjects(rows):
    """Study's individual endpoints, provisional (file, arm, workerId) identity.
    Discernment: P(final=real|real) - P(final=real|fake), when both present.
    Sharing: mean(share|real)-mean(share|fake); percentage-point scale 0..100.
    """
    groups=defaultdict(list)
    for r in rows:groups[(r['condition'],r['arm'],r['worker'])].append(r)
    out=[]
    for (condition,arm,worker),sample in groups.items():
        real=[r for r in sample if r['label']==1]
        fake=[r for r in sample if r['label']==-1]
        acc=sum(r['final']==r['label'] for r in sample)/len(sample)
        disc=(sum(r['final']==1 for r in real)/len(real)-sum(r['final']==1 for r in fake)/len(fake)) if real and fake else None
        sdisc=(sum(r['share'] for r in real)/len(real)-sum(r['share'] for r in fake)/len(fake)) if real and fake else None
        out.append({'condition':condition,'arm':arm,'worker':worker,'tasks':len(sample),
                    'individual_accuracy':acc,'truth_discernment':disc,'sharing_discernment':sdisc})
    return out

def mean_sd(v):
    values=[float(x) for x in v if x is not None and math.isfinite(float(x))]
    n=len(values)
    if n<2:return {'n':n,'mean':None,'sd':None}
    m=sum(values)/n
    return {'n':n,'mean':m,'sd':math.sqrt(sum((x-m)**2 for x in values)/(n-1))}

def cohens_d(a,b):
    if a['n']<2 or b['n']<2:return None
    denom=math.sqrt(((a['n']-1)*a['sd']**2+(b['n']-1)*b['sd']**2)/(a['n']+b['n']-2))
    return (a['mean']-b['mean'])/denom if denom>0 else None

def effect_tables(rows):
    subject=subjects(rows)
    metrics=['individual_accuracy','truth_discernment','sharing_discernment']
    cells={}
    for cond in ('social','independent'):
        for arm in (0,1,2):
            group=[s for s in subject if s['condition']==cond and s['arm']==arm]
            cells[f'{cond}|{arm}']={'n':len(group),'avg_tasks':sum(s['tasks'] for s in group)/len(group)}
            for metric in metrics:
                cells[f'{cond}|{arm}'][metric]=mean_sd(s[metric] for s in group)
    effects={}
    for cond in ('social','independent'):
        for arm in (1,2):
            key=f'{cond}|{arm}'
            effects[key]={}
            for metric in metrics:
                treated=cells[key][metric];control=cells[f'{cond}|0'][metric]
                effects[key][metric]={
                    'difference':treated['mean']-control['mean'],
                    'cohens_d':cohens_d(treated,control),
                    'n_treated':treated['n'],'n_control':control['n']}
    interactions={}
    for arm in (1,2):
        interactions[str(arm)]={}
        for metric in metrics:
            interactions[str(arm)][metric]={
                'cohens_d_social_minus_independent':(effects[f'social|{arm}'][metric]['cohens_d']-effects[f'independent|{arm}'][metric]['cohens_d']) if effects[f'social|{arm}'][metric]['cohens_d'] is not None and effects[f'independent|{arm}'][metric]['cohens_d'] is not None else None,
                'raw_difference_in_differences':effects[f'social|{arm}'][metric]['difference']-effects[f'independent|{arm}'][metric]['difference']}
    return {'cells':cells,'effects':effects,'interactions':interactions}

def run(files,verify=True):
    allrows=[]
    hashes={}
    for condition,(name,sha) in SOURCES.items():
        path=files/name
        data=path.read_bytes();hashes[condition]={'git_blob_sha1':git_sha(data),'sha256':hashlib.sha256(data).hexdigest(),'size_bytes':len(data)}
        allrows+=read_csv(path,condition,verify)
    out={
        'research_round':'R013','status':'EXPLORATORY_PREREG_ALIGNED_DESCRIPTIVE_ANALYSIS',
        'sources':{'repo':REPO,'prereg':PREREG,'files':hashes},
        'audit':audit(allrows),'variants':{},
        'research_limitations':[
          'No raw sequence id or actual predecessor exposure: independence of person effects is unsupported.',
          'Source files flagged preliminary; no full original exclusion/attention-check log.',
          'WorkerId collision across arms in social file: identity and randomization unit uncertain.',
          'Multiple comparisons and subject-level treatment means are exploratory, not official randomization inference.',
          'Original prereg uses Cohen d + bootstrap on multiple prespecified outcomes, not news-balanced percentages.',
          'Major chronology discrepancy: time field often precedes claimed registration; timestamp semantics unverified. Never assert confirmed prospective preregistration.'
        ]}
    for policy in ('as_published','first_composite_key','exclude_ambiguous_workers'):
        rows=row_variants(allrows,policy)
        out['variants'][policy]={'n_records':len(rows),'subject_level':effect_tables(rows)}
    return out

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-dir',type=Path,default=Path('source'))
    parser.add_argument('--fetch',action='store_true')
    parser.add_argument('--allow-different-blob',action='store_true',help='For diagnostic only; never present outputs as the verified original study data')
    parser.add_argument('--output',type=Path,default=Path('r013_results.json'))
    args=parser.parse_args()
    if args.fetch:acquire(args.source_dir)
    results=run(args.source_dir,verify=not args.allow_different_blob)
    args.output.write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('R013 extracted:',results['audit']['records'],'records; saved',args.output)
if __name__=='__main__':main()
