import tempfile
import unittest
from pathlib import Path
from r013_analysis import (git_sha,read_csv,audit,row_variants,subjects,mean_sd,cohens_d,effect_tables,parse_exp_time,PREREG_UTC)
class Tests(unittest.TestCase):
    def record(self,cond='social',arm=0,worker='A',news=0,label=1,final=1,share=50):
        return dict(condition=cond,arm=arm,worker=worker,news=news,initial=1,
                    final=final,label=label,share=share)
    def test_blob_sha(self):
        self.assertEqual(git_sha(b'test'),'30d74d258442c7c65512eafab474568dd706c430')
    def test_audit_worker_reuse(self):
        r=[self.record(arm=0),self.record(arm=1)]
        a=audit(r)
        self.assertEqual(a['ambiguous_file_scoped_worker_ids'],1)
    def test_duplicate_counts(self):
        r=[self.record(),self.record(),self.record(news=1)]
        self.assertEqual(audit(r)['duplicate_key_extra_records'],1)
        self.assertEqual(len(row_variants(r,'first_composite_key')),2)
    def test_exclude_ambiguous(self):
        r=[self.record(arm=0),self.record(arm=1),self.record(worker='B')]
        self.assertEqual(len(row_variants(r,'exclude_ambiguous_workers')),1)
    def test_truth_discernment(self):
        r=[self.record(news=0,label=1,final=1,share=75),self.record(news=1,label=-1,final=-1,share=10)]
        x=subjects(r)[0]
        self.assertAlmostEqual(x['individual_accuracy'],1)
        self.assertAlmostEqual(x['truth_discernment'],1)
        self.assertAlmostEqual(x['sharing_discernment'],65)
    def test_missing_class(self):
        r=[self.record()]
        self.assertIsNone(subjects(r)[0]['truth_discernment'])
    def test_sd(self):
        s=mean_sd([0,1])
        self.assertEqual(s['mean'],.5)
        self.assertAlmostEqual(s['sd'],2**-.5)
    def test_d(self):
        a=mean_sd([1,2,3]);b=mean_sd([0,1,2])
        self.assertAlmostEqual(cohens_d(a,b),1)
    def test_bad_arm(self):
        with self.assertRaises(ValueError):row_variants([], 'no_such')
    def test_subject_acc(self):
        r=[]
        for cond in ('social','independent'):
            for t in (0,1,2):
                for w in ('A','B'):
                    r.append(self.record(cond=cond,arm=t,worker=w,news=0,label=1,final=1))
                    r.append(self.record(cond=cond,arm=t,worker=w,news=1,label=-1,final=-1))
        a=effect_tables(r)
        self.assertAlmostEqual(a['cells']['social|0']['individual_accuracy']['mean'],1)
        self.assertEqual(a['interactions']['1']['individual_accuracy']['raw_difference_in_differences'],0)
    def test_prereg_timestamp_before(self):
        a=parse_exp_time('Fri Dec 24 2021 10:39:20 GMT-0500 (GMT-05:00)')
        self.assertLess(a, PREREG_UTC)
    def test_prereg_timestamp_after(self):
        a=parse_exp_time('Tue Dec 28 2021 15:00:00 GMT+0800 (GMT+08:00)')
        self.assertGreater(a, PREREG_UTC)
    def test_unparseable_time(self):
        self.assertIsNone(parse_exp_time('unknown'))
    def test_read_csv_verify_consistency(self):
        hdr=',workerId,treatment,initialDecision,shareWillingness,finalDecision,newsIndex,time,mlCorrectness,finalCorrectness,label\n'
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'fixture.csv'
            path.write_text(hdr+'0,7,0,1,10,-1,2,test,True,True,-1\n',encoding='utf-8')
            r=read_csv(path,'social',verify=False)
            self.assertEqual(len(r),1)
            with self.assertRaises(ValueError):read_csv(path,'social',verify=True)
            path.write_text(hdr+'0,7,0,1,10,-1,2,test,True,False,-1\n',encoding='utf-8')
            with self.assertRaises(ValueError):read_csv(path,'social',verify=False)
if __name__=='__main__': unittest.main()
