# R028跨社区异质性审计研究包

日期：2026-10-14，接续 R027 与主控台 v1.8。PESEN v0.1 冻结。

**证据级别：从公开 GitHub 分析笔记本保存的作者舍入系数独立重算数学诊断；尚未获取2019/2020年实验的原始CSV字节、原始随机化日志或完整评论级数据。**

使用 Python 3.9+，无第三方依赖：

```bash
python -m unittest discover -s tests -v
python r028_meta_diagnostic.py
```

文件：`R028_EVIDENCE_AUDIT.md` 为科研论证和识别风险；`SOURCE_OUTPUT_TRANSCRIPTION.json` 为人工根据笔记本已保存输出制作的来源输入记录；`r028_meta_diagnostic.py`/`tests/` 可独立重算指数效应及四项研究的近似Q；`R028_RESULTS.json` 为机器结果；`R029_PREANALYSIS_GATE_DRAFT.md` 为下一轮前瞻性研究条件草案（未独立注册）。

不要将此包描述成2019/2020年的原始数据完整复现、稳定因果机制验证或已经被伦理机构批准的实验方案。
