#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""R028: audit approximate across-study heterogeneity from *saved* published notebook results.
Uses rounded beta / standard errors. Does not claim access to original 2019-2020 CSV.
Python >= 3.9; standard library only. This is a method diagnostic, not causal identification.
"""
import json
import math
import argparse
from pathlib import Path

def ch2_sf(q, df):
    """Chi-square survival function for df=2 or df=3, without SciPy."""
    if q < 0:
        raise ValueError('Q must be nonnegative')
    if df == 2:
        return math.exp(-q / 2)
    if df == 3:
        return math.erfc(math.sqrt(q / 2)) + math.sqrt(2 * q / math.pi) * math.exp(-q / 2)
    raise ValueError('Only df 2 or 3 supported')

def study_result(x):
    b, se = float(x['beta']), float(x['se'])
    if se <= 0 or not math.isfinite(b) or not math.isfinite(se):
        raise ValueError('Invalid coefficient/SE')
    return {
       'study':x['id'], 'n_posts_author_saved_output':x['n_posts_output'],
       'beta_author_rounded':b, 'se_author_rounded':se,
       'irr_from_rounded_beta':math.exp(b),
       'normal_approx_95_irr': [math.exp(b-1.96*se), math.exp(b+1.96*se)],
       'reproduction_level':'Recomputed from author saved rounded coefficients, NOT raw data'
    }

def heterogeneity(studies):
    if len(studies) not in (3,4):
        raise ValueError('Expect 3 or 4 studies')
    weights=[1/(x['se']**2) for x in studies]
    weighted_beta=sum(w*x['beta'] for w,x in zip(weights,studies))/sum(weights)
    q=sum(w*(x['beta']-weighted_beta)**2 for w,x in zip(weights,studies))
    df=len(studies)-1
    return {
       'k_studies':len(studies), 'q':q, 'df':df,
       'approx_chi_square_tail_p':ch2_sf(q,df),
       'i2_descriptive':max(0,(q-df)/q) if q else 0,
       'inverse_variance_weighted_beta_diagnostic_only':weighted_beta,
       'inverse_variance_weighted_irr_diagnostic_only':math.exp(weighted_beta),
       'warning':'Rounded published model outputs; assumed independent model estimates and normal errors; fixed-effect summary is not an eligible transportable causal effect. Do not treat I2 as established environmental moderator.'
    }

def calculate(src):
    studies=src['datasets']
    return {
      'round':'R028','source_notebook_sha1':src['primary_notebook']['blob_sha1'],
      'raw_csv_replicated':False,
      'per_study':[study_result(x) for x in studies],
      'all_studies_diagnostic':heterogeneity(studies),
      'followup_only_diagnostic':heterogeneity(studies[1:]),
      'study_input_counts_not_independent_people':sum(x['n_posts_output'] for x in studies),
      'qualifications':[
        'Only one source notebook with output snapshots; no new randomized effect independently fitted.',
        '2016 notebook model uses 2214 posts; original published scientific-article sample uses 2190.',
        'Design, classification, moderation visibility and COVID period differ; lack of significant effect does not establish zero effect.',
        'Outcome is newcomer COMMENT COUNT per post, not count of unique people, not observed exposure or punished beliefs.',
        'Four-study Q diagnostic cannot establish which contextual variable generates heterogeneity.',
        'PESEN v0.1 must remain frozen.'
      ]
    }

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,default=Path(__file__).with_name('SOURCE_OUTPUT_TRANSCRIPTION.json'))
    p.add_argument('--output',type=Path,default=Path(__file__).with_name('R028_RESULTS.json'))
    a=p.parse_args()
    result=calculate(json.loads(a.input.read_text(encoding='utf-8')))
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f"R028_SAVED_OUTPUT_DIAGNOSTIC_COMPLETE q={result['all_studies_diagnostic']['q']:.5f} p={result['all_studies_diagnostic']['approx_chi_square_tail_p']:.6f} raw_replication=NO")

if __name__=='__main__':
    main()
