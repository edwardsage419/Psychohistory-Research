import math
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from r028_meta_diagnostic import ch2_sf, study_result, heterogeneity, calculate

class R028Tests(unittest.TestCase):
 def setUp(self):
  self.data=[
   dict(id='science.2016',n_posts_output=2214,beta=.51,se=.14),
   dict(id='ffxiv.2019',n_posts_output=12100,beta=-.03,se=.04),
   dict(id='science.2020',n_posts_output=8259,beta=-.11,se=.07),
   dict(id='futurology.2020',n_posts_output=9963,beta=.01,se=.06)
  ]
 def test_irrs(self):
  self.assertAlmostEqual(study_result(self.data[0])['irr_from_rounded_beta'],math.exp(.51))
 def test_heterogeneity(self):
  x=heterogeneity(self.data)
  self.assertAlmostEqual(x['q'],16.197262258636623,places=8)
  self.assertAlmostEqual(x['approx_chi_square_tail_p'],0.0010331220322439658,places=9)
 def test_followup_only(self):
  x=heterogeneity(self.data[1:])
  self.assertAlmostEqual(x['approx_chi_square_tail_p'],.4218961189939402,places=9)
 def test_no_fake_sample_reproduction(self):
  s={'datasets':self.data,'primary_notebook':{'blob_sha1':'example'}}
  r=calculate(s)
  self.assertFalse(r['raw_csv_replicated'])
 def test_negative_q(self):
  with self.assertRaises(ValueError):ch2_sf(-1,2)
 def test_invalid_se(self):
  with self.assertRaises(ValueError):study_result(dict(id='x',se=0,beta=1))
 def test_df_two(self):
  self.assertAlmostEqual(ch2_sf(2,2),math.exp(-1))
 def test_identical_zero_heterogeneity(self):
  x=heterogeneity([dict(beta=1,se=1) for _ in range(3)])
  self.assertEqual(x['q'],0)
  self.assertEqual(x['i2_descriptive'],0)
 def test_counts_study_not_users(self):
  s={'datasets':self.data,'primary_notebook':{'blob_sha1':'example'}}
  r=calculate(s)
  self.assertEqual(r['study_input_counts_not_independent_people'],32536)
if __name__=='__main__':unittest.main()
