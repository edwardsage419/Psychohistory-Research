import unittest
import numpy as np
from pathlib import Path
from tempfile import TemporaryDirectory
from r051_temporal_audit import ols_slope, temporal_identity, null_simulation, audit_r048_csv

class TemporalAuditTests(unittest.TestCase):
    def test_identity_random_balanced(self):
        rng = np.random.default_rng(3)
        for sz in (2, 4, 10):
            now = rng.normal(size=(5, 7, sz))
            prev = rng.normal(size=(5, 7, sz))
            result = temporal_identity(now, prev)
            self.assertLess(result['max_identity_error'], 1e-12)
            self.assertEqual(result['rows'], now.size)

    def test_identity_with_common_shock(self):
        base = np.arange(24.).reshape(2, 3, 4)
        r = temporal_identity(base+50., base)
        self.assertEqual(r['max_identity_error'], 0)

    def test_identity_with_individual_change(self):
        old = np.array([[0., 10., 20., 30.]])
        new = np.array([[1., 8., 24., 35.]])
        self.assertLess(temporal_identity(new, old)['max_identity_error'], 1e-12)

    def test_identity_changes_under_wrong_lag_group(self):
        old = np.array([[0., 1., 2., 3.], [4., 5., 6., 7.]])
        new = old*2
        correct = temporal_identity(new, old)
        self.assertEqual(correct['max_identity_error'], 0)
        wrong_group_old = old[:, ::-1]
        wrong = temporal_identity(new, wrong_group_old)
        # The algebra still holds for arrays even when subject IDs are permuted.
        # Structural alignment of subject IDs is a separate mandatory check.
        self.assertLess(wrong['max_identity_error'], 1e-12)

    def test_identity_is_algebraic_for_non_integer_values(self):
        prev = np.array([[[1.5, 2.5, 3.5, 4.5]]])
        now = np.array([[[2.0, 4.1, 1.7, 5.0]]])
        self.assertLess(temporal_identity(now, prev)['max_identity_error'], 1e-12)

    def test_nonfinite_rejected(self):
        with self.assertRaises(ValueError):
            temporal_identity(np.array([[float('nan'), 1]]), np.array([[1, 2]]))

    def test_misaligned_rejected(self):
        with self.assertRaises(ValueError):
            temporal_identity(np.ones((2, 4)), np.ones((2, 3)))

    def test_one_dim_rejected(self):
        with self.assertRaises(ValueError):
            temporal_identity(np.ones(4), np.ones(4))

    def test_constant_regressor_rejected(self):
        with self.assertRaises(ValueError):
            ols_slope([1,1,1],[1,2,3])

    def test_ols_known_slope(self):
        self.assertAlmostEqual(ols_slope([1,2,3], [4,6,8]), 2.)

    def test_ols_length_mismatch(self):
        with self.assertRaises(ValueError):
            ols_slope([1,2,3],[1,2])

    def test_null_rho_0(self):
        r=null_simulation(0, seed=8, periods=350, groups=80)
        self.assertLess(abs(r['ols_slope_current_deviation']+1),.06)
        self.assertLess(abs(r['ols_slope_previous_deviation']-1),.06)

    def test_null_rho_05(self):
        r=null_simulation(.5, seed=8, periods=350, groups=80)
        self.assertLess(abs(r['ols_slope_current_deviation']+.5),.06)
        self.assertLess(abs(r['ols_slope_previous_deviation']-.5),.06)

    def test_null_rho_08(self):
        r=null_simulation(.8, seed=8, periods=350, groups=80)
        self.assertLess(abs(r['ols_slope_current_deviation']+.2),.06)
        self.assertLess(abs(r['ols_slope_previous_deviation']-.2),.06)

    def test_invalid_rho(self):
        for rho in (-1, 1, 4):
            with self.assertRaises(ValueError):
                null_simulation(rho)

    def test_missing_real_source(self):
        with TemporaryDirectory() as t:
            with self.assertRaises(FileNotFoundError):
                audit_r048_csv(Path(t)/'none.csv')

    def test_fake_real_source_rejected(self):
        with TemporaryDirectory() as t:
            p=Path(t)/'fake.csv'
            p.write_bytes(b'ProfileID,FF,Invest\n100,1,2\n')
            with self.assertRaises(ValueError):
                audit_r048_csv(p)

if __name__ == '__main__':
    unittest.main(verbosity=2)
