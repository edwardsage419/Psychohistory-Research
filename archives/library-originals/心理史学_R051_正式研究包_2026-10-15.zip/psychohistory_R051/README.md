# R051 可复现研究包

R051为时间口径代数耦合与零机制反例审计，基于R048公开真人CSV在GitHub连接器侧验证的896次真实观察。**包内不含该作者原始CSV**，请从原仓库自行合法取得原始字节。R051没有产生独立新团队的真实数值预测结果。

环境：Python 3.10+，NumPy。程序目录中的`r048_source_reader_frozen.py`为继承读取及来源指纹核验代码；没有额外命令需要运行Stata。

```sh
python -m pip install numpy
python -m unittest -v test_r051
python r051_temporal_audit.py --simulate --output R051_NULL_SIMULATION.json
python r051_temporal_audit.py --csv /path/to/InequalityCPR/data/data.csv --output REAL_R051_AUDIT.json
```

最后一条命令只有在源Git blob等于`73c02176bc9e060af987149594a85f9f7b591230`时才产生真实结果，否则主动拒绝。原始资料与两份额外候选研究的来源状态见`SOURCE_LEDGER.json`。
