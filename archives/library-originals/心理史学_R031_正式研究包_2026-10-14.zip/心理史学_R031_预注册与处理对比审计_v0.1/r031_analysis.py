#!/usr/bin/env python3
"""R031. Source-locked independent testing of hypotheses in Munger's Twitter field experiment.

Requires original author anonymized CSV bytes, fetched only on --download.
No Bayesian story, preregistration compliance, direct message exposure, or sanction mediator
is inferred by this script. Prior exploration informed these contrasts: do not describe
p-values as confirmatory without the EGAP registration's frozen testing plan.
"""
from __future__ import annotations
import argparse
import json
import pathlib
import math
import numpy as np
import statsmodels.api as sm
from scipy import stats
from statsmodels.stats.multitest import multipletests
from r030_analysis import SOURCE, HORIZONS, FOLLOWERS, BASELINE, verify_source, parse_rows, complete_rows, fetch_and_lock, group_counts

ROOT = pathlib.Path(__file__).resolve().parent
CONTRASTS = {'C_minus_A': (3,1), 'C_minus_B': (3,2), 'C_minus_D': (3,4),
             'A_minus_D': (1,4), 'A_minus_B': (1,2), 'D_minus_B': (4,2)}


def arm_model(rows, outcome):
    d = complete_rows(rows)
    if len(d) <= 20:
        raise ValueError('Too few complete subject rows')
    X = np.array([[1.0] + [float(int(r['treat.f']) == k) for k in (1,2,3,4)]
                  + [float(r[FOLLOWERS]), float(r[BASELINE])] for r in d], dtype=float)
    y = np.array([float(r[outcome]) for r in d], dtype=float)
    model = sm.OLS(y, X).fit()
    hc3 = model.get_robustcov_results(cov_type='HC3', use_t=True)
    return model, hc3, len(d)


def direct_contrasts(rows, outcome):
    ols, robust, n = arm_model(rows, outcome)
    comparisons = {}
    for name, (i, j) in CONTRASTS.items():
        L = np.zeros(len(ols.params))
        L[i], L[j] = 1.0, -1.0
        classic = ols.t_test(L)
        hc = robust.t_test(L)
        comparisons[name] = {
            'estimate': float(classic.effect.item()),
            'se_classical': float(classic.sd.item()),
            'p_classical_two_sided': float(classic.pvalue.item()),
            'se_HC3': float(hc.sd.item()),
            'p_HC3_two_sided': float(hc.pvalue.item()),
            'CI95_HC3': [float(v) for v in hc.conf_int()[0]],
        }
    c_tests = [comparisons[k]['p_HC3_two_sided'] for k in ('C_minus_A','C_minus_B','C_minus_D')]
    corrected = multipletests(c_tests, method='holm')[1]
    factorial = treated_factorial(rows, outcome)
    return {
        'n_complete': n,
        'OLS_arm_coefficients': {'A_ingroup_low': float(ols.params[1]),
                                 'B_outgroup_low': float(ols.params[2]),
                                 'C_ingroup_high': float(ols.params[3]),
                                 'D_outgroup_high': float(ols.params[4])},
        'raw_C_more_negative_than_A_D_B': all(float(ols.params[3]) < float(ols.params[i]) for i in (1,2,4)),
        'strict_raw_order_C_A_D_B': bool(ols.params[3]<ols.params[1]<ols.params[4]<ols.params[2]),
        'direct_comparisons': comparisons,
        'exploratory_Holm_adjusted_HC3_C_vs_other_arms': dict(zip(('C_minus_A','C_minus_B','C_minus_D'), [float(v) for v in corrected])),
        'factorial_treated_only': factorial,
    }


def treated_factorial(rows, outcome):
    d = [r for r in complete_rows(rows) if int(r['treat.f']) > 0]
    if len(d)<20:
        raise ValueError('Too few treated subjects')
    X=np.array([[1, float(r['In_group']),float(r['high_followers']),
                 float(r['In_group'])*float(r['high_followers']),
                 float(r[FOLLOWERS]),float(r[BASELINE])] for r in d], dtype=float)
    y=np.array([float(r[outcome]) for r in d], dtype=float)
    m=sm.OLS(y,X).fit()
    robust=m.get_robustcov_results(cov_type='HC3',use_t=True)
    return {'n':len(d),'interaction_ingroup_x_highfollowers':float(m.params[3]),
            'se_HC3':float(robust.bse[3]),'p_HC3_two_sided':float(robust.pvalues[3]),
            'CI95_HC3':[float(v) for v in robust.conf_int()[3]]}


def audit_counts(rows):
    allcounts=group_counts(rows)
    complete=complete_rows(rows)
    compcounts=group_counts(complete)
    paper={'0':51,'1':49,'2':44,'3':50,'4':48}
    missing=[{'X':str(r['X']),'treatment':r['treat.f'],'anonymity':r['anonymity']}
             for r in rows if r[BASELINE] in ('','NA')]
    return {'source_n':len(rows),'complete_n':len(complete),
            'source_counts':allcounts,'complete_counts':compcounts,
            'paper_table2_counts':paper,
            'delta_complete_minus_paper':{k:compcounts[k]-paper[k] for k in paper},
            'missing_baseline_records':missing,
            'anonymous_complete_count':sum(int(r['anonymity'])==2 for r in complete),
            'less_anonymous_complete_count':sum(int(r['anonymity'])<2 for r in complete)}


def run_one(data:bytes, key:str):
    verify_source(data,SOURCE[key]['git_blob'])
    rows=parse_rows(data)
    return {'source_git_blob_verified':SOURCE[key]['git_blob'],
            'count_audit':audit_counts(rows),
            'week1':direct_contrasts(rows,HORIZONS['week_1'])}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--data-dir',default=str(ROOT/'data'))
    parser.add_argument('--download',action='store_true')
    parser.add_argument('--output',default=str(ROOT/'R031_LOCAL_RECOMPUTED.json'))
    args=parser.parse_args()
    data_dir=pathlib.Path(args.data_dir)
    if args.download:
        fetch_and_lock(data_dir)
    output={}
    for key,meta in SOURCE.items():
        path=data_dir/meta['filename']
        if not path.is_file():
            raise SystemExit('SOURCE_MISSING: %s. Download both source-locked files explicitly with --download.' % path)
        output[key]=run_one(path.read_bytes(),key)
    pathlib.Path(args.output).write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('R031 source-verified independent contrasts saved:',args.output)


if __name__=='__main__':
    main()
