import sys
import unittest
import pathlib
import numpy as np
P=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(P))
import r031_analysis as a
from r030_analysis import HORIZONS


def make_rows(n=120):
    rng=np.random.default_rng(145)
    rows=[]
    groups=(list(range(5)) * (n//5))
    for i,g in enumerate(groups):
        ing=int(g in [1,3]); hi=int(g in [3,4]); pre=float(rng.uniform(.05,.8)); f=float(rng.uniform(2,9));
        # Effects deliberately specified to test contrast ordering.
        effects=[0,-.10,-.01,-.32,-.08]
        y=1.25+effects[g]+.08*f+.3*pre+float(rng.normal(0,.21))
        rows.append({'X':str(i+1),'treat.f':str(g),'In_group':str(ing),
                     'high_followers':str(hi),'anonymity':str(i%3),
                     'log.followers':str(f),'racism.scores.pre.2mon':str(pre),
                     HORIZONS['week_1']:str(y)})
    return rows


class R031Tests(unittest.TestCase):
    def test_expected_group_sizes(self):
        d=make_rows();self.assertEqual(len(d),120)
        self.assertEqual(a.audit_counts(d)['complete_counts']['3'],24)
    def test_missing_baseline(self):
        d=make_rows(); d[0]['racism.scores.pre.2mon']='NA'
        x=a.audit_counts(d)
        self.assertEqual(x['complete_n'],119)
        self.assertEqual(x['missing_baseline_records'][0]['X'],'1')
    def test_effective_model(self):
        d=make_rows();x=a.direct_contrasts(d,HORIZONS['week_1']);self.assertEqual(x['n_complete'],120)
    def test_direct_contrast_direction(self):
        d=make_rows();x=a.direct_contrasts(d,HORIZONS['week_1']);self.assertLess(x['direct_comparisons']['C_minus_B']['estimate'],0)
    def test_C_is_strongest(self):
        d=make_rows();x=a.direct_contrasts(d,HORIZONS['week_1']);self.assertTrue(x['raw_C_more_negative_than_A_D_B'])
    def test_hc3_nonzero(self):
        d=make_rows();x=a.direct_contrasts(d,HORIZONS['week_1']);self.assertGreater(x['direct_comparisons']['C_minus_B']['se_HC3'],0)
    def test_interval_order(self):
        d=make_rows();x=a.direct_contrasts(d,HORIZONS['week_1']);self.assertLess(*x['direct_comparisons']['C_minus_A']['CI95_HC3'])
    def test_factorial(self):
        d=make_rows();x=a.treated_factorial(d,HORIZONS['week_1']);self.assertEqual(x['n'],96)
    def test_holm_n_tests(self):
        d=make_rows();x=a.direct_contrasts(d,HORIZONS['week_1']);self.assertEqual(len(x['exploratory_Holm_adjusted_HC3_C_vs_other_arms']),3)
    def test_source_expected_keys(self):
        self.assertEqual(set(a.SOURCE), {"standard", "conservative"})
    def test_github_blob_verification_fails(self):
        from r030_analysis import verify_source
        with self.assertRaises(ValueError):verify_source(b'not actual source',a.SOURCE['standard']['git_blob'])
    def test_ranking_under_noise(self):
        x=a.direct_contrasts(make_rows(),HORIZONS['week_1']);self.assertTrue(x['strict_raw_order_C_A_D_B'])
    def test_treat_only_fewer(self):
        d=make_rows();self.assertLess(a.treated_factorial(d,HORIZONS['week_1'])['n'],len(d))
    def test_combined_source_fails_if_corrupt(self):
        with self.assertRaises(ValueError):a.run_one(b'broken','standard')

if __name__=='__main__':unittest.main()
