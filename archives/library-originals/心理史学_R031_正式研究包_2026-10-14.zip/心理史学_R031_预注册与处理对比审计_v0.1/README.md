# R031 正式研究包

2026-10-14。内容：2015年公开设计草稿 vs 2017年正式论文、官方CSV与论文样本差异、四处理之间直接对比、身份×关注者人数的竞争假设、来源状态与严格不确定性登记。PESEN v0.1冻结。

## 文件

- `R031_EVIDENCE_AUDIT.md` 正式研究审计及来源。
- `SOURCE_AND_STATUS_LEDGER.json` 来源和权限状态。
- `R031_CONNECTOR_CONTRAST_RESULTS.json` 已实读GitHub CSV的连接器侧计算结果。
- `r031_analysis.py`, `r030_analysis.py` 运行在联网环境且经过固定SHA核验的复算程序。
- `tests/test_r031.py` 构造样本的软件测试。

## 在可下载源数据的环境执行

```bash
python -m pip install numpy scipy statsmodels
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python r031_analysis.py --download
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python -m unittest discover -s tests -v
```

默认离线运行，需有 `data/data_anonymized_{standard,conservative}_assumption.csv` 两份作者原始字节。只有 `--download` 明确允许主动下载。每份原始字节在分析前按预先记录的Git blob SHA1验证。`R031_LOCAL_RECOMPUTED.json` 仅在通过检验后生成。

当前容器DNS无法取回 GitHub 原始字节，因此研究包不含两份CSV或本地真实源运行结果。14项测试是合成构造数据的软件测试。

研究结论为事后探索性，EGAP官方注册文件未能实读。不能用早期设计稿替代原始预注册承诺，也不能因此判定作者研究违规。
