import math
import tempfile
import unittest
from pathlib import Path
from r021_identification import (sigmoid,logit,direct_probability,speech_from_d,
       audience_probability,inverse_audience_weight,proof_table,contrast,save)
class Checks(unittest.TestCase):
    def test_sigmoid_zero(self):self.assertAlmostEqual(sigmoid(0),.5)
    def test_sigmoid_extremes(self):self.assertGreater(sigmoid(30),.999)
    def test_logit_symmetry(self):self.assertAlmostEqual(logit(.2),-logit(.8))
    def test_logit_bad(self):
        for q in [-.1,0,1,1.01]:
            with self.assertRaises(ValueError):logit(q)
    def test_invalid_sigmoid(self):
        with self.assertRaises(ValueError):sigmoid(float('nan'))
    def test_speech_d_zero(self):self.assertEqual(speech_from_d(0),0)
    def test_speech_d_one(self):self.assertEqual(speech_from_d(1),.5)
    def test_speech_bad(self):
        with self.assertRaises(ValueError):speech_from_d(-1)
    def test_d_to_p_zero(self):self.assertAlmostEqual(audience_probability(0),sigmoid(-2))
    def test_inverse_p(self):
        for d in [0,.1,1,2,20]:
            self.assertAlmostEqual(inverse_audience_weight(audience_probability(d)),d,places=11)
    def test_inverse_reject_high(self):
        with self.assertRaises(ValueError):inverse_audience_weight(.999999)
    def test_inverse_reject_low(self):
        with self.assertRaises(ValueError):inverse_audience_weight(.01)
    def test_direct_binary(self):
        with self.assertRaises(ValueError):direct_probability(2,1,0)
    def test_cost_down_in_each_cell(self):
        for a in [0,1]:
            for v in [0,1]:self.assertLess(direct_probability(a,v,1),direct_probability(a,v,0))
    def test_same_population_observable(self):
        r=proof_table();self.assertLess(r['max_absolute_cell_prediction_gap'],1e-12)
    def test_eight_cells(self):self.assertEqual(len(proof_table()['cells']),8)
    def test_positive_reputation_interaction(self):self.assertGreater(proof_table()['contrasts']['evaluation_by_visibility_ITT'],0)
    def test_cost_negative(self):self.assertLess(proof_table()['contrasts']['cost_main_ITT'],0)
    def test_anonymous_eval_placebo(self):self.assertAlmostEqual(proof_table()['contrasts']['evaluation_effect_when_anonymous'],0)
    def test_cost_d_sensitivity(self):
        z=proof_table();self.assertGreater(z['cost_shift_sensitivity']['max_abs_delta_D_needed_at_fixed_bridge'],0)
    def test_cost_match_requires_varying_D(self):
        z=proof_table();self.assertTrue(all(abs(x['delta_d_cost1_minus_cost0'])>1e-7 for x in z['cost_shift_sensitivity']['pairwise_delta_D'].values()))
    def test_json_csv_written(self):
        with tempfile.TemporaryDirectory() as d:
            j=Path(d)/'a.json';c=Path(d)/'b.csv';save(j,c)
            self.assertEqual(len(c.read_text().splitlines()),9)
            self.assertIn('flexible_d',j.read_text())
    def test_no_unjustified_mechanism(self):self.assertIn('does not uniquely identify',proof_table()['decision'])
if __name__=='__main__':unittest.main()
