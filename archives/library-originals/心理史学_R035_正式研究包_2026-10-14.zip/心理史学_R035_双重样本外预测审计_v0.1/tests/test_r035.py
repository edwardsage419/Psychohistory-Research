import copy
import hashlib
import importlib.util
import json
import math
import sys
import tempfile
import unittest
from pathlib import Path

BASE=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('r035_analysis',BASE/'r035_analysis.py')
a=importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)

class R035Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.r032=a.load_derived()
        cls.dynamic=json.loads((BASE/'DYNAMIC_DERIVED_COUNTS.json').read_text(encoding='utf8'))

    def test_01_prior_r032_hash(self):
        self.assertEqual(hashlib.sha256((BASE/'R032_VERIFIED_CELLS.json').read_bytes()).hexdigest(),a.R032_SHA256)

    def test_02_raw_git_hash_matches_known_synthetic(self):
        content=b'abc\n'
        self.assertEqual(a.git_blob_sha1(content),hashlib.sha1(b'blob 4\0abc\n').hexdigest())

    def test_03_git_sha_changes_with_extra_byte(self):
        self.assertNotEqual(a.git_blob_sha1(b'abc'),a.git_blob_sha1(b'abc\n'))

    def test_04_raw_mismatch_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'fake.csv';path.write_bytes(b'fake,data\n')
            with self.assertRaises(ValueError):a.check_bytes(path,'0'*40)

    def test_05_bad_derived_hash_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'bad.json';path.write_text('{}',encoding='utf8')
            with self.assertRaises(ValueError):a.load_derived(path)

    def test_06_r032_total_counts(self):
        by=a.city_cells(self.r032)
        self.assertEqual(sum(x['N'][1]+x['R'][1] for x in by.values()),588)
        self.assertEqual(sum(x['N'][0]+x['R'][0] for x in by.values()),284)

    def test_07_city_strata(self):
        self.assertEqual(set(a.city_cells(self.r032)),{'Shanghai','Nanjing','Wenzhou','Hangzhou','Changzhou'})

    def test_08_source_counts_mismatch(self):
        c=copy.deepcopy(self.r032);c['credamo_cells'][0][4]=999
        with self.assertRaises(ValueError):a.city_cells(c)

    def test_09_clip_range(self):
        self.assertGreater(a.clip(0),0);self.assertLess(a.clip(1),1)

    def test_10_sigmoid_logit_inverse(self):
        for p in [.01,.2,.5,.86,.99]:self.assertAlmostEqual(a.expit(a.logit(p)),p,places=13)

    def test_11_brier_perfect(self):
        self.assertAlmostEqual(a.brier(1,1,1-1e-6),1e-12,places=14)

    def test_12_log_loss_p_half(self):
        self.assertAlmostEqual(a.loss(1,2,.5)/2,math.log(2),places=12)

    def test_13_city_fold_count(self):
        x=a.site_cv(a.city_cells(self.r032))
        self.assertEqual(x['n_cities'],5);self.assertEqual(x['n_test_treated'],295)

    def test_14_no_effect_best(self):
        x=a.site_cv(a.city_cells(self.r032))['metrics']
        self.assertLess(x['null_effect']['pooled_treated_person_log_loss'],x['pooled_log_odds_ratio']['pooled_treated_person_log_loss'])
        self.assertLess(x['null_effect']['pooled_treated_person_log_loss'],x['pooled_risk_difference']['pooled_treated_person_log_loss'])

    def test_15_city_predictions_never_observed_treated_rate(self):
        cv=a.site_cv(a.city_cells(self.r032))
        for f in cv['folds']:
            self.assertTrue(0<f['forecast_p']['null_effect']<1)
        self.assertEqual(cv['fixed_rd_sign_correct_count'],0)

    def test_16_city_heldout_treated_excluded_train(self):
        data=a.city_cells(self.r032);cv=a.site_cv(data)
        for f in cv['folds']:
            rest={k:v for k,v in data.items() if k!=f['city']}
            expected=sum(v['R'][0] for v in rest.values())/sum(v['R'][1] for v in rest.values())-sum(v['N'][0] for v in rest.values())/sum(v['N'][1] for v in rest.values())
            self.assertAlmostEqual(f['train_pooled_rd'],expected)

    def test_17_band_nonnegative_tau(self):
        cv=a.site_cv(a.city_cells(self.r032))
        for f in cv['folds']:self.assertGreaterEqual(f['random_effects_exploratory']['tau2'],0)

    def test_18_dynamic_train_counts(self):
        a.validate_dynamic(self.dynamic)
        self.assertEqual(sum(x[3] for x in self.dynamic['train_by_period_arm']),527)

    def test_19_dynamic_bad_test_size(self):
        d=copy.deepcopy(self.dynamic);d['test_arm_period'][0][2]=67
        with self.assertRaises(ValueError):a.validate_dynamic(d)

    def test_20_dynamic_bad_train_time(self):
        d=copy.deepcopy(self.dynamic);d['train_by_period_arm'][0][1]=8
        with self.assertRaises(ValueError):a.validate_dynamic(d)

    def test_21_dynamic_bad_margin(self):
        d=copy.deepcopy(self.dynamic);d['test_by_train_k'][0][-1]=3
        with self.assertRaises(ValueError):a.validate_dynamic(d)

    def test_22_dynamic_train_transition_sum(self):
        x=a.dynamic_cv(self.dynamic)
        self.assertEqual(x['train_n'],938)
        self.assertEqual(x['test_n'],402)
        self.assertAlmostEqual(x['training_markov_p'][0],50.5/346)
        self.assertAlmostEqual(x['training_markov_p'][1],390.5/460)

    def test_23_train_trend_negative(self):
        b0,b1=a.trend_logit([(t,sum(x[2] for x in self.dynamic['train_by_period_arm'] if x[1]==t),sum(x[3] for x in self.dynamic['train_by_period_arm'] if x[1]==t)) for t in range(1,8)])
        self.assertLess(b1,0)

    def test_24_markov_scores(self):
        x=a.dynamic_cv(self.dynamic)['metrics']
        self.assertAlmostEqual(x['one_step_markov']['mean_log_loss'],.44626059067438895,places=11)
        self.assertLess(x['one_step_markov']['mean_log_loss'],x['individual_first7']['mean_log_loss'])

    def test_25_person_stability_scores(self):
        x=a.dynamic_cv(self.dynamic)['metrics']
        self.assertAlmostEqual(x['individual_first7']['mean_log_loss'],.548152093489029,places=11)

    def test_26_fixed_scores(self):
        x=a.dynamic_cv(self.dynamic)['metrics']
        self.assertAlmostEqual(x['pooled_fixed']['mean_log_loss'],.71998712155475,places=11)

    def test_27_dynamic_raw_missing_subject_rejected(self):
        data=[{'subject_unq':'1','treatment':'CondInfo','period':'1','isCC':'TRUE'}]
        with self.assertRaises(ValueError):a.aggregate_dynamic_raw(data)

    def test_28_fake_raw_classification_rejected(self):
        data=[{'subject_unq':'1','treatment':'CondInfo','period':'1','isCC':'INVALID'}]
        with self.assertRaises(ValueError):a.aggregate_dynamic_raw(data)

    def test_29_full_run_doesnt_claim_raw(self):
        out=a.run()
        self.assertEqual(out['source_validation']['mode'],'DERIVED_COUNTS_ONLY_OR_PARTIAL')
        self.assertEqual(out['mechanism_result'],'NO_INDEPENDENT_SOCIAL_SANCTION_IDENTIFICATION')

    def test_30_strict_mode_rejects_missing(self):
        with self.assertRaises(ValueError):a.run(require_raw=True)

    def test_31_unmodified_baseline_preserved(self):
        out=a.run();self.assertEqual(out['pesen'],'V0.1_FROZEN')

if __name__=='__main__': unittest.main()

class SessionBootstrapTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sessions=json.loads((BASE/'SESSION_HOLDOUT_SCORES.json').read_text(encoding='utf8'))

    def test_32_source_session_count(self):
        self.assertEqual(len(self.sessions['sessions']),6)
        self.assertEqual(sum(x[1] for x in self.sessions['sessions']),402)

    def test_33_observed_session_difference(self):
        out=a.session_bootstrap(self.sessions,replications=100,seed=1)
        self.assertAlmostEqual(out['loss_difference_frozen_markov_minus_stable_person'],.5087932277150782-.548152093489029,places=11)

    def test_34_count_better_sessions(self):
        out=a.session_bootstrap(self.sessions,replications=100,seed=1)
        self.assertEqual(out['better_sessions_frozen_markov'],4)

    def test_35_seed_reproducibility(self):
        p=a.session_bootstrap(self.sessions,replications=300,seed=123)
        q=a.session_bootstrap(self.sessions,replications=300,seed=123)
        self.assertEqual(p['bootstrap_percentile_95'],q['bootstrap_percentile_95'])

    def test_36_invalid_session_count_fails(self):
        data=copy.deepcopy(self.sessions);data['sessions'].pop()
        with self.assertRaises(ValueError):a.session_bootstrap(data,replications=100)
