# 心理史学 R035 正式研究包

状态：**两个事后留出预测基准已完成，36项软件测试PASS；本地原始CSV字节验证未完成；独立社会制裁机制仍未识别。**

本包包含 R032 来源核验的匿名派生汇总、R035 新的134人十轮实验无ID派生汇总、实际通过GitHub连接器分析后保存的结果、独立运行Python脚本、测试、来源审计和 R036 关口。

## 运行

```bash
python r035_analysis.py
python -m unittest discover -s tests -v
```

程序默认读取随包已锁定的 `R032_VERIFIED_CELLS.json` 与 `DYNAMIC_DERIVED_COUNTS.json`，无需联网，只重算**派生汇总数据**。

持有两个作者GitHub原始CSV时，可运行严格核验：

```bash
python r035_analysis.py \
  --credamo-raw /path/to/cooperation_with_strangers/data/credamo_data_all.csv \
  --dynamic-raw /path/to/stabilitycondcoop/data/csv/subjects.csv \
  --require-raw
```

强制源字节 Git SHA1 与全量派生单元一致；任何源缺失、SHA不匹配或源记录的派生计数不符均失败。当前环境原始文件未下载成功，所以尚不能声称上面的真实数据端到端检查已经通过。

## 来源

- Molina, Nee, Holm (Organization Science), DOI `10.1287/orsc.2021.1521`；源仓库 `mariomolinam/cooperation_with_strangers`，其 Credamo 样本由R032首次读取。
- Andreozzi, Ploner, Saral (Scientific Reports, 2020), DOI `10.1038/s41598-020-70681-z`；`seyhunsaral/stabilitycondcoop` ，2020年作者仓库README标注资料CC BY 4.0，源码MIT。
- Mieth, Buchner, Bell (Scientific Reports, 2021), DOI `10.1038/s41598-021-89675-6`，OSF `kucya`，机制候选资料，尚未读取数据字节。

这三个来源的处理、结局和实验单位具有实质差异，当前不进行未经测量等值核验的统一效应元分析。
