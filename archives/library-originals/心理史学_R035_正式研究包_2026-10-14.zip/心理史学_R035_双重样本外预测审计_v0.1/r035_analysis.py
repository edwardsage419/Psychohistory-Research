#!/usr/bin/env python3
"""R035 exploratory out-of-sample benchmarks with original-source provenance.

Read-only, standard library only. Default uses previously connector-verified derived
cell counts. Optional original CSV inputs MUST pass Git blob SHA1 before analysis.
No claim of preregistration, independent mechanism identification, or raw-byte
local source verification is made unless those bytes are actually provided.
"""
import argparse
import csv
import hashlib
import json
import math
import random
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
R032_SHA256 = '1fa5c79f5a3b7f530e14a5097015bb033655963383f9ea1fd10ef02fdb8efcc7'


def git_blob_sha1(content):
    return hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\x00' + content).hexdigest()


def check_bytes(path, sha):
    raw = Path(path).read_bytes()
    actual = git_blob_sha1(raw)
    if actual != sha:
        raise ValueError('Git blob SHA mismatch: expected %s, got %s' % (sha, actual))
    return list(csv.DictReader(raw.decode('utf-8-sig').splitlines()))


def load_derived(path=HERE / 'R032_VERIFIED_CELLS.json'):
    data = Path(path).read_bytes()
    if hashlib.sha256(data).hexdigest() != R032_SHA256:
        raise ValueError('R032 derived count file SHA256 mismatch')
    val = json.loads(data.decode('utf-8'))
    assert len(val['credamo_cells']) == 20
    assert sum(c[3] for c in val['credamo_cells']) == 588
    assert sum(c[4] for c in val['credamo_cells']) == 284
    return val


def city_cells(derived):
    cells = defaultdict(dict)
    for city, population, arm, n, y in derived['credamo_cells']:
        if not (0 <= y <= n and arm in ('R', 'N')):
            raise ValueError('invalid derived city counts')
        s, t = cells[city].get(arm, (0, 0))
        cells[city][arm] = (s + y, t + n)
    if len(cells) != 5 or any(set(groups) != {'R','N'} for groups in cells.values()):
        raise ValueError('city groups incomplete')
    return dict(cells)


def check_r032_raw(path, derived):
    rows = check_bytes(path, derived['provenance']['credamo']['git_blob_sha1'])
    observed = defaultdict(lambda: [0, 0])
    for r in rows:
        if r['attention_check'] == '5':
            k = r['city'],r['population'],r['treatment']
            observed[k][0] += 1
            observed[k][1] += int(r['cooperation'])
    expected = {(a,b,c):[n,y] for a,b,c,n,y in derived['credamo_cells']}
    if dict(observed) != expected or len(rows) != 599:
        raise ValueError('original CSV does not reproduce R032 cells')
    return len(rows)


def clip(p):
    return max(1e-9, min(1.0-1e-9, p))


def logit(p):
    return math.log(p/(1-p))


def expit(x):
    if x >= 0:
        z = math.exp(-x)
        return 1/(1+z)
    z=math.exp(x)
    return z/(1+z)


def loss(y,n,p):
    p=clip(p)
    return -(y*math.log(p)+(n-y)*math.log1p(-p))


def brier(y,n,p):
    return (y*(1-p)**2 + (n-y)*p**2)/n


def heterogeneity_band(training):
    """Exploratory normal-approx random-effects predictive interval for site RD.

    Between-site variance: DerSimonian-Laird, with only four sites per fold.
    Coverage is descriptive; interval does not propagate holdout baseline
    measurement uncertainty or account for all effect identification errors.
    """
    diffs, variances = [], []
    for v in training.values():
        y0,n0=v['N'];y1,n1=v['R']
        a=y0/n0;b=y1/n1
        diffs.append(b-a)
        variances.append(a*(1-a)/n0+b*(1-b)/n1)
    w=[1/v for v in variances]
    mu=sum(w[i]*diffs[i] for i in range(len(w)))/sum(w)
    q=sum(w[i]*(diffs[i]-mu)**2 for i in range(len(w)))
    divisor=sum(w)-sum(x*x for x in w)/sum(w)
    tau2=max(0,(q-(len(w)-1))/divisor)
    w2=[1/(v+tau2) for v in variances]
    avg=sum(w2[i]*diffs[i] for i in range(len(w)))/sum(w2)
    se=math.sqrt(tau2+1/sum(w2))
    return {'mean_rd':avg,'tau2':tau2,'se_prediction':se,'interval_95_normal':[avg-1.96*se,avg+1.96*se]}


def site_cv(cells):
    folds=[]
    for city in sorted(cells):
        hold=cells[city]
        train={k:v for k,v in cells.items() if k!=city}
        c,n0=hold['N'];y,n1=hold['R']
        c_tr=sum(t['N'][0] for t in train.values());n0_tr=sum(t['N'][1] for t in train.values())
        y_tr=sum(t['R'][0] for t in train.values());n1_tr=sum(t['R'][1] for t in train.values())
        p_local=(c+0.5)/(n0+1)
        rd_train=y_tr/n1_tr-c_tr/n0_tr
        or_train=logit((y_tr+.5)/(n1_tr+1))-logit((c_tr+.5)/(n0_tr+1))
        probs={'null_effect':p_local, 'pooled_risk_difference':clip(p_local+rd_train),
               'pooled_log_odds_ratio':expit(logit(p_local)+or_train)}
        actual_rd=y/n1-c/n0
        h=heterogeneity_band(train)
        lo,hi=h['interval_95_normal']
        folds.append({'city':city,'control':[n0,c],'treated':[n1,y],
                      'observed_treated_rate':y/n1,'observed_rd':actual_rd,
                      'train_pooled_rd':rd_train,'train_pooled_log_or':or_train,
                      'forecast_p':probs,'forecast_log_loss_per_person':{k:loss(y,n1,p)/n1 for k,p in probs.items()},
                      'forecast_rate_squared_error':{k:(y/n1-p)**2 for k,p in probs.items()},
                      'forecast_rd_sign_correct':(rd_train*actual_rd>0),
                      'random_effects_exploratory':{**h,'observed_rd_covered':lo<=actual_rd<=hi}})
    models=list(folds[0]['forecast_p'])
    out={}
    for m in models:
        out[m]={
          'mean_city_rate_squared_error':sum(f['forecast_rate_squared_error'][m] for f in folds)/len(folds),
          'pooled_treated_person_log_loss':sum(f['forecast_log_loss_per_person'][m]*f['treated'][0] for f in folds)/sum(f['treated'][0] for f in folds),
          'mean_city_log_loss':sum(f['forecast_log_loss_per_person'][m] for f in folds)/len(folds)}
    return {'design':'LOCO, holdout city treated outcomes unseen; local control baseline observed',
            'after_the_fact_exploration':True,'n_cities':len(folds),'n_test_treated':sum(f['treated'][0] for f in folds),
            'folds':folds,'metrics':out,
            'fixed_rd_sign_correct_count':sum(f['forecast_rd_sign_correct'] for f in folds),
            'random_effects_interval_coverage':sum(f['random_effects_exploratory']['observed_rd_covered'] for f in folds)}


def validate_dynamic(d):
    if d['source']['raw_records'] != 1340 or d['source']['n_people']!=134:
        raise ValueError('wrong source sample')
    tr=d['train_by_period_arm'];ta=d['test_arm_period']
    if len(tr)!=14 or len(ta)!=6 or sum(x[2] for x in tr)!=938 or sum(x[2] for x in ta)!=402:
        raise ValueError('wrong train/test sizes')
    if sum(x[3] for x in tr)!=527 or sum(x[3] for x in ta)!=170:
        raise ValueError('wrong target counts')
    if sum(x[1] for x in d['train_transitions'])!=804:
        raise ValueError('wrong transition sample')
    for field in ('test_previous','test_by_train_k','test_by_arm_period_prev','test_by_k_arm','test_by_period7_state'):
        if sum(x[-2] for x in d[field])!=402 or sum(x[-1] for x in d[field])!=170:
            raise ValueError('test margins differ for %s'%field)
    if any(x[1]>7 for x in tr) or any(x[1]<8 for x in ta):
        raise ValueError('train/test period leakage')


def aggregate_dynamic_raw(rows):
    people=defaultdict(list)
    for row in rows:
        yy=row['isCC'];
        if yy not in ('TRUE','FALSE'):
            raise ValueError('isCC missing')
        people[row['subject_unq']].append({'arm':row['treatment'], 't':int(row['period']),
             'y':int(yy=='TRUE'), 'id':row['subject_unq']})
    if len(people)!=134 or sum(map(len,people.values()))!=1340:
        raise ValueError('source size unexpected')
    train=[]; test=[]; transitions=[]
    for person,a in people.items():
        a.sort(key=lambda x:x['t'])
        if [x['t'] for x in a]!=list(range(1,11)) or len({x['arm'] for x in a})!=1:
            raise ValueError('person timeline incomplete')
        k=sum(x['y'] for x in a[:7]);train.extend(a[:7])
        for i in range(1,7):transitions.append({**a[i],'previous':a[i-1]['y']})
        for i in range(7,10):test.append({**a[i],'previous':a[i-1]['y'],'start7':a[6]['y'],'k':k})
    def grouped(fields,data):
        grouped=defaultdict(lambda:[0,0])
        for row in data:
            key=tuple(row[f] for f in fields)
            grouped[key][0]+=1;grouped[key][1]+=row['y']
        return sorted([list(k)+v for k,v in grouped.items()])
    return {'train_by_period_arm':grouped(('arm','t'),train),
      'train_transitions':grouped(('previous',),transitions),
      'test_arm_period':grouped(('arm','t'),test),
      'test_previous':grouped(('previous',),test),
      'test_by_train_k':grouped(('k',),test),
      'test_by_arm_period_prev':grouped(('arm','t','previous'),test),
      'test_by_k_arm':grouped(('k','arm'),test),
      'test_by_period7_state':grouped(('start7','t','arm'),test)}


def check_dynamic_raw(path, derived):
    original=check_bytes(path,derived['source']['git_blob_sha1'])
    cells=aggregate_dynamic_raw(original)
    for k,v in cells.items():
        if sorted(v)!=sorted(derived[k]):
            raise ValueError('raw-to-derived mismatch for '+k)
    return len(original)


def trend_logit(period_counts):
    """Logistic fit to the seven training periods only. Center x=t-4."""
    b0=b1=0.0
    for _ in range(80):
        g0=g1=h00=h01=h11=0.0
        for t,n,y in period_counts:
            x=t-4;p=expit(b0+b1*x);w=n*p*(1-p)
            g0+=y-n*p;g1+=x*(y-n*p)
            h00+=w;h01+=x*w;h11+=x*x*w
        det=h00*h11-h01*h01
        if det<1e-12:raise ValueError('singular trend fit')
        d0=(h11*g0-h01*g1)/det
        d1=(-h01*g0+h00*g1)/det
        b0+=d0;b1+=d1
        if max(abs(d0),abs(d1))<1e-12:break
    return b0,b1


def dynamic_cv(d):
    validate_dynamic(d)
    tr=d['train_by_period_arm']; ta=d['test_arm_period']; total_train=sum(x[2] for x in tr);ys=sum(x[3] for x in tr)
    p0=(ys+.5)/(total_train+1)
    arms={}
    for arm in ('NoCondInfo','CondInfo'):
        a=[x for x in tr if x[0]==arm]
        arms[arm]=(sum(x[3] for x in a)+.5)/(sum(x[2] for x in a)+1)
    tm={v:(y+.5)/(n+1) for v,n,y in d['train_transitions']}
    period=[(t,sum(x[2] for x in tr if x[1]==t),sum(x[3] for x in tr if x[1]==t)) for t in range(1,8)]
    b0,b1=trend_logit(period)
    src={
      'pooled_fixed':[(p0,n,y) for _,_,n,y in ta],
      'treatment_arm_fixed':[(arms[arm],n,y) for arm,_,n,y in ta],
      'time_trend':[(expit(b0+b1*(t-4)),n,y) for _,t,n,y in ta],
      'one_step_markov':[(tm[prev],n,y) for prev,n,y in d['test_previous']],
      'individual_first7':[((k+.5)/8,n,y) for k,n,y in d['test_by_train_k']],
      'markov_period7_rollforward':[]
    }
    # Frozen test horizon: only the observed round-7 state is available
    # at the time of issuing all three period 8-10 forecasts.
    a0,a1=tm[0],tm[1]
    frozen={0:0.0,1:1.0}; predictions={}
    for period in (8,9,10):
        frozen={state:a0+(a1-a0)*prob for state,prob in frozen.items()}
        predictions[period]=dict(frozen)
    src['markov_period7_rollforward']=[(predictions[t][start],n,y) for start,t,arm,n,y in d['test_by_period7_state']]
    metrics={}
    for name,rows in src.items():
        n_all=sum(n for p,n,y in rows)
        metrics[name]={'n':n_all,
          'mean_log_loss':sum(loss(y,n,p) for p,n,y in rows)/n_all,
          'mean_brier':sum(brier(y,n,p)*n for p,n,y in rows)/n_all}
    return {'design':'Train periods 1..7, test periods 8..10; Markov uses OBSERVED preceding period in a one-step-ahead forecast',
      'after_the_fact_exploration':True,'n_subjects':134,'n_sessions':6,'train_n':938,'test_n':402,
      'train_cooperators':527,'test_cooperators':170,'training_markov_p':tm,
      'train_period_logit':{'intercept_at_period4':b0,'slope_per_period':b1},
      'frozen_markov_forecast_probabilities':predictions,
      'metrics':metrics,'source_sha':d['source']['git_blob_sha1']}


def session_bootstrap(aggregate, replications=20000, seed=20261014):
    """Exploratory session-resampled pairwise logloss difference, only 6 clusters."""
    sess=aggregate['sessions']
    if len(sess)!=6 or sum(x[1] for x in sess)!=402:
        raise ValueError('session sample invalid')
    observed=(sum(x[2]-x[3] for x in sess)/sum(x[1] for x in sess))
    random_gen=random.Random(seed)
    sims=[]
    for _ in range(replications):
        chosen=[sess[random_gen.randrange(len(sess))] for _ in range(len(sess))]
        sims.append(sum(x[2]-x[3] for x in chosen)/sum(x[1] for x in chosen))
    sims.sort()
    return {'source':'AGGREGATED_SESSION_SCORES_FROM_LIVE_GITHUB_CSV',
       'unit':'session', 'n_sessions':6,'n_heldout':402,'replications':replications,
       'seed':seed, 'loss_difference_frozen_markov_minus_stable_person':observed,
       'bootstrap_percentile_95':[sims[int(.025*replications)],sims[int(.975*replications)-1]],
       'better_sessions_frozen_markov':sum(x[2]<x[3] for x in sess),
       'note':'Exploratory, six sessions insufficient for strong generalizable inferential claims.'}


def run(credamo_raw=None, dynamic_raw=None, require_raw=False):
    r032=load_derived()
    d=json.loads((HERE/'DYNAMIC_DERIVED_COUNTS.json').read_text(encoding='utf8'))
    if require_raw and (not credamo_raw or not dynamic_raw):
        raise ValueError('require_raw needs both --credamo-raw and --dynamic-raw')
    verified={}
    if credamo_raw:verified['r032_credamo_rows']=check_r032_raw(credamo_raw,r032)
    if dynamic_raw:verified['andreozzi_subject_round_rows']=check_dynamic_raw(dynamic_raw,d)
    out={'protocol':'R035','status':'EXPLORE_AFTER_SOURCE_EXPOSURE',
      'source_validation':{'mode':'RAW_BYTES_CHECKED' if len(verified)==2 else 'DERIVED_COUNTS_ONLY_OR_PARTIAL',
                           'verified_bytes':verified,'r032_derived_sha256':R032_SHA256,
                           'andreozzi_git_blob_sha1':d['source']['git_blob_sha1']},
      'heldout_city':site_cv(city_cells(r032)),
      'heldout_later_rounds':dynamic_cv(d),
      'cluster_sensitivity':session_bootstrap(json.loads((HERE/'SESSION_HOLDOUT_SCORES.json').read_text(encoding='utf8'))),
      'mechanism_result':'NO_INDEPENDENT_SOCIAL_SANCTION_IDENTIFICATION',
      'pesen':'V0.1_FROZEN'}
    return out


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--credamo-raw', type=Path,help='optional original Credamo CSV path')
    parser.add_argument('--dynamic-raw',type=Path,help='optional original subjects.csv path')
    parser.add_argument('--require-raw',action='store_true',help='fail unless both originals are locally provided and verified')
    parser.add_argument('--out',type=Path,default=HERE/'R035_RESULT.json')
    args=parser.parse_args()
    value=run(args.credamo_raw,args.dynamic_raw,args.require_raw)
    args.out.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
    print('R035_OK',json.dumps({'mode':value['source_validation']['mode'],
         'city_metrics':value['heldout_city']['metrics'],
         'period_metrics':value['heldout_later_rounds']['metrics']},ensure_ascii=False))

if __name__=='__main__':main()
