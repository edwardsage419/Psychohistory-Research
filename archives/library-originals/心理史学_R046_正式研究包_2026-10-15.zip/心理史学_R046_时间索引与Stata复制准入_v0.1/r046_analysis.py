#!/usr/bin/env python3
"""R046. Offline genuine-source session sufficient-statistics OLS, strict optional ingress.

Not Stata xtreg, not statistical causal inference; paper's published random-effects
model cannot be reconstructed from the session cross products alone.
"""
from __future__ import annotations
import argparse, csv, hashlib, json, math, pathlib, sys

RAW_CSV_SHA = '73c02176bc9e060af987149594a85f9f7b591230'
DTA_SHA = '7f846841aa2e23a0699614473dfef1f809a519b3'
SESSION_FILE = pathlib.Path(__file__).with_name('R046_SESSION_SUFFICIENT_STATS.csv')
LABELS = ('const', 'quarter_deviation', 'punishment_unequal', 'punishment_equal')
TARGETS = ('source', 'verified')
TIMINGS = ('current', 'previous')
STRATA = ('B', 'A')


def git_blob_hash(data: bytes) -> str:
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def verify_binary(path: str, sha: str = DTA_SHA) -> dict:
    content = pathlib.Path(path).read_bytes()
    observed = git_blob_hash(content)
    if observed != sha:
        raise ValueError(f'Binary source SHA mismatch: expected {sha}, got {observed}')
    return {'bytes': len(content), 'sha': observed, 'content_fields_uninspected': True}


def read_moments(path: pathlib.Path = SESSION_FILE):
    result = {}
    with path.open(newline='', encoding='utf-8') as f:
        for r in csv.DictReader(f):
            parts = r['case'].split('|')
            if len(parts) != 4:
                raise ValueError('Invalid source case')
            sess, timing, stratum, received = parts
            if sess not in ('5','6','7','8') or timing not in TIMINGS or stratum not in STRATA or received not in TARGETS:
                raise ValueError('Unexpected session, timing, stratum or receipt variant')
            key = (int(sess), timing, stratum, received)
            if key in result:
                raise ValueError('Duplicated sufficient-statistics cell')
            vals = {k:int(v) for k,v in r.items() if k != 'case'}
            if len(vals) != 16 or vals['n'] <= 0 or vals['n'] != vals['x00']:
                raise ValueError('Malformed cross product')
            if sess in ('5','6') and (vals['x03'] != 0 or vals['x13'] != 0 or vals['x23'] != 0 or vals['x33'] != 0 or vals['xy3'] != 0):
                raise ValueError('Unequal subgroup must not have Equal sanction interactions')
            if sess in ('7','8') and (vals['x02'] != 0 or vals['x12'] != 0 or vals['x22'] != 0 or vals['x23'] != 0 or vals['xy2'] != 0):
                raise ValueError('Equal subgroup must not have Unequal sanction interactions')
            result[key] = vals
    if len(result) != 32:
        raise ValueError(f'Expected 32 source cells, found {len(result)}')
    for sess in (5,6):
        for timing in TIMINGS:
            for stratum in STRATA:
                if result[(sess,timing,stratum,'source')] != result[(sess,timing,stratum,'verified')]:
                    raise ValueError('No sanction-ledger anomaly expected in Unequal arms')
    for s in (5,6,7,8):
        for timing in TIMINGS:
            for target in TARGETS:
                d = result[(s,timing,'B',target)]['n'] + result[(s,timing,'A',target)]['n']
                if d < 200 or d > 224:
                    raise ValueError('Unexpected sample size by session')
    return result


def gaussian_solve(matrix, vector):
    n = len(vector)
    a = [[float(x) for x in row]+[float(v)] for row,v in zip(matrix,vector)]
    for c in range(n):
        k = max(range(c,n), key=lambda i:abs(a[i][c]))
        a[c],a[k] = a[k],a[c]
        pivot=a[c][c]
        if abs(pivot) < 1e-12: raise ValueError('Nonidentifiable linear model')
        for j in range(c,n+1): a[c][j]/=pivot
        for i in range(n):
            if i==c: continue
            factor=a[i][c]
            for j in range(c,n+1): a[i][j]-=factor*a[c][j]
    return [a[i][-1] for i in range(n)]


def fit(cells):
    if not cells: raise ValueError('Missing input cells')
    fields=['x00','x01','x02','x03','x11','x12','x13','x22','x23','x33']
    xx=[sum(c[f] for c in cells) for f in fields]
    xy=[sum(c['xy'+str(j)] for c in cells) for j in range(4)]
    A=[[0.0]*4 for _ in range(4)]; pos=0
    for i in range(4):
        for j in range(i,4):
            A[i][j]=A[j][i]=xx[pos];pos+=1
    coef=gaussian_solve(A,xy)
    # stored quarter deviation = (sum of four current extractions)-4*self_extraction;
    # unit dev=quarter_deviation/4, hence beta_for_actual_deviation=4*b[1]
    predictions=dict(zip(('intercept','deviation_ed','lag_sanction_unequal','lag_sanction_equal'),
                         (coef[0],4*coef[1],coef[2],coef[3])))
    return {'n':sum(c['n'] for c in cells),'coefficients':predictions,
            'y_y':sum(c['yy'] for c in cells),
            'residual_sum_squares':sum(c['yy'] for c in cells)-sum(a*b for a,b in zip(coef,xy))}


def analyze(moments=None):
    d = read_moments() if moments is None else moments
    result={}
    for timing in TIMINGS:
        for stratum in STRATA:
            for variant in TARGETS:
                key=f'{timing}_{stratum}_{variant}'
                cells=[d[(sid,timing,stratum,variant)] for sid in (5,6,7,8)]
                fitted=fit(cells)
                try:
                    lo = {str(s):fit([d[(x,timing,stratum,variant)] for x in (5,6,7,8) if x!=s])['coefficients'] for s in (5,6,7,8)}
                except ValueError:
                    lo = None
                result[key]={**fitted, 'leave_one_session_out':lo}
    return result


def session_grid(moments=None):
    d = read_moments() if moments is None else moments
    return {f'{timing}_{stratum}':sum(d[(i,timing,stratum,'source')]['n'] for i in (5,6,7,8))
            for timing in TIMINGS for stratum in STRATA}


def audit_original_csv(path: str) -> dict:
    """Only assert source provenance and shape; full R046 model can later be re-derived.
    Reject all mismatched raw CSV files before estimating or linking records.
    """
    b=pathlib.Path(path).read_bytes()
    sha=git_blob_hash(b)
    if sha!=RAW_CSV_SHA:
        raise ValueError(f'Original CSV hash mismatch: {sha}')
    s=b.decode('utf-8-sig');rows=list(csv.DictReader(s.splitlines()))
    selected=[r for r in rows if r.get('ProfileID','').strip() and r.get('RoundID','').strip()]
    if len(selected)!=2048:raise ValueError('Expected 2048 nonempty original CSV records')
    group={}; persons={}
    for r in selected:
        sid=(r['Homo'],r['FF'],r['Session'],r['GameID'])
        group.setdefault(sid,set()).add((r['ProfileID'],int(r['RoundID'])))
        persons.setdefault(r['ProfileID'],set()).add(int(r['RoundID']))
    if len(group)!=32 or len(persons)!=128 or any(len(v)!=64 for v in group.values()) or any(v!=set(range(1,17)) for v in persons.values()):
        raise ValueError('Incomplete participant-round/group structure')
    return {'source_csv_hash':sha,'nonempty_records':len(selected),'groups':32,'participants':128,
            'full_original_file_bytes_verified':True}


def rebuild_sufficient_stats(rows):
    """Rebuild full cross-products from author-shaped person/round records.

    This pure function also supports miniature synthetic fixtures in software tests.
    Every sanction is matched through its within-round self-slot, never through
    a permanent player position. Only exact integer values enter sufficient stats.
    """
    by_round, people = {}, {}
    for v in rows:
        if not v.get('ProfileID') or not v.get('RoundID'):
            continue
        group = '_'.join(v[k] for k in ('Homo','FF','Session','GameID'))
        t = int(v['RoundID'])
        x = dict(v)
        x.update(group=group, t=t, invest=int(v['Invest']), person=v['ProfileID'],
                 sess=int(v['Session']), h=int(v['Homo']), punish=int(v['FF']))
        by_round.setdefault((group,t),[]).append(x)
        people.setdefault(x['person'],[]).append(x)
    means = {}
    for (group,t),r in by_round.items():
        if len(r) != 4 or len({x['person'] for x in r}) != 4:
            raise ValueError('Four distinct participants required for each group-round')
        means[(group,t)] = sum(x['invest'] for x in r)
        if t <= 1 or r[0]['punish'] == 0: continue
        slots = {}
        for x in r:
            seq=[x[f'Seq{i}'] for i in range(1,5)]
            positions=[i for i,y in enumerate(seq) if y == '.']
            if len(positions)!=1 or positions[0] in slots:
                raise ValueError('Each individual must occupy one unique self-slot in each round')
            slots[positions[0]]=x
        incoming={x['person']:0 for x in r}
        for sender in r:
            amount = 0
            for j in range(4):
                x = sender[f'Seq{j+1}']
                if x == '.': continue
                z=int(x)
                if z < 0 or z % 3 != 0:
                    raise ValueError('Invalid punitive points or fractional sanction cost')
                amount+=z
                incoming[slots[j]['person']]+=z
            if amount!=3*int(sender['Paid']):
                raise ValueError('Sender paid != total sanction points/3')
        for x in r:
            x['verified']=incoming[x['person']]
            before=float(x['Total'])
            after=float(x['Total2'])
            if abs((before-float(x['Paid'])-x['verified'])-after)>1e-5:
                raise ValueError('Observed payoff fails independently reconstructed sanction ledger')
    products={}
    for subject,ar in people.items():
        ar.sort(key=lambda x:x['t'])
        for i in range(1,len(ar)):
            x,prev=ar[i],ar[i-1]
            if x['punish']!=1 or x['t']<=2:continue
            if x['t']-prev['t']!=1 or x['group']!=prev['group']:
                raise ValueError('Broken participant consecutive-round chain')
            y=x['invest']-prev['invest']
            for timing in TIMINGS:
                drow = x if timing=='current' else prev
                dev=means[(drow['group'],drow['t'])]-4*drow['invest']
                sign = 'B' if dev>0 else 'A' if dev<0 else None
                if sign is None: continue
                for variant in TARGETS:
                    pv=int(prev['Received']) if variant=='source' else prev['verified']
                    phi=[1,dev,pv if x['h']==0 else 0,pv if x['h']==1 else 0]
                    k=(x['sess'],timing,sign,variant)
                    cell=products.get(k) or {'n':0,**{f'x{i}{j}':0 for i in range(4) for j in range(i,4)},**{f'xy{i}':0 for i in range(4)},'yy':0}
                    cell['n']+=1;cell['yy']+=y*y
                    for a in range(4):
                        cell[f'xy{a}']+=phi[a]*y
                        for b in range(a,4):cell[f'x{a}{b}']+=phi[a]*phi[b]
                    products[k]=cell
    return products


def verify_and_rebuild_original_csv(path):
    identity=audit_original_csv(path)
    content=pathlib.Path(path).read_bytes().decode('utf-8-sig')
    rows=list(csv.DictReader(content.splitlines()))
    observed=rebuild_sufficient_stats(rows)
    expected=read_moments()
    if observed != expected:
        keys=set(observed)|set(expected)
        diff=[repr(k) for k in keys if observed.get(k)!=expected.get(k)]
        raise ValueError('Original CSV and archived sufficient stats diverge: '+', '.join(diff[:6]))
    return {**identity,'all_32_source_sufficient_cells_equal':True,
            'sanction_target_payoff_checks_passed':True}

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--raw-csv',help='Optional author CSV for Git SHA and shape verification')
    p.add_argument('--author-dta',help='Optional author Stata binary Git blob identity verification only')
    p.add_argument('--output',help='JSON output location')
    args=p.parse_args(argv)
    out={'research_round':'R046','status':'DERIVED_REAL_SOURCE_SUFFICIENT_STATS_OLS',
         'source_csv_blob_sha1':RAW_CSV_SHA,'stata_binary_blob_sha1':DTA_SHA,
         'stata_binary_content_verified':False,'published_RE_replication':False,
         'disclaimer':'Pooled OLS on cross-products is not the published Stata xtreg random-effects model.',
         'sample_counts':session_grid(),'results':analyze(),
         'temporal_group_switches_including_ties':315,'transitions':896,
         'source_field_amount_mismatches':80}
    if args.raw_csv: out['raw_csv_verification']=verify_and_rebuild_original_csv(args.raw_csv)
    if args.author_dta:
        out['stata_binary_verified_blob']=verify_binary(args.author_dta)
        # File identity only. No field extraction; keep replication gate closed.
        out['stata_binary_content_verified']=False
    text=json.dumps(out,ensure_ascii=False,indent=2,sort_keys=True)+'\n'
    if args.output:pathlib.Path(args.output).write_text(text,encoding='utf-8')
    else:sys.stdout.write(text)
    return out

if __name__=='__main__':main()
