import contextlib
import csv
import copy
import importlib.util
import io
import json
import math
import pathlib
import tempfile
import unittest

ROOT=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('r046_analysis',ROOT/'r046_analysis.py')
a=importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)

class GenuineDerivedStats(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.d=a.read_moments();cls.output=a.analyze(cls.d)

    def test_01_original_moments_32(self):self.assertEqual(len(self.d),32)
    def test_02_both_timings(self):self.assertEqual(set(k[1] for k in self.d),{'current','previous'})
    def test_03_both_sanction_versions(self):self.assertEqual(set(k[3] for k in self.d),{'source','verified'})
    def test_04_four_sessions(self):self.assertEqual(set(k[0] for k in self.d),{5,6,7,8})
    def test_05_all_samples_positive(self):self.assertTrue(all(z['n']>0 for z in self.d.values()))
    def test_06_expected_paper_below_n(self):self.assertEqual(self.output['current_B_source']['n'],451)
    def test_07_expected_paper_above_n(self):self.assertEqual(self.output['current_A_source']['n'],414)
    def test_08_previous_below_n(self):self.assertEqual(self.output['previous_B_source']['n'],450)
    def test_09_previous_above_n(self):self.assertEqual(self.output['previous_A_source']['n'],417)
    def test_10_both_original_field_groups_equal(self):
        for s in (5,6):
            for time in a.TIMINGS:
                for stratum in a.STRATA:
                    self.assertEqual(self.d[(s,time,stratum,'source')],self.d[(s,time,stratum,'verified')])
    def test_11_reconstruction_published_current_lower_beta(self):
        self.assertAlmostEqual(self.output['current_B_source']['coefficients']['deviation_ed'],-.7815277895799978,10)
    def test_12_reconstruction_published_current_upper_beta(self):
        self.assertAlmostEqual(self.output['current_A_source']['coefficients']['deviation_ed'],-.9483632760711553,10)
    def test_13_reconstruction_prior_lower_beta(self):
        self.assertAlmostEqual(self.output['previous_B_source']['coefficients']['deviation_ed'],.9532906303814601,10)
    def test_14_reconstruction_prior_upper_beta(self):
        self.assertAlmostEqual(self.output['previous_A_source']['coefficients']['deviation_ed'],.47839088520075324,10)
    def test_15_source_current_sanction_unequal(self):
        self.assertAlmostEqual(self.output['current_B_source']['coefficients']['lag_sanction_unequal'],-.12244509313773339,10)
    def test_16_source_current_sanction_equal(self):
        self.assertAlmostEqual(self.output['current_B_source']['coefficients']['lag_sanction_equal'],-.06321710183537477,10)
    def test_17_verified_changes_equal_upper_slope(self):
        self.assertAlmostEqual(self.output['current_A_verified']['coefficients']['lag_sanction_equal'],-.06104909359077931,10)
    def test_18_rss_positive(self):
        self.assertTrue(all(x['residual_sum_squares']>0 for x in self.output.values()))
    def test_19_session_loo_count(self):
        self.assertTrue(all(x['leave_one_session_out'] is not None and len(x['leave_one_session_out'])==4 for x in self.output.values()))
    def test_20_missing_cases_rejected(self):
        z=dict(self.d);z.pop(next(iter(z)))
        with self.assertRaises(KeyError):a.analyze(z)
    def test_21_degenerate_fit_rejected(self):
        dummy={'n':1,'x00':1,**{f'x{i}{j}':0 for i in range(4) for j in range(i,4) if not(i==j==0)},**{f'xy{j}':0 for j in range(4)},'yy':0}
        with self.assertRaises(ValueError):a.fit([dummy])
    def test_22_absolute_sha_git(self):
        self.assertEqual(a.git_blob_hash(b'hello\n'),'ce013625030ba8dba906f756967f9e9ca394464a')
    def test_23_binary_blob_identity_only(self):
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d)/'not-author.dta';p.write_bytes(b'fake binary data')
            with self.assertRaises(ValueError):a.verify_binary(str(p))
            status=a.verify_binary(str(p),a.git_blob_hash(p.read_bytes()))
            self.assertTrue(status['content_fields_uninspected'])
    def test_24_raw_csv_requires_blob_identity(self):
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d)/'source.csv';p.write_text('ProfileID,RoundID\n1,1\n',encoding='utf-8')
            with self.assertRaisesRegex(ValueError,'hash mismatch'):a.audit_original_csv(str(p))
    def test_25_duplicate_source_cell_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d)/'bad.csv';p.write_text(a.SESSION_FILE.read_text(encoding='utf-8')+a.SESSION_FILE.read_text(encoding='utf-8').splitlines()[1]+'\n',encoding='utf-8')
            with self.assertRaisesRegex(ValueError,'Duplicated'):a.read_moments(p)
    def test_26_missing_source_cell_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d)/'bad.csv';p.write_text('\n'.join(a.SESSION_FILE.read_text(encoding='utf-8').splitlines()[:-1])+'\n',encoding='utf-8')
            with self.assertRaisesRegex(ValueError,'Expected 32'):a.read_moments(p)
    def test_27_group_misclassification_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d)/'bad.csv';txt=a.SESSION_FILE.read_text(encoding='utf-8').replace('5|current|A|source,117,117,-2447,645,0,','5|current|A|source,117,117,-2447,645,123,',1);p.write_text(txt,encoding='utf-8')
            with self.assertRaisesRegex(ValueError,'Unequal subgroup'):a.read_moments(p)
    def test_28_bad_header_or_case_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d)/'bad.csv';txt=a.SESSION_FILE.read_text(encoding='utf-8').replace('5|current|A|source','5|false|A|source',1);p.write_text(txt,encoding='utf-8')
            with self.assertRaisesRegex(ValueError,'Unexpected session'):a.read_moments(p)
    def test_29_mutating_original_source_crossproduct_not_allowed(self):
        z=copy.deepcopy(self.d);z[(5,'current','A','verified')]['xy0']+=1
        with self.assertRaisesRegex(ValueError,'No sanction-ledger anomaly'):a.read_moments(self.write_grid(z))
    def write_grid(self, grid):
        tmp=tempfile.NamedTemporaryFile(mode='w',suffix='.csv',delete=False,encoding='utf-8')
        cols=a.SESSION_FILE.read_text(encoding='utf-8').splitlines()[0].split(',')
        writer=csv.DictWriter(tmp,fieldnames=cols);writer.writeheader()
        for (sess,timing,sign,var),vals in grid.items():writer.writerow(dict(case=f'{sess}|{timing}|{sign}|{var}',**vals))
        tmp.close();self.addCleanup(pathlib.Path(tmp.name).unlink);return pathlib.Path(tmp.name)
    def test_30_results_export_and_flags(self):
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d)/'result.json';v=a.main(['--output',str(p)]);z=json.loads(p.read_text(encoding='utf-8'))
            self.assertEqual(v['sample_counts']['current_B'],451);self.assertFalse(z['published_RE_replication']);self.assertFalse(z['stata_binary_content_verified'])
    def test_31_actual_row_count_r045_source_supported(self):
        self.assertEqual(sum(v['n'] for k,v in self.d.items() if k[1:] == ('current','B','source')),451)
    def test_32_stratum_excludes_exact_mean(self):
        self.assertEqual(896-self.output['current_B_source']['n']-self.output['current_A_source']['n'],31)
        self.assertEqual(896-self.output['previous_B_source']['n']-self.output['previous_A_source']['n'],29)
    def test_33_local_both_versions_reproduce_same_unequal_input(self):
        for timing in a.TIMINGS:
            for state in a.STRATA:
                self.assertEqual(sum(self.d[(s,timing,state,'source')]['xy2'] for s in (5,6)),sum(self.d[(s,timing,state,'verified')]['xy2'] for s in (5,6)))
    def test_34_declared_model_params_stable(self):
        self.assertEqual(tuple(a.LABELS),('const','quarter_deviation','punishment_unequal','punishment_equal'))
    def test_35_fit_requires_any_cell(self):
        with self.assertRaisesRegex(ValueError,'Missing input'):a.fit([])


class SyntheticOriginalCSVReconstruction(unittest.TestCase):
    @staticmethod
    def fixture():
        rows=[]
        for round_ in range(1,5):
            for pid in range(4):
                seq=['0']*4
                if round_>1:
                    slots={j:(j+round_-2)%4 for j in range(4)}
                    own=slots[pid]
                    seq[own]='.'
                    seq[slots[(pid+1)%4]]='3'
                else:seq=['.']*4
                row={'ProfileID':str(pid+1),'Homo':'1','FF':'1','Session':'7',
                     'GameID':'1','RoundID':str(round_),
                     'Invest':str([15,20,30,40][pid]+round_*(pid%2)),
                     'Paid':'1' if round_>1 else '.',
                     'Received':'3' if round_>1 else '.',
                     'Total':'100','Total2':'96' if round_>1 else '.',
                     'Seq1':seq[0],'Seq2':seq[1],'Seq3':seq[2],'Seq4':seq[3]}
                rows.append(row)
        return rows

    def test_36_synthetic_round_rotating_slots_rebuilds(self):
        v=a.rebuild_sufficient_stats(self.fixture())
        self.assertTrue(v)
        self.assertEqual(sum(z['n'] for k,z in v.items() if k[1:] == ('current','B','source')) + sum(z['n'] for k,z in v.items() if k[1:] == ('current','A','source')),8)

    def test_37_synthetic_ledger_mismatch_rejected(self):
        v=self.fixture();v[6]['Paid']='2'
        with self.assertRaisesRegex(ValueError,'Sender paid'):a.rebuild_sufficient_stats(v)

    def test_38_synthetic_false_payoff_rejected(self):
        v=self.fixture();v[6]['Total2']='90'
        with self.assertRaisesRegex(ValueError,'payoff'):a.rebuild_sufficient_stats(v)

    def test_39_synthetic_bad_self_slots_rejected(self):
        v=self.fixture();v[6]['Seq2']='.'
        with self.assertRaisesRegex(ValueError,'self-slot'):a.rebuild_sufficient_stats(v)

    def test_40_synthetic_bad_sanction_increment_rejected(self):
        v=self.fixture();v[6][next(k for k in ['Seq1','Seq2','Seq3','Seq4'] if v[6][k]=='3')]='2'
        with self.assertRaisesRegex(ValueError,'punitive points'):a.rebuild_sufficient_stats(v)

    def test_41_synthetic_doubled_participant_rejected(self):
        v=self.fixture();v[6]['ProfileID']='1'
        with self.assertRaisesRegex(ValueError,'distinct participants'):a.rebuild_sufficient_stats(v)

    def test_42_synthetic_gap_in_rounds_rejected(self):
        v=self.fixture()
        for row in v:
            if row['RoundID']=='3':row['RoundID']='5'
        with self.assertRaisesRegex(ValueError,'consecutive-round'):a.rebuild_sufficient_stats(v)

    def test_43_synthetic_reported_field_not_substituted(self):
        v=self.fixture();v[6]['Received']='30'
        out=a.rebuild_sufficient_stats(v)
        self.assertNotEqual(out[(7,'current','A','source')]['x33'],out[(7,'current','A','verified')]['x33'])

    def test_44_synthetic_no_punishment_gives_no_punishment_moments(self):
        v=self.fixture()
        for row in v:row['FF']='0';row['Paid']='.';row['Received']='.';row.update({f'Seq{j}':'.' for j in range(1,5)})
        self.assertEqual(a.rebuild_sufficient_stats(v),{})

    def test_45_frozen_data_gate_declines_fake_dta(self):
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d)/'dummy.dta';p.write_bytes(b'not the original stata file')
            with self.assertRaises(ValueError):a.main(['--author-dta',str(p)])

if __name__=='__main__':unittest.main()
