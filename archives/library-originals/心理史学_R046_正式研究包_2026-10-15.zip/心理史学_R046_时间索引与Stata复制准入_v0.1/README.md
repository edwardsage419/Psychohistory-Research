# 心理史学 R046｜时间索引与 Stata 复制准入

执行时间：2026-10-15。

核心结果：原作者论文Table 4的N=451/414与作者分析代码的**当期偏离量**完全吻合。改用决定发生之前的前期偏离量，样本N=450/417，896条行为转移中315条改变正负/零状态（包含零），独立OLS得到不同方向和幅度的关联。此非`xtreg`随机效应复现，也不确认社会惩罚因果效应。

## 文件

- `R046_EVIDENCE_AUDIT.md`：完整方法、结果及界限。
- `R046_SOURCE_LEDGER.json`：网页、CSV、脚本、Git blob指纹与阻断记录。
- `R046_SESSION_SUFFICIENT_STATS.csv`：来自公开原始作者CSV的32个场次级真实整数统计单元，变量顺序`[1,4*偏离均值,滞后罚款×不均等,滞后罚款×均等]`；`xx`上三角、`xy`和`yy`均精确存储。
- `r046_analysis.py`：纯Python 3标准库离线OLS、逐场次剔除与源文件hash/账本准入验证。
- `R046_RESULTS.json`：离线真实派生样本统计结果。
- `tests/test_r046.py`：45项合成/真实派生统计数据的软件测试。
- `R046_TEST_LOG.txt`：实际测试完整输出。
- `R047_RESEARCH_GATE.md`：下一轮源和独立机制准入要求。
- `MASTER_CONTROLLER_v3.7.md`：累计主控台备份，严格包含v3.6的全部原文字节。
- `MANIFEST.json`, `CHECKSUMS.sha256`：正式研究包内来源完整性和校验记录。

## 运行

```bash
python r046_analysis.py --output my_results.json
python -m unittest discover -s tests -v
```

作者原CSV与二进制Stata文件若后续可访问：

```bash
python r046_analysis.py --raw-csv /path/to/data.csv --output audited_results.json
python r046_analysis.py --author-dta /path/to/main_data_labels.dta --output metadata_only.json
```

`--raw-csv`在Git blob匹配后会重建惩罚事件、核对收益账本，并将32单元充分统计逐字段与归档值比较。`--author-dta`**只验证文件字节Git身份，不解释Stata字段、不运行作者`xtreg`**；绝不输出原论文回归已经复现的误导性声明。

关键复现等级：连接器端完整读作者CSV＋本地真值派生交叉积独立计算；**本地无作者原CSV字节和作者Stata二进制字节**。PESEN v0.1未改变。
