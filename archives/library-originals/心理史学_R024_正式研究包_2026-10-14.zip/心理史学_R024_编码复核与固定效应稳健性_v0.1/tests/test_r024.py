import io
import sys
import unittest
from pathlib import Path
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import r024_analysis as r

class R024Test(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.encoded=(ROOT/'DERIVED_NUMERIC_ROWS.txt').read_text()
        cls.df=r.decode(cls.encoded)
    def test_actual_source_derived_record_count(self):
        self.assertEqual(len(self.df),439)
    def test_actual_pseudonymous_people(self):
        self.assertEqual(self.df.participant.nunique(),58)
    def test_actual_items(self):
        self.assertEqual(self.df.item.nunique(),130)
    def test_actual_subreddit_topic_cells(self):
        self.assertEqual(self.df.groupby(['subreddit','topic']).ngroups,90)
    def test_source_numeric_checksum_frozen(self):
        z=''.join(self.encoded.split());acc=2166136261
        for c in z:
            acc^=ord(c);acc=(acc*16777619)&0xffffffff
        self.assertEqual(f'{acc:08x}','d6606b70')
    def test_coding_439_consistent(self):
        self.assertEqual(r.check(self.df)['incongruency_coding_mismatch'],0)
    def test_coding_detects_flip(self):
        d=self.df.copy();d.loc[0,'incongruency']=1-d.loc[0,'incongruency']
        with self.assertRaises(ValueError):r.check(d)
    def test_101_incongruence(self):
        self.assertEqual(int((self.df.incongruency==1).sum()),104)
    def test_known_raw_mean(self):
        a=self.df[self.df.incongruency==1].comment_likelihood.mean();b=self.df[self.df.incongruency==0].comment_likelihood.mean()
        self.assertAlmostEqual(a,3.0096153846153846,9)
        self.assertAlmostEqual(b,4.146268656716418,9)
    def test_paired_replicates_r023(self):
        z=r.participant_contrasts(self.df)
        self.assertEqual(len(z),42)
        self.assertAlmostEqual(float(np.mean(z)),-0.9040154950869235,8)
    def test_actual_viewpoint_overlap(self):
        z=r.item_contrasts(self.df)
        self.assertEqual(len(z),42)
        self.assertEqual(sum(v['n_incongruent']+v['n_congruent'] for v in z),244)
    def test_naive_ols_actual(self):
        f=r.fe(self.df,'comment_likelihood ~ incongruency')
        self.assertAlmostEqual(f['beta'],-1.1366532721010314,8)
    def test_twfe_ols_actual(self):
        f=r.fe(self.df,'comment_likelihood ~ incongruency + agreement + C(participant) + C(item)')
        self.assertAlmostEqual(f['beta'],-1.0894867177388994,7)
        self.assertEqual(f['rank'],189)
    def test_bad_frame(self):
        with self.assertRaises(ValueError):r.decode('AAA')
    def test_invalid_code(self):
        with self.assertRaises(ValueError):r.decode('!!!!!!!!!!')
    def test_invalid_scale(self):
        with self.assertRaises(ValueError):r.decode('AAAAAAAAAA')
    def test_same_item_one_direction(self):
        d=pd.DataFrame([dict(participant=0,item=0,subreddit=0,topic=1,agreement=7,community_agreement=6,incongruency=0,comment_likelihood=5,upvote_likelihood=6),
                        dict(participant=1,item=0,subreddit=0,topic=1,agreement=7,community_agreement=3,incongruency=1,comment_likelihood=2,upvote_likelihood=6)])
        self.assertEqual(len(r.item_contrasts(d)),1)
        self.assertEqual(r.item_contrasts(d)[0]['difference'],-3)
    def test_item_mismatch_guard(self):
        d=self.df.copy(); j=int(d.loc[0,'item']); d.loc[0,'subreddit']=20
        self.assertTrue(d.groupby('item').subreddit.nunique().max()>1)
        with self.assertRaises(ValueError):r.check(d)
if __name__=='__main__':unittest.main()

class EncodingTests(unittest.TestCase):
    def test_git_blob_known(self):
        from rebuild_from_author_csv import git_blob
        import hashlib
        self.assertEqual(git_blob(b'test'),hashlib.sha1(b'blob 4\0test').hexdigest())
    def test_encode_roundtrip_subset(self):
        from rebuild_from_author_csv import encode
        sample='Participant,Subreddit,Topic,Viewpoint,Agreement,Sub_Agree,Incongruency,Comment_Likelihood,Upvote_Likelihood\nA,politics,1,10,7,2,1,2,5\nB,politics,1,10,7,5,0,6,7\n'
        enc=encode(sample)
        d=r.decode(enc)
        self.assertEqual(len(d),2)
        self.assertEqual(d.item.nunique(),1)
        self.assertEqual(d.incongruency.tolist(),[1,0])
    def test_frozen_encoded_repeat(self):
        z=(ROOT/'DERIVED_NUMERIC_ROWS.txt').read_text()
        self.assertEqual(len(''.join(z.split())),4390)
