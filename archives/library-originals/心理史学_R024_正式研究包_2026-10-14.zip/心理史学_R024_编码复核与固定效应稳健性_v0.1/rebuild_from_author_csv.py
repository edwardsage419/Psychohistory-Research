#!/usr/bin/env python3
"""Rebuild the R024 pseudonymous derivative from original author data.csv.

Requires the exact original Git blob. Does not download automatically or persist
original participant strings. Derivative contains participant integer codes and
no viewpoint text. The mapping to author IDs is NOT exported.
"""
import argparse
import csv
import hashlib
import io
from pathlib import Path

EXPECTED='11c4ccb53944a79b1f1def49d358e04c944e42f1'
ABC='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_'

def git_blob(data):
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()

def encode(text):
    rows=list(csv.DictReader(io.StringIO(text)))
    persons=sorted(set(z['Participant'] for z in rows))
    items=sorted(set(z['Subreddit']+'|'+z['Topic']+'|'+z['Viewpoint'] for z in rows))
    subs=sorted(set(z['Subreddit'] for z in rows))
    if len(persons)>64 or len(items)>=4096 or len(subs)>64:
        raise ValueError('Unsupported category count')
    pi={v:i for i,v in enumerate(persons)}; it={v:i for i,v in enumerate(items)}; sb={v:i for i,v in enumerate(subs)}
    out=[]
    for r in rows:
        item=it[r['Subreddit']+'|'+r['Topic']+'|'+r['Viewpoint']]
        vals=[pi[r['Participant']],item//64,item%64,sb[r['Subreddit']],int(r['Topic']),int(r['Agreement']),int(r['Sub_Agree']),int(r['Incongruency']),int(r['Comment_Likelihood']),int(r['Upvote_Likelihood'])]
        if any(v<0 or v>=64 for v in vals):raise ValueError('Out-of-range code')
        out.append(''.join(ABC[v] for v in vals))
    return ''.join(out)

def main():
    p=argparse.ArgumentParser();p.add_argument('author_csv',type=Path);p.add_argument('--output',type=Path,default=Path(__file__).with_name('rebuilt_payload.txt'));a=p.parse_args()
    raw=a.author_csv.read_bytes();sha=git_blob(raw)
    if sha!=EXPECTED:raise SystemExit(f'Git blob mismatch: {sha}; expected {EXPECTED}')
    s=encode(raw.decode('utf-8-sig'))
    a.output.write_text(s+'\n',encoding='ascii')
    print(f'Verified original {sha}; wrote {len(s)//10} rows to {a.output}')
if __name__=='__main__':main()
