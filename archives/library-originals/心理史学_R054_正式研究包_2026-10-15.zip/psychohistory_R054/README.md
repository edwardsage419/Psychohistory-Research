# 心理史学 R054 正式研究包

本包含R054研究报告、来源计算指标、Python重算程序、20项本地测试、上轮R053已固定指标和下一轮R055关口。数据访问等级为“GitHub连接器侧真实CSV分析，本地仅软件构造测试”，**原始CSV源文件未打包**，不冒充已取得原作者字节。

运行：

```
python -m pip install numpy
python -m unittest -v test_r054.py
python r054_history_bench.py --csv /path/to/author/data.csv --out R054_LOCAL_REPLAY.json --r053-json R053_PREVIOUS_RESULTS.json
```

原始来源：<https://github.com/lrdegeest/InequalityCPR/blob/master/data/data.csv>；哈希须严格匹配 `73c02176bc9e060af987149594a85f9f7b591230`。所有结果后验探索，PESEN v0.1冻结。
