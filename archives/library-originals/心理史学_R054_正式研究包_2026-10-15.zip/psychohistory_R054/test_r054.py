import copy
import io
import json
import sys
import unittest
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parent))
from r054_history_bench import history_forecast, score_prediction_rows, compare_to_r053, HISTORY_MODES
from r053_holdout import parse_raw_csv


def fixtures(periods=5, sessions=(1,2)):
    out=[]
    for session in sessions:
        for sid in range(1,5):
            ident=1000*session+sid
            for t in range(1,periods+1):
                out.append({'Session':session,'GameID':1,'RoundID':t,
                    'ProfileID':ident,'Invest':float(sid+t),'Token':50.,
                    'FF':int(session==2), 'Homo':int(session==2)})
    return out


class HistoryBenchmarkTests(unittest.TestCase):
    def test_modes_unique(self): self.assertEqual(len(HISTORY_MODES),len(set(HISTORY_MODES)))
    def test_initial_prediction_round_three(self):
        ps=history_forecast(fixtures(),strict=False)
        x=next(z for z in ps if z['subject']==1001 and z['round']==3)
        self.assertEqual(x['pred']['meanAll'],3.) # Round2 invest = 1+2
        self.assertEqual(x['pred']['mean3'],3.)
        self.assertEqual(x['pred']['priorGroupMean'],4.5) # Round2 values 3,4,5,6
    def test_practice_excluded(self):
        rows=fixtures()
        for z in rows:
            if z['RoundID']==1: z['Invest']=0.
        ps=history_forecast(rows,strict=False)
        x=next(z for z in ps if z['subject']==1001 and z['round']==3)
        self.assertEqual(x['pred']['meanAll'],3.)
    def test_no_future_leakage(self):
        a=fixtures()
        baseline=history_forecast(a,strict=False)
        b=copy.deepcopy(a)
        for x in b:
            if x['RoundID']==5: x['Invest']=40.
        altered=history_forecast(b,strict=False)
        def early(p): return [(z['subject'],z['round'],z['pred']) for z in p if z['round']<=5]
        self.assertEqual(early(baseline),early(altered))
    def test_current_outcome_change_not_in_prediction(self):
        a=fixtures(); b=copy.deepcopy(a)
        for x in b:
            if x['RoundID']==3 and x['ProfileID']==1001: x['Invest']=32.
        aa=history_forecast(a,strict=False);bb=history_forecast(b,strict=False)
        x=next(z for z in aa if z['subject']==1001 and z['round']==3)
        y=next(z for z in bb if z['subject']==1001 and z['round']==3)
        self.assertEqual(x['pred'],y['pred']);self.assertNotEqual(x['y'],y['y'])
    def test_each_fold_count(self):
        res=score_prediction_rows(history_forecast(fixtures(),strict=False))
        self.assertEqual(res['n'],24)
        self.assertEqual([x['n'] for x in res['folds']],[12,12])
    def test_zero_when_prediction_exact(self):
        v=history_forecast(fixtures(),strict=False)
        for r in v: r['y']=r['pred']['persistence']
        res=score_prediction_rows(v)
        self.assertEqual(res['overall']['persistence']['mse'],0.)
    def test_duplicate_subject_period_fails(self):
        data=fixtures();data.append(copy.deepcopy(data[-1]))
        with self.assertRaises(ValueError): history_forecast(data,strict=False)
    def test_missing_invest_fails(self):
        data=fixtures();data[3]['Invest']=None
        with self.assertRaises(ValueError): history_forecast(data,strict=False)
    def test_negative_invest_fails(self):
        data=fixtures();data[-1]['Invest']=-1.
        with self.assertRaises(ValueError): history_forecast(data,strict=False)
    def test_out_of_cap_fails(self):
        data=fixtures();data[-1]['Invest']=60.
        with self.assertRaises(ValueError): history_forecast(data,strict=False)
    def test_cross_group_change_fails(self):
        data=fixtures();data[-1]['GameID']=2
        with self.assertRaises(ValueError): history_forecast(data,strict=False)
    def test_empty_history_and_missing_round(self):
        data=fixtures();data=[x for x in data if not (x['ProfileID']==1001 and x['RoundID']==3)]
        with self.assertRaises(ValueError): history_forecast(data,strict=False)
    def test_change_endowment_fails(self):
        data=fixtures();data[-1]['Token']=40.
        with self.assertRaises(ValueError): history_forecast(data,strict=False)
    def test_source_hash_gate(self):
        with self.assertRaises(ValueError):parse_raw_csv(b'example,not,original\n',source_check=True)
    def test_comparison_eight_folds(self):
        fakehist={'folds':[{'session':i,'models':{'meanAll':{'mse':11.}}} for i in range(1,9)]}
        faker={'heldout_folds_rounded_4_decimals':[{'session':i,'M1':10.} for i in range(1,9)]}
        result=compare_to_r053(fakehist,faker)
        self.assertEqual(result['mean_difference'],-1.)
        self.assertEqual(result['m1_better_sessions'],8)
        self.assertAlmostEqual(result['session_bootstrap_95'][0],-1.)
    def test_comparison_wrong_folds(self):
        with self.assertRaises(ValueError): compare_to_r053({'folds':[]},{'heldout_folds_rounded_4_decimals':[]})
    def test_comparison_undefined_session(self):
        fakehist={'folds':[{'session':i,'models':{'meanAll':{'mse':11.}}} for i in range(1,9)]}
        faker={'heldout_folds_rounded_4_decimals':[{'session':i,'M1':10.} for i in range(2,10)]}
        with self.assertRaises(KeyError):compare_to_r053(fakehist,faker)
    def test_ewma_manual(self):
        r=history_forecast(fixtures(),strict=False)
        x=next(z for z in r if z['subject']==1001 and z['round']==5)
        # observed formal history round2,3,4 = [3,4,5] -> 4.25
        self.assertEqual(x['pred']['ewmaHalf'],4.25)
    def test_mean_all_manual(self):
        r=history_forecast(fixtures(),strict=False)
        x=next(z for z in r if z['subject']==1001 and z['round']==5)
        self.assertEqual(x['pred']['meanAll'],4.)

if __name__=='__main__':unittest.main()
