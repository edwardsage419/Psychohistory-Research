# R050 心理史学研究包

本研究包提供来源审计、程序质量升级和下一轮验证准入，不包含真正的 Abatayo/Lynham `alldata.dta`，不包含任何真人微观实验数据。

验证依赖：Python 3.10+、pandas、numpy。

```bash
cd psychohistory_R050
python -m unittest -v test_r050
python r050_integrity.py /path/to/author/alldata.dta --output /path/to/r050_source_check.json
```

后续运行R049冻结模型的原始文件入口（取得并独立认证合法原始数据后）：

```bash
python r049_replay_frozen.py --dta /path/to/author/alldata.dta --output /path/to/r051_predictions.json
```

以上两条来源运行命令均要求使用授权公开的真实作者DTA，不能使用测试样本替代并宣称实证复现。字段编码不符时拒绝，不应绕过校验。

文件：
- `R050_REPORT.md`：研究结论与来源状态
- `r050_integrity.py`：新来源及时间一致性审计
- `test_r050.py`：16项构造数据反证测试
- `r049_replay_frozen.py`：上一轮固定模型代码副本
- `NEW_TEST_OUTPUT.txt`：R050测试结果
- `INHERITED_TEST_OUTPUT.txt`：R049继承测试记录
- `R051_RESEARCH_GATE.md`：下一轮研究门槛
- `PROJECT_STATE_R050.md`：快照
- `SOURCE_LEDGER.json`：公开来源身份及访问状态
- `SHA256SUMS.txt`：研究包内文件指纹
