#!/usr/bin/env python3
"""R050 strict group and prechoice-exposure audit for Abatayo & Lynham data.

Only validates records loaded from a user-supplied DTA. This module does not
fetch sources and cannot authenticate a dataset merely from its shape.

Usage:
    python r050_integrity.py /path/to/alldata.dta --output integrity.json
Requires: pandas, numpy (pandas.read_stata).
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import pandas as pd

# A game state must distinguish concurrent ten-person groups in a session.
GROUP = ['sesid', 'Match', 'Block', 'Round', 'Group']
REQUIRED = GROUP + [
    'subject_id', 'strategyA', 'strategyB', 'strategyB_old',
    'countA', 'countB', 'countmessage', 'countpunish',
    'message', 'punish', 'message_old', 'punish_old',
    'badmess', 'badpun', 'social', 'financial',
]

class IntegrityError(ValueError):
    pass

def check(ok: bool, message: str) -> None:
    if not ok:
        raise IntegrityError(message)

def check_integrity(df: pd.DataFrame, strict: bool = True) -> dict:
    check(set(REQUIRED).issubset(df.columns), 'Missing fields: ' + str(sorted(set(REQUIRED)-set(df.columns))))
    w = df[REQUIRED].copy()
    for c in REQUIRED:
        w[c] = pd.to_numeric(w[c], errors='coerce')
    for c in GROUP+['subject_id', 'strategyA', 'strategyB', 'countA', 'countB', 'countmessage', 'countpunish']:
        check(w[c].notna().all(), f'Invalid or missing {c}')
    check((w['strategyA']+w['strategyB'] == 1).all(), 'Strategy not complementary')
    check(w['social'].isin([0,1]).all() and w['financial'].isin([0,1]).all(), 'Invalid arm')
    check((w['social']+w['financial'] == 1).all(), 'Ambiguous arm')
    check(~w.duplicated(['subject_id','Match','Block','Round']).any(), 'Duplicate subject transition')
    check((w['Round'].between(1,9)).all(), 'Invalid block round')
    # Check action eligibility first so a corrupted sender cannot be hidden in a
    # group aggregate mismatch or mislabeled as a mere count error.
    check(w['message'].isin([0,1]).all() and w['punish'].isin([0,1]).all(), 'Invalid sanction decision')
    check((w.loc[w.message==1, 'strategyA']==1).all(), 'Ineligible message sender')
    check((w.loc[w.punish==1, 'strategyA']==1).all(), 'Ineligible fine sender')
    check((w.loc[w.message==1, 'social']==1).all(), 'Message in financial arm')
    check((w.loc[w.punish==1, 'financial']==1).all(), 'Fine in social arm')
    states = w.groupby(GROUP, sort=False, dropna=False)
    check((states.size()==10).all(), 'A group round does not contain ten participants')
    grp_counts=states.agg(
        observedA=('strategyA','sum'), observedB=('strategyB','sum'),
        observedMessages=('message','sum'), observedFines=('punish','sum'),
        nCountA=('countA','nunique'), nCountB=('countB','nunique'),
        nMessages=('countmessage','nunique'), nFines=('countpunish','nunique'),
        statedA=('countA','first'), statedB=('countB','first'),
        statedMessages=('countmessage','first'), statedFines=('countpunish','first'),
    )
    for p in ('A', 'B', 'Messages', 'Fines'):
        check((grp_counts['n'+('Count'+p if p in ('A','B') else p)]==1).all(), f'Within-group {p} counts conflict')
        check((grp_counts['observed'+p] == grp_counts['stated'+p]).all(), f'Published {p} counts do not match individual decisions')
    # Join only within the exact subject, match and block. No new-match spillover.
    key=['subject_id','Match','Block','Round']
    prior=w[key+['strategyB','message','punish']].copy()
    prior['Round'] += 1
    prior=prior.rename(columns={'strategyB':'recomputed_strategyB_old',
                                'message':'recomputed_message_old',
                                'punish':'recomputed_punish_old'})
    check(~prior.duplicated(key).any(), 'Nonunique source previous round')
    z=w.merge(prior,on=key,how='left',validate='one_to_one',sort=False)
    first=z['Round']==1
    check((~z.loc[~first,'recomputed_strategyB_old'].isna()).all(), 'Missing valid previous action')
    for col in ['strategyB','message','punish']:
        old=col+'_old'
        v=z[old]
        check(v.loc[first].isna().all(), f'{old} leaks across new block')
        check(v.loc[~first].notna().all(), f'{old} incomplete inside block')
        check((v.loc[~first].to_numpy()==z.loc[~first,'recomputed_'+old].to_numpy()).all(),f'{old} mismatches observed prior decision')

    # Prior group counts are observable only after the previous round.
    counts = w[GROUP+['countmessage','countpunish']].drop_duplicates()
    check(not counts.duplicated(GROUP).any(),'Nonunique group punishment counts')
    counts['Round'] += 1
    counts=counts.rename(columns={'countmessage':'previous_group_messages',
                                  'countpunish':'previous_group_fines'})
    z=z.merge(counts,on=GROUP,how='left',validate='many_to_one',sort=False)
    check(z.loc[~first,'previous_group_messages'].notna().all(), 'Missing previous group sanction count')
    for actual,arm,prior_count in [('badmess','social','previous_group_messages'),('badpun','financial','previous_group_fines')]:
        check(z.loc[~first,actual].isin([0,1]).all(),f'Invalid {actual} exposure field')
        # Documented mechanism: any sanctioner penalizes each high extractor.
        should=(z['strategyB_old'].eq(1)&z[arm].eq(1)&z[prior_count].gt(0)).astype(int)
        check((z.loc[~first,actual].to_numpy()==should.loc[~first].to_numpy()).all(),
              f'{actual} conflicts with previous-group decisions; investigate source encoding')
    if strict:
        check(len(w)==3060 and w.subject_id.nunique()==160 and w.sesid.nunique()==8,
              'Published sample scope mismatch')
        check(int(first.sum())==340, 'Published first-round count mismatch')
        check(len(grp_counts)==306, 'Expected 306 ten-person group rounds')
    return {'status':'PASS', 'source_authenticity':'NOT_ESTABLISHED_BY_STRUCTURAL_CHECKS',
            'rows':int(len(w)), 'group_rounds':int(len(grp_counts)),
            'subjects':int(w.subject_id.nunique()),'sessions':int(w.sesid.nunique()),
            'first_round_rows':int(first.sum()),'eligible_lag_rows':int((~first).sum()),
            'group_counts_cross_checked':True,'lag_actions_cross_checked':True,
            'lag_sanctions_cross_checked':True,'published_scope_enforced':strict}

def main() -> None:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('dta',type=Path)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    check(args.dta.is_file(),'Original DTA not supplied')
    result=check_integrity(pd.read_stata(args.dta,convert_categoricals=False))
    result['original_dta_sha256']=hashlib.sha256(args.dta.read_bytes()).hexdigest()
    result['original_dta_bytes']=args.dta.stat().st_size
    result['publisher_sha256_verified']=False
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('Structural audit passed. Publisher identity requires independent verification.')

if __name__ == '__main__':
    main()
