# 心理史学 R050 研究报告

日期：2026-10-15
研究性质：真实公开来源核验、独立实验验证门槛增强及软件反例审计

## 结论及完成等级

**R050 已完成其可执行的来源审计和验证程序增强；尚无 Abatayo–Lynham 原始DTA的本地数值结果。** 不得把本轮代码测试、文献数字或构造样本模型成绩表述为独立实验的真实数据预测成功。

PESEN v0.1继续 FROZEN。独立心理惩罚因果机制保持 UNIDENTIFIED。跨团队预测保持 NOT TESTED ON NEW ORIGINAL BYTES。

## R049继承

R049固定B0总基率、B1上一轮自身行为、B2 B1加上一轮受罚暴露、B3 B2加处理制度。留一场次为测试，平滑常数λ=8。严禁查看留出结果后回改预测超参数。

## R050来源审计

1. 第一优先数据源：Abatayo & Lynham《Resource Booms and Group Punishment in a Coupled Social-Ecological System》原始公开实验，Mendeley DOI `10.17632/c2z95m5gty.1`，2022-12-29，CC BY 4.0。公开元数据称8个场次、160人、3060人次记录、33字段，文件包括Stata DTA、Codebook、ReadMe、5个`.do`。<https://data.mendeley.com/datasets/c2z95m5gty/1>。
2. 独立出版的字段说明为 Abatayo & Lynham (2023), *Data in Brief*, DOI `10.1016/j.dib.2023.109215`，开放全文 <https://pmc.ncbi.nlm.nih.gov/articles/PMC10197006/>。其中确认`badmess`和`badpun`指上一轮因选择高提取而**收到**的社会或经济惩罚；`message`和`punish`指当期**实施**惩罚的行为；`strategyB_old`指个人上一轮高提取。 `countA`, `countB`, `countmessage`, `countpunish`为同轮当前十人组行为数量。接受惩罚为前期暴露，并不是直接测量的羞耻、规范内化或心理恐惧。
3. 结构推导：3060人次 / 每组10人=306组轮；3060与2720个有效滞后行为记录之差340，为每个个体区块首轮数量。如果所有区块正好9轮，3060/9=340个人区块，340/20=17场次完整区块；全部只是**公开描述及假设下的代数检验目标**，不代表已观测到17个真实区块。
4. 原始字节访问：本运行环境 `data.mendeley.com` 与 `api.data.mendeley.com` 的DNS均解析失败，网页版公开目录可读，公开DTA本地字节未取得。`Mendeley DTA=NOT_OBTAINED`、`PUBLISHER_SHA256=UNKNOWN`。不可凭假文件名、公开表格或合成样本替代DTA。
5. 第二候选独立团队：Alsobay, Rand, Watts & Almaatouq (2026), *Science* DOI `10.1126/science.aeb5280`。摘要报告7100人、147618次行为选择、360个条件，惩罚制度在不同设置下与福利变动正负方向均有关联。数据/代码线索 OSF `https://osf.io/2d56w/overview` 本环境网页403，原始字节未取得。此研究只作为 R051 候选外部验证对象，绝未复算或合并其数据。摘要见 https://pubmed.ncbi.nlm.nih.gov/41955365/。

## R050新发现：R049来源准入弱点

R049 `r049_replay.py` 检查每条记录声称 `countA+countB==10`，但不验证这两个报告数字是否等于同一十人组真实 `strategyA` / `strategyB` 的总和。攻击性构造样本可以把同组 `countA` 全部加1、`countB` 全部减1，仍满足旧检查并通过 `source_checks(strict=False)`。这是本轮在软件测试中直接重复的可执行反例，指向 **源数据交叉字段一致性缺口**，不是作者真实DTA已出现此异常。

## R050修复与反证程序

`r050_integrity.py` 是独立增量审计程序：

* 每个 `sesid, Match, Block, Round, Group` 应有10条行为记录，检查组内 `countA/countB` 字段一致，并与原始行为重新求和比对。
* 按实际 `message/punish` 发起记录逐组重算 `countmessage/countpunish`，检查发送者选择低提取且机制正确。
* 仅在同一 `subject_id, Match, Block` 内将上一轮行为及实施惩罚记录映射到 `_old` 字段，禁止新匹配/新区块时间泄漏。
* 用**上一轮同一组**的实际惩罚人数及本人上一轮 `strategyB` 核对 `badmess/badpun` 的前期被罚标志。这个映射依赖作者关于制裁面向全部高提取者的流程说明；若真实数据无法满足，应调查实验系统编码，不能擅自更改原始记录或自动认定论文错误。
* 使用严格模式时核对3060记录、160人、8场次、340首轮记录、306个组轮；通过这些检查仍不代表原始字节来源身份得到证明。

## 测试与可复现性

- 继承R049的24项构造数据测试全部通过。保留上一轮冻结源文件副本 `r049_replay_frozen.py`。
- R050新增16项构造数据测试全部通过。包含旧程序可以接受虚假人数分解，而新程序拒绝的对抗性案例；两类前期受罚字段被篡改时拒绝；跨区块泄漏拒绝；假样本即使满足3060条亦保持 `source_authenticity=NOT_ESTABLISHED_BY_STRUCTURAL_CHECKS`。
- 40项测试均属于程序层验证，0项为新研究真实微观数据的统计复现。运行记录见 `INHERITED_TEST_OUTPUT.txt` 和 `NEW_TEST_OUTPUT.txt`。
- 测试不建立DTA真实性、随机化合理性、原论文的全部因果分析或历史变化的一般规律。

## 研究决策

1. `PESEN v0.1=FROZEN`。
2. `NEW_INDEPENDENT_NUMERIC_REPLICATION=NO`。
3. `GROUP_LEVEL_SOURCE_AUDIT=IMPLEMENTED_AND_CONSTRUCTED_TESTED`。
4. `RAW_DATA_PUBLISHER_AUTHENTICATION=BLOCKED`。
5. `R051` 的首要任务是以原始字节和正式来源清单准入一个独立团队数据源；所有迁移模型参数必须沿用R049冻结值，不做事后选优。

## 研究伦理与权限

无真人招募、无真实参与者交互、无外部仓库写入、无第三方账户操作；本轮所有文件只在本次会话沙盒生成。
