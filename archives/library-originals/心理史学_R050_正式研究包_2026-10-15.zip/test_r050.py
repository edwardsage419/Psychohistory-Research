"""Only constructed data. Never claim these tests validate real experimental results."""
import itertools
import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

from r049_replay_frozen import source_checks as previous_source_checks
from r050_integrity import IntegrityError, check_integrity


def fixture():
    rows = []
    combos = list(itertools.product((0,1),(0,1)))
    for si in range(8):
        high, social = combos[si//2]
        for g in (1,2):
            prev = {}
            for rd in range(1,10):
                choices={}
                sent={}
                for j in range(10):
                    b = int((j+rd+si)%3 != 0)
                    choices[j]=b
                    sent[j]=int(b==0 and (j+rd)%4==0)
                nm=sum(sent.values()) if social else 0
                nf=sum(sent.values()) if not social else 0
                for j in range(10):
                    b=choices[j]
                    p=prev.get(j)
                    rows.append(dict(
                        subject_id=1000*si+100*g+j, sesid=si+1, Match=g, Block=1,
                        Group=g, Round=rd, Period=rd, strategyA=1-b, strategyB=b,
                        strategyB_old=np.nan if p is None else p['b'],
                        message_old=np.nan if p is None else p['message'],
                        punish_old=np.nan if p is None else p['punish'],
                        social=social,financial=1-social,high=high,low=1-high,
                        message=int(social and sent[j]),punish=int(not social and sent[j]),
                        countA=10-sum(choices.values()),countB=sum(choices.values()),
                        countmessage=nm,countpunish=nf,
                        badmess=int(bool(p and p['b']==1 and social and p['countmessage']>0)),
                        badpun=int(bool(p and p['b']==1 and not social and p['countpunish']>0)),
                    ))
                prev={j:dict(b=choices[j],message=int(social and sent[j]),
                             punish=int(not social and sent[j]),countmessage=nm,countpunish=nf)
                      for j in range(10)}
    return pd.DataFrame(rows)

class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.df=fixture()

    def test_valid_constructed(self):
        out=check_integrity(self.df,False)
        self.assertEqual(out['rows'],1440)
        self.assertEqual(out['group_rounds'],144)
        self.assertEqual(out['eligible_lag_rows'],1280)
    def test_missing_source(self):
        with self.assertRaisesRegex(IntegrityError,'Missing fields'):
            check_integrity(self.df.drop(columns='Group'),False)
    def test_falsified_count_even_if_sum_10(self):
        x=self.df.copy();m=(x.Group.eq(1)&x.sesid.eq(1)&x.Round.eq(2))
        x.loc[m,'countA']+=1;x.loc[m,'countB']-=1
        # Previous script only tests countA+countB==10; it can accept this lie.
        self.assertEqual(previous_source_checks(x,False)['status'],'PASS')
        with self.assertRaisesRegex(IntegrityError,'counts do not match'):
            check_integrity(x,False)
    def test_group_size_corruption(self):
        x=self.df.copy();x.loc[x.index[0],'Group']=2
        with self.assertRaisesRegex(IntegrityError,'ten participants'):
            check_integrity(x,False)
    def test_group_count_inconsistent_by_row(self):
        x=self.df.copy();x.loc[x.index[0],'countB']+=1
        with self.assertRaisesRegex(IntegrityError,'counts conflict'):
            check_integrity(x,False)
    def test_prior_sanction_fabricated(self):
        x=self.df.copy();mask=(x.social==1)&(x.Round==2)&(x.strategyB_old==1)
        i=x.index[mask][0];x.loc[i,'badmess']=1-x.loc[i,'badmess']
        with self.assertRaisesRegex(IntegrityError,'badmess conflicts'):
            check_integrity(x,False)
    def test_prior_fine_fabricated(self):
        x=self.df.copy();mask=(x.financial==1)&(x.Round==2)&(x.strategyB_old==1)
        i=x.index[mask][0];x.loc[i,'badpun']=1-x.loc[i,'badpun']
        with self.assertRaisesRegex(IntegrityError,'badpun conflicts'):
            check_integrity(x,False)
    def test_shifted_previous(self):
        x=self.df.copy();i=x.index[x.Round.eq(2)][0];x.loc[i,'strategyB_old']=1-x.loc[i,'strategyB_old']
        with self.assertRaisesRegex(IntegrityError,'strategyB_old mismatches'):
            check_integrity(x,False)
    def test_cross_block_leak(self):
        x=self.df.copy();x.loc[0,'strategyB_old']=1
        with self.assertRaisesRegex(IntegrityError,'leaks'):
            check_integrity(x,False)
    def test_false_message_count(self):
        x=self.df.copy();mask=(x.social==1)&(x.Round==2)&(x.sesid==3)&(x.Group==1)
        x.loc[mask,'countmessage']+=1
        with self.assertRaisesRegex(IntegrityError,'Messages counts do not match'):
            check_integrity(x,False)
    def test_ineligible_sender(self):
        x=self.df.copy();i=x.index[(x.social==1)&(x.strategyB==1)][0];x.loc[i,'message']=1
        with self.assertRaisesRegex(IntegrityError,'Ineligible message sender'):
            check_integrity(x,False)
    def test_strict_synthetic_rejected(self):
        with self.assertRaisesRegex(IntegrityError,'Published sample scope'):
            check_integrity(self.df,True)
    def test_full_size_synthetic_still_not_authentic(self):
        chunks=[self.df]
        for si in range(1,9):
            d=self.df[self.df.sesid==si].copy();d['Block']=2;d['Period']+=9
            chunks.append(d)
        d=self.df[self.df.sesid==1].copy();d['Block']=3;d['Period']+=18
        chunks.append(d)
        artificial=pd.concat(chunks,ignore_index=True)
        self.assertEqual(len(artificial),3060)
        result=check_integrity(artificial,True)
        self.assertEqual(result['source_authenticity'],'NOT_ESTABLISHED_BY_STRUCTURAL_CHECKS')
    def test_duplicate_subject(self):
        x=pd.concat([self.df,self.df.iloc[[0]]],ignore_index=True)
        with self.assertRaisesRegex(IntegrityError,'Duplicate subject transition'):
            check_integrity(x,False)
    def test_missing_first_prior(self):
        x=self.df.copy();i=x.index[x.Round.eq(1)][0];x.loc[i,'message_old']=1
        with self.assertRaisesRegex(IntegrityError,'message_old leaks'):
            check_integrity(x,False)
    def test_source_not_created_by_tests(self):
        with tempfile.TemporaryDirectory() as p:
            self.assertFalse((Path(p)/'alldata.dta').exists())

if __name__=='__main__':
    unittest.main(verbosity=2)
