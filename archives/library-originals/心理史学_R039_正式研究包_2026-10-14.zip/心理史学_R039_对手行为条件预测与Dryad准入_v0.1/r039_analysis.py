#!/usr/bin/env python3
"""R039 audited secondary prediction from source-derived anonymized counts.

Dryad analysis is strictly opt-in: raw fix/rand files AND independently
verified schema are mandatory; no Dryad results are fabricated by fallback.
"""
import argparse
import csv
import hashlib
import json
import math
import random
from collections import Counter, defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
GIT_SHA1 = '2dd67c6ff80f2d7aa07a70b470e26fe3592c6d95'
PATTERNS = HERE / 'R039_DERIVED_PATTERN_COUNTS.txt'
STATS = HERE / 'R039_TRAIN_CONTEXT_COUNTS.json'
MODEL_NAMES = ('coin_50', 'R037_frozen_self', 'local_self', 'local_opponent',
               'local_joint', 'personal_first7')


def git_sha1(data):
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()


def posterior(n, y):
    if n <= 0 or not (0 <= y <= n):
        raise ValueError('invalid binomial count')
    return (y + .5)/(n+1)


def decode(k):
    if not (0 <= k < 8192):
        raise ValueError('13-bit key out of range')
    arm = (k >> 12) & 1
    ncoop = (k >> 9) & 7
    tr = []
    for sh in (6, 3, 0):
        bits = (k >> sh) & 7
        tr.append(((bits >> 2) & 1, (bits >> 1) & 1, bits & 1))
    if (ncoop == 0 and tr[0][0]) or (ncoop == 7 and not tr[0][0]):
        raise ValueError('impossible first-seven end state')
    for j in (1, 2):
        if tr[j][0] != tr[j-1][2]:
            raise ValueError('history leaks across test rounds')
    return arm, ncoop, tuple(tr)


def encode(arm, ncoop, trips):
    if arm not in (0, 1) or ncoop not in range(8) or len(trips) != 3:
        raise ValueError('invalid pattern')
    k=(arm<<12)|(ncoop<<9)
    for (a,b,c),sh in zip(trips, (6,3,0)):
        if any(v not in (0,1) for v in (a,b,c)):
            raise ValueError('nonbinary feature')
        k|=((a<<2)|(b<<1)|c)<<sh
    if decode(k)!=(arm,ncoop,tuple(trips)):
        raise ValueError('invalid or inconsistent history')
    return k


def histogram(path=PATTERNS):
    words=' '.join(s.split('#',1)[0] for s in Path(path).read_text('utf-8').splitlines()).split()
    output={}
    for word in words:
        key,v=word.split(':')
        k=int(key,16)
        decode(k)
        count=int(v)
        if count<=0 or k in output:
            raise ValueError('duplicate or empty histogram bin')
        output[k]=count
    return output


def iter_people(hist):
    for k,n in sorted(hist.items()):
        for _ in range(n):
            yield decode(k)


def load_stats(path=STATS):
    d=json.loads(Path(path).read_text('utf-8'))
    return d


def validate(hist, d):
    people=list(iter_people(hist))
    if len(people)!=195:
        raise ValueError('not 195 independent participants')
    if [sum(p[0]==a for p in people) for a in (0,1)] != [97,98]:
        raise ValueError('arm count mismatch')
    if sum(p[1] for p in people)!=705:
        raise ValueError('train cooperation mismatch')
    test_by_self={str(i):[0,0] for i in range(2)}
    test_by_opp={str(i):[0,0] for i in range(2)}
    test_by_joint={f'{i}{j}':[0,0] for i in range(2) for j in range(2)}
    for _,_,trips in people:
        for self_,opp,y in trips:
            for dest,key in ((test_by_self,str(self_)),(test_by_opp,str(opp)),
                             (test_by_joint,f'{self_}{opp}')):
                dest[key][0]+=1
                dest[key][1]+=y
    if test_by_self!=d['test_previous_self'] or test_by_opp!=d['test_previous_peer'] or test_by_joint!=d['test_joint_state_self_peer']:
        raise ValueError('source-derived held-out sufficient counts mismatch')
    if [sum(v[0] for v in test_by_self.values()),sum(v[1] for v in test_by_self.values())]!=d['test_total']:
        raise ValueError('test total mismatch')
    p=d['train_previous_self']
    pp=d['train_previous_peer']
    joint=d['train_joint_state_self_peer']
    for i in (0,1):
        if [sum(joint[f'{i}{j}'][q] for j in (0,1)) for q in (0,1)]!=p[str(i)]:
            raise ValueError('train own marginal mismatch')
        if [sum(joint[f'{j}{i}'][q] for j in (0,1)) for q in (0,1)]!=pp[str(i)]:
            raise ValueError('train opponent marginal mismatch')
    if sum(p[str(i)][0] for i in (0,1))!=195*6:
        raise ValueError('not 6 train transitions per participant')
    return {'people':len(people),'test_n':585,'test_cooperations':226,
            'by_self':test_by_self,'by_opponent':test_by_opp,'by_joint':test_by_joint}


def probabilities(d):
    return {
        'frozen': {k:posterior(*v) for k,v in d['source_transfer_frozen'].items()},
        'own':{k:posterior(*v) for k,v in d['train_previous_self'].items()},
        'peer':{k:posterior(*v) for k,v in d['train_previous_peer'].items()},
        'joint':{k:posterior(*v) for k,v in d['train_joint_state_self_peer'].items()}}


def logloss(y,p):
    if y not in (0,1) or not (0<p<1):
        raise ValueError('invalid evaluation value')
    return -(y*math.log(p)+(1-y)*math.log(1-p))


def people_losses(hist,d):
    p=probabilities(d)
    out=[]
    for arm,k,triples in iter_people(hist):
        person={'arm':'Base' if arm==0 else 'Prompted','k':k,
                'logloss':{name:0.0 for name in MODEL_NAMES},
                'brier':{name:0.0 for name in MODEL_NAMES},
                'predicted_sum':{name:0.0 for name in MODEL_NAMES},
                'actual_sum':0, 'n':3}
        for prev,opp,y in triples:
            predictions={
                'coin_50':.5,
                'R037_frozen_self':p['frozen'][str(prev)],
                'local_self':p['own'][str(prev)],
                'local_opponent':p['peer'][str(opp)],
                'local_joint':p['joint'][f'{prev}{opp}'],
                'personal_first7':(k+.5)/8,
            }
            person['actual_sum']+=y
            for name,prob in predictions.items():
                person['logloss'][name]+=logloss(y,prob)
                person['brier'][name]+=(y-prob)**2
                person['predicted_sum'][name]+=prob
        out.append(person)
    return out


def model_scores(people):
    n=sum(a['n'] for a in people)
    yes=sum(a['actual_sum'] for a in people)
    return {key:{'n':n,'actual_rate':yes/n,
                'mean_predicted_rate':sum(a['predicted_sum'][key] for a in people)/n,
                'logloss':sum(a['logloss'][key] for a in people)/n,
                'brier':sum(a['brier'][key] for a in people)/n} for key in MODEL_NAMES}


def bootstrap_pair(people,a,b,seed=39039,reps=10000):
    rr=random.Random(seed)
    xs=[(p['logloss'][a]-p['logloss'][b])/p['n'] for p in people]
    out=[]
    for _ in range(reps):
        out.append(sum(xs[rr.randrange(len(xs))] for j in xs)/len(xs))
    out.sort()
    return {'contrast':f'{a}_minus_{b}', 'mean':sum(xs)/len(xs),
            'percentile95':[out[int(.025*len(out))],out[int(.975*len(out))]],
            'unit':'participant', 'replicates':reps,'seed':seed,'exploratory':True}


def raw_bridge(path):
    # Verify Git blob and rebuild *anonymous* pattern histogram from original file.
    raw=Path(path).read_bytes()
    actual=git_sha1(raw)
    if actual!=GIT_SHA1:
        raise ValueError('Git blob sha mismatch; expected '+GIT_SHA1+' got '+actual)
    table=list(csv.DictReader(raw.decode('utf-8-sig').splitlines()))
    if len(table)!=3900:
        raise ValueError('expected 3900 rows in original source')
    groups=defaultdict(list)
    qa={'payoff_inconsistent':[]}
    for i,row in enumerate(table,2):
        if row['game']!='PD':continue
        y=int(row['action']); s=int(row['score']); arm=row['opponent']
        if y not in (0,1) or arm not in ('Base','Prompted'):
            raise ValueError('unexpected action/treatment')
        payout={(0,10):1,(0,5):0,(1,8):1,(1,0):0}
        peer=payout.get((y,s))
        if peer is None: qa['payoff_inconsistent'].append({'line':i,'action':y,'score':s})
        groups[row['id']].append((arm,y,peer))
    if len(groups)!=195:
        raise ValueError('expected 195 human subjects')
    source_hist=Counter()
    for seq in groups.values():
        if len(seq)!=10 or len(set(z[0] for z in seq))!=1:
            raise ValueError('invalid subject PD records')
        arm=0 if seq[0][0]=='Base' else 1
        k=sum(z[1] for z in seq[:7])
        trips=[]
        for j in (7,8,9):
            if seq[j-1][2] is None:raise ValueError('missing opponent state required as previous period')
            trips.append((seq[j-1][1],seq[j-1][2],seq[j][1]))
        source_hist[encode(arm,k,tuple(trips))]+=1
    if dict(source_hist)!=histogram():
        raise ValueError('raw source does not reproduce aggregate histogram')
    return {'raw_git_blob_sha1_verified':actual, 'subjects':len(groups),'rows':len(table),
            'histogram_exact_match':True, 'quality':qa}


def safe_posterior(n,y):
    # Explicit neutral .5 fallback for unseen first-order/context states.
    if n==0 and y==0:
        return .5
    return posterior(n,y)


def load_long(path, condition, schema):
    # No column inference: a verified schema from README and actual CSV is mandatory.
    needed=('participant','session','round','action','opponent_action','coop_token','defect_token')
    if set(needed)-set(schema):
        raise ValueError('verified schema missing mappings '+str(sorted(set(needed)-set(schema))))
    if schema['coop_token']==schema['defect_token']:
        raise ValueError('cooperation and defection tokens must differ')
    records=[]
    with Path(path).open('r',encoding='utf-8-sig',newline='') as f:
        tab=csv.DictReader(f,delimiter=schema.get('delimiter',','))
        for fcol in ('participant','session','round','action','opponent_action'):
            if schema[fcol] not in (tab.fieldnames or []):
                raise ValueError('source schema mapping unverified: '+fcol)
        for row in tab:
            def action(x):
                if x==schema['coop_token']:return 1
                if x==schema['defect_token']:return 0
                raise ValueError('unknown decision token: '+repr(x))
            records.append({'condition':condition,'id':row[schema['participant']],
                'session':row[schema['session']],'round':int(row[schema['round']]),
                'y':action(row[schema['action']]),'peer':action(row[schema['opponent_action']])})
    return records


def validate_dryad(rows,expected_counts=(92,96),sessions_each=6,rounds=100):
    people={}
    for r in rows:
        if r['condition'] not in ('fixed','shuffled') or not r['id'] or not r['session']:
            raise ValueError('invalid treatment/id/session')
        key=(r['condition'],r['session'],r['id'])
        people.setdefault(key,[]).append(r)
    counts=[]
    ses_expected = (sessions_each,sessions_each) if isinstance(sessions_each,int) else sessions_each
    for c,expected,expected_sessions in zip(('fixed','shuffled'),expected_counts,ses_expected):
        sub={k:v for k,v in people.items() if k[0]==c}
        counts.append(len(sub))
        if len(sub)!=expected:
            raise ValueError(f'{c}: participant count {len(sub)} not matching reported {expected}')
        if len(set(k[1] for k in sub))!=expected_sessions:
            raise ValueError(f'{c}: session count mismatch')
        for k,rs in sub.items():
            if len(rs)!=rounds or sorted(z['round'] for z in rs)!=list(range(1,rounds+1)):
                raise ValueError('missing/duplicated periods for '+str(k))
    return {'participants':sum(counts),'fixed':counts[0],'shuffled':counts[1],
            'sessions':sum(ses_expected),'rounds_per_person':rounds}


def dryad_scores(rows):
    # Formal holdout: fit on rounds 2..25, predict rounds 76..100.
    grouped=defaultdict(list)
    for r in rows:grouped[(r['condition'],r['session'],r['id'])].append(r)
    per_cond={}
    for cond in ('fixed','shuffled'):
        subset=[sorted(v,key=lambda x:x['round']) for k,v in grouped.items() if k[0]==cond]
        base_self={i:[0,0] for i in (0,1)}
        base_joint={f'{i}{j}':[0,0] for i in (0,1) for j in (0,1)}
        for ar in subset:
            for j in range(1,25):
                z=ar[j];prev=ar[j-1]['y'];peer=ar[j-1]['peer']
                for arr in (base_self[prev],base_joint[f'{prev}{peer}']):arr[0]+=1;arr[1]+=z['y']
        pown={k:safe_posterior(*v) for k,v in base_self.items()}
        pjoint={k:safe_posterior(*v) for k,v in base_joint.items()}
        psrc={0:posterior(345,50),1:posterior(459,390)}
        observations=[]
        for ar in subset:
            k=sum(z['y'] for z in ar[:25]);p_person=(k+.5)/26
            for j in range(75,100):
                z=ar[j];prev=ar[j-1]['y'];peer=ar[j-1]['peer'];y=z['y']
                observations.append({'session':z['session'],'y':y,'probs':{
                    'fixed50':.5,'R037frozen':psrc[prev],
                    'personal_1_25':p_person, 'own_train_2_25':pown[prev],
                    'joint_train_2_25':pjoint[f'{prev}{peer}']}})
        N=len(observations)
        scores={name:{'n':N,'logloss':sum(logloss(v['y'],v['probs'][name]) for v in observations)/N,
                      'brier':sum((v['y']-v['probs'][name])**2 for v in observations)/N,
                      'mean_predicted':sum(v['probs'][name] for v in observations)/N,
                      'actual_cooperation':sum(v['y'] for v in observations)/N}
                for name in observations[0]['probs']}
        session_results=defaultdict(lambda: {'n':0,'own_logloss':0.,'joint_logloss':0.,'personal_logloss':0.})
        for z in observations:
            rec=session_results[z['session']]
            rec['n']+=1
            rec['own_logloss']+=logloss(z['y'],z['probs']['own_train_2_25'])
            rec['joint_logloss']+=logloss(z['y'],z['probs']['joint_train_2_25'])
            rec['personal_logloss']+=logloss(z['y'],z['probs']['personal_1_25'])
        sessions=list(session_results.values())
        rng=random.Random(39039)
        boots={'joint_minus_own':[],'joint_minus_personal':[]}
        for _ in range(3000):
            sample=[sessions[rng.randrange(len(sessions))] for j in sessions]
            denom=sum(z['n'] for z in sample)
            boots['joint_minus_own'].append(sum(z['joint_logloss']-z['own_logloss'] for z in sample)/denom)
            boots['joint_minus_personal'].append(sum(z['joint_logloss']-z['personal_logloss'] for z in sample)/denom)
        boot95={}
        for name,vals in boots.items():
            vals.sort()
            boot95[name]={'point_estimate':(sum(z['joint_logloss']-(z['own_logloss'] if name=='joint_minus_own' else z['personal_logloss']) for z in sessions)/N),
                          'ci95':[vals[75],vals[2925]], 'resample_unit':'session', 'exploratory':True}
        per_cond[cond]={'scores':scores,'train_transition_sufficient_counts':base_self,
                        'n_sessions':len(session_results),'session_bootstrap':boot95}
    return per_cond


def main(argv=None):
    ap=argparse.ArgumentParser()
    ap.add_argument('--raw',help='Optional original Akata GitHub CSV for byte-for-byte SHA verification')
    ap.add_argument('--dryad',nargs=2,metavar=('FIX_CSV','RAND_CSV'))
    ap.add_argument('--schema',help='Independently verified JSON file mapping real Dryad columns and tokens')
    args=ap.parse_args(argv)
    h=histogram();s=load_stats();qc=validate(h,s)
    people=people_losses(h,s)
    output={'research_id':'R039','data_status':'Akata anonymized GitHub-source-derived histogram; Dryad unavailable by default',
            'validity':qc,'source_sha':GIT_SHA1, 'training_sufficient_counts':s,
            'scores':model_scores(people),
            'arm_scores':{arm:model_scores([x for x in people if x['arm']==arm]) for arm in ('Base','Prompted')},
            'exploratory_bootstrap':[
                bootstrap_pair(people,'local_joint','local_self'),
                bootstrap_pair(people,'local_joint','personal_first7'),
                bootstrap_pair(people,'local_joint','R037_frozen_self')],
            'dryad':{'status':'NO_RAW_DATA_NO_ESTIMATES',
                'doi':'10.5061/dryad.37pvmcvmk','required_files':['fix.csv','rand.csv','README.txt']},
            'PESEN_v0_1':'FROZEN'}
    if args.raw:output['source_raw_validation']=raw_bridge(args.raw)
    if args.dryad:
        if not args.schema:
            raise ValueError('Dryad source column/time mapping MUST be confirmed with --schema; no auto-inference')
        mapping=json.loads(Path(args.schema).read_text('utf-8'))
        fix=load_long(args.dryad[0],'fixed',mapping['fixed'])
        rand=load_long(args.dryad[1],'shuffled',mapping['shuffled'])
        valid=validate_dryad(fix+rand)
        output['dryad']={'status':'RAW_IMPORTED_WITH_USER_VERIFIED_SCHEMA',
                          'source_data_validation':valid,'results':dryad_scores(fix+rand)}
    elif args.schema:
        raise ValueError('schema supplied without Dryad source files')
    outfile=HERE/'R039_RESULTS.json'
    outfile.write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'validity':qc,'scores':output['scores'],
                      'bootstrap':output['exploratory_bootstrap'],
                      'dryad':output['dryad']['status']},ensure_ascii=False,indent=2))
    return output

if __name__=='__main__':main()
