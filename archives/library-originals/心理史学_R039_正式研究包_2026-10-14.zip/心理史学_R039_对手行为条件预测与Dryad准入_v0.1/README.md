# 心理史学 R039：双边行为历史预测与长程Dryad数据准入

本包包含独立研究原始数据来源记录、73种无个人身份的派生测试模式、训练充分统计、回顾性预测程序和测试。**没有Montero-Porras Dryad `fix.csv`/`rand.csv`原始内容，外部目标未复现。**

## 可离线复跑的结果

```bash
cd 心理史学_R039_对手行为条件预测与Dryad准入_v0.1
python r039_analysis.py
python -m unittest discover -s tests -v
```

默认不访问网络，重算585次测试选择、模型log loss/Brier、受试者级bootstrap，并生成`R039_RESULTS.json`。真实原作者Akata CSV经GitHub连接器读取，Git blob `2dd67c6ff80f2d7aa07a70b470e26fe3592c6d95`；本地没有原始CSV，只保存严格区分来源的真实派生统计。与R038为同一批195名参与者。

## 原始文件可选校验

取得原作者 `repgames.csv` 后运行：

```bash
python r039_analysis.py --raw /path/to/repgames.csv
```

源码核对完整Git blob SHA1、原始3900行、195名参与者、测试预测派生模式直方图，不匹配即拒绝。

未来如合法取得Dryad的`README.txt`与`fix.csv`/`rand.csv`，先根据README**人工核实**字段、本人和对手动作的正反编码与来源变换。对于严格的一人一轮长表，可建立schema JSON：

```json
{
  "fixed": {
    "participant": "CONFIRM_ID_COLUMN", "session": "CONFIRM_SESSION_COLUMN", "round": "CONFIRM_ROUND_COLUMN",
    "action": "CONFIRM_OWN_ACTION_COLUMN", "opponent_action": "CONFIRM_OPPONENT_ACTION_COLUMN",
    "coop_token": "CONFIRM_COOP_TOKEN", "defect_token": "CONFIRM_DEFECT_TOKEN"
  },
  "shuffled": {
    "participant": "CONFIRM_ID_COLUMN", "session": "CONFIRM_SESSION_COLUMN", "round": "CONFIRM_ROUND_COLUMN",
    "action": "CONFIRM_OWN_ACTION_COLUMN", "opponent_action": "CONFIRM_OPPONENT_ACTION_COLUMN",
    "coop_token": "CONFIRM_COOP_TOKEN", "defect_token": "CONFIRM_DEFECT_TOKEN"
  }
}
```

填写上述**占位符不可直接运行**。执行：`python r039_analysis.py --dryad /path/to/fix.csv /path/to/rand.csv --schema /path/to/verified_schema.json`。如果文件为宽表/特殊编码，请先构建有来源版本记录的长表并核查一致性；所有不匹配都拒绝输出该实验的效应。研究包在当前环境没有执行过这一步。

强制层级：固定对手92、轮换对手96、每条件6场、每人100轮；源论文没有完整的原始结构字节进入本地，以上只是**待验证的准入规则**。未来协议为前25轮固定训练、最后25轮滚动一步预测、不同条件分别报告、场次级敏感性与校准。

所有数值限于合法读取的真实派生数据，并非独立惩罚机制识别证据。PESEN v0.1冻结。详细参见`R039_EVIDENCE_AUDIT.md`。
