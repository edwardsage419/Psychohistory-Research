import json
import math
import tempfile
import unittest
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import r039_analysis as a

class R039Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.h=a.histogram()
        cls.d=a.load_stats()
        cls.people=a.people_losses(cls.h,cls.d)
        cls.results=a.model_scores(cls.people)

    def test_genuine_git_provenance(self):
        self.assertEqual(a.GIT_SHA1,'2dd67c6ff80f2d7aa07a70b470e26fe3592c6d95')
    def test_blob_sha_math(self):
        import hashlib
        self.assertEqual(a.git_sha1(b'a'), hashlib.sha1(b'blob 1\x00a').hexdigest())
    def test_read_pattern_rows(self):
        self.assertEqual(len(self.h),73)
    def test_number_subjects(self):
        self.assertEqual(len(self.people),195)
    def test_treatment_counts(self):
        self.assertEqual([sum(p['arm']==k for p in self.people) for k in ('Base','Prompted')],[97,98])
    def test_outcomes_total(self):
        self.assertEqual(sum(p['actual_sum'] for p in self.people),226)
    def test_all_tests_count(self):
        self.assertEqual(sum(p['n'] for p in self.people),585)
    def test_validated_source_counts(self):
        self.assertEqual(a.validate(self.h,self.d)['test_n'],585)
    def test_baseline_metrics(self):
        self.assertAlmostEqual(self.results['coin_50']['logloss'],math.log(2),12)
    def test_frozen_transfer_unchanged(self):
        self.assertAlmostEqual(self.results['R037_frozen_self']['logloss'],.47275015138958365,10)
    def test_own_state_unchanged(self):
        self.assertAlmostEqual(self.results['local_self']['logloss'],.48383396894947767,10)
    def test_personal_comparator_unchanged(self):
        self.assertAlmostEqual(self.results['personal_first7']['logloss'],.4369022730170648,10)
    def test_opponent_state_effect(self):
        self.assertAlmostEqual(self.results['local_opponent']['logloss'],.4645033932955535,10)
    def test_joint_context_effect(self):
        self.assertAlmostEqual(self.results['local_joint']['logloss'],.4074854667865264,10)
    def test_joint_brier(self):
        self.assertAlmostEqual(self.results['local_joint']['brier'],.11994674591289547,10)
    def test_comparator_ranking(self):
        self.assertLess(self.results['local_joint']['logloss'],self.results['local_self']['logloss'])
    def test_personal_not_inferior_certain(self):
        info=a.bootstrap_pair(self.people,'local_joint','personal_first7',reps=600)
        self.assertLess(info['percentile95'][0],0)
        self.assertGreater(info['percentile95'][1],0)
    def test_enc_dec_basic(self):
        trips=((1,1,0),(0,0,1),(1,0,1))
        k=a.encode(1,5,trips)
        self.assertEqual(a.decode(k),(1,5,trips))
    def test_enc_dec_bad_history(self):
        with self.assertRaises(ValueError):a.encode(0,0,((1,1,1),(1,0,1),(1,1,0)))
    def test_bad_nibble_rejected(self):
        with self.assertRaises(ValueError):a.decode(8192)
    def test_histogram_extra_person_rejected(self):
        h=dict(self.h)
        h[next(iter(h))]+=1
        with self.assertRaises(ValueError):a.validate(h,self.d)
    def test_tampered_test_totals_rejected(self):
        d=json.loads(json.dumps(self.d))
        d['test_previous_peer']['0'][1]+=1
        with self.assertRaises(ValueError):a.validate(self.h,d)
    def test_tampered_train_marginal_rejected(self):
        d=json.loads(json.dumps(self.d))
        d['train_previous_peer']['0'][0]+=1
        with self.assertRaises(ValueError):a.validate(self.h,d)
    def test_no_unsupported_raw(self):
        with tempfile.TemporaryDirectory() as p:
            f=Path(p)/'foo.csv';f.write_text('not same raw')
            with self.assertRaises(ValueError):a.raw_bridge(f)
    def test_probability_guard(self):
        with self.assertRaises(ValueError):a.posterior(0,0)
        with self.assertRaises(ValueError):a.logloss(2,.5)
    def test_bootstrap_deterministic(self):
        x=a.bootstrap_pair(self.people,'local_joint','local_self',reps=700)
        y=a.bootstrap_pair(self.people,'local_joint','local_self',reps=700)
        self.assertEqual(x,y)
    def test_dryad_missing_schema_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            f=Path(tmp)/'test.csv'; f.write_text('foo,bar\na,b\n')
            with self.assertRaises(ValueError):a.load_long(f,'fixed',{'action':'foo'})
    def test_dryad_unknown_token_fails(self):
        schema={i:i for i in ('participant','session','round','action','opponent_action')}
        schema.update(coop_token='C',defect_token='D')
        with tempfile.TemporaryDirectory() as tmp:
            f=Path(tmp)/'x.csv'
            f.write_text('participant,session,round,action,opponent_action\n1,s,1,X,C\n')
            with self.assertRaises(ValueError):a.load_long(f,'fixed',schema)
    def test_dryad_toy_validation_passes(self):
        source=[]
        for cond,ct in [('fixed',2),('shuffled',3)]:
            for i in range(ct):
                for rnd in (1,2,3):
                    source.append({'condition':cond,'id':str(i),'session':cond+str(i),'round':rnd,'y':1,'peer':0})
        self.assertEqual(a.validate_dryad(source,expected_counts=(2,3),sessions_each=(2,3),rounds=3)['participants'],5)
    def test_dryad_toy_duplicate_period_rejected(self):
        source=[]
        for cond in ('fixed','shuffled'):
            for i in range(2):
                for rnd in (1,2,3):
                    source.append({'condition':cond,'id':str(i),'session':cond+str(i),'round':rnd,'y':1,'peer':0})
        source[-1]['round']=2
        with self.assertRaises(ValueError):a.validate_dryad(source,expected_counts=(2,2),sessions_each=2,rounds=3)
    def test_dryad_toy_eval_has_no_holdout_without_rounds(self):
        rows=[]
        for cond in ('fixed','shuffled'):
            for i in range(2):
                for rnd in range(1,101):
                    rows.append({'condition':cond,'id':str(i),'session':cond+str(i),'round':rnd,'y':(rnd+i)%2,'peer':rnd%2})
        a.validate_dryad(rows,expected_counts=(2,2),sessions_each=2,rounds=100)
        out=a.dryad_scores(rows)
        self.assertEqual(out['fixed']['scores']['fixed50']['n'],50)
        self.assertIn('joint_train_2_25',out['shuffled']['scores'])
    def test_dryad_toy_eval_no_nans(self):
        rows=[]
        for cond in ('fixed','shuffled'):
            for i in range(2):
                for rnd in range(1,101):
                    rows.append({'condition':cond,'id':str(i),'session':cond+str(i),'round':rnd,'y':i,'peer':1-i})
        out=a.dryad_scores(rows)
        self.assertTrue(math.isfinite(out['fixed']['scores']['joint_train_2_25']['logloss']))

if __name__ == '__main__':unittest.main()
