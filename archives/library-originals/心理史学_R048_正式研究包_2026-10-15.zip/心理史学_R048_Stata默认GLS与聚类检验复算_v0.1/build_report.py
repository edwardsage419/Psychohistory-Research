#!/usr/bin/env python3
from __future__ import annotations
import datetime, json, csv, pathlib
import r048_analysis as a
ROOT=pathlib.Path(__file__).resolve().parent
z=json.loads((ROOT/'R048_RESULTS.json').read_text())
f=lambda x:f'{x:.6f}'
def w(st,receipt='raw',when='current'):
 return z['cases'][f'{when}_{st}_{receipt}']['wald_punishment_arm_difference']

def match_table():
 with (ROOT/'R048_PUBLISHED_MATCH.csv').open('w',newline='') as f1:
  t=csv.writer(f1);t.writerow(['model','n','coefficient','published_beta_rounded','R048_default_GLS','published_SE_rounded','R048_cluster_SE'])
  for st in 'BA':
   r=z['cases'][f'current_{st}_raw'];p=a.PRINTED[st]
   for i,k in enumerate(a.NAMES):t.writerow([st,r['n'],k,p['coefficients'][i],r['coefficients'][k],p['se'][i],r['cluster_standard_errors'][k]])
 with (ROOT/'R048_WALD_SENSITIVITY.csv').open('w',newline='') as f1:
  t=csv.writer(f1);t.writerow(['timing','stratum','receipt','N','coef_unequal','coef_equal','chi2_group_cluster_1df','nominal_p_1df','variance_method'])
  for q,r in z['cases'].items():
   when,st,rec=q.split('_');s=r['wald_punishment_arm_difference'];t.writerow([when,st,rec,r['n'],r['coefficients']['punishment_unequal'],r['coefficients']['punishment_equal'],s['chi2_df1'],s['p_chi2_df1'],r['variance_method']])

ledger={'round':'R048','date':'2026-10-15','PESEN_v0.1':'FROZEN','evidence':[ 
 {'name':'author CSV, original records','url':'https://github.com/lrdegeest/InequalityCPR/blob/master/data/data.csv','sha1_gitblob':'73c02176bc9e060af987149594a85f9f7b591230','remote_source_status':'fully read and audited in R043-R047 via connected GitHub','local_bytes_in_R048':False,'derivative':'R047 verified de-identified compressed behavior panel; R046 source cross-check'},
 {'name':'author Stata treatment cleaning script','url':'https://github.com/lrdegeest/InequalityCPR/blob/master/data/label_main_data.do','sha1_gitblob':'a825e6ff5bc90e99984c02f928dd2f5452e5e925','read':True},
 {'name':'author Stata regression script','url':'https://github.com/lrdegeest/InequalityCPR/blob/master/analysis/punishment_response.do','sha1_gitblob':'7772fe3e655cf8455bc56017654564036a99176d','read':True,'model':'xtreg delta_invest dev i.homo#c.lag_received if dev>0 or dev<0, re cluster(uniquegroup)'},
 {'name':'published original paper Table 4','url':'https://lrdegeest.github.io/InequalityCPR.pdf','doi':'10.1561/102.00000099','paper_pdf_zero_index_page':15,'checked':True},
 {'name':'official Stata 15 reference manual','url':'https://www.stata.com/manuals15/xtxtreg.pdf','pages':'printed 28-29 / PDF zero-index 27-28','read':True,'role':'default GLS variance components, optional sa, cluster robust'},
 {'name':'author Stata labeled binary, not accessible','url':'https://github.com/lrdegeest/InequalityCPR/blob/master/data/main_data_labels.dta','sha1_gitblob':'7f846841aa2e23a0699614473dfef1f809a519b3','metadata_file_size_bytes':184352,'read':False,'reason':'GitHub connector rejects non-UTF8; local network DNS unavailable','stata_execution':False},
 {'name':'independent human peer-punishment next dataset candidate','url':'https://www.nature.com/articles/s41467-017-00731-0','doi':'10.1038/s41467-017-00731-0','authors':'Abbink et al 2017','study':'232 people 58 groups, public goods with normative appropriateness experiment','data_url':'https://figshare.com/s/1dc581ff601213c35e83','raw_data_read':False,'blocking':'figshare public share page returned HTTP403 from available web tool'},
 {'name':'independent ICPSR published dataset candidate','url':'https://www.icpsr.umich.edu/sites/view/studies/112568','doi':'10.3886/E112568V1','title':'Imperfect Public Monitoring with Costly Punishment','listed_files':['punnoise_data.txt','punnoise_data_description.txt','punnoise_regressions.do'],'raw_data_read':False}
], 'reproduction_grade':{
 'Stata Table4 models1_and3':'published-rounded coefficients, group-cluster robust SE and published contrast χ² numerically reconstructed from author source-derived R047 panel using independently implemented Stata15 default GLS and second statsmodels quasi-demean check',
 'source_binary_DTA_verified':False,'native_Stata_ran':False,'models2_and4_replicated':False,'original_CSV_direct_local_bytes':False,
 'mechanism_causally_identified':False}}
(ROOT/'R048_SOURCE_LEDGER.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n')
match_table()

B=z['cases']['current_B_raw']; A=z['cases']['current_A_raw'];BC=z['cases']['current_B_verified'];AC=z['cases']['current_A_verified']
L=lambda x:x['wald_punishment_arm_difference']['chi2_df1']; P=lambda x:x['wald_punishment_arm_difference']['p_chi2_df1']
looB=[x['wald_punishment_arm_difference']['chi2_df1'] for x in z['robustness']['B']['leave_one_group'].values()]
looA=[x['wald_punishment_arm_difference']['chi2_df1'] for x in z['robustness']['A']['leave_one_group'].values()]
report=f'''# 心理史学 R048 正式研究审计（2026-10-15）

## 研究问题与成果等级

**R048在严格限定的数据口径下首次重建了论文表4（模型1和3）全部8个固定效应系数、8个组聚类稳健标准误和两个组间 Wald χ² 到论文的印刷精度。** 上一轮R047的高斯随机截距最大似然为不同估计器，仅属近似；本轮采用Stata官方文档所列的默认方差分量GLS估计法，修正了这一区别。

- **数据来源**：De Geest & Kingsley (2021)，DOI `10.1561/102.00000099`；作者GitHub公开源 `data/data.csv` Git blob SHA1 `73c02176bc9e060af987149594a85f9f7b591230`。R043—R047中由连接器全量分析原CSV；**本地 R048 仍仅使用在R047验证过的匿名逐轮行为压缩衍生物**，没有作者原 CSV 原始字节；不能误称本地端到端原文件复现。
- **研究范围**：仅惩罚臂64人、16个四人组、4场次、896次 t3—t16 连续行为转移；当期偏离定义与作者脚本一致，下段样本451、上段414；**没有新的独立实验，也没有对处理分配机制的新证明**。
- **Stata访问限制**：作者`main_data_labels.dta`仍因二进制UTF-8访问限制而不可读，本地未运行Stata；结果属**按官方算法跨软件数值等值重建（paper-rounding match）**，不属于 Stata 软件或发布二进制的直接复制。

## 重建的估计定义

从作者`punishment_response.do`对照得模型

\\[\\Delta E_{{it}}=\\alpha+\\beta (\\overline E_{{g,t}}-E_{{it}})+\\gamma_U P_{{i,t-1}}1(H_i=0)+\\gamma_E P_{{i,t-1}}1(H_i=1)+u_i+\\epsilon_{{it}}.\\]

当期变量 `dev_t = groupmean_t − extraction_t` 同时影响样本筛选和结果变化，保留R045—R047的**同时性/碰撞与机制非识别**警告。

参考Stata 15官方《xtreg》，PDF零索引第27—28页（纸本第28—29页）：

\\[\\hat\\sigma_e^2=SSR_{{within}}/(N-n-K+1),\\qquad
\\hat\\sigma_u^2=\\max[0,SSR_{{between}}/(n-K)-\\hat\\sigma_e^2/\\overline T_H].\\]

其中K=4（包括截距），`between`用每人平均数的非加权 OLS，`\\overline T_H`为每人可用观测轮数的调和平均。再按 `\\theta_i=1-\\sqrt{{\\hat\\sigma_e^2/(T_i\\hat\\sigma_u^2+\\hat\\sigma_e^2)}}` 变换并对四人组聚类计算 sandwich SE（簇数G=16，有限样本校正G/(G−1)×(N−1)/(N−K)）。注意 `sa` 是替代方差分量方法，**不属于作者脚本默认设置**。

## 表4（模型1与3）全部关键数值

| 条件和系数 | 论文发表（系数；标准误） | R048重建（系数；组聚类标准误） |
|---|---:|---:|
| 低于均值，常数项 | 3.117；1.07 | {f(B['coefficients']['intercept'])}；{f(B['cluster_standard_errors']['intercept'])} |
| 低于均值，偏离量 | −0.839；0.12 | {f(B['coefficients']['deviation_t'])}；{f(B['cluster_standard_errors']['deviation_t'])} |
| 低于均值，不均等惩罚斜率 | −0.123；0.04 | {f(B['coefficients']['punishment_unequal'])}；{f(B['cluster_standard_errors']['punishment_unequal'])} |
| 低于均值，均等惩罚斜率 | −0.065；0.01 | {f(B['coefficients']['punishment_equal'])}；{f(B['cluster_standard_errors']['punishment_equal'])} |
| 高于均值，常数项 | −1.932；0.96 | {f(A['coefficients']['intercept'])}；{f(A['cluster_standard_errors']['intercept'])} |
| 高于均值，偏离量 | −1.128；0.12 | {f(A['coefficients']['deviation_t'])}；{f(A['cluster_standard_errors']['deviation_t'])} |
| 高于均值，不均等惩罚斜率 | −0.305；0.11 | {f(A['coefficients']['punishment_unequal'])}；{f(A['cluster_standard_errors']['punishment_unequal'])} |
| 高于均值，均等惩罚斜率 | −0.003；0.04 | {f(A['coefficients']['punishment_equal'])}；{f(A['cluster_standard_errors']['punishment_equal'])} |

* 低于均值 Wald χ²(1)：发表1.77，本轮 `{f(L(B))}`，名义P `{f(P(B))}`（论文比较数值；严格区分来源）。
* 高于均值 Wald χ²(1)：发表7.31，本轮 `{f(L(A))}`，名义P `{f(P(A))}`。
* 所有系数到论文小数后三位一致，SE到小数后两位一致；Wald到两位一致，使用未四舍五入数据计算。

Stata 15官方方法来源：https://www.stata.com/manuals15/xtxtreg.pdf ，论文原文：https://lrdegeest.github.io/InequalityCPR.pdf ，原始公开Stata命令：https://github.com/lrdegeest/InequalityCPR/blob/master/analysis/punishment_response.do 。

## 实际收到的罚款字段质量敏感性（同样默认GLS）

| 回归分层 | 原始 Received 组间χ²（名义P） | 事件账本/最终收益核验罚款χ²（名义P） |
|---|---:|---:|
| 低于小组均值 | {f(L(B))}（{f(P(B))}） | {f(L(BC))}（{f(P(BC))}） |
| 高于小组均值 | {f(L(A))}（{f(P(A))}） | {f(L(AC))}（{f(P(AC))}） |

改用账本核验字段后，位于**高于均值组**的均等资源惩罚斜率由 `{f(A['coefficients']['punishment_equal'])}` 变为 `{f(AC['coefficients']['punishment_equal'])}`，不均等斜率由 `{f(A['coefficients']['punishment_unequal'])}` 变为 `{f(AC['coefficients']['punishment_unequal'])}`。原来80条`Received`值不一致、9条二元是否受罚分类不一致，本轮**不改写原数据，只平行报告两种口径**。校正后的高于均值名义P约0.024，并不等于稳健因果显著性。

原字段留一四人组重算，低于均值χ²范围约`[{min(looB):.4f},{max(looB):.4f}]`，高于均值χ²范围`[{min(looA):.4f},{max(looA):.4f}]`。**高于均值原本的名义0.05阈值结论在部分留组情景失效**。任何按实验场次只有4个簇的渐近式标准误都不可信，本轮虽保留场次聚类数值作诊断，**不以其输出P值作推断**。

## 不确定性与机制识别边界

1. 原论文处理条件与8个场次完全嵌套，其中本轮只有4个惩罚臂场次、每等额/不等额2场次；没有独立处理分配日志。再精确的回归复制也不增加真正的随机化单元。
2. `Received`错误因果成因未知；其与账本核验罚款和`Total2`之间的三重关系已核验，但作者二进制发布版本内容仍不能断言。
3. 回归对象为**观察到上一轮惩罚金额与提取变化的关联**。实际惩罚由其他参与者自主选择，非随机介入变量；不能从系数推出「社会惩罚导致合作」或「规范/评价恐惧」独立机制。
4. 仅论文表4模型**1及3**完整匹配；模型2及4包含个体禀赋分层，当前匿名衍生物不存禀赋个体映射，不能声称已复现。
5. 未在本地执行原作者Stata二进制 `main_data_labels.dta` 或原生 Stata 命令；未核验论文报告120人与公开CSV128人之差异。真正新样本验证依旧未通过。

## 独立数值实现、软件测试与外部候选

- 主程序 `r048_analysis.py` 提供Stata默认FGLS、替代`sa`、组聚类、场次聚类诊断及留一组/场次重估； `independent_statsmodels_check.py` 以**第二套statsmodels实现**比对八个回归的固定效应与聚类SE，误差低于`2×10⁻14`。
- `tests/test_r048.py`已执行 **56项软件测试全部PASS**，涵盖原文到三位/两位小数匹配、来源哈希闸门、异构估计器区别、错误输入拒绝、逐组敏感性及跨实现一致性。
- 下一批独立真人实验候选：Abbink等（2017），*Peer punishment promotes enforcement of bad social norms*，DOI `10.1038/s41467-017-00731-0`，232人58个四人组，实测惩罚可用性、真实惩罚与规范问卷；作者声明数据于 `https://figshare.com/s/1dc581ff601213c35e83`，当前网页HTTP403且**原始数据未取得**。另有Ambrus/Greiner2019 `https://doi.org/10.3886/E112568V1` 公共ICPSR存档，列出`punnoise_data.txt`，尚未下载。新试验结局单位均需另建测量映射，不得将贡献金额当成二元C/D。

**决定：R048正式通过跨软件Stata默认GLS数字重建；PESEN v0.1严格继续FROZEN；社会惩罚独立因果机制UNIDENTIFIED。**
'''
(ROOT/'R048_EVIDENCE_AUDIT.md').write_text(report)
(ROOT/'R049_RESEARCH_GATE.md').write_text('''# R049严格研究关口（2026-10-15，R048完成后生效）

1. **原始二进制交叉核验**：优先经合法来源取得作者Stata `main_data_labels.dta` 与 `targeting_data.dta`，严格Git blob SHA，再用pandas或真正Stata读列、行数、`Received`异常；尝试原生Stata脚本对照R048模型1、3。未经实际字节读取不得宣称原生数据复现。
2. **表4其余模型**：在原始CSV与个体实际禀赋40/50/60映射得到严格核验后，独立复现模型2、4的`self_type × lag_received`及四人组SE；不使用R048匿名面板臆测禀赋。
3. **独立外部惩罚研究优先**：优先获取Abbink等2017年第三方组实测的`figshare`数据；次选Ambrus/Greiner2019公开ICPSR的`punnoise_data.txt`。逐条审计处理分配、成本、决策前规范/信念、实际惩罚时序、组层级。未得原始可核数据不写出效应复算。
4. **真正第三个独立真人—真人重复二元C/D数据**依旧单列目标：任何公共物品连续贡献不能当作等价C/D，维持R039冻结迁移参数。
5. **因果随机化**：对惩罚可用性 Z 的ITT与实际惩罚行为 P 的内生性严格区分；没有排除限制、决策前信念与真实中介随机操纵，禁止称独立惩罚心理机制被确认。
6. **审计**：发表120 vs作者CSV128人数差异、随机化场次分配日志、`Received`差错生成机制仍开放。每轮形成版本化研究包与完整原始来源缺口表。
7. **PESEN v0.1 FROZEN**；不修改外部仓库或基础权重，不冒充外部新证据。
''')
(ROOT/'README.md').write_text('''# 心理史学 R048 研究包：Stata默认GLS及已发表表4精度重建

## 运行

依赖Python3.10+、numpy、scipy、pytest、statsmodels。

```bash
OPENBLAS_NUM_THREADS=1 python r048_analysis.py
OPENBLAS_NUM_THREADS=1 python independent_statsmodels_check.py
OPENBLAS_NUM_THREADS=1 python -m pytest -q tests/test_r048.py
```

程序读 `panel_derivative.b64.txt`。这**是R047源GitHub已核验匿名派生物而不是原始CSV字节**。`r047_analysis.py`为R047原本的哈希与衍生面板工具副本。R048主要新实现为`r048_analysis.py`，与官方Stata15默认xtreg,re估计器规则等值，输出8套规格，并重建发表表4模型1和3的点估计、四人组聚类SE、组间Wald检验到论文印刷精度。

如拥有作者原始CSV，先执行`python r048_analysis.py --audit-csv /path/to/author.csv`；必须过Git Blob SHA1及原始源数据账本重建一致性门槛。

如拥有作者原始Stata文件，执行`python r048_analysis.py --audit-dta /path/to/main_data_labels.dta`；它先校验Git Blob SHA1再通过`pandas.read_stata`检查必需字段。**不能在没有真实文件时声明此门槛通过。**

参考原论文：https://lrdegeest.github.io/InequalityCPR.pdf ；Stata15参考文档：https://www.stata.com/manuals15/xtxtreg.pdf 。

结论等级：已发表数字的跨软件复算；非原生Stata软件复制，非新样本，非惩罚因果识别。PESEN v0.1 FROZEN。
''')
print('wrote reports',len(report))
