"""R048 regression formula, source provenance, and non-causal robustness tests."""
import json, pathlib, sys, numpy as np, pytest, statsmodels.api as sm
BASE=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE))
import r048_analysis as a
import r047_analysis as old

ROWS=old.longitudinal_design(old.decode_panel())
RESULTS=json.loads((BASE/'R048_RESULTS.json').read_text())

@pytest.mark.parametrize('stratum,expected',[(x,p) for x,p in a.PRINTED.items()])
def test_pub_n(stratum,expected):
    assert RESULTS['published_comparison'][stratum]['n_matches']
    assert RESULTS['published_comparison'][stratum]['reproduced']['n']==expected['n']

@pytest.mark.parametrize('stratum,coef',[(s,i) for s in 'BA' for i in range(4)])
def test_table4_coefficients(stratum,coef):
    predicted=list(RESULTS['published_comparison'][stratum]['reproduced']['coefficients'].values())[coef]
    assert abs(predicted-a.PRINTED[stratum]['coefficients'][coef])<0.0006

@pytest.mark.parametrize('stratum,coef',[(s,i) for s in 'BA' for i in range(4)])
def test_table4_cluster_se_matches_printing(stratum,coef):
    predicted=list(RESULTS['published_comparison'][stratum]['reproduced']['cluster_standard_errors'].values())[coef]
    assert abs(predicted-a.PRINTED[stratum]['se'][coef])<.0051

@pytest.mark.parametrize('stratum',list('BA'))
def test_table4_wald_matches_print(stratum):
    predicted=RESULTS['published_comparison'][stratum]['reproduced']['wald_punishment_arm_difference']['chi2_df1']
    assert abs(predicted-a.PRINTED[stratum]['chi2'])<.005

@pytest.mark.parametrize('stratum',list('BA'))
def test_default_variance_components_positive(stratum):
    q=a.estimate(old.prepare(ROWS,'current','raw',stratum))
    assert q['variance_components']['sigma_e2']>0
    assert q['variance_components']['sigma_u2']>0
    assert q['group_clusters']==16 and q['session_clusters']==4

@pytest.mark.parametrize('stratum',list('BA'))
def test_statsmodels_independent_transformed_coefficient_and_se(stratum):
    d=old.prepare(ROWS,'current','raw',stratum)
    x=a.estimate(d,include_arrays=True)['model_internal']
    fit=sm.OLS(x['transY'],x['transX']).fit(cov_type='cluster',cov_kwds={'groups':x['groups'],'use_correction':True})
    np.testing.assert_allclose(fit.params,x['beta'],atol=1e-9,rtol=0)
    np.testing.assert_allclose(fit.bse,x['se'],atol=1e-9,rtol=0)

@pytest.mark.parametrize('stratum',list('BA'))
def test_sa_option_is_different(stratum):
    def get(m):return np.array(list(m['coefficients'].values()))
    x=RESULTS['cases'][f'current_{stratum}_raw'];s=RESULTS['robustness'][stratum]['sa_option']
    assert np.max(np.abs(get(x)-get(s)))>.01

@pytest.mark.parametrize('stratum',list('BA'))
def test_ml_option_is_different(stratum):
    src=RESULTS['cases'][f'current_{stratum}_raw']
    ml=old.fit_ml_re(old.prepare(ROWS,'current','raw',stratum))
    assert np.max(np.abs(np.array(list(src['coefficients'].values()))-np.array(list(ml['coefficients'].values()))))>.01

@pytest.mark.parametrize('stratum',list('BA'))
def test_verified_receipts_impact_wald(stratum):
    raw=RESULTS['cases'][f'current_{stratum}_raw']['wald_punishment_arm_difference']['chi2_df1']
    verified=RESULTS['cases'][f'current_{stratum}_verified']['wald_punishment_arm_difference']['chi2_df1']
    assert verified<raw

@pytest.mark.parametrize('stratum',list('BA'))
def test_lag_order_changes_pool(stratum):
    prev=RESULTS['cases'][f'previous_{stratum}_raw']['n']
    now=RESULTS['cases'][f'current_{stratum}_raw']['n']
    assert prev!=now

@pytest.mark.parametrize('stratum',list('BA'))
def test_leave_one_session_changes_original_stratum_wald(stratum):
    base=RESULTS['cases'][f'current_{stratum}_raw']['wald_punishment_arm_difference']['chi2_df1']
    loo=RESULTS['robustness'][stratum]['leave_one_session']
    assert len(loo)==4
    assert any(abs(v['wald_punishment_arm_difference']['chi2_df1']-base)>.5 for v in loo.values())

@pytest.mark.parametrize('stratum',list('BA'))
def test_receive_original_x_corrected_provenance(stratum):
    v=RESULTS['cases'][f'current_{stratum}_raw']
    assert v['variance_method']=='default' and v['cluster_method']=='group'
    assert v['subjects']>=50

@pytest.mark.parametrize('stratum',list('BA'))
def test_sandwich_properties(stratum):
    x=a.estimate(old.prepare(ROWS,'current','raw',stratum),include_arrays=True)['model_internal']
    assert np.all(np.linalg.eigvalsh(x['cov'])>=-1e-8)
    assert np.allclose(x['cov'],x['cov'].T,atol=1e-12)

@pytest.mark.parametrize('timing,stratum,receipt',[(t,s,r) for t in ('current','previous') for s in ('B','A') for r in ('raw','verified')])
def test_all_eight_specs(timing,stratum,receipt):
    d=old.prepare(ROWS,timing,receipt,stratum)
    z=a.estimate(d)
    recorded=RESULTS['cases'][f'{timing}_{stratum}_{receipt}']
    assert z['n']==recorded['n']
    for key in a.NAMES:assert abs(z['coefficients'][key]-recorded['coefficients'][key])<1e-9

@pytest.mark.parametrize('case',[
    [], [(0,0,0,float('nan'),[1,2,3,4])]*25,
    [(0,0,0,1,[1,2,3])]*25,
    [(0,0,0,1,[1,2,3,float('inf')])]*25,
])
def test_corrupt_rows_rejected(case):
    with pytest.raises(ValueError):a.ensure_input(case)

def test_wrong_estimator_rejected():
    d=old.prepare(ROWS,'current','raw','B')
    X,y,people,*_=a.arrays(d)
    with pytest.raises(ValueError):a.variance_components(X,y,people,'unknown')

def test_wrong_cluster_rejected():
    with pytest.raises(ValueError):a.estimate(old.prepare(ROWS,'current','raw','B'),cluster='household')

def test_original_derivative_sha_known():
    assert old.SOURCE_SHA=='73c02176bc9e060af987149594a85f9f7b591230'
    assert RESULTS['qc']['corrected_Received_cells']==80
    assert RESULTS['qc']['transitions']==896

def test_source_dta_absent_and_not_faked():
    assert RESULTS['provenance']['stata_binary_read'] is False
    assert RESULTS['provenance']['native_stata_ran'] is False

def test_source_identity_gate_non_authorized_bytes(tmp_path):
    f=tmp_path/'pretend.csv';f.write_text('not the original CSV')
    with pytest.raises(ValueError):old.compare_original_source(f)

def test_source_identity_gate_stata_nonbinary(tmp_path):
    f=tmp_path/'pretend.dta';f.write_text('not Stata')
    with pytest.raises(ValueError):
        contents=f.read_bytes()
        if old.git_blob_sha(contents)!=old.DTA_SHA:raise ValueError('Invalid DTA fingerprint')
