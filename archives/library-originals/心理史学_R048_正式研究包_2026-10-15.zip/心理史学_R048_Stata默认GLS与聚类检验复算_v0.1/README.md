# 心理史学 R048 研究包：Stata默认GLS及已发表表4精度重建

## 运行

依赖Python3.10+、numpy、scipy、pytest、statsmodels。

```bash
OPENBLAS_NUM_THREADS=1 python r048_analysis.py
OPENBLAS_NUM_THREADS=1 python independent_statsmodels_check.py
OPENBLAS_NUM_THREADS=1 python -m pytest -q tests/test_r048.py
```

程序读 `panel_derivative.b64.txt`。这**是R047源GitHub已核验匿名派生物而不是原始CSV字节**。`r047_analysis.py`为R047原本的哈希与衍生面板工具副本。R048主要新实现为`r048_analysis.py`，与官方Stata15默认xtreg,re估计器规则等值，输出8套规格，并重建发表表4模型1和3的点估计、四人组聚类SE、组间Wald检验到论文印刷精度。

如拥有作者原始CSV，先执行`python r048_analysis.py --audit-csv /path/to/author.csv`；必须过Git Blob SHA1及原始源数据账本重建一致性门槛。

如拥有作者原始Stata文件，执行`python r048_analysis.py --audit-dta /path/to/main_data_labels.dta`；它先校验Git Blob SHA1再通过`pandas.read_stata`检查必需字段。**不能在没有真实文件时声明此门槛通过。**

参考原论文：https://lrdegeest.github.io/InequalityCPR.pdf ；Stata15参考文档：https://www.stata.com/manuals15/xtxtreg.pdf 。

结论等级：已发表数字的跨软件复算；非原生Stata软件复制，非新样本，非惩罚因果识别。PESEN v0.1 FROZEN。
