#!/usr/bin/env python3
"""Second implementation using statsmodels OLS clustered covariance after GLS transform."""
from __future__ import annotations
import json, pathlib
import numpy as np, statsmodels.api as sm
import r047_analysis as old
import r048_analysis as analysis
ROOT=pathlib.Path(__file__).resolve().parent
ROWS=old.longitudinal_design(old.decode_panel())
def main():
  report={'method':'statsmodels OLS cov_type cluster on independently computed quasi-demeaned columns',
          'source':'same R047 anonymous verified source derivative','cases':{}}
  for time in ('current','previous'):
   for st in 'BA':
    for receipt in ('raw','verified'):
     key=f'{time}_{st}_{receipt}'
     data=old.prepare(ROWS,time,receipt,st)
     est=analysis.estimate(data,include_arrays=True)
     z=est['model_internal']
     smfit=sm.OLS(z['transY'],z['transX']).fit(cov_type='cluster',cov_kwds={'groups':z['groups'],'use_correction':True})
     e1=float(max(abs(smfit.params-z['beta'])))
     e2=float(max(abs(smfit.bse-z['se'])))
     if max(e1,e2)>1e-8:raise RuntimeError(key+' secondary implementation mismatch')
     report['cases'][key]={'n':est['n'],'coefficient_max_abs_difference':e1,'cluster_se_max_abs_difference':e2}
  (ROOT/'R048_CROSSCHECK.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
  print('independent statsmodels crosscheck eight specs PASSED',max(max(v['coefficient_max_abs_difference'],v['cluster_se_max_abs_difference']) for v in report['cases'].values()))
if __name__=='__main__':main()
