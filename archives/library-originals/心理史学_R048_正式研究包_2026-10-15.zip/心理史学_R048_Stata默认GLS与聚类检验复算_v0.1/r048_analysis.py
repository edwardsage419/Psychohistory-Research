#!/usr/bin/env python3
"""R048 -- reproduce Stata xtreg,re default moment-based feasible GLS, not ML.

Source: public author data/data.csv (Git blob 73c0...), via R047's exact source-derived
anonymous panel. Original author CSV and Stata .dta are not embedded in this package.
This script reproduces Table 4 (1,3) point estimates, approximate printed SE and
Wald chi2 at the author's original time-index and original Received definition.

Estimator follows Stata 15 xtreg manual, pp28-29 (PDF pages 27-28):
* within residual variance = SSE_within / (N - n - K + 1), K=number of columns including intercept;
* default between SSR estimator: sigma_u^2=max(0,SSR_between/(n-K) - sigma_e^2 / harmonic_mean(T_i));
* theta_i=1-sqrt(sigma_e^2/(T_i*sigma_u^2 + sigma_e^2));
* quasi demean and compute group-clustered sandwich variance with finite correction.
No randomization or causal mechanism identification claims are made.
"""
from __future__ import annotations
import argparse, collections, csv, json, pathlib, math
import numpy as np
from scipy.stats import chi2
import r047_analysis as upstream

ROOT=pathlib.Path(__file__).resolve().parent
NAMES=('intercept','deviation_t','punishment_unequal','punishment_equal')
PRINTED={
 'B':{'n':451,'coefficients':[3.117,-.839,-.123,-.065], 'se':[1.07,.12,.04,.01],'chi2':1.77},
 'A':{'n':414,'coefficients':[-1.932,-1.128,-.305,-.003], 'se':[.96,.12,.11,.04], 'chi2':7.31}
}

def ensure_input(data):
    if len(data)<15:raise ValueError('Fewer than 15 observations')
    for p,g,s,y,x in data:
        if not isinstance(x,(list,tuple,np.ndarray)) or len(x)!=4 or any(not np.isfinite(v) for v in [y,*x]):
            raise ValueError('Nonfinite or invalid design')

def arrays(data):
    ensure_input(data)
    X=np.asarray([z[4] for z in data],float)
    y=np.asarray([z[3] for z in data],float)
    people=np.asarray([z[0] for z in data])
    groups=np.asarray([z[1] for z in data])
    sessions=np.asarray([z[2] for z in data])
    if not np.allclose(X[:,0],1):raise ValueError('First column must be intercept')
    if np.linalg.matrix_rank(X)!=4:raise ValueError('Design not full rank')
    if len(np.unique(people))<5 or len(np.unique(groups))<4:raise ValueError('Too few people/groups')
    return X,y,people,groups,sessions

def variance_components(X,y,people,method='default'):
    if method not in ('default','sa'):raise ValueError('Unknown method')
    people_list,inverse=np.unique(people,return_inverse=True)
    n=len(people_list);N=len(y);k=X.shape[1]
    if N<=n+k-1 or n<=k:raise ValueError('Insufficient degrees of freedom')
    xmeans=np.vstack([X[inverse==j].mean(axis=0) for j in range(n)])
    ymeans=np.array([y[inverse==j].mean() for j in range(n)])
    size=np.array([np.sum(inverse==j) for j in range(n)])
    Xw=X-xmeans[inverse];yw=y-ymeans[inverse]
    wbeta=np.linalg.lstsq(Xw,yw,rcond=None)[0]
    sseW=float(np.sum((yw-Xw@wbeta)**2))
    sigma_e=sseW/(N-n-k+1)
    if sigma_e<=0:raise ValueError('Nonpositive within variance')
    if method=='default':
        b=np.linalg.lstsq(xmeans,ymeans,rcond=None)[0]
        sseB=float(np.sum((ymeans-xmeans@b)**2))
        hmean=n/np.sum(1/size)
        sigma_u=max(0.,sseB/(n-k)-sigma_e/hmean)
    else:
        b=np.linalg.lstsq(xmeans*np.sqrt(size)[:,None],ymeans*np.sqrt(size),rcond=None)[0]
        sseB=float(np.sum(size*(ymeans-xmeans@b)**2))
        p=(xmeans.T*size)@xmeans
        zz=(xmeans.T*(size**2))@xmeans
        trace=float(np.trace(np.linalg.solve(p,zz)))
        sigma_u=max(0.,(sseB-(n-k)*sigma_e)/(N-trace))
        hmean=n/np.sum(1/size)
    theta=1-np.sqrt(sigma_e/(size*sigma_u+sigma_e))
    return {'people_idx':inverse,'people':people_list,'sizes':size,'xmeans':xmeans,'ymeans':ymeans,
        'theta':theta,'sigma_e2':float(sigma_e),'sigma_u2':float(sigma_u),'n':n,'N':N,'K':k,
        'harmonic_nrounds':float(hmean),'ssr_within':sseW,'ssr_between':sseB}

def estimate(data,method='default',cluster='group',include_arrays=False):
    X,y,ids,groups,sessions=arrays(data)
    if cluster not in ('group','session','person'):raise ValueError('Unknown clustering rule')
    cvar={'group':groups,'session':sessions,'person':ids}[cluster]
    g=np.unique(cvar)
    if len(g)<3:raise ValueError('Too few clusters')
    v=variance_components(X,y,ids,method)
    transX=X-v['theta'][v['people_idx'],None]*v['xmeans'][v['people_idx']]
    transY=y-v['theta'][v['people_idx']]*v['ymeans'][v['people_idx']]
    XtX=transX.T@transX
    inv=np.linalg.inv(XtX)
    beta=inv@(transX.T@transY)
    residuals=transY-transX@beta
    meat=np.zeros((len(beta),len(beta)))
    for label in g:
        sc=transX[cvar==label].T@residuals[cvar==label]
        meat+=np.outer(sc,sc)
    adjustment=len(g)/(len(g)-1)*(len(y)-1)/(len(y)-len(beta))
    covariance=inv@meat@inv*adjustment
    se=np.sqrt(np.diag(covariance))
    contrast=np.array([0,0,1,-1.])
    diff=float(contrast@beta)
    var=float(contrast@covariance@contrast)
    stat=diff**2/var
    result={'n':len(y),'subjects':v['n'],'group_clusters':len(np.unique(groups)),
            'session_clusters':len(np.unique(sessions)),
            'variance_method':method,'cluster_method':cluster,
            'coefficients':dict(zip(NAMES,map(float,beta))),
            'cluster_standard_errors':dict(zip(NAMES,map(float,se))),
            'cluster_variance_correction':float(adjustment),
            'variance_components':{s:v[s] for s in ['sigma_e2','sigma_u2','harmonic_nrounds','ssr_within','ssr_between']},
            'wald_punishment_arm_difference':{'chi2_df1':float(stat),'p_chi2_df1':float(chi2.sf(stat,1)),
                      'contrast_unequal_minus_equal':float(diff),'se_contrast':float(np.sqrt(var))}}
    if include_arrays:result['model_internal']={'beta':beta,'se':se,'X':X,'y':y,'ids':ids,'groups':groups,
                'transX':transX,'transY':transY,'cov':covariance,'var':v,'residuals':residuals}
    return result

def all_models():
    panel=upstream.decode_panel();rows=upstream.longitudinal_design(panel)
    result={'round':'R048','provenance':{'source_git_blob':upstream.SOURCE_SHA,'source_read':'R047 anonymous derivative from full GitHub connector CSV','stata_binary_read':False,'native_stata_ran':False,'same_64_people_as_R047':True},
       'qc':{'person_round_rows':len(panel),'transitions':len(rows),'corrected_Received_cells':sum(z['raw']!=z['verified'] for z in panel if z['t']>=2)},
       'cases':{},'published_comparison':{},'robustness':{}}
    for strata in ['B','A']:
        for time in ['current','previous']:
            for receipt in ['raw','verified']:
                name=f'{time}_{strata}_{receipt}'
                data=upstream.prepare(rows,time,receipt,strata)
                f=estimate(data)
                result['cases'][name]=f
                if time=='current' and receipt=='raw':
                    pub=PRINTED[strata]
                    result['published_comparison'][strata]={'n_matches':f['n']==pub['n'],
                       'coef_point_errors':[f['coefficients'][k]-t for k,t in zip(NAMES,pub['coefficients'])],
                       'se_print_errors':[f['cluster_standard_errors'][k]-t for k,t in zip(NAMES,pub['se'])],
                       'chi2_error':f['wald_punishment_arm_difference']['chi2_df1']-pub['chi2'],
                       'published':pub,'reproduced':f}
    for st in ['B','A']:
        d=upstream.prepare(rows,'current','raw',st)
        result['robustness'][st]={
            'sa_option':estimate(d,method='sa'),
            'session_cluster':estimate(d,cluster='session'),
            'leave_one_group':{},'leave_one_session':{}
        }
        for g in sorted({z[1] for z in d}):
            sub=[z for z in d if z[1]!=g]
            if len({z[1] for z in sub})>=4:
                result['robustness'][st]['leave_one_group'][g]=estimate(sub)
        for session in sorted({z[2] for z in d}):
            sub=[z for z in d if z[2]!=session]
            if len({z[2] for z in sub})>=3:
                result['robustness'][st]['leave_one_session'][str(session)]=estimate(sub)
    return result

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',default='R048_RESULTS.json');ap.add_argument('--audit-csv',default=None);ap.add_argument('--audit-dta',default=None)
    args=ap.parse_args()
    if args.audit_csv:print(upstream.compare_original_source(args.audit_csv))
    if args.audit_dta:
        b=pathlib.Path(args.audit_dta).read_bytes()
        if upstream.git_blob_sha(b)!=upstream.DTA_SHA:raise ValueError('Original DTA source hash mismatch')
        import pandas as pd
        df=pd.read_stata(args.audit_dta,convert_categoricals=False)
        print('Stata binary source verified; rows:',len(df),'columns',df.columns.tolist())
        if 'received' not in df or 'uniquesubject' not in df:raise ValueError('Missing Stata analysis variables')
    out=all_models();(ROOT/args.output).write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    for st in ['B','A']:
        o=out['published_comparison'][st]['reproduced'];print(st,'N',o['n'],'beta',o['coefficients'],'SE',o['cluster_standard_errors'],'Wald',o['wald_punishment_arm_difference'])
    print('Saved',ROOT/args.output)
if __name__=='__main__':main()
