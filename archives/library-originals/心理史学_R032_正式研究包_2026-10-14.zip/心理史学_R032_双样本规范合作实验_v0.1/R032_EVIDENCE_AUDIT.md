# 心理史学 R032 正式证据审计

日期：2026-10-14。状态：**完成新增独立团队两项原始公开个体CSV的工具端审查，并在本地对其严格派生的分层计数做独立统计分析。** 论文原始完整模型仍未完成本地端到端复现。

## 1. 科研问题

群体互惠规范的随机信息提示是否改变陌生人的实际合作选择？这种影响能否跨城市、职业与国家场景稳定成立？

本轮为“行为选择如何受规范提示和制度/地方线索影响”的独立跨研究测试，不声称观察了动态规范形成、网络行为扩散、独立社会惩罚或历史演化。

## 2. 独立来源和证据边界

- Mario Molina、Victor Nee、Hakan Holm，*Cooperation with Strangers: Spillover of Community Norms*，*Organization Science*，DOI `10.1287/orsc.2021.1521`；2022-03-25在线出版；卷34期6（2023）。论文：https://pubsonline.informs.org/doi/10.1287/orsc.2021.1521
- 官方复现仓库：https://github.com/mariomolinam/cooperation_with_strangers 。连接器端实读`README.md`、`code/mturk_study.R`、`code/credamo_study.R`、两份公开原始CSV。
- Credamo源 `data/credamo_data_all.csv` Git blob `29cd29b81365c2507acc397cc27f3e020f9a76fe`；MTurk源`data/mturk_data_all.csv` Git blob `7f89062511d49c002431172e7fe1153e877448e5`。具体分层计数已从完整CSV逐行重新聚合，并在本地持久化为 `CELL_SUMMARIES.json`。尚未把完整原始CSV下载到本地，且不在包内散发受试者层记录；`--source-dir`提供经Git对象SHA1核验的完整本地复算入口。
- Credamo预注册：https://osf.io/tu8vc ；MTurk预注册：https://osf.io/5mkz4 。作者代码和论文列出注册入口，但此环境未取回实际注册正文，预分析锁定条件未独立核实。
- 观察性原CEO样本须经CISER许可取得，本轮没有尝试规避其资料使用限制；未把该观察性样本与上述两个随机实验混用。

## 3. 六关口审查

| 关口 | Credamo（中国） | MTurk（美国） |
|---|---|---|
| 来源 | 两份实验CSV之一已由GitHub连接器整表读取并核对Git SHA | 同左 |
| 随机化单位 | 作者描述为个体分配规范情景，分配算法与日志未独立取得 | 作者描述为个体分配三种情景，分配算法与日志未独立取得 |
| 干预 | 同城企业规范违背后的报复性制裁将发生（R）或什么都不会发生（N） | 报复性制裁（R）、社区制裁（C）、无制裁（N） |
| 行为结局 | 一次性囚徒困境合作决策，源变量`cooperation`为0/1 | 一次性囚徒困境合作决策，`PD_choice == "Choice A"` |
| 流失/排除 | 源599人，注意力通过588人，排除11人，处理后筛选 | 源610人；公开CSV无同口径注意力排除步骤 |
| 权限和复现 | GitHub直接公开两份实验匿名CSV；原CEO观察性样本有许可约束 | 同左 |

**重要限定：** 一次性激励兼容博弈属于实验真实经济行为选择，不等于现实组织持续合作或网络传播。两个国家的处理文案和受试者来源不同，不能直接用“中美效应差”作文化因果推断。

## 4. 预先指定研究关口与本轮探索性分析

该实验作者主结果采用含人口变量的logit模型。本轮统计为已看见样本后的独立来源比较，所有下面P值和异质性试验均按**探索性**标注，不属于论文的确认性注册复核。

### 4.1 中国 Credamo

- 整体：N组 `139/293 = 47.4403%`，R组 `145/295 = 49.1525%`；差 `+1.7123` 个百分点；Wald 95%区间 `[-6.3648, +9.7893]` 个百分点，双侧 P=`0.67777`。
- 仅调整城市与职业主效应的二项logit：处理组OR=`1.05737`，P=`0.73819`。这不是作者包含完整人口学变量的Model 1。
- 城市原始差异：南京 `+16.93`；温州 `+18.12`；杭州 `−1.00`；常州 `−11.84`；上海 `−15.34` 个百分点。五城的双侧Wald比较经Holm校正后，所有调整P均大于0.20。
- 异质性：二项GLM `rate ~ treatment + C(city) + C(population)` 与添加 `treatment × city` 的模型进行似然比检验，LR=`11.76278`、df=`4`，探索性 P=`0.01921`。此检验支持效应随城市变化的可能性，不证明社会惩罚、制度强度或地方文化是变化原因；城市只有五个且本检验为事后指定。
- 南京经理亚组：对照 `12/25 = 48.0%`，处理 `25/33 = 75.76%`；原始差 `+27.76` 个百分点，双侧Wald P=`0.0260`。十个城市×职业亚组Holm调整P=`0.2316`。论文报告经理南京条件下经完整人口学控制的有利结果，不能把两种模型的P值混称重复确认。
- 排除敏感性：原本排除的11人中，N组4人3合作，R组7人5合作。全部599人计数时处理组合作 `150/302=49.67%`，对照组 `142/297=47.81%`，差 `+1.8574` 个百分点，双侧 P=`0.64925`。该敏感性保留了全部观测行为，不等于严格ITT，因为仍未知是否有从未进入公开CSV的随机化对象。

### 4.2 美国MTurk

- 无制裁提示 N组 `76/195=38.97%`；社区制裁提示 C组 `73/187=39.04%`；报复性制裁提示 R组 `104/228=45.61%`。
- C−N `+0.063` 个百分点，双侧Wald P=`0.9899`。
- R−N `+6.640` 个百分点，95% Wald区间 `[−2.776,+16.055]` 个百分点，双侧P=`0.1669`。
- 本轮数据整体与作者“美国实验未得到组间合作差异证据”的描述一致，但没有重做作者全部协变量模型或实验注册分析。

## 5. 对模型的约束

1. 不应设定跨样本统一的“规范提示必然提升合作”系数。两个随机化实验整体都没有可辨的普遍正效应。
2. 中国数据包含城市间方向相反的点估计和一个探索性异质性信号。后续候选模型应明确`treatment × context`，并用留出场景评估预测，不允许在五城市中挑选显著城市来反推出机制。
3. 本研究**操纵的是关于当地规范执行的文字信息**。被试实际接收到的信息、对制裁的心理预期、对发送者的信任、其私下规范性信念都未独立作行为前后机制测量。因此无法把处理总效应拆解成PESEN的独立制裁项。
4. 对美国和中国的效应只能分别记账。社会身份、经济激励、语言、时间和样本构成不同，跨社会效应差不识别文化作用。
5. 不能把此一次性囚徒困境研究当作群体网络扩散或长期历史变化的观测。

## 6. 复现等级和未完成项

`SOURCE_PUBLIC_RAW_READ = YES_CONNECTOR_SIDE`；`ORIGINAL_GIT_OBJECT_IDS_VERIFIED = YES`；`DERIVED_STRATA_COUNTS_VERIFIED = YES_CONNECTOR_SIDE`；`PYTHON_DERIVED_COUNTS_REANALYSIS = YES`；`LOCAL_RAW_BYTE_END_TO_END = NO`；`ORIGINAL_FULL_LOGISTIC_MODELS_REPRODUCED = NO`；`PREREG_TEXT_VERIFIED = NO`；`RANDOMIZATION_LOG_VERIFIED = NO`；`INDEPENDENT_SANCTION_MECHANISM_IDENTIFIED = NO`。

源表中并无用于验证持续行为扩散的时序互动信息。对PESEN v0.1的决定：**冻结、不改动**。

## 7. R033议程（按证据获取顺序）

1. 尝试通过有访问权限的环境取得Credamo和MTurk官方CSV的原始字节；严格使用包内Git blob验证及 `--source-dir` 样本聚合比较，然后运行作者R程序，以完全复现其表6和附录D。逐条核查每项被排除受试者和意向处理分母。
2. 获取两项OSF预注册真正的存档内容，确认假设、城市异质性、经理交互、单侧检验和多重比较家族是否事前确定；在此前标注事后探索。
3. 单独审查2021 Salazar等真实草吸管消费现场随机实验的Figshare原始数据作为自然场景外部样本：https://doi.org/10.6084/m9.figshare.15134754 。确定随机化究竟由日、服务台还是消费个体承担，并做分层/时间序列相关性审计，避免以每次交易为独立随机单元。
4. 建立一条**可证伪的竞争预测**：单一稳定规范效应模型 vs 地方条件交互模型；训练、验证和探索性模型区分遵循文档化时间顺序。缺乏真实跨场景留出数据时，模型仍停留机制候选，不宣称预测成功。

## 8. 可检查来源

- 论文 `https://doi.org/10.1287/orsc.2021.1521`
- GitHub `https://github.com/mariomolinam/cooperation_with_strangers`
- 源码 `https://github.com/mariomolinam/cooperation_with_strangers/blob/main/code/credamo_study.R`
- 源码 `https://github.com/mariomolinam/cooperation_with_strangers/blob/main/code/mturk_study.R`
- Credamo注册 `https://osf.io/tu8vc`，MTurk注册 `https://osf.io/5mkz4`
- 候选后续独立自然场景数据 `https://doi.org/10.6084/m9.figshare.15134754`
