# 心理史学 R032 正式研究包

2026-10-14 | 双平台规范提示与陌生人合作实验的独立复算及外部一致性审计。

## 文档

- `R032_EVIDENCE_AUDIT.md`：科研审计、发现、不能声称的机制、下一轮门槛。
- `CELL_SUMMARIES.json`：从作者两份完整公开CSV由GitHub连接器读取并直接聚合的20个中国城市×职业×处理单元和3个美国处理单元，附准确Git blob SHA1，不包含参与者级记录。
- `r032_analysis.py`：从分组计数复算处理率、Wald区间、5城市Holm校正、10亚组Holm校正、城市处理异质性LR检验、美国2臂对照与中国排除敏感性。可对本地官方CSV执行SHA1和逐单元聚合校验。
- `R032_RESULT.json`：已经运行成功的派生数据分析结果；明确本地未取回原始CSV。
- `tests/test_r032.py`：24项小规模构造数据和数值不变量的软件测试。

## 离线复算（分层派生计数）

```bash
python -m pip install numpy pandas scipy statsmodels
python r032_analysis.py
python -m unittest discover -s tests -v
```

## 原始字节端到端复算（需要自己取得作者公开仓库）

```bash
git clone https://github.com/mariomolinam/cooperation_with_strangers.git
python r032_analysis.py --source-dir ./cooperation_with_strangers
```

`--source-dir`要求相应原始CSV的Git blob SHA1与`CELL_SUMMARIES.json`所列值完全相符，随后逐单元比较预存计数，检验失败则中止。原作者GitHub仓库的文件版本可能未来改变，因此应检出与记录中的blob版本一致的提交。本包因本地DNS网络限制没有执行此端到端命令，**也不应声称其已通过**。

## 纪律

PESEN v0.1保持冻结。原始作者的随机化日志、OSF实际注册文书和个人协变量调整的logit模型尚未独立获取验证。探索性显著性仅用于规划后续验证，不构成普适规律或确认性社会惩罚效应。
