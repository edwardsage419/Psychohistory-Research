#!/usr/bin/env python3
"""R032: audit and analyze public aggregated randomized cooperation-choice experiments.

The accompanying CELL_SUMMARIES.json was aggregated from the original GitHub CSVs
read by the connector. This analysis operates on counts, not individual records.
Optional --source-dir independently checks local Git raw bytes and re-aggregates them.
All subgroup comparisons are exploratory; exact assignment mechanism not yet audited.
"""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
from collections import defaultdict

import numpy as np
import pandas as pd
from scipy.stats import chi2, norm
import statsmodels.api as sm
import statsmodels.formula.api as smf

DIR = Path(__file__).resolve().parent


def git_blob_sha1(raw: bytes) -> str:
    return hashlib.sha1(b'blob ' + str(len(raw)).encode('ascii') + b'\0' + raw).hexdigest()


def load_cells(path=DIR / 'CELL_SUMMARIES.json'):
    data = json.loads(Path(path).read_text(encoding='utf8'))
    validate_cells(data)
    return data


def validate_cells(data):
    C = data['credamo_cells']; U = data['mturk_cells']
    assert len(C) == 20 and len(U) == 3
    assert sum(x[3] for x in C) == 588
    assert sum(x[4] for x in C) == 284
    assert sum(x[1] for x in U) == 610
    assert sum(x[2] for x in U) == 253
    assert set(x[2] for x in C) == {'R', 'N'}
    assert set(x[0] for x in U) == {'R', 'N', 'C'}
    assert all(0 <= x[4] <= x[3] for x in C)
    assert all(0 <= x[2] <= x[1] for x in U)
    assert len({(x[0], x[1], x[2]) for x in C}) == 20


def parse_original(path, expected_sha):
    raw = Path(path).read_bytes()
    observed = git_blob_sha1(raw)
    if observed != expected_sha:
        raise ValueError(f'Git blob SHA1 mismatch for {path}: {observed} != {expected_sha}')
    return list(csv.DictReader(raw.decode('utf-8-sig').splitlines()))


def reconstruct_from_sources(data, source_dir):
    source_dir = Path(source_dir)
    s = data['provenance']
    cn = parse_original(source_dir / s['credamo']['path'], s['credamo']['git_blob_sha1'])
    us = parse_original(source_dir / s['mturk']['path'], s['mturk']['git_blob_sha1'])
    assert len(cn) == 599 and len(us) == 610
    china = defaultdict(lambda: [0, 0])
    for row in cn:
        if row['attention_check'] != '5':
            continue
        k = row['city'], row['population'], row['treatment']
        china[k][0] += 1
        china[k][1] += int(row['cooperation'])
    original_cn = {(r[0],r[1],r[2]):[r[3],r[4]] for r in data['credamo_cells']}
    assert dict(china) == original_cn, 'Credamo source/derived cell mismatch'
    america = defaultdict(lambda: [0, 0])
    for row in us:
        t = row['treatment']; choice = row['PD_choice']
        assert choice in ('Choice A', 'Choice B')
        america[t][0] += 1
        america[t][1] += int(choice == 'Choice A')
    original_us = {r[0]:[r[1],r[2]] for r in data['mturk_cells']}
    assert dict(america) == original_us, 'MTurk source/derived cell mismatch'
    return {'status':'SOURCE_RAW_BYTES_AND_CELLS_VERIFIED','credamo_records':len(cn),'mturk_records':len(us)}


def contrast(c0, c1):
    """c0=[n,s], c1=[n,s]; treatment minus control, unadjusted Wald inference."""
    n0,y0=c0; n1,y1=c1
    p0=y0/n0; p1=y1/n1; d=p1-p0
    se=math.sqrt(p0*(1-p0)/n0+p1*(1-p1)/n1)
    z=d/se if se>0 else float('nan')
    return {'n0':n0,'y0':y0,'n1':n1,'y1':y1,
            'rate0':p0,'rate1':p1,'difference':d,'se_wald':se,
            'ci95_wald':[d-1.96*se,d+1.96*se],
            'p_two_sided_wald':2*norm.sf(abs(z))}


def holm(pvalues):
    n=len(pvalues); order=sorted(range(n), key=lambda i:pvalues[i])
    out=[None]*n; running=0.0
    for rank,i in enumerate(order):
        running=max(running,(n-rank)*pvalues[i]); out[i]=min(1.0,running)
    return out


def aggregate(rows):
    return [sum(r[0] for r in rows),sum(r[1] for r in rows)]


def analyze(data):
    cells=data['credamo_cells']
    chi=pd.DataFrame(cells,columns=['city','population','arm','n','success'])
    chi['treatment']=(chi['arm']=='R').astype(int)
    chi['rate']=chi['success']/chi['n']
    us={name:[n,y] for name,n,y in data['mturk_cells']}
    arm_counts={arm:[int(g.n.sum()),int(g.success.sum())] for arm,g in chi.groupby('arm')}
    overall=contrast(arm_counts['N'],arm_counts['R'])
    cities=[]
    for city,g in sorted(chi.groupby('city')):
        gg={arm:[int(d.n.sum()),int(d.success.sum())] for arm,d in g.groupby('arm')}
        v=contrast(gg['N'],gg['R']); v['city']=city;cities.append(v)
    corrected=holm([x['p_two_sided_wald'] for x in cities])
    for x,p in zip(cities,corrected):x['p_holm_5_cities']=p
    subgroup=[]
    for (city,pop),g in sorted(chi.groupby(['city','population'])):
        gg={arm:[int(d.n.sum()),int(d.success.sum())] for arm,d in g.groupby('arm')}
        v=contrast(gg['N'],gg['R']);v['city']=city;v['population']=pop;subgroup.append(v)
    for v,p in zip(subgroup,holm([x['p_two_sided_wald'] for x in subgroup])):
        v['p_holm_10_city_population']=p
    # Aggregate binomial likelihood; these exact models only use city and manager
    # labels, not the paper's person-level demographic covariates.
    fam=sm.families.Binomial()
    g0=smf.glm('rate ~ treatment + C(city) + C(population)',data=chi,
                family=fam, freq_weights=chi.n).fit()
    g1=smf.glm('rate ~ treatment * C(city) + C(population)',data=chi,
                family=fam, freq_weights=chi.n).fit()
    hetero_lr=2*(g1.llf-g0.llf); hetero_df=int(g1.df_model-g0.df_model)
    baseline={'or':float(math.exp(g0.params['treatment'])),
              'coef':float(g0.params['treatment']),
              'se':float(g0.bse['treatment']),
              'p':float(g0.pvalues['treatment'])}
    manager_nj=next(v for v in subgroup if v['city']=='Nanjing' and v['population']=='managers')
    # Sensitivity: include excluded attention-check failures, with their observed
    # choices, without assigning their city/manager subgroup.
    fail={k:[n,y] for k,n,y in data['credamo_fail_counts']}
    allC={k:[arm_counts[k][0]+fail[k][0],arm_counts[k][1]+fail[k][1]] for k in ('N','R')}
    source_all=contrast(allC['N'],allC['R'])
    return {
        'analysis_scope':'Connector-aggregated public original CSVs, Python derived-cell reanalysis',
        'china':{
           'overall_unadjusted':overall,
           'city_unadjusted':cities,
           'city_population_unadjusted':subgroup,
           'city_population_adjusted_global_logistic':baseline,
           'treatment_x_city_likelihood_ratio':{'LR':float(hetero_lr),'df':hetero_df,'p_chisq':float(chi2.sf(hetero_lr,hetero_df)),
                                                  'model':'binomial GLM, rates with frequency weights; city and population main effects, city x treatment'},
           'nanjing_managers_unadjusted':manager_nj,
           'attention_failure_included_sensitivity':source_all,
        },
        'us':{'sample_n':sum(n for n,y in us.values()),
              'unadjusted_retaliation_vs_no_norm':contrast(us['N'],us['R']),
              'unadjusted_community_vs_no_norm':contrast(us['N'],us['C']),
              'all_arms':{k:{'n':x[0],'cooperate':x[1],'rate':x[1]/x[0]} for k,x in us.items()}},
        'warnings':[
            'Post-hoc, exploratory comparisons and Wald intervals are unadjusted except explicitly stated Holm fields.',
            'No direct cross-country causal contrast: treatment variants, population, language and protocol differ.',
            'No direct observations of private beliefs, realized sanctions, group ties, or long-run diffusion.',
            'Randomization implementation and preregistration text not independently verified.',
            'China study attention-check exclusions postassignment: original ITT denominator includes 11 more subjects.',
            'All inferential tests assume independent participants; full randomization structure not verified.',
            'Paper fully adjusted models with individual covariates not replicated from stratified aggregate cells.'
        ]
    }


def main():
    p=argparse.ArgumentParser();p.add_argument('--source-dir',type=Path,default=None)
    p.add_argument('--out',type=Path,default=DIR/'R032_RESULT.json')
    args=p.parse_args();data=load_cells()
    res=analyze(data)
    res['raw_source_status']=(reconstruct_from_sources(data,args.source_dir) if args.source_dir is not None
                              else {'status':'NOT_LOCAL; GitHub connector full read was verified, only cell summaries available locally'})
    args.out.write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({
        'CHINA_N':588,'CHINA_GLOBAL_DIFF':res['china']['overall_unadjusted']['difference'],
        'CHINA_GLOBAL_P':res['china']['overall_unadjusted']['p_two_sided_wald'],
        'CHINA_HETEROGENEITY_P':res['china']['treatment_x_city_likelihood_ratio']['p_chisq'],
        'US_N':610, 'RAW_STATUS':res['raw_source_status']['status']},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
