"""Unit checks on derived aggregate logic; not a substitute for full source bytes."""
import sys
import unittest
from pathlib import Path
from copy import deepcopy
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from r032_analysis import load_cells, validate_cells, contrast, holm, analyze, git_blob_sha1

class R032Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data=load_cells()
        cls.out=analyze(cls.data)

    def test_01_git_sha_toy(self):
        self.assertEqual(git_blob_sha1(b'test content\n'), 'd670460b4b4aece5915caf5c68d12f560a9fe3e4')
    def test_02_china_total(self):
        self.assertEqual(sum(c[3] for c in self.data['credamo_cells']),588)
    def test_03_china_successes(self):
        self.assertEqual(sum(c[4] for c in self.data['credamo_cells']),284)
    def test_04_china_balanced_arms(self):
        v=self.out['china']['overall_unadjusted'];self.assertEqual((v['n0'],v['n1']), (293,295))
    def test_05_china_global_estimate(self):
        self.assertAlmostEqual(self.out['china']['overall_unadjusted']['difference'],145/295-139/293)
    def test_06_china_global_interval_includes_zero(self):
        lo,hi=self.out['china']['overall_unadjusted']['ci95_wald'];self.assertTrue(lo<0<hi)
    def test_07_china_city_count(self):
        self.assertEqual(len(self.out['china']['city_unadjusted']),5)
    def test_08_china_20_cells(self):
        self.assertEqual(len(self.data['credamo_cells']),20)
    def test_09_nanjing_manager_difference(self):
        x=self.out['china']['nanjing_managers_unadjusted'];self.assertAlmostEqual(x['difference'],25/33-12/25)
    def test_10_wenzhou_positive(self):
        v=next(x for x in self.out['china']['city_unadjusted'] if x['city']=='Wenzhou');self.assertGreater(v['difference'],0)
    def test_11_shanghai_negative(self):
        v=next(x for x in self.out['china']['city_unadjusted'] if x['city']=='Shanghai');self.assertLess(v['difference'],0)
    def test_12_holm_monotone_and_dominates(self):
        p=[.01,.02,.009,.9]; adj=holm(p);self.assertTrue(all(a>=b for a,b in zip(adj,p)))
        self.assertEqual(holm([.1]),[.1])
    def test_13_holm_no_city_survives(self):
        self.assertTrue(all(x['p_holm_5_cities']>.05 for x in self.out['china']['city_unadjusted']))
    def test_14_us_total(self):
        self.assertEqual(self.out['us']['sample_n'],610)
    def test_15_us_retaliation_comparison(self):
        x=self.out['us']['unadjusted_retaliation_vs_no_norm'];self.assertAlmostEqual(x['difference'],104/228-76/195)
    def test_16_us_community_comparison(self):
        x=self.out['us']['unadjusted_community_vs_no_norm'];self.assertAlmostEqual(x['difference'],73/187-76/195)
    def test_17_us_both_uncertain(self):
        self.assertGreater(self.out['us']['unadjusted_retaliation_vs_no_norm']['p_two_sided_wald'],.05)
        self.assertGreater(self.out['us']['unadjusted_community_vs_no_norm']['p_two_sided_wald'],.05)
    def test_18_city_heterogeneity_df(self):
        self.assertEqual(self.out['china']['treatment_x_city_likelihood_ratio']['df'],4)
    def test_19_reject_wrong_derived_total(self):
        z=deepcopy(self.data);z['credamo_cells'][0][3]+=1
        with self.assertRaises(AssertionError):validate_cells(z)
    def test_20_reject_duplicate_cells(self):
        z=deepcopy(self.data);z['credamo_cells'][1][:3]=z['credamo_cells'][0][:3]
        with self.assertRaises(AssertionError):validate_cells(z)
    def test_21_attention_sensitivity_denominator(self):
        v=self.out['china']['attention_failure_included_sensitivity'];self.assertEqual(v['n0']+v['n1'],599)
    def test_22_binomial_positive_se(self):
        v=contrast([20,10],[20,15]);self.assertGreater(v['se_wald'],0)
    def test_23_binomial_symmetric_null(self):
        v=contrast([20,10],[20,10]);self.assertEqual(v['difference'],0);self.assertAlmostEqual(v['p_two_sided_wald'],1)
    def test_24_mismatch_sha(self):
        self.assertNotEqual(git_blob_sha1(b'changed'),self.data['provenance']['credamo']['git_blob_sha1'])

if __name__=='__main__':unittest.main()
