#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, zipfile, subprocess, sys

ROOT=Path(__file__).resolve().parent
ARCHIVE=ROOT.parent/'心理史学_R061_正式研究包_2026-10-15.zip'
FILES=[
 'R061_REPORT.md', 'PROJECT_STATE_R061.md', 'R062_RESEARCH_GATE.md',
 'README.md', 'SOURCE_LEDGER.json', 'R061_RESULTS.json',
 'R061_ACCURACY_BY_PERSON.csv', 'R061_CV_DELTAS_BY_PERSON.csv',
 'r061_replay.py', 'test_r061.py', 'build_results.py', 'build_package.py',
 'TEST_OUTPUT.txt',
]

def sha256(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    for fn in FILES:
        if not (ROOT/fn).is_file():raise RuntimeError(f'Missing {fn}')
    test=subprocess.run([sys.executable,'-m','unittest','-q','test_r061.py'],cwd=ROOT,capture_output=True,text=True)
    if test.returncode!=0:raise RuntimeError(test.stdout+test.stderr)
    # Strong derived-statistic consistency test, independent of R061_RESULTS writer.
    summary=json.loads((ROOT/'R061_RESULTS.json').read_text(encoding='utf8'))
    if summary['experiments']['1']['cv']['delta_social_minus_private']!=0:raise RuntimeError('Task1 score drift')
    if abs(summary['experiments']['2']['cv']['delta_social_minus_private']-.005075232352117148)>1e-12:raise RuntimeError('Task2 score drift')
    entries=[{'file':fn,'bytes':(ROOT/fn).stat().st_size,'sha256':sha256(ROOT/fn)} for fn in FILES]
    manifest={'round':'R061','status':'RESEARCH_ARCHIVED_NOT_FROZEN_MODEL_UPDATED','date':'2026-10-15','files':entries,'tests':27,'source_raw_local_replay':False}
    (ROOT/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    allfiles=FILES+['MANIFEST.json']
    (ROOT/'SHA256SUMS.txt').write_text(''.join(f'{sha256(ROOT/fn)}  {fn}\n' for fn in allfiles),encoding='utf8')
    allfiles+=['SHA256SUMS.txt']
    with zipfile.ZipFile(ARCHIVE,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for fn in allfiles:z.write(ROOT/fn,arcname=f'psychohistory_R061/{fn}')
    with zipfile.ZipFile(ARCHIVE) as z:
        if z.testzip() is not None:raise RuntimeError('ZIP CRC failure')
        if len(z.namelist())!=len(allfiles):raise RuntimeError('ZIP missing entries')
        for entry in entries:
            if hashlib.sha256(z.read('psychohistory_R061/'+entry['file'])).hexdigest()!=entry['sha256']:
                raise RuntimeError('Hash mismatch in ZIP: '+entry['file'])
    print(json.dumps({'status':'PASS','archive':str(ARCHIVE),'entries':len(allfiles),'zip_bytes':ARCHIVE.stat().st_size,'zip_sha256':sha256(ARCHIVE),'tests':27,'local_raw_verified':False},ensure_ascii=False))

if __name__=='__main__':main()
