from pathlib import Path
import csv, json, random, statistics
ROOT=Path(__file__).parent
ACC=list(csv.DictReader((ROOT/'R061_ACCURACY_BY_PERSON.csv').open(encoding='utf-8')))
CV=list(csv.DictReader((ROOT/'R061_CV_DELTAS_BY_PERSON.csv').open(encoding='utf-8')))
source={
  '1': {'path':'data/task1.csv','repo':'hrl-team/mfree_imitation','git_blob_sha1':'6f90784a49c26c92806b4876cb0ce4b446f810b1','bytes':652938,'raw_rows':9600,'participant_count':24,'sessions_per_person':4,'private_decisions':5760,'demonstrations':3840,'correct_private':4308},
  '2': {'path':'data/task2.csv','repo':'hrl-team/mfree_imitation','git_blob_sha1':'5239155f233d42e4dbbe3f986865d5459a3e9cee','bytes':905163,'raw_rows':13200,'participant_count':44,'sessions_per_person':3,'private_decisions':7920,'demonstrations':5280,'correct_private':4916},
}

def avg(a): return sum(a)/len(a)
def draw_mean(seq, rng):return sum(seq[rng.randrange(len(seq))] for _ in range(len(seq)))/len(seq)
def interval(a):
    a.sort();return [a[int(len(a)*.025)],a[int(len(a)*.975)-1]]
result={'round':'R061','date':'2026-10-15','data_retrieval':'GITHUB_CONNECTOR_REAL_AUTHOR_CSV','local_author_raw_byte_replay':'NOT_COMPLETED','source':source,'model':{'training':'leave_one_subject_out_nested_grid','grid_points':192,'per_stimulus_state':True,'same_private_reward_learning_rule':True,'social_learning_nonnegative_including_zero':True,'reward_for_demonstrator_unavailable':True,'primary_metric':'binary_logloss_of_real_private_cgb_choice'},'experiments':{}}
for task in ('1','2'):
    A=[z for z in ACC if z['task']==task]
    D=[float(z['vs_minus_rw_logloss']) for z in CV if z['task']==task]
    skilled=[float(z['skilled'])-float(z['private']) for z in A if z['skilled']]
    unskilled=[float(z['unskilled'])-float(z['private']) for z in A if z['unskilled']]
    assert len(D)==len(A)==source[task]['participant_count']
    rng=random.Random(61701+int(task));bootstrap=[];cv_bootstrap=[]
    for b in range(20000):
        if task=='1':
            draw=[A[rng.randrange(len(A))] for _ in A]
            bootstrap.append(avg([float(z['skilled'])-float(z['unskilled']) for z in draw]))
        else:
            bootstrap.append(draw_mean(skilled,rng)-draw_mean(unskilled,rng))
        cv_bootstrap.append(draw_mean(D,rng))
    p=None
    if task=='2':
        labels=skilled+unskilled;ob=avg(skilled)-avg(unskilled);cnt=0
        for _ in range(50000):
            rng.shuffle(labels)
            d=avg(labels[:len(skilled)])-avg(labels[len(skilled):])
            if abs(d)>=abs(ob)-1e-15:cnt+=1
        p=cnt/50000
    result['experiments'][task]={
       'accuracy':{
          'private_correct_choice_rate':source[task]['correct_private']/source[task]['private_decisions'],
          'skilled_minus_private':avg(skilled),'unskilled_minus_private':avg(unskilled),
          'skilled_minus_unskilled_diff_in_differences':avg(skilled)-avg(unskilled),
          'participants_skilled':len(skilled),'participants_unskilled':len(unskilled),
          'bootstrap_95_exploratory':interval(bootstrap),'label_permutation_p_two_sided_conditional_exchangeability':p,
       },
       'cv':{
          'delta_social_minus_private':avg(D),
          'selected_social_better_subjects':sum(x < -1e-12 for x in D),
          'delta_bootstrap_95_exploratory':interval(cv_bootstrap),
          'source_true_model_losses':({'RW':0.47395591903316253,'VS_nested':0.47395591903316253} if task=='1' else {'RW':0.6042948357827496,'VS_nested':0.6093700681348669}),
          'selected_social_learning_zero_subjects':(24 if task=='1' else 9),
       }
    }
(ROOT/'R061_RESULTS.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print(json.dumps({'exp1':result['experiments']['1'],'exp2':result['experiments']['2']},indent=2))
