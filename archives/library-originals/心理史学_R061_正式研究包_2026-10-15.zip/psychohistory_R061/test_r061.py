import copy
import csv
import io
import math
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import r061_replay as r


def make_raw(task=1, subjects=("3",), spoil=None):
    """Small artificial dataset with 100-step sessions; never presented as author data."""
    fields = ["expid", "id", "session", "trial", "condition.demskill" if task == 1 else "group.demskill", "condition.obs", "state", "p1", "p2", "ctrial", "clr", "cgb", "rtime", "rgb", "out"]
    f = io.StringIO(newline="")
    writer = csv.DictWriter(f, fieldnames=fields)
    writer.writeheader()
    for subj in subjects:
        for session in range(1, r.SOURCE[task]["sessions"] + 1):
            for trial in range(1, 101):
                demonstrator = (trial % 5 == 0)
                c = int((trial // 8) % 2 == 0)
                skill = ("skilled.dem" if session % 2 else "unskilled.dem")
                row = {"expid": subj, "id": "dem" if demonstrator else subj,
                       "session": session, "trial": trial,
                       "condition.obs": "Choice" if demonstrator or session % 2 else "Private",
                       "state": session, "p1": .7 if task == 1 else .6,
                       "p2": .3 if task == 1 else .4, "ctrial": trial,
                       "clr": -1 if c else 1, "cgb": c,
                       "rtime": .8, "rgb": "NA" if demonstrator else c,
                       "out": "NA" if demonstrator else 1 if c else -1}
                row[fields[4]] = skill if task == 2 or row["condition.obs"] == "Choice" else "private"
                if spoil:
                    spoil(row)
                writer.writerow(row)
    return f.getvalue().encode("utf-8")


class Integrity(unittest.TestCase):
    def test_author_sha_fail_closed(self):
        with self.assertRaisesRegex(ValueError, "SHA1 mismatch"):
            r.parse_data(make_raw(), 1)

    def test_source_sha_definitions(self):
        self.assertEqual(len(r.SOURCE[1]["sha"]), 40)
        self.assertEqual(len(r.SOURCE[2]["sha"]), 40)

    def test_gitblob_function(self):
        import hashlib
        b = b"abc"
        self.assertEqual(r.git_blob_sha(b), hashlib.sha1(b"blob 3\0abc").hexdigest())

    def test_synthetic_task1(self):
        p, c = r.parse_data(make_raw(), 1, False)
        self.assertEqual((len(p), c["dem"], c["private"]), (1, 80, 320))

    def test_synthetic_task2(self):
        p, c = r.parse_data(make_raw(2), 2, False)
        self.assertEqual((len(p), c["dem"], c["private"]), (1, 60, 240))

    def test_invalid_task(self):
        with self.assertRaises(ValueError):
            r.parse_data(make_raw(), 9, False)

    def test_duplicate_trial(self):
        text = make_raw().decode("utf-8").splitlines()
        text[2] = text[1]
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            r.parse_data(("\n".join(text) + "\n").encode(), 1, False)

    def test_short_session(self):
        text = make_raw().decode("utf-8").splitlines()
        with self.assertRaisesRegex(ValueError, "Missing/duplicate"):
            r.parse_data(("\n".join(text[:-1]) + "\n").encode(), 1, False)

    def test_bad_demo_outcome(self):
        def spoil(row):
            if row["id"] == "dem":
                row["out"] = "1"
        with self.assertRaisesRegex(ValueError, "Demonstrator"):
            r.parse_data(make_raw(spoil=spoil), 1, False)

    def test_bad_stimulus_choice(self):
        def spoil(row):
            if row["trial"] == 20:
                row["cgb"] = 4
        with self.assertRaisesRegex(ValueError, "stimulus-choice"):
            r.parse_data(make_raw(spoil=spoil), 1, False)

    def test_bad_private_reward(self):
        def spoil(row):
            if row["trial"] == 2:
                row["out"] = "NA"
        with self.assertRaisesRegex(ValueError, "own reward"):
            r.parse_data(make_raw(spoil=spoil), 1, False)

    def test_bad_condition(self):
        def spoil(row):
            if row["trial"] == 2:
                row["condition.obs"] = "Fake"
        with self.assertRaisesRegex(ValueError, "observation condition"):
            r.parse_data(make_raw(spoil=spoil), 1, False)

    def test_synthetic_accuracy(self):
        p, _ = r.parse_data(make_raw(), 1, False)
        a = r.accuracy_subject(p["3"])
        self.assertIsNotNone(a["private"])
        self.assertIsNotNone(a["skilled"])
        self.assertIsNone(a["unskilled"])  # No unskilled observed trials in this fixture


    def test_motor_direction_is_not_stimulus_choice(self):
        original, _ = r.parse_data(make_raw(), 1, False)
        def invert_motor(row):
            row["clr"] *= -1
        changed, _ = r.parse_data(make_raw(spoil=invert_motor), 1, False)
        params = (.1, 2, .15, .1)
        self.assertAlmostEqual(r.score_subject(original["3"], params)["loss"],
                               r.score_subject(changed["3"], params)["loss"])

    def test_outcome_and_choice_have_different_roles(self):
        # Correct action label is a prediction TARGET; only the learner's own
        # reward is used as an update after an observed private choice.
        people, checks = r.parse_data(make_raw(), 1, False)
        sample = people["3"][1]
        self.assertTrue(all(e["out"] is None for e in sample if e["demo"]))
        self.assertTrue(all(e["out"] in (-1, 1) for e in sample if not e["demo"]))

    def test_connector_derived_accuracy_file(self):
        import csv
        f = Path(__file__).with_name("R061_ACCURACY_BY_PERSON.csv")
        a = list(csv.DictReader(f.open(encoding="utf8")))
        for task, size, contrast in ((1, 24, .03177083333333334), (2, 44, .09772727272727272)):
            z = [x for x in a if int(x["task"]) == task]
            self.assertEqual(len(z), size)
            s = [float(x["skilled"])-float(x["private"]) for x in z if x["skilled"]]
            u = [float(x["unskilled"])-float(x["private"]) for x in z if x["unskilled"]]
            self.assertAlmostEqual(sum(s)/len(s)-sum(u)/len(u), contrast, places=8)

    def test_connector_derived_cv_delta_file(self):
        import csv
        f = Path(__file__).with_name("R061_CV_DELTAS_BY_PERSON.csv")
        a = list(csv.DictReader(f.open(encoding="utf8")))
        for task, size, expected in ((1, 24, 0), (2, 44, .005075232352117148)):
            z = [float(x["vs_minus_rw_logloss"]) for x in a if int(x["task"]) == task]
            self.assertEqual(len(z), size)
            self.assertAlmostEqual(sum(z)/len(z), expected, places=10)


class TimeAndModel(unittest.TestCase):
    def setUp(self):
        self.events = {1: [
            {"trial": 1, "state": 1, "choice": 1, "demo": True, "out": None, "condition": "Choice", "skill": "skilled.dem"},
            {"trial": 2, "state": 1, "choice": 1, "demo": False, "out": 1, "condition": "Choice", "skill": "skilled.dem"},
            {"trial": 3, "state": 1, "choice": 1, "demo": False, "out": -1, "condition": "Choice", "skill": "skilled.dem"},
        ]}

    def test_grid_has_zero_social(self):
        self.assertTrue(any(g[3] == 0 for g in r.GRID))

    def test_grid_size(self):
        self.assertEqual(len(r.GRID), 192)

    def test_model_ignores_social_at_zero(self):
        a = r.score_subject(self.events, (.1, 2, .15, 0))
        changed = copy.deepcopy(self.events)
        changed[1][0]["choice"] = 0
        b = r.score_subject(changed, (.1, 2, .15, 0))
        self.assertAlmostEqual(a["loss"], b["loss"])

    def test_positive_social_updates_affect_prediction(self):
        a = r.score_subject(self.events, (.1, 2, 0, .3))
        changed = copy.deepcopy(self.events)
        changed[1][0]["choice"] = 0
        b = r.score_subject(changed, (.1, 2, 0, .3))
        self.assertNotAlmostEqual(a["loss"], b["loss"])

    def test_current_outcome_not_in_same_trial_prediction(self):
        x = {1: [self.events[1][0], self.events[1][1]]}
        y = copy.deepcopy(x)
        y[1][-1]["out"] = -1
        self.assertAlmostEqual(r.score_subject(x, (.1, 2, 0, .2))["loss"],
                               r.score_subject(y, (.1, 2, 0, .2))["loss"])

    def test_future_demo_not_in_past_predictions(self):
        a = r.score_subject(self.events, (.1, 2, 0, .3))
        changed = copy.deepcopy(self.events)
        changed[1].append({**changed[1][0], "trial": 4, "choice": 0})
        b = r.score_subject(changed, (.1, 2, 0, .3))
        self.assertAlmostEqual(a["loss"], b["loss"])

    def test_state_isolation(self):
        a = copy.deepcopy(self.events)
        a[1][0]["state"] = 2
        v1 = r.score_subject(self.events, (.2, 2, 0, .3))["loss"]
        v2 = r.score_subject(a, (.2, 2, 0, .3))["loss"]
        self.assertNotAlmostEqual(v1, v2)

    def test_session_reset(self):
        two = copy.deepcopy(self.events)
        second = {"trial": 1, "state": 1, "choice": 0, "demo": False,
                  "out": 1, "condition": "Private", "skill": "private"}
        z = {1: two[1], 2: [second]}
        a = r.score_subject(z, (.3, 2, 0, .2))
        b = r.score_subject({1: [second]}, (.3, 2, 0, .2))
        base = r.score_subject(two, (.3, 2, 0, .2))
        self.assertAlmostEqual(a["loss"] * a["n"],
                               b["loss"] * b["n"] + base["loss"] * base["n"])

    def test_softplus_extremes(self):
        self.assertAlmostEqual(r.softplus(0), math.log(2))
        self.assertLess(r.softplus(-100), 1e-30)
        self.assertAlmostEqual(r.softplus(100), 100)

    def test_end_to_end_synthetic_cv(self):
        people, checks = r.parse_data(make_raw(subjects=("3", "4")), 1, False)
        result = r.cross_validate(people)
        self.assertEqual(len(result), 2)
        self.assertTrue(all(0 <= z["vs_params"][3] <= 1 for z in result))
        out = r.summarize(1, people, checks, result)
        self.assertEqual(out["participants"], 2)
        self.assertEqual(out["improved_people"], sum(z["delta"] < -1e-12 for z in result))


if __name__ == "__main__":
    unittest.main()
