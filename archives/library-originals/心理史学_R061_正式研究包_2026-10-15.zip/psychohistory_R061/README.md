# 心理史学 R061 正式研究包

本包保存Najar等(2020)两项真实实验的来源台账、研究方法、两个作者原始文件**在GitHub连接器侧读取后计算**的匿名参加者级派生指标、数学/统计汇总、Python原始认证复算程序、构造数据测试、下一轮关口和项目状态快照。

## 文件

- `R061_REPORT.md`：完整结果、限制、可复现性级别。
- `R061_RESULTS.json`：本地派生数据重算的研究结果及探索性不确定性。
- `R061_ACCURACY_BY_PERSON.csv`：来自连接器侧真实CSV的68名匿名参加者条件正确选择率（少量小数舍入）。
- `R061_CV_DELTAS_BY_PERSON.csv`：来自连接器侧真实CSV的留一参加者VS−RW对数损失差，实验1全部为0。
- `r061_replay.py`：读取两份作者**原始未修改字节**、校验Git blob SHA1后逐行验证并完整重算留一预测；当前原始文件未随包分发。
- `test_r061.py`：构造数据和本地派生数据一致性验证。
- `build_results.py`：本地派生数据的确定性统计重算。
- `SOURCE_LEDGER.json`、`PROJECT_STATE_R061.md`、`R062_RESEARCH_GATE.md`、`TEST_OUTPUT.txt`。

## 命令

```bash
python -m unittest -v test_r061.py
python build_results.py
# 取得两个原始未修改的作者CSV文件后：
python r061_replay.py --task1 /path/to/task1.csv --task2 /path/to/task2.csv --out /tmp/r061_raw_verified.json
```

若原始Git blob不匹配，复算程序拒绝执行。**不得使用派生数据代替原始字节而声称完成了本地原始认证重放。** 不得把代码测试数字当作真实独立实验结果。PESEN v0.1保持冻结。
