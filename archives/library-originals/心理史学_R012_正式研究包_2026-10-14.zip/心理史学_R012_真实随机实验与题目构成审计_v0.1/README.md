# 心理史学 R012：第二套真实随机实验的题目构成与社会信息审计

2026-10-14。状态：**真实作者 CSV 已通过 GitHub 连接器逐行读取并计算；本地 Python 代码仅完成构造样本测试，未保存原始 CSV 的本地全量端到端复跑。** PESEN v0.1 不变。

## 研究问题

先前 R009–R011 从独立组的全部成员均值推断社会影响，发现未经曝光的安慰剂组信号也有预测力。R012 改用确有社会反馈开关的独立实验，检查：

1. 有/无社会信息及 AI 提示时，新闻真假判断正确率的描述性差异是什么？
2. 各实验组抽到的新闻题目构成是否影响粗略比较？
3. 文件是否具备支持严格复现的数据质量？

## 来源和实验设计

原论文：Lu, Li, Wang & Yin (2022), *The Effects of AI-based Credibility Indicators on the Detection and Spread of Misinformation under Social Influence*, *Proceedings of the ACM on Human-Computer Interaction*, DOI: https://doi.org/10.1145/3555562 。实验二采用 2×3 随机分配：是否看到之前人的真假判断（Social/Independent）；不显示 AI（treatment=0）、在个人初始判断前显示 AI（1）、在个人初始判断后显示 AI（2）。参与者完成多条新闻任务。公开仓库 https://github.com/ZhuoranLu/Misinformation 。

作者原始 CSV 的 Git blob SHA1：

- `experimentTwoWithInfluenceIndividualLevelRes.csv`: `1c00c215d1c65436f52baaf7b5ddd98e450833bb`
- `experimentTwoNoInfluenceIndividualLevelRes.csv`: `e32926e78a1e7698cb5d070d52f57e078b3864be`

注意 Git blob 哈希不是普通文件字节 SHA1。源 README 将这些数据标注为 preliminary version；分析应在取得原始预注册文本和序列相关性定义后再次审核。

## 数据质量审计

直接读取真实作者记录 9,916 行：Social 5,453 行，Independent 4,463 行。组合 `(文件，treatment，workerId，newsIndex)` 有 9 条额外重复记录，其中 2 个重复键对应不同真假判断；社交文件中 9 个 `workerId` 跨多个 AI 处理组。两份文件里许多 workerId 数值相同，不能未经核实跨文件合并身份。按文件、处理组、workerId 划分的参与者-实验组组合数 1,108；按文件、workerId 的唯一组合数 1,098。40 个新闻项目，真实标签对所有记录一致，其中 20 个真、20 个假。全部记录的 `finalCorrectness` 与公开 `finalDecision == label` 对应。

去重不作为默认操作；另作第一条记录保留及排除处理组歧义编号的敏感性检查。

## 真实记录描述性结果

下表原始正确率按记录加权；题目等权则每个实验组先分别计算40条新闻的正确率，再平均（每条新闻权重1/40）。

| 实验条件 | 记录 | 参与者-处理组单位 | 原始正确率 | 新闻题目等权正确率 | 原始记录中真新闻比例 |
|---|---:|---:|---:|---:|---:|
| Social, 无 AI | 1829 | 205 | 50.36% | 50.44% | 49.86% |
| Social, AI 前置 | 1796 | 210 | 56.63% | 56.67% | 49.94% |
| Social, AI 后置 | 1828 | 217 | 55.31% | 55.28% | 50.00% |
| Independent, 无 AI | 1434 | 156 | 52.72% | 50.44% | 56.49% |
| Independent, AI 前置 | 1615 | 167 | 57.96% | 57.37% | 52.94% |
| Independent, AI 后置 | 1414 | 153 | 60.82% | 58.84% | 52.55% |

未显示 AI 的 Social 与 Independent 组，未调整的准确率差约 -2.36 个百分点；题目等权后差约 **-0.0009 个百分点**。这说明原始差异很大一部分来自不同新闻题目组成或其难度分布。**不能以原始组差直接解释为社会信息致使准确率下降。**

题目等权后，相对各自无 AI 对照，AI 前置提示对应的正确率差 Social 为 +6.23 pp、Independent 为 +6.93 pp；AI 后置提示分别为 +4.84 pp、+8.40 pp。两种交互对比为 -0.70 pp 和 -3.56 pp。

在原始全部行上用按 `(文件, treatment, workerId)` 重采样且每轮重新题目等权的 1,300 次探索性 bootstrap 中，AI 前置交互的近似 95% 百分位区间 [-5.49, +3.96] pp，AI 后置交互 [-8.78, +1.52] pp，均跨零。该算法只处理同一参与者多次回答的相关性，**没有充分处理新闻序列中前人判断对后人的干预溢出、部分编号跨处理组、动态网络结构及实验原始随机化程序**，不得作为正式因果效应或论文随机化推断的置信区间。

两项敏感性口径下，前置交互约 -0.71pp 与 -0.50pp；后置交互分别约 -3.54pp 与 -3.56pp。方向基本不变。这里全部分析均属于读取真实数据后的探索性再分析，尚未复现作者论文的正式全部统计模型。

## 对 PESEN 的意义及失败边界

- 随机操纵 social 信息可帮助研究其总体条件效应，但没有逐人的真实先前判断序列与展示内容，不能计算个体对某个同伴的实际学习权重。
- AI 提示出现前后影响个体判断可能源于证据整合、锚定、提示可信度等多种机制；当前结果不足以区分。
- 组别正确率差不能直接外推为私人立场/公开表达差异、规范形成或历史变迁。
- 原始新闻分布不均及编号冲突需要优先解决，否则即使随机分配也可能产生有问题的未经调整估计。
- 目前不声明第二套实验支持或否定 PESEN 的核心心理方程。

## 研究程序运行

具网络访问权限的机器上：

```bash
python3 r012_analysis.py --fetch --source-dir source --output r012_full_results.json --bootstrap 1300
python3 -m unittest discover -s tests -v
```

也可手动从作者 GitHub 下载这两份 CSV 并明确给出 `--social` 与 `--independent` 路径。程序校验 Git blob SHA1，避免静默使用其他修订。当前交付包**不包含原始 CSV 字节**，包含通过连接器计算的 `CONNECTOR_CALCULATIONS.json`，以及可独立运行的 Python 程序和单元测试。

## 下一步 R013

优先获取并核对论文的正式预注册分析单元、曝光序列与去重规则；检验真实社交链依赖。若开放数据缺少真实逐人邻居信号，则继续寻找更精细的原始实验日志；Jayles Figshare 若获取成功再进行四种预设更新机制的留题目验证。R012 仅更新数据方法档案，PESEN v0.1 维持不变。
