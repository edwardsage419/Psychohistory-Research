import csv
import tempfile
import unittest
from pathlib import Path
from r012_analysis import git_blob_sha, parse_source, audit, variants, equal_item_accuracy, contrasts

FIELDS=["", "workerId", "treatment", "initialDecision", "shareWillingness",
        "finalDecision","newsIndex","time","mlCorrectness","finalCorrectness","label"]
def row(worker,treat,news,label=1,correct=True):
    final=label if correct else -label
    return ["",str(worker),str(treat),"1","50",str(final),str(news),"t","True",str(bool(correct)),str(label)]
def file(path, body):
    with path.open("w",newline="",encoding="utf-8") as f:
        w=csv.writer(f);w.writerow(FIELDS);w.writerows(body)
class Tests(unittest.TestCase):
    def test_git_blob(self):
        import hashlib
        s=b"test"
        self.assertEqual(git_blob_sha(s),hashlib.sha1(b"blob 4\0test").hexdigest())
    def test_parse_and_audit(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/"s.csv"
            file(path,[row(1,0,0),row(1,0,1,correct=False),row(2,1,0)])
            r=parse_source(path,"social",False)
            self.assertEqual(len(r),3)
            self.assertEqual(audit(r)["rows"],3)
            self.assertEqual(audit(r)["file_scoped_worker_ids"],2)
    def test_invalid_correctness(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/"s.csv"
            x=row(1,0,0)
            x[9]="False"
            file(path,[x])
            with self.assertRaises(ValueError):parse_source(path,"social",False)
    def test_duplicate_audit(self):
        a=[dict(condition="social",treatment=0,worker="1",news=0,correct=1),
           dict(condition="social",treatment=0,worker="1",news=0,correct=1)]
        self.assertEqual(len(variants(a,"first_per_worker_news")),1)
    def test_exclude_ambiguous(self):
        a=[dict(condition="social",treatment=0,worker="1",news=0,correct=1),
           dict(condition="social",treatment=1,worker="1",news=1,correct=1),
           dict(condition="independent",treatment=0,worker="1",news=0,correct=0)]
        b=variants(a,"exclude_ambiguous_and_first")
        self.assertEqual(len(b),1)
        self.assertEqual(b[0]["condition"],"independent")
    def test_equal_weight(self):
        a=[]
        for c in ("social","independent"):
            for t in range(3):
                a.extend([dict(condition=c,treatment=t,news=0,correct=1),
                          dict(condition=c,treatment=t,news=1,correct=0),
                          dict(condition=c,treatment=t,news=1,correct=0)])
        z=equal_item_accuracy(a,[0,1])
        self.assertTrue(all(abs(x-.5)<1e-12 for x in z.values()))
    def test_contrasts(self):
        d={"social|0":.5,"social|1":.6,"social|2":.65,
           "independent|0":.5,"independent|1":.55,"independent|2":.60}
        x=contrasts(d)
        self.assertAlmostEqual(x["AI_before_interaction"],.05)
        self.assertAlmostEqual(x["AI_after_interaction"],.05)
if __name__=="__main__":unittest.main()
