import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import csv, hashlib, tempfile, unittest
from r016_analysis import git_blob_sha, parse, person_aggregates, cell_means, effects, bootstrap, study, ARMS


def fixture():
    rows=[]
    for arm in ARMS:
        for i in range(3):
            for item in range(1,37):
                rows.append({'arm':arm,'person':str(i),'item':item,
                    'valence':'positive' if item%2 else 'negative',
                    'intimacy':((item-1)%7)-3,
                    'disclosure':int((item+i)%4)})
    return rows

class TestR016(unittest.TestCase):
    def test_hash(self):
        self.assertEqual(git_blob_sha(b'a'),hashlib.sha1(b'blob 1\0a').hexdigest())
    def test_subject_count(self):
        p=person_aggregates(fixture())
        self.assertEqual(sum(map(len,p.values())),12)
    def test_arm_n(self):
        self.assertTrue(all(c['n']==3 for c in cell_means(person_aggregates(fixture())).values()))
    def test_effect_zero_when_arms_identical(self):
        e=effects(cell_means(person_aggregates(fixture())))
        self.assertAlmostEqual(e['anon_baseline'],0)
        self.assertAlmostEqual(e['ties_baseline'],0)
    def test_valence_penalty(self):
        e=effects(cell_means(person_aggregates(fixture())))
        self.assertAlmostEqual(e['anonymous_reduces_valence_penalty'],0)
    def test_bootstrap_seed(self):
        p=person_aggregates(fixture())
        self.assertEqual(bootstrap(p,80,17),bootstrap(p,80,17))
    def test_incomplete_person_rejected(self):
        with self.assertRaises(ValueError): person_aggregates(fixture()[1:])
    def test_duplicate_item_rejected(self):
        r=fixture();r[0]=dict(r[0],item=2)
        with self.assertRaises(ValueError): person_aggregates(r)
    def test_zero_variation_slope(self):
        r=fixture()
        for z in r: z['intimacy']=2
        x=study(r)
        self.assertEqual(x['zero_intimacy_variation_persons'],12)
    def test_carriage_return_csv(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'fixture.csv'
            header='participant_id,identification,audience,item_id,intimacy,self-disclosure,valence'
            text=header+'\r'+ '\r'.join(f'1,anonymous,nearby,{j},0,1,{"positive" if j%2 else "negative"}' for j in range(1,37))
            p.write_bytes(text.encode())
            self.assertEqual(len(parse(p,'clean',verify=False)),36)
    def test_bad_range_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'fixture.csv'
            p.write_text('participant_id,identification,audience,item_id,intimacy,self-disclosure,valence\n1,anonymous,nearby,1,0,9,positive\n')
            with self.assertRaises(ValueError):parse(p,'clean',verify=False)

if __name__=='__main__':unittest.main()
