#!/usr/bin/env python3
"""R016: Ma, Hancock & Naaman (CHI 2016) empirical replication template.

Run on source CSV files obtained lawfully from the authors' public repository:
  python r016_analysis.py --fetch --out results.json
  python r016_analysis.py --clean experiment-data.csv --raw experiment-raw.csv --out results.json

This script treats PEOPLE as independently assigned experimental units and
never treats 36 answers per person as 36 independent treatment assignments.
"""
import argparse
import base64
import csv
import hashlib
import json
import math
import random
import urllib.request
from collections import defaultdict
from pathlib import Path
from statistics import mean

REPO = 'sTechLab/SelfDisclosureItems'
EXPECTED = {
    'clean': ('experiment-data.csv', 'a9cbdabce1a8f25b30af4cc4d98f23fc1b909156'),
    'raw': ('experiment-raw.csv', '116e127f82ba46631e05429280d442e8713080eb'),
}
ARMS = ['anonymous|nearby', 'real_name|nearby', 'anonymous|social_ties', 'real_name|social_ties']
MEASURES = ('mean', 'positive', 'negative', 'valence_penalty', 'slope', 'intimacy_mean')

def git_blob_sha(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()

def fetch_blob(name, sha, destination):
    url = f'https://api.github.com/repos/{REPO}/git/blobs/{sha}'
    request = urllib.request.Request(url, headers={'Accept': 'application/vnd.github+json',
        'User-Agent': 'Psychohistory-R016/0.1'})
    with urllib.request.urlopen(request, timeout=40) as response:
        obj = json.load(response)
    if obj.get('encoding') != 'base64':
        raise ValueError('Unexpected GitHub blob encoding')
    data = base64.b64decode(obj['content'])
    if git_blob_sha(data) != sha:
        raise ValueError('Git blob integrity check failed')
    destination.write_bytes(data)
    return len(data)

def parse(path, key, verify=True):
    data = path.read_bytes()
    expected = EXPECTED[key][1]
    if verify and git_blob_sha(data) != expected:
        raise ValueError(f'{path}: unexpected Git blob revision')
    # Original GitHub file uses lone CR delimiters, NOT CRLF.
    content = data.decode('utf-8-sig')
    normalized = content.replace('\r\n', '\n').replace('\r', '\n')
    rows = list(csv.DictReader(normalized.splitlines()))
    result = []
    for i,r in enumerate(rows,2):
        if not r or None in r:
            raise ValueError(f'Malformed CSV record {path}:{i}')
        try:
            ident, audience, pid, v = r['identification'], r['audience'], r['participant_id'], r['valence']
            x, y, item = int(r['intimacy']), int(r['self-disclosure']), int(r['item_id'])
        except (ValueError, TypeError, KeyError) as e:
            raise ValueError(f'Invalid record {path}:{i}: {e}') from e
        if ident not in ('anonymous','real_name') or audience not in ('nearby','social_ties'):
            raise ValueError(f'Unknown treatment at {i}')
        if v not in ('positive','negative') or not (-3 <= x <= 3) or not (0 <= y <= 3) or item not in range(1,37):
            raise ValueError(f'Out-of-range response at {i}')
        result.append({'arm': f'{ident}|{audience}', 'person': pid, 'valence':v, 'intimacy':x,
                       'disclosure':y, 'item':item})
    return result

def person_aggregates(rows):
    groups = defaultdict(list)
    for r in rows: groups[(r['arm'],r['person'])].append(r)
    people = {arm:[] for arm in ARMS}
    for (arm,pid), rs in groups.items():
        if len(rs) != 36 or {r['item'] for r in rs} != set(range(1,37)):
            raise ValueError(f'Incomplete or duplicate 36-item participant: {arm}/{pid}')
        pos = [r for r in rs if r['valence']=='positive']
        neg = [r for r in rs if r['valence']=='negative']
        if len(pos)!=18 or len(neg)!=18: raise ValueError('Not 18+18 valence design')
        xm=mean(r['intimacy'] for r in rs)
        ym=mean(r['disclosure'] for r in rs)
        var=sum((r['intimacy']-xm)**2 for r in rs)
        cov=sum((r['intimacy']-xm)*(r['disclosure']-ym) for r in rs)
        p=mean(r['disclosure'] for r in pos)
        n=mean(r['disclosure'] for r in neg)
        people[arm].append({'mean':ym,'positive':p,'negative':n,'valence_penalty':p-n,
             'slope':(cov/var if var>0 else None),'intimacy_mean':xm})
    if any(not people[arm] for arm in ARMS): raise ValueError('Missing experimental arm')
    return people

def cell_means(ppl):
    return {arm:{'n':len(v),**{m:mean(x[m] for x in v if x[m] is not None)
        if any(x[m] is not None for x in v) else None for m in MEASURES}} for arm,v in ppl.items()}

def effects(c):
    A,B,C,D=(c[a] for a in ARMS)
    return {
      'anon_baseline': ((A['mean']-B['mean'])+(C['mean']-D['mean']))/2,
      'ties_baseline': ((C['mean']-A['mean'])+(D['mean']-B['mean']))/2,
      'anon_by_audience': (C['mean']-D['mean'])-(A['mean']-B['mean']),
      'anonymous_reduces_valence_penalty': ((B['valence_penalty']-A['valence_penalty'])+
                                          (D['valence_penalty']-C['valence_penalty']))/2,
      'anonymity_valence_penalty_nearby': B['valence_penalty']-A['valence_penalty'],
      'anonymity_valence_penalty_ties': D['valence_penalty']-C['valence_penalty'],
      'mean_intimacy_slope': (mean(v['slope'] for v in (A,B,C,D) if v['slope'] is not None) if any(v['slope'] is not None for v in (A,B,C,D)) else None),
      'ties_changes_intimacy_slope': ((C['slope']-A['slope'])+(D['slope']-B['slope']))/2 if
         all(v['slope'] is not None for v in (A,B,C,D)) else None
    }

def bootstrap(ppl, n=2500, seed=20261014):
    rng=random.Random(seed)
    draws=defaultdict(list)
    for _ in range(n):
        sample={arm:[rs[rng.randrange(len(rs))] for _ in rs] for arm,rs in ppl.items()}
        est=effects(cell_means(sample))
        for k,v in est.items():
            if v is not None:draws[k].append(v)
    return {k:[sorted(v)[int(.025*len(v))], sorted(v)[int(.975*len(v))]] for k,v in draws.items()}

def study(rows, reps=0, seed=20261014):
    people=person_aggregates(rows)
    cells=cell_means(people)
    return {'records':len(rows),'participants':sum(len(v) for v in people.values()),
            'cells':cells,'effects':effects(cells),
            'bootstrap_95':bootstrap(people,reps,seed) if reps else {},
            'zero_intimacy_variation_persons':sum(x['slope'] is None for v in people.values() for x in v)}

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--fetch',action='store_true',help='Download exact original Git blobs over HTTPS')
    parser.add_argument('--source-dir',type=Path,default=Path('source'))
    parser.add_argument('--clean',type=Path)
    parser.add_argument('--raw',type=Path)
    parser.add_argument('--bootstrap',type=int,default=2500)
    parser.add_argument('--seed',type=int,default=20261014)
    parser.add_argument('--out',type=Path,default=Path('r016_results.json'))
    parser.add_argument('--skip-hash-check',action='store_true', help='Synthetic fixture only')
    args=parser.parse_args()
    if args.fetch:
        args.source_dir.mkdir(parents=True,exist_ok=True)
        for key,(filename,sha) in EXPECTED.items():
            fetch_blob(filename,sha,args.source_dir/filename)
    paths={'clean':args.clean or args.source_dir/EXPECTED['clean'][0],
           'raw':args.raw or args.source_dir/EXPECTED['raw'][0]}
    output={'research':'R016','status':'REAL_PUBLIC_DATA_REANALYSIS',
            'source_repository':REPO,'provenance':{},
            'estimand':'participant-balanced condition means; exploratory cluster bootstrap',
            'causal_caveats':['reported comfort, not actual disclosure','intimacy-valence association',
                              'selection by author filtering','no measure of actual network exposure']}
    for key,path in paths.items():
        data=path.read_bytes()
        output['provenance'][key]={'git_blob':git_blob_sha(data),'sha256':hashlib.sha256(data).hexdigest()}
        output[key]=study(parse(path,key,not args.skip_hash_check),args.bootstrap if key=='clean' else 0,args.seed)
    args.out.write_text(json.dumps(output,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print('R016 completed:',output['clean']['participants'],'clean participants; saved',args.out)

if __name__=='__main__':main()
