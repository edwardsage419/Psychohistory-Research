# 心理史学 R055研究包

本轮为**场次固定效应不可识别性研究与匿名真实源派生汇总计算**。其结论用于识别边界审计，不表示取得新的独立实验预测证据。

## 离线复算

标准库即可运行：

```bash
python r055_identifiability.py --out R055_RESULTS_LOCAL.json
python -m unittest -v test_r055.py
```

如果以后从官方仓库合法取得精确原始CSV字节：

```bash
python r055_identifiability.py --raw-csv /path/to/original/data.csv --out R055_SOURCE_REPLAY.json
```

原始字节须与作者 Git blob `73c02176bc9e060af987149594a85f9f7b591230` 精确一致，程序再重算冻结匿名汇总并拒绝不匹配的结果。

本包仅含场次层派生数值，不含可识别参与者的原始记录。

## 文件

`R055_REPORT.md` 研究结论与假设边界；`R055_SESSION_AGGREGATES.json` 连接器侧真实CSV统计派生；`r055_identifiability.py` 无额外依赖复算；`test_r055.py` 构造及不变量测试；`R055_RESULTS.json` 严格有理数计算；`TEST_OUTPUT.txt` 软件测试日志；`SOURCE_LEDGER.json` 来源说明；`PROJECT_STATE_R055.md` 继承状态；`R056_RESEARCH_GATE.md` 下轮关口；`SHA256SUMS.txt` 本地归档哈希。
