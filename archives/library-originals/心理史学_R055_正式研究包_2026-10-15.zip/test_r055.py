"""R055 offline construct and invariant tests; no invented true-data validation."""
import copy
from fractions import Fraction
import json
from pathlib import Path
import tempfile
import unittest

import r055_identifiability as r

SOURCE = Path(__file__).with_name('R055_SESSION_AGGREGATES.json')


class R055Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.session_data = json.loads(SOURCE.read_text('utf-8'))['sessions']
        cls.s, cls.level = r.load_summary(SOURCE)
        cls.result = r.analyze(cls.s, cls.level)

    def test_01_expected_source_file(self):
        self.assertEqual(r.EXPECTED_BLOB, '73c02176bc9e060af987149594a85f9f7b591230')

    def test_02_derived_source_flag(self):
        self.assertIn('aggregates_only', self.level)

    def test_03_shape(self):
        self.assertEqual(len(self.s), 8)

    def test_04_sessions(self):
        self.assertEqual({z['session'] for z in self.s}, set(range(1, 9)))

    def test_05_counts(self):
        self.assertEqual(sum(z['n'] for z in self.s), 1920)

    def test_06_four_cells(self):
        self.assertEqual(set((z['homo'], z['ff']) for z in self.s), {(0, 0), (0, 1), (1, 0), (1, 1)})

    def test_07_equal_endowment_fraction(self):
        self.assertEqual(r.mean_fraction(self.s[2]), Fraction(7992, 240 * 50))

    def test_08_unequal_endowment_fraction(self):
        self.assertEqual(r.mean_fraction(self.s[0]), (Fraction(3528, 40) + Fraction(4106, 60)) / 240)

    def test_09_punishment_difference(self):
        self.assertAlmostEqual(self.result['observed']['punishment_difference'], -0.061670138888888885)

    def test_10_interaction(self):
        self.assertAlmostEqual(self.result['observed']['factorial_interaction'], -0.024659722222222222)

    def test_11_session_FE_absorption(self):
        self.assertEqual(self.result['fixed_effect_rank']['rank'], 8)
        self.assertEqual(self.result['fixed_effect_rank']['additional_rank_from_treatment_columns'], 0)

    def test_12_conditional_assignments_count(self):
        self.assertEqual(len(list(r.label_assignments(self.s, True))), 36)

    def test_13_unrestricted_assignments_count(self):
        self.assertEqual(len(list(r.label_assignments(self.s, False))), 2520)

    def test_14_conditional_reference(self):
        self.assertEqual(self.result['reference_enumeration']['stratified']['punishment']['extreme'], 2)

    def test_15_unrestricted_reference(self):
        self.assertEqual(self.result['reference_enumeration']['unrestricted']['punishment']['extreme'], 72)

    def test_16_conditional_interaction(self):
        self.assertEqual(self.result['reference_enumeration']['stratified']['interaction']['extreme'], 20)

    def test_17_unrestricted_interaction(self):
        self.assertEqual(self.result['reference_enumeration']['unrestricted']['interaction']['extreme'], 1296)

    def test_18_rank_identity(self):
        self.assertEqual(r.matrix_rank([[Fraction(1), Fraction(0)], [Fraction(0), Fraction(1)]]), 2)

    def test_19_rank_collinear(self):
        self.assertEqual(r.matrix_rank([[Fraction(1), Fraction(1)], [Fraction(2), Fraction(2)]]), 1)

    def test_20_rank_zero(self):
        self.assertEqual(r.matrix_rank([[Fraction(0), Fraction(0)]]), 0)

    def test_21_duplicate_session_rejected(self):
        arr = copy.deepcopy(self.s); arr[0]['session'] = 2
        with self.assertRaises(ValueError): r.validate_sessions(arr)

    def test_22_unbalanced_treatment_rejected(self):
        arr = copy.deepcopy(self.s); arr[0]['ff'] = 1
        with self.assertRaises(ValueError): r.validate_sessions(arr)

    def test_23_wrong_group_size_rejected(self):
        arr = copy.deepcopy(self.s); arr[0]['groups'] = 5
        with self.assertRaises(ValueError): r.validate_sessions(arr)

    def test_24_wrong_token_sum_rejected(self):
        arr = copy.deepcopy(self.s); arr[0]['by_token']['40']['sumInvest'] = 99999
        with self.assertRaises(ValueError): r.validate_sessions(arr)

    def test_25_wrong_token_composition_rejected(self):
        arr = copy.deepcopy(self.s); arr[2]['by_token'] = {'40': arr[2]['by_token']['50']}
        with self.assertRaises(ValueError): r.validate_sessions(arr)

    def test_26_wrong_summary_hash_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            a = json.loads(SOURCE.read_text('utf-8')); a['provenance']['source_git_blob_sha1'] = '0' * 40
            p = Path(temp) / 'bad.json'; p.write_text(json.dumps(a), 'utf-8')
            with self.assertRaises(ValueError): r.load_summary(p)

    def test_27_unauthenticated_raw_csv_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            p = Path(temp) / 'fake.csv'; p.write_text('ProfileID,Session\n1,1\n', 'utf-8')
            with self.assertRaises(ValueError): r.load_summary(SOURCE, p)

    def test_28_true_source_raw_not_claimed(self):
        self.assertFalse(self.result['new_independent_study'])

    def test_29_design_inference_blocked(self):
        self.assertIn('no inferential validity', self.result['reference_warning'])

    def test_30_exact_counterfactual_equivalence(self):
        self.assertEqual(self.result['observational_equivalence_example']['max_prediction_difference'], 0.)

    def test_31_sensitivity_sign_reversal(self):
        values = self.result['illustrative_session_shock_sensitivity']
        self.assertGreater(values[0]['implied_punishment_effect'], 0)
        self.assertLess(values[-1]['implied_punishment_effect'], 0)

    def test_32_permutations_unique_conditional(self):
        assignments=list(r.label_assignments(self.s, True))
        encoded={tuple(x[i] for i in range(1,9)) for x in assignments}
        self.assertEqual(len(encoded),len(assignments))

    def test_33_permutations_unique_unrestricted(self):
        assignments=list(r.label_assignments(self.s, False))
        encoded={tuple(x[i] for i in range(1,9)) for x in assignments}
        self.assertEqual(len(encoded),len(assignments))

    def test_34_cell_average_equal_weight(self):
        label={z['session']:(z['homo'],z['ff']) for z in self.s}
        calc=r.estimands(self.s,label)
        self.assertEqual(calc['cell_means'][0,0],(r.mean_fraction(self.s[0])+r.mean_fraction(self.s[1]))/2)

    def test_35_missing_one_session_rejected(self):
        with self.assertRaises(ValueError): r.validate_sessions(self.s[:-1])

    def test_36_invalid_homo_rejected(self):
        arr=copy.deepcopy(self.s);arr[0]['homo']=3
        with self.assertRaises(ValueError):r.validate_sessions(arr)


if __name__ == '__main__':
    unittest.main(verbosity=2)
