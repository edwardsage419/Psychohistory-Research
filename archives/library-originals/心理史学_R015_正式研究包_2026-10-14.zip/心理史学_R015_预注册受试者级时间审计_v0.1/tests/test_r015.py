import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from r015_audit import classify_people, analyze, EXP1_REG, EXP2_REG
from r013_analysis import PREREG_UTC, parse_exp_time

def obj(w,a,date,cond='social'):
    return {'condition':cond,'worker':w,'arm':a,'time':date}
BEFORE='Fri Dec 24 2021 12:00:00 GMT-0500 (EST)'
AFTER='Mon Dec 27 2021 12:00:00 GMT-0500 (EST)'

class TestR015(unittest.TestCase):
    def test_disjoint_partitions(self):
        a=[obj('one',0,BEFORE),obj('one',0,BEFORE),obj('two',1,AFTER),obj('both',2,BEFORE),obj('both',2,AFTER)]
        x=classify_people(a,'social')
        self.assertEqual([x[k] for k in ('worker_before_only','worker_after_only','worker_crossing_cutoff')],[1,1,1])
        self.assertEqual(x['worker_with_any_before'],2)
        self.assertEqual(x['worker_with_any_after'],2)
    def test_no_pseudoreplication(self):
        a=[obj('same',0,BEFORE) for i in range(50)]
        x=classify_people(a,'social')
        self.assertEqual(x['before_records'],50)
        self.assertEqual(x['first_observed_event_before_cutoff'],1)
    def test_multitreatment_not_necessarily_date_cross(self):
        a=[obj('id',0,BEFORE),obj('id',1,BEFORE)]
        x=classify_people(a,'social')
        self.assertEqual(x['worker_multiple_ai_arms'],1)
        self.assertEqual(x['worker_crossing_cutoff'],0)
    def test_cross_not_necessarily_multitreatment(self):
        a=[obj('id',0,BEFORE),obj('id',0,AFTER)]
        x=classify_people(a,'social')
        self.assertEqual(x['worker_multiple_ai_arms'],0)
        self.assertEqual(x['worker_crossing_cutoff'],1)
    def test_intersection(self):
        a=[obj('id',0,BEFORE),obj('id',1,AFTER)]
        x=classify_people(a,'social')
        self.assertEqual(x['crossing_and_multiple_ai_arms'],1)
    def test_treatment_counts(self):
        a=[obj('w1',0,BEFORE),obj('w1',0,AFTER),obj('w2',2,AFTER)]
        x=classify_people(a,'social')
        self.assertEqual(x['arm_counts']['0']['before_unique_workers'],1)
        self.assertEqual(x['arm_counts']['0']['after_unique_workers'],1)
        self.assertEqual(x['arm_counts']['2']['after_records'],1)
    def test_refuse_mixed_conditions(self):
        with self.assertRaises(ValueError):classify_people([obj('x',0,BEFORE,'independent')],'social')
    def test_refuse_empty(self):
        with self.assertRaises(ValueError):classify_people([],'social')
    def test_refuse_bad_timestamp(self):
        with self.assertRaises(ValueError):classify_people([obj('x',0,'bad')],'social')
    def test_prereg_separate(self):
        self.assertNotEqual(EXP1_REG,EXP2_REG)
        self.assertEqual(PREREG_UTC.isoformat(),'2021-12-27T03:59:00+00:00')
    def test_timezone_equivalence(self):
        t=parse_exp_time('Sun Dec 26 2021 19:59:00 GMT-0800 (PST)')
        self.assertEqual(t,PREREG_UTC)
    def test_reproduce_requires_files(self):
        with TemporaryDirectory() as d:
            with self.assertRaises(FileNotFoundError): analyze(Path(d))

if __name__=='__main__':unittest.main()
