"""R015 chronology audit. Requires original Lu et al. experiment-2 CSVs.

R015: audit record-level and file-scoped worker-level date partitions.
Never equate exported 'time' with data collection time without a codebook.
No original participant CSV files are redistributed with this research package.

  python r013_analysis.py --fetch --source-dir source    # network required
  python r015_audit.py --source-dir source --output results.json
"""
from __future__ import annotations
from collections import defaultdict, Counter
from pathlib import Path
import argparse, hashlib, json
from r013_analysis import read_csv, git_sha, parse_exp_time, SOURCES, PREREG_UTC

EXP1_REG = '2021-05-23 23:49 PT'  # AsPredicted #66,622; NOT experiment-2 register
EXP2_REG = '2021-12-26 19:59 PT'  # AsPredicted #84,011


def classify_people(rows: list[dict], condition: str) -> dict:
    """Return disjoint worker-id counts; do not reuse IDs between files."""
    if not rows:
        raise ValueError('Empty dataset')
    by_worker = defaultdict(list)
    by_arm = defaultdict(lambda: {'before_records':0, 'after_records':0,
                                  'before_worker_ids':set(), 'after_worker_ids':set()})
    daily = Counter()
    before_total=0
    after_total=0
    for rec in rows:
        if rec['condition']!=condition:
            raise ValueError('Mixed condition files')
        t=parse_exp_time(rec['time'])
        if t is None:
            raise ValueError('Invalid timestamp')
        w=str(rec['worker'])
        a=int(rec['arm'])
        pre=(t < PREREG_UTC)
        by_worker[w].append((pre,a,t))
        arm=by_arm[a]
        arm['before_records' if pre else 'after_records']+=1
        arm['before_worker_ids' if pre else 'after_worker_ids'].add(w)
        daily[t.date().isoformat()] += 1
        before_total+=int(pre)
        after_total+=int(not pre)
    pre_only=post_only=cross=multi=0
    first_pre=0
    any_pre=0
    any_post=0
    crossing=set()
    multi_ids=set()
    for w,events in by_worker.items():
        is_pre=any(z[0] for z in events)
        is_post=any(not z[0] for z in events)
        n_arms=len({z[1] for z in events})
        if is_pre and is_post:cross+=1;crossing.add(w)
        elif is_pre:pre_only+=1
        else:post_only+=1
        if n_arms>1:multi+=1;multi_ids.add(w)
        any_pre+=int(is_pre)
        any_post+=int(is_post)
        first_pre+=int(min(z[2] for z in events)<PREREG_UTC)
    # Do not return pseudonymous IDs in exported aggregate report.
    return {
        'condition':condition, 'records':before_total+after_total,
        'before_records':before_total, 'after_records':after_total,
        'file_scoped_unique_worker_ids':len(by_worker),
        'worker_before_only':pre_only,'worker_after_only':post_only,
        'worker_crossing_cutoff':cross,
        'worker_with_any_before':any_pre,'worker_with_any_after':any_post,
        'first_observed_event_before_cutoff':first_pre,
        'worker_multiple_ai_arms':multi,
        'crossing_and_multiple_ai_arms':len(crossing & multi_ids),
        'arm_counts':{str(k):{
             'before_records':v['before_records'],'after_records':v['after_records'],
             'before_unique_workers':len(v['before_worker_ids']),
             'after_unique_workers':len(v['after_worker_ids'])
        } for k,v in sorted(by_arm.items())},
        'dates_utc':dict(sorted(daily.items())),
        'semantic_status':'exported_time_field_unverified_as_collection_timestamp'
    }


def analyze(root:Path, verify=True) -> dict:
    result={
        'study':'Lu, Li, Wang and Yin (2022) Experiment 2',
        'exp1_registry':{'url':'https://aspredicted.org/u5fu5.pdf','date':EXP1_REG,
             'does_not_register_experiment_2_as_six_arms':True},
        'exp2_registry':{'url':'https://aspredicted.org/rh32h.pdf','date':EXP2_REG,
             'cutoff_utc':PREREG_UTC.isoformat()},
        'source_commit':'de9b7714a7084f9891bbb41c644e3bc936554405',
        'groups':{},'sha256':{},'git_sha':{},
        'interpretation':'Source chronology anomaly, NOT proof of misconduct, field semantics unresolved.'
    }
    groups=[]
    for cond,(filename,expected) in SOURCES.items():
        p=root/filename
        raw=p.read_bytes()
        actual=git_sha(raw)
        if verify and expected!=actual:raise ValueError('Source byte version mismatch: '+cond)
        parsed=read_csv(p,cond,verify=verify)
        result['groups'][cond]=classify_people(parsed,cond)
        result['sha256'][cond]=hashlib.sha256(raw).hexdigest()
        result['git_sha'][cond]=actual
        groups.append(result['groups'][cond])
    result['combined']={
         'total_records':sum(x['records'] for x in groups),
         'before_records':sum(x['before_records'] for x in groups),
         'total_file_scoped_worker_ids':sum(x['file_scoped_unique_worker_ids'] for x in groups),
         'workers_first_observed_before':sum(x['first_observed_event_before_cutoff'] for x in groups),
         'workers_with_any_before':sum(x['worker_with_any_before'] for x in groups),
         'worker_after_only':sum(x['worker_after_only'] for x in groups),
         'worker_crossing_cutoff':sum(x['worker_crossing_cutoff'] for x in groups)
    }
    a=result['combined']
    a['fraction_first_observed_before']=a['workers_first_observed_before']/a['total_file_scoped_worker_ids']
    a['fraction_records_before']=a['before_records']/a['total_records']
    return result


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source-dir',type=Path,default=Path('source'))
    ap.add_argument('--output',type=Path,default=Path('results.json'))
    ap.add_argument('--allow-changed-source',action='store_true',help='for synthetic diagnostic only')
    args=ap.parse_args()
    res=analyze(args.source_dir,verify=not args.allow_changed_source)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(res,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print('R015',res['combined'])

if __name__=='__main__':main()
