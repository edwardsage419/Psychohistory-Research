#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""R026: 原始文件完整性检查、真实发言零值保留和实验设计审计。
只输出群体聚合量，不写出参与者身份信息或评论内容。
Python >= 3.9，零第三方依赖。
"""
import argparse
import csv
import hashlib
import itertools
import json
import math
from collections import Counter, defaultdict
from datetime import datetime, date
from pathlib import Path
from urllib.request import urlopen
from urllib.error import URLError

RECORD = "https://zenodo.org/records/16109520"
EXPECTED = {
    "discussions_anon.csv": "e9b8d3ffdb7a8ce5b71fa316fe3e83ee",
    "external_reddit_anon.csv": "4ac36f63cdd3898254dd5ecfe378497e",
    "post_surveys_anon.csv": "6a84e047a26269c2be767d1d0b859880",
    "pre_survey_anon.csv": "bbcf5dec3a7507e4b2fcb593e5d65ff7",
    "users_anon.csv": "2f45cb4523168c8c9bca40a95614ef29",
}
START = date(2024, 6, 10)
END = date(2024, 7, 5)

def md5sum(path):
    h = hashlib.md5()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def load_csv(path):
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

def download_one(base, name):
    target = base / name
    if target.exists():
        return "already present"
    url = f"{RECORD}/files/{name}?download=1"
    tmp = base / (name + ".part")
    try:
        with urlopen(url, timeout=40) as inp, tmp.open("wb") as out:
            for block in iter(lambda: inp.read(1024*1024), b""):
                out.write(block)
        if md5sum(tmp) != EXPECTED[name]:
            tmp.unlink(missing_ok=True)
            raise ValueError("MD5 mismatch from downloaded source")
        tmp.replace(target)
        return "downloaded and verified"
    except Exception as e:
        tmp.unlink(missing_ok=True)
        return f"download failed: {type(e).__name__}: {e}"

def normalize_id(value):
    return str(value or "").strip()

def date_from_timestamp(s):
    if not s:
        return None
    try:
        return datetime.fromisoformat(s.strip().replace("Z", "+00:00")).date()
    except ValueError:
        return None

def gini(values):
    # 标准有限样本描述性 Gini，所有值必须非负
    xs = sorted(float(x) for x in values)
    n = len(xs)
    if not n or sum(xs) == 0:
        return 0.0
    return (2*sum((i+1)*x for i,x in enumerate(xs))/(n*sum(xs)))-((n+1)/n)

def classify(pre, discussions, post):
    """返回完全聚合的参与者和社区统计。不假定处理随机化可由CSV证实。"""
    eligible = [r for r in pre if str(r.get("on_reddit", "")).strip().lower()
                in {"1", "true", "yes"}]
    by_id = {}
    warnings = []
    for r in eligible:
        pid = normalize_id(r.get("ParticipantID"))
        if not pid or pid in by_id:
            raise ValueError("Eligible roster has missing/duplicate ParticipantID")
        by_id[pid] = r
    if not by_id:
        raise ValueError("No eligible on_reddit==1 participants; inspect schema first.")
    post_ids = {normalize_id(r.get("ParticipantID")) for r in post}
    all_counts = Counter()
    window_counts = Counter()
    unmatched_comments = 0
    after_end = 0
    before_start = 0
    invalid_stamp = 0
    for r in discussions:
        pid = normalize_id(r.get("ParticipantID"))
        if pid not in by_id:
            unmatched_comments += 1
            continue
        all_counts[pid] += 1
        d = date_from_timestamp(r.get("created_comment"))
        if d is None:
            invalid_stamp += 1
        elif d < START:
            before_start += 1
        elif d > END:
            after_end += 1
        else:
            window_counts[pid] += 1
    groups = defaultdict(list)
    conditions = defaultdict(list)
    missing_assignment = 0
    for pid, r in by_id.items():
        arm = str(r.get("condition", "")).strip().lower()
        grp = str(r.get("subreddit", "")).strip()
        if not arm or not grp:
            missing_assignment += 1
            continue
        groups[grp].append(pid)
        conditions[arm].append(pid)
    group_summary = {}
    group_arm = {}
    for grp, pids in sorted(groups.items()):
        arms = sorted({str(by_id[p].get("condition", "")).strip().lower() for p in pids})
        group_arm[grp] = arms
        group_summary[grp] = {
            "n_assigned": len(pids),
            "assigned_arms": arms,
            "n_any_comment": sum(all_counts[p] > 0 for p in pids),
            "n_zero_comments": sum(all_counts[p] == 0 for p in pids),
            "n_any_followup": sum(p in post_ids for p in pids),
            "mean_comments_all_archive": sum(all_counts[p] for p in pids)/len(pids),
        }
        if len(arms) != 1:
            warnings.append(f"Group {grp} contains conflicting conditions")
    arm_summary = {}
    for arm, pids in sorted(conditions.items()):
        ys = [all_counts[p] for p in pids]
        in_window = [window_counts[p] for p in pids]
        arm_summary[arm] = {
            "n_assigned": len(pids),
            "n_active_all_archive": sum(x > 0 for x in ys),
            "n_zero_comments": sum(x == 0 for x in ys),
            "activity_rate_all_archive": sum(x > 0 for x in ys)/len(pids),
            "mean_comments_all_archive": sum(ys)/len(pids),
            "mean_comments_date_window": sum(in_window)/len(pids),
            "gini_all_archive_descriptive": gini(ys),
            "n_any_followup": sum(p in post_ids for p in pids),
        }
    join_only = sum(all_counts[p] == 0 and p not in post_ids for p in by_id)
    silent = sum(all_counts[p] == 0 and p in post_ids for p in by_id)
    active = sum(all_counts[p] > 0 for p in by_id)
    if after_end or before_start or invalid_stamp:
        warnings.append("Observed dates outside stated study window or unparseable timestamps: do not silently discard")
    if missing_assignment:
        warnings.append("Some eligible participants lack condition/subreddit assignment")
    if unmatched_comments:
        warnings.append("Some discussion records do not match eligible roster; inspect source inclusion rules")
    warnings.append("Experiment condition not independently randomized at six-community level by evidence reviewed; do not assert 90-label permutation is the original randomization design.")
    warnings.append("Comment score lacks observed vote-time history; do not treat collected score as known pre-next-comment feedback.")
    warnings.append("Weekly perception surveys occur after associated discussion week; do not use them as pretreatment covariates for that week.")
    return {
        "eligible_n": len(by_id),
        "active_n": active, "silent_followup_n": silent,
        "join_only_n": join_only,
        "total_comments_all_archive": sum(all_counts.values()),
        "total_comments_within_declared_window": sum(window_counts.values()),
        "comments_after_2024_07_05": after_end,
        "comments_before_2024_06_10": before_start,
        "comments_unparseable_date": invalid_stamp,
        "comments_unmatched_eligible": unmatched_comments,
        "n_communities": len(groups),
        "group_summary": group_summary,
        "arm_summary": arm_summary,
        "warnings": warnings
    }

def manifest(base):
    file_info = {}
    for name, expected in EXPECTED.items():
        path = base / name
        exists = path.is_file()
        actual = md5sum(path) if exists else None
        file_info[name] = {
            "origin_url": f"{RECORD}/files/{name}?download=1",
            "expected_md5": expected, "exists": exists,
            "actual_md5": actual,
            "verified": actual == expected if exists else False
        }
    return file_info

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--data-dir", default="data", type=Path)
    ap.add_argument("--output", default="R026_RESULT.json", type=Path)
    ap.add_argument("--download", action="store_true", help="Try official Zenodo downloads")
    args = ap.parse_args()
    args.data_dir.mkdir(parents=True, exist_ok=True)
    download_status = {}
    if args.download:
        for name in EXPECTED:
            download_status[name] = download_one(args.data_dir, name)
    m = manifest(args.data_dir)
    required = {"discussions_anon.csv", "pre_survey_anon.csv", "post_surveys_anon.csv"}
    all_verified = all(v["verified"] for v in m.values())
    res = {
        "round": "R026",
        "raw_source": RECORD,
        "files": m, "download_attempts": download_status,
        "all_five_md5_verified": all_verified,
        "analysis": None,
        "analysis_status": "BLOCKED_RAW_DATA_MISSING_OR_MD5_MISMATCH",
        "interpretation": "No confirmed randomization ITT; any calculated differences are descriptive until assignment mechanism and interference are verified.",
        "warnings": []
    }
    if all_verified:
        try:
            res["analysis"] = classify(
                load_csv(args.data_dir / "pre_survey_anon.csv"),
                load_csv(args.data_dir / "discussions_anon.csv"),
                load_csv(args.data_dir / "post_surveys_anon.csv")
            )
            res["analysis_status"] = "VERIFIED_RAW_DESCRIPTIVE_AUDIT"
        except Exception as e:
            res["warnings"].append(f"Schema/analysis error: {type(e).__name__}: {e}")
            res["analysis_status"] = "VERIFIED_RAW_BUT_SCHEMA_ANALYSIS_FAILED"
    else:
        res["warnings"].append("MD5 verification incomplete: deliberately omit all numerical reanalysis.")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"{res['analysis_status']} | output={args.output}")
    return 0 if res["analysis_status"] in ("VERIFIED_RAW_DESCRIPTIVE_AUDIT", "BLOCKED_RAW_DATA_MISSING_OR_MD5_MISMATCH") else 2

if __name__ == "__main__":
    raise SystemExit(main())
