# 心理史学 R026 研究包

日期 2026-10-14。研究完成公开文献和作者代码的**审计**，没有完成 Zenodo 五份原始 CSV 的下载与 MD5 核验。PESEN v0.1 冻结。

运行环境 Python 3.9+，无需第三方库。

```bash
python -m unittest discover -s tests -v
python r026_source_audit.py --data-dir data --output R026_RESULT.json
```

如果在可联网的个人计算机上运行，可从 Zenodo 官方来源自动下载并校验：

```bash
python r026_source_audit.py --download --data-dir data --output R026_RESULT.json
```

仅当五份源 CSV 全部通过 MD5 校验时，程序才输出真实数据的描述性审计。即使运行成功，**不会**把描述性差异标成随机试验处理因果效应。程序不输出评论内容或个体记录。

包内：`R026_FINDINGS.md`、`r026_source_audit.py`、`R026_RESULT.json`、`tests/test_r026.py`、`SOURCE_ACCESS_LEDGER.json`。无真实源数据、无个人可识别原始信息。开放来源许可证尚需使用方核对，避免再次分发 Zenodo 数据。
