import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from r026_source_audit import classify, gini, date_from_timestamp, EXPECTED

class TestR026(unittest.TestCase):
    def setUp(self):
        self.pre = [
            {"ParticipantID":"p1","on_reddit":"1","condition":"control","subreddit":"g1"},
            {"ParticipantID":"p2","on_reddit":"1","condition":"control","subreddit":"g1"},
            {"ParticipantID":"p3","on_reddit":"1","condition":"incentives","subreddit":"g2"},
            {"ParticipantID":"p4","on_reddit":"1","condition":"incentives","subreddit":"g2"},
            {"ParticipantID":"screened","on_reddit":"0","condition":"control","subreddit":"g1"},
        ]
        self.comments = [
            {"ParticipantID":"p1","created_comment":"2024-06-10 13:00:00"},
            {"ParticipantID":"p1","created_comment":"2024-07-08 13:00:00"},
            {"ParticipantID":"p4","created_comment":"2024-06-12 13:00:00"},
        ]
        self.post = [{"ParticipantID":"p2","survey_week":"1"}]

    def test_all_assigned_included(self):
        r=classify(self.pre,self.comments,self.post)
        self.assertEqual(r["eligible_n"],4)
        self.assertEqual(r["active_n"],2)
        self.assertEqual(r["silent_followup_n"],1)
        self.assertEqual(r["join_only_n"],1)

    def test_date_outside_window_tracked(self):
        r=classify(self.pre,self.comments,self.post)
        self.assertEqual(r["comments_after_2024_07_05"],1)
        self.assertEqual(r["total_comments_within_declared_window"],2)

    def test_no_post_selection_in_activity_rate(self):
        r=classify(self.pre,self.comments,self.post)
        self.assertEqual(r["arm_summary"]["control"]["activity_rate_all_archive"],0.5)

    def test_zero_included_in_gini(self):
        self.assertAlmostEqual(gini([0,2]),0.5)

    def test_all_zero_gini(self):
        self.assertEqual(gini([0,0,0]),0.)

    def test_duplicate_eligible_rejected(self):
        with self.assertRaises(ValueError):
            classify(self.pre+[dict(self.pre[0])],self.comments,self.post)

    def test_cross_arm_community_flagged(self):
        x=[dict(z) for z in self.pre]
        x[2]["subreddit"]="g1"
        r=classify(x,self.comments,self.post)
        self.assertTrue(any("conflicting" in s for s in r["warnings"]))

    def test_missing_csv_fingerprint_registry(self):
        self.assertEqual(len(EXPECTED),5)
        self.assertTrue(all(len(x)==32 for x in EXPECTED.values()))

    def test_iso_time(self):
        self.assertEqual(date_from_timestamp("2024-07-05 12:00:00").isoformat(),"2024-07-05")
        self.assertIsNone(date_from_timestamp("NA"))
if __name__=="__main__":
    unittest.main()
