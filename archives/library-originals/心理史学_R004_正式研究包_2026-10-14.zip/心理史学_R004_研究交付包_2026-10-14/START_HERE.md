# 心理史学 R004 独立研究交付包

创建日期：2026-10-14。所有数值输出仅属于合成模拟。

## 先读的三个文件

1. `心理史学_R004_数据适配与混淆反例_v0.1/README.md`：研究报告、结果及模型边界。
2. `心理史学_R004_数据适配与混淆反例_v0.1/数据适配矩阵.md`：ICPSR 官方信息与待核实变量。
3. `心理史学_R004_数据适配与混淆反例_v0.1/PROTOCOL.md`：实验结果生成之前固定的方案。

## Linux Mint / Python 3.10+ 复现

在本目录运行：

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r 心理史学_R004_数据适配与混淆反例_v0.1/requirements.txt
.venv/bin/python -m unittest discover -s PESEN_v0_1/tests -v
.venv/bin/python -m unittest discover -s 心理史学_R003_机制识别实验_v0.1/tests -v
.venv/bin/python -m unittest discover -s 心理史学_R004_数据适配与混淆反例_v0.1/tests -v
OPENBLAS_NUM_THREADS=1 .venv/bin/python 心理史学_R004_数据适配与混淆反例_v0.1/confounding.py --splits 12 --exploratory-permutation --out r004_recheck
```

比较 `r004_recheck/results.json` 与交付目录内 `results/results.json` 以核对结果。不同 BLAS 和软件版本可能导致浮点数末位差异。

## 范围

上一版本不变。本版本没有下载真实个体数据，也没有修改旧模型机制。 `MANIFEST.json` 列出包内每个文件的 SHA256，方便版本核查。
