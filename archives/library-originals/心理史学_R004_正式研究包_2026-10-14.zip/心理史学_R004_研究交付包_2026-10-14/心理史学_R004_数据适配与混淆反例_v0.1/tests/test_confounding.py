import sys
import unittest
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE))
sys.path.insert(0,str(HERE.parent/'心理史学_R003_机制识别实验_v0.1'))
from confounding import Config,generate,design,fit,heldout,GROUP_SIZE,permutation_negative_control
from recovery import generate_panel

class TestR004(unittest.TestCase):
    def setUp(self):
        self.cfg=Config(population=40,degree=4,rounds=8,shock_round=4,seed=42)

    def test_no_shock_matches_original_m0(self):
        got=generate(self.cfg,[21],False)
        src=generate_panel(self.cfg,'M0',[21],True)
        for k in ('y','p','q','s'):
            np.testing.assert_array_equal(got[k],src[k])

    def test_seed_reproducibility(self):
        first=generate(self.cfg,[11,12],True)
        second=generate(self.cfg,[11,12],True)
        for key in first:
            np.testing.assert_array_equal(first[key],second[key])

    def test_group_shock_is_shared_inside_contiguous_blocks(self):
        panel=generate(self.cfg,[11],True)
        for t in range(self.cfg.rounds):
            for g in range(self.cfg.population//GROUP_SIZE):
                u=panel['u'][0,t,g*GROUP_SIZE:(g+1)*GROUP_SIZE]
                self.assertTrue(np.all(u==u[0]))

    def test_design_and_oracle_extension(self):
        panel=generate(self.cfg,[11],True)
        for m in ('M0','M1','M2'):
            no=design(panel,m,False,self.cfg.initial_expressing_fraction)
            yes=design(panel,m,True,self.cfg.initial_expressing_fraction)
            self.assertEqual(yes.shape[1],no.shape[1]+1)
            np.testing.assert_array_equal(yes[:,3],panel['u'].ravel())

    def test_network_permutation_changes_q_but_not_outcomes(self):
        panel=generate(self.cfg,[11,12],True)
        out=permutation_negative_control(panel,[11,12],self.cfg)
        for key in ("y","p","s","u"):
            np.testing.assert_array_equal(out[key],panel[key])
        self.assertFalse(np.array_equal(out["q"],panel["q"]))

    def test_fit_outputs_valid_loss(self):
        panel=generate(self.cfg,[11,12],True)
        for mode in ('M0','M1','M2'):
            f=fit(panel,mode,True,self.cfg.initial_expressing_fraction)
            self.assertTrue(np.isfinite(f['train_bic']))
            self.assertGreater(heldout(panel,f,True,self.cfg.initial_expressing_fraction),0)

if __name__=='__main__': unittest.main()
