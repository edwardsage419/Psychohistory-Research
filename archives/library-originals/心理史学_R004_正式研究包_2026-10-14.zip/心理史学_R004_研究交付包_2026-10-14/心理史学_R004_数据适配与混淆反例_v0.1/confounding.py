#!/usr/bin/env python3
"""R004: A falsifiable synthetic counterexample, not evidence for real contagion.

Run from any directory: python confounding.py --out results --splits 12
Uses only numpy/scipy plus R003 recovery.py and PESEN_v0_1/pesen.py.
R004 directory must be adjacent to those two baseline directories.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys
import math
from collections import Counter

import numpy as np
from scipy.optimize import minimize

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent
sys.path.insert(0, str(PARENT / '心理史学_R003_机制识别实验_v0.1'))
from recovery import Config, generate_panel, empirical_expectation, neigh_fraction, setup

MODES = ('M0', 'M1', 'M2')
FIXED_ALPHA = 0.18
GAMMA = 2.0
PHI = 0.90
GROUP_SIZE = 10
SEED0 = 20261014


def generate(cfg: Config, seeds: list[int], with_group_shock: bool) -> dict:
    if cfg.population % GROUP_SIZE:
        raise ValueError('population must be divisible by group size')
    if not seeds:
        raise ValueError('need >=1 seed')
    arrays = []
    for seed in seeds:
        p, initial, uniforms = setup(cfg, seed)
        p = np.asarray(p, dtype=float)
        x = np.asarray(initial, dtype=float)
        rng = np.random.default_rng(seed + 250001)
        n_group = cfg.population // GROUP_SIZE
        u_state = rng.normal(size=n_group) if with_group_shock else np.zeros(n_group)
        data = {key:[] for key in ('p', 'y', 's', 'q', 'u')}
        for t in range(cfg.rounds):
            # q is measured, and is NEVER used to generate y; absence of contagion is by construction.
            q = neigh_fraction(x, cfg.degree)
            s = cfg.sanction_after if t >= cfg.shock_round else cfg.sanction_before
            u = np.repeat(u_state, GROUP_SIZE)
            z = (cfg.base_intercept + cfg.private_weight * (2*p-1)
                 - cfg.sanction_weight * s + GAMMA * u)
            prob = 1 / (1 + np.exp(-np.clip(z, -40, 40)))
            y = (np.asarray(uniforms[t]) < prob).astype(float)
            for key, v in (('p', p.copy()), ('y', y.copy()), ('s', np.full_like(p,s)),
                           ('q',q.copy()), ('u',u.copy())):
                data[key].append(v)
            x = y
            if with_group_shock:
                u_state = PHI*u_state + math.sqrt(1-PHI**2)*rng.normal(size=n_group)
        arrays.append({key:np.stack(v) for key,v in data.items()})
    return {key:np.stack([v[key] for v in arrays]) for key in arrays[0]}



def permutation_negative_control(panel:dict, seeds:list[int], cfg:Config) -> dict:
    """Exploratory control: rewire the *measured* ring ties, preserve each y and latent shock.

    Each replicate has a fixed permutation across all rounds; outcome-generating process
    is untouched because outcomes did not depend on ties. This is NOT a causal test.
    """
    output={k:v.copy() for k,v in panel.items()}
    for rep, seed in enumerate(seeds):
        perm=np.random.default_rng(seed+333333).permutation(cfg.population)
        inv=np.argsort(perm)
        _, initial, _=setup(cfg,seed)
        x=np.asarray(initial,dtype=float)
        for t in range(cfg.rounds):
            output['q'][rep,t]=neigh_fraction(x[perm],cfg.degree)[inv]
            x=panel['y'][rep,t].copy()
    return output

def design(panel:dict, mode:str, oracle:bool, initial:float) -> np.ndarray:
    if mode not in MODES:
        raise ValueError(mode)
    cols = [np.ones(panel['p'].size), (2*panel['p']-1).ravel(), -panel['s'].ravel()]
    if oracle:
        cols.append(panel['u'].ravel())
    if mode == 'M1':
        cols.append((2*panel['q']-1).ravel())
    elif mode == 'M2':
        e = empirical_expectation(panel['q'], FIXED_ALPHA, initial)
        cols.append((2*e-1).ravel())
    return np.column_stack(cols)


def fit(train:dict, mode:str, oracle:bool, initial:float) -> dict:
    X = design(train,mode,oracle,initial)
    y = train['y'].ravel()
    def objective(beta):
        z = X @ beta
        nll = np.logaddexp(0,z).sum() - y@z
        pred = 1/(1+np.exp(-np.clip(z,-40,40)))
        grad = X.T @ (pred-y)
        ridge = 1e-5 * np.dot(beta[1:],beta[1:])
        grad[1:] += 2e-5*beta[1:]
        return nll+ridge, grad
    result=minimize(objective,np.zeros(X.shape[1]),method='L-BFGS-B',jac=True,
                    bounds=[(-8,8)]*X.shape[1], options={'maxiter':200,'ftol':1e-10})
    if not result.success and np.linalg.norm(result.jac)>0.02:
        raise RuntimeError(result.message)
    z=X@result.x
    nll=float(np.logaddexp(0,z).sum()-y@z)
    return {'mode':mode,'coef':result.x.tolist(),
            'train_bic':float(2*nll+X.shape[1]*math.log(len(y)))}


def heldout(test:dict, fit_result:dict, oracle:bool, initial:float) -> float:
    z=design(test,fit_result['mode'],oracle,initial)@np.asarray(fit_result['coef'])
    y=test['y'].ravel()
    return float(np.mean(np.logaddexp(0,z)-y*z))


def run(splits:int=12, exploratory_permutation:bool=False) -> dict:
    if splits<1: raise ValueError('splits must be >=1')
    cfg=Config(population=80, degree=6, rounds=28, shock_round=14, seed=SEED0)
    records=[]
    for split in range(splits):
        base=SEED0+split*1200013
        trains=[base+31*i for i in range(4)]
        tests=[base+100003+31*i for i in range(2)]
        conditions=[('control_M0',False,False,False),
                    ('hidden_shared_shock',True,False,False),
                    ('observed_shared_shock_oracle',True,True,False)]
        if exploratory_permutation:
            conditions.append(('permuted_network_exploratory',True,False,True))
        for label, group_shocks,oracle,permuted in conditions:
            train=generate(cfg,trains,group_shocks)
            test=generate(cfg,tests,group_shocks)
            if permuted:
                train=permutation_negative_control(train,trains,cfg)
                test=permutation_negative_control(test,tests,cfg)
            fits=[fit(train,mode,oracle,cfg.initial_expressing_fraction) for mode in MODES]
            selected=min(fits,key=lambda f:f['train_bic'])['mode']
            testloss={f['mode']:heldout(test,f,oracle,cfg.initial_expressing_fraction) for f in fits}
            records.append({'split':split,'case':label,'selected':selected,
                            'spurious_social_choice':selected!='M0',
                            'train_bic':{f['mode']:round(f['train_bic'],3) for f in fits},
                            'test_log_loss':{m:round(testloss[m],6) for m in MODES},
                            'test_advantage_best_social_vs_m0':round(testloss['M0']-min(testloss['M1'],testloss['M2']),6),
                            'selected_coefficients':[round(float(v),4) for v in next(f['coef'] for f in fits if f['mode']==selected)]})
    summaries=[]
    for label in ('control_M0','hidden_shared_shock','observed_shared_shock_oracle') +\
                 (('permuted_network_exploratory',) if exploratory_permutation else ()):
        rows=[r for r in records if r['case']==label]
        choices=Counter(r['selected'] for r in rows)
        summaries.append({'case':label,'splits':splits,
                          'choices':{m:choices[m] for m in MODES},
                          'false_social_choice_fraction':round(sum(r['spurious_social_choice'] for r in rows)/splits,4),
                          'mean_test_log_loss_by_fit':{m:round(float(np.mean([r['test_log_loss'][m] for r in rows])),6) for m in MODES},
                          'mean_test_advantage_best_social_vs_m0':round(float(np.mean([r['test_advantage_best_social_vs_m0'] for r in rows])),6)})
    return {'evidence_type':'SYNTHETIC_ONLY','model':'PESEN R004 confounding counterexample',
            'premise':'True DGP has NO causal neighbor effect',
            'seed_rule':'SEED0+split*1200013; train base+31*i; test base+100003+31*i',
            'configuration':{'population':80,'degree':6,'rounds':28,'train_reps':4,'test_reps':2,
                             'group_size':GROUP_SIZE,'phi':PHI,'gamma':GAMMA,'alpha_for_M2':FIXED_ALPHA,
                             'private_preference':'exactly observed oracle', 'sanction':'relief at t=14'},
            'limitations':['simplified conditional BIC with dependent observations',
                           'known ring network','no true contagion in generative process',
                           'oracle U case only an identification upper bound'],
            'summary':summaries,'records':records}


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--out',type=Path,default=Path('results'))
    p.add_argument('--splits',type=int,default=12)
    p.add_argument('--exploratory-permutation',action='store_true',
                   help='post hoc negative control, documented separately')
    a=p.parse_args()
    a.out.mkdir(parents=True,exist_ok=True)
    result=run(a.splits,exploratory_permutation=a.exploratory_permutation)
    with (a.out/'results.json').open('w',encoding='utf-8') as f:
        json.dump(result,f,ensure_ascii=False,indent=2)
    for row in result['summary']:
        print(row)

if __name__=='__main__': main()
