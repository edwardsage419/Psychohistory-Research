import sys
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from r018_identification import (sharp_disagreement_bounds,four_joint_couplings,
                                 weighted_stratified_bounds,audit_binary_rows)

class TestR018(unittest.TestCase):
    def test_hypothetical_bounds(self):
        lo,hi=sharp_disagreement_bounds(.3,.6)
        self.assertAlmostEqual(lo,.3)
        self.assertAlmostEqual(hi,.9)
    def test_identical_marginals_can_hide_everyone_switching(self):
        self.assertEqual(sharp_disagreement_bounds(.5,.5),(0.,1.))
    def test_deterministic_private(self):
        self.assertEqual(sharp_disagreement_bounds(0.,.8),(.8,.8))
    def test_zero_and_one(self):
        self.assertEqual(sharp_disagreement_bounds(0.,1.),(1.,1.))
    def test_reject_out_of_range(self):
        for a,b in [(-.01,.3),(.2,1.001),(float('nan'),.5),(.2,float('inf'))]:
            with self.subTest(a=a,b=b),self.assertRaises(ValueError):sharp_disagreement_bounds(a,b)
    def test_extremes_have_correct_marginals_and_mismatch(self):
        for a,b in [(0.3,0.6),(.5,.5),(.9,.8),(0.,.75)]:
            bounds=sharp_disagreement_bounds(a,b)
            for key,out in four_joint_couplings(a,b).items():
                self.assertAlmostEqual(sum(out[x] for x in ['00','01','10','11']),1)
                self.assertAlmostEqual(out['10']+out['11'],a)
                self.assertAlmostEqual(out['01']+out['11'],b)
                self.assertTrue(all(out[x]>=-1e-12 for x in ['00','01','10','11']))
                self.assertAlmostEqual(out['mismatch'],bounds[0 if key.startswith('minimum') else 1])
    def test_stratum_refinement_can_improve_bounds(self):
        s=[{'weight':.5,'private_rate':0,'public_rate':1},
           {'weight':.5,'private_rate':1,'public_rate':0}]
        r=weighted_stratified_bounds(s)
        self.assertAlmostEqual(r['public_minus_private'],0)
        self.assertAlmostEqual(r['mismatch_lower'],1)
        self.assertAlmostEqual(r['mismatch_upper'],1)
        self.assertEqual(sharp_disagreement_bounds(.5,.5),(0,1))
    def test_stratum_weights_required(self):
        with self.assertRaises(ValueError):weighted_stratified_bounds([{'weight':.9,'private_rate':0,'public_rate':1}])
    def test_clean_unpaired_marginals(self):
        rows=[{'id':str(i),'q':'same','arm':str(t),'y':str(y)}
              for i,t,y in [(1,0,0),(2,0,1),(3,1,1),(4,1,1)]]
        out=audit_binary_rows(rows,'id','q','arm','y')
        self.assertEqual(out['status'],'BETWEEN_ARM_MARGINALS_ONLY_DESIGN_VALIDATION_REQUIRED')
        self.assertEqual(out['cells'][0]['private_rate'],.5)
        self.assertEqual(out['cells'][0]['public_rate'],1)
        self.assertEqual(out['cells'][0]['logical_mismatch_lower'],.5)
        self.assertEqual(out['cells'][0]['logical_mismatch_upper'],.5)
    def test_reject_duplicate_person_item_arm(self):
        rows=[{'id':'1','q':'a','arm':'0','y':'0'}]*2
        self.assertEqual(audit_binary_rows(rows,'id','q','arm','y')['status'],
                         'REJECT_DUPLICATE_PARTICIPANT_ITEM_ARM')
    def test_cross_arm_same_id_needs_review(self):
        rows=[{'id':'1','q':'a','arm':'0','y':'0'},
              {'id':'1','q':'a','arm':'1','y':'1'}]
        self.assertEqual(audit_binary_rows(rows,'id','q','arm','y')['status'],
                         'REVIEW_CROSS_ARM_SUBJECT_IDS')
    def test_missing_arm_does_not_make_fake_contrast(self):
        rows=[{'id':'1','q':'a','arm':'0','y':'0'},
              {'id':'2','q':'b','arm':'1','y':'1'}]
        r=audit_binary_rows(rows,'id','q','arm','y')
        self.assertEqual(r['item_stratum_cells_analyzable'],0)
        self.assertEqual(len(r['item_stratum_cells_missing_comparator']),2)
    def test_reject_nonbinary(self):
        for y in ['-1','2','NA','']:
            with self.subTest(y=y),self.assertRaises(ValueError):
                audit_binary_rows([{'id':'1','q':'a','arm':'0','y':y}],
                                  'id','q','arm','y')

if __name__=='__main__': unittest.main()
