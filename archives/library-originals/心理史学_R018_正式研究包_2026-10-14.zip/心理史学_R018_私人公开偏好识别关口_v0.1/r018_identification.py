#!/usr/bin/env python3
"""R018: nonparametric logical bounds and an auditable private/public-arm gate.

All estimands assume a binary, consistently defined item response. For a
randomized between-subject experiment, marginals identify an average arm
contrast, not the fraction of people who would change when exposed publicly.
Use with raw data ONLY after verifying questionnaire, randomization unit,
response mapping, missingness and follow-up ordering in the original archive.
"""
from __future__ import annotations
import argparse
import csv
import json
import math
from collections import defaultdict, Counter
from pathlib import Path


def sharp_disagreement_bounds(private_rate: float, public_rate: float) -> tuple[float, float]:
    """Fréchet-sharp bounds on Pr(Y(private) != Y(public)) from marginals.

    Consistency of both binary potential outcomes is assumed; effect is an
    unidentified joint parameter even if arm marginals are point identified.
    """
    a, b = float(private_rate), float(public_rate)
    if not (math.isfinite(a) and math.isfinite(b) and 0 <= a <= 1 and 0 <= b <= 1):
        raise ValueError('Rates must be finite and within [0,1]')
    return (abs(a-b), min(a+b, 2-a-b))


def four_joint_couplings(p_private: float, p_public: float):
    """Return extreme joint distributions over Ypriv,Ypub in {0,1}."""
    a,b=p_private,p_public
    lower_joint=max(0.0,a+b-1.0)
    upper_joint=min(a,b)
    def construct(p11):
        p10=a-p11
        p01=b-p11
        p00=1.0-p11-p10-p01
        return {'00':p00,'01':p01,'10':p10,'11':p11,
                'mismatch':p10+p01}
    return {'minimum_mismatch':construct(upper_joint),
            'maximum_mismatch':construct(lower_joint)}


def weighted_stratified_bounds(strata):
    """Sharp bounds conditional on observed pre-treatment strata marginals.

    Each input: {'weight': w, 'private_rate': p0, 'public_rate': p1}.
    Weights must be the population share of each baseline stratum, not
    post-treatment response-conditioned sample fractions unless justified.
    """
    if not strata: raise ValueError('No strata')
    total=sum(float(s['weight']) for s in strata)
    if not math.isfinite(total) or abs(total-1)>1e-9:
        raise ValueError('Stratum weights must sum to 1')
    lower=upper=effect=0.0
    for s in strata:
        w=float(s['weight'])
        if not math.isfinite(w) or w<0: raise ValueError('Invalid stratum weight')
        a,b=float(s['private_rate']),float(s['public_rate'])
        lo,hi=sharp_disagreement_bounds(a,b)
        lower+=w*lo; upper+=w*hi; effect+=w*(b-a)
    return {'public_minus_private':effect,
            'mismatch_lower':lower,'mismatch_upper':upper,
            'identified_individual_mismatch':abs(upper-lower)<1e-12}


def audit_binary_rows(rows, id_col='participant_id', item_col='item_id',
                      arm_col='arm', response_col='response',
                      stratum_col=None):
    """Do not assume independent subjects, randomization, or per-person pairs.

    Analyzes *structure*, not proof of random assignment. Response is a
    prespecified Bernoulli recoding of original sensitive-question scale.
    """
    if not rows: raise ValueError('No rows supplied')
    required=[id_col,item_col,arm_col,response_col]
    if stratum_col: required.append(stratum_col)
    if any(any(k not in r for k in required) for r in rows):
        raise ValueError('Missing required columns')
    by_id=defaultdict(set)
    key_seen=set()
    by_item_stratum=defaultdict(lambda: {'0':[], '1':[]})
    duplicates=[]
    for pos,r in enumerate(rows):
        person=str(r[id_col]).strip();item=str(r[item_col]).strip()
        arm=str(r[arm_col]).strip();out=str(r[response_col]).strip()
        stratum=str(r[stratum_col]).strip() if stratum_col else '__all__'
        if not person or not item or arm not in ('0','1') or out not in ('0','1'):
            raise ValueError(f'Invalid identity/arm/binary outcome at row {pos+1}')
        key=(person,item,arm)
        if key in key_seen: duplicates.append(key)
        key_seen.add(key)
        by_id[person].add(arm)
        by_item_stratum[(item,stratum)][arm].append(int(out))
    if duplicates:
        return {'status':'REJECT_DUPLICATE_PARTICIPANT_ITEM_ARM',
                'duplicate_count':len(duplicates),'observations':len(rows)}
    both=[person for person,arms in by_id.items() if len(arms)>1]
    if both:
        return {'status':'REVIEW_CROSS_ARM_SUBJECT_IDS',
                'observations':len(rows), 'unique_subject_ids':len(by_id),
                'cross_arm_subject_ids_count':len(both),
                'instruction':'Check whether crossover, repeated measurement, ID reuse or joined records; do not automatically compute matched disagreement.'}
    analysis=[];coverage=[]
    for (item,stratum), arms in sorted(by_item_stratum.items()):
        n0,n1=len(arms['0']),len(arms['1'])
        if not (n0 and n1):
            coverage.append({'item':item,'stratum':stratum,
                             'private_n':n0,'public_n':n1})
            continue
        a=sum(arms['0'])/n0;b=sum(arms['1'])/n1
        lo,hi=sharp_disagreement_bounds(a,b)
        analysis.append({'item':item,'stratum':stratum,'private_n':n0,
                         'public_n':n1,'private_rate':a,'public_rate':b,
                         'public_minus_private':b-a,
                         'logical_mismatch_lower':lo,'logical_mismatch_upper':hi})
    return {'status':'BETWEEN_ARM_MARGINALS_ONLY_DESIGN_VALIDATION_REQUIRED',
            'observations':len(rows),'unique_subject_ids':len(by_id),
            'item_stratum_cells_analyzable':len(analysis),
            'item_stratum_cells_missing_comparator':coverage,
            'cells':analysis,
            'limits':['Randomization, sample selection and measurement equivalence NOT certified.',
                      'The mismatch bounds are logical plug-in bounds, NOT confidence intervals.',
                      'No individual counterfactual outcome is observed.']}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--csv',type=Path,help='Normalized CSV, NOT original openICPSR Stata schema')
    p.add_argument('--id',default='participant_id')
    p.add_argument('--item',default='item_id')
    p.add_argument('--arm',default='arm')
    p.add_argument('--response',default='response')
    p.add_argument('--stratum',default=None)
    p.add_argument('--output',type=Path,default=Path('r018_output.json'))
    args=p.parse_args()
    if args.csv:
        with args.csv.open('r',encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
        result=audit_binary_rows(rows,args.id,args.item,args.arm,args.response,args.stratum)
    else:
        result={'status':'MATHEMATICAL_DEMO_ONLY_NO_BRAGHIERI_DATA',
                'hypothetical_private_rate':0.3,'hypothetical_public_rate':0.6,
                'bounds':sharp_disagreement_bounds(.3,.6),
                'extreme_joint_distributions':four_joint_couplings(.3,.6)}
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'output':str(args.output),'status':result['status']},ensure_ascii=False))


if __name__=='__main__':main()
