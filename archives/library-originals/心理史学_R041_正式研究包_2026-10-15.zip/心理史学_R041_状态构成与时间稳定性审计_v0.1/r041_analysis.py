#!/usr/bin/env python3
"""R041: executable offline, source-derived session-count analysis.

Raw GitHub CSV bytes were read by a connected GitHub tool and checked there.
This script independently reproduces analyses using nonidentifying sufficiency counts.
It does NOT claim raw bytes, Dryad equivalence or causal identification.
"""
from __future__ import annotations
import argparse
import json
import math
import random
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ARM = ('fix', 'rand')
STATES = ('DD', 'DC', 'CD', 'CC')
WINDOWS = ('02-25', '26-50', '51-75', '76-100')


def read_inputs(root=ROOT):
    base = json.loads((root / 'R040_SOURCE_DERIVED_SESSION_COUNTS.json').read_text(encoding='utf-8'))
    more = json.loads((root / 'R041_DERIVED_MIDDLE_WINDOWS.json').read_text(encoding='utf-8'))
    if base['source_checks']['persons'] != 188 or base['source_checks']['total_rows'] != 18800:
        raise ValueError('R040 provenance mismatch')
    src = base['source_train_counts']
    prior_own = [(src['own'][str(j)][1] + 0.5) / (src['own'][str(j)][0] + 1) for j in (0, 1)]
    prior_joint = [(src['joint'][str(j)][1] + 0.5) / (src['joint'][str(j)][0] + 1) for j in ('00','01','10','11')]
    sessions = []
    ids = set()
    npeople = 0
    for x in base['sessions']:
        key = x['id']
        if key in ids or key not in more['sessions']:
            raise ValueError('Missing or duplicate session')
        ids.add(key)
        npeople += x['people']
        wins = [x['train'], *more['sessions'][key], x['test']]
        if len(wins) != 4 or x['arm'] not in ARM:
            raise ValueError('Treatment / windows malformed')
        for j, cells in enumerate(wins):
            if len(cells) != 4:
                raise ValueError('Wrong number of contexts')
            for n, y in cells:
                if not isinstance(n, int) or not isinstance(y, int) or n < 0 or y < 0 or y > n:
                    raise ValueError('Invalid cell')
            if sum(n for n, _ in cells) != x['people'] * (24 if j == 0 else 25):
                raise ValueError('Wrong number of rounds in window')
        sessions.append(dict(id=key, arm=x['arm'], people=x['people'], windows=wins))
    if npeople != 188 or len(ids) != 12 or len([s for s in sessions if s['arm']=='fix']) != 6:
        raise ValueError('Unexpected sample size / treatment balance')
    return sessions, prior_own, prior_joint, base['source']


def merge_cells(cells):
    ans = [[0,0] for _ in range(4)]
    for item in cells:
        for j, (n,y) in enumerate(item):
            ans[j][0] += n
            ans[j][1] += y
    return ans


def loss(n, y, p):
    if not (0 < p < 1 and 0 <= y <= n):
        raise ValueError('Invalid probability or observation')
    return -y*math.log(p) - (n-y)*math.log1p(-p)


def brier(n, y, p):
    return (y*(1-p)**2 + (n-y)*p*p)


def summary(cells, own, joint):
    if not len(cells)==4:
        raise ValueError('Four states required')
    counts = [cell[0] for cell in cells]
    n = sum(counts)
    if n <= 0:
        raise ValueError('Empty sample')
    d=[]; db=[]; two_loss=0.; four_loss=0.; two_br=0.; four_br=0.
    for i,(m,y) in enumerate(cells):
        if m<=0:
            raise ValueError('All state cells required for standardization')
        p2=own[i//2];p4=joint[i]
        l2=loss(m,y,p2);l4=loss(m,y,p4)
        b2=brier(m,y,p2);b4=brier(m,y,p4)
        two_loss+=l2;four_loss+=l4;two_br+=b2;four_br+=b4
        d.append((l4-l2)/m)
        db.append((b4-b2)/m)
    return {
      'n':n,'cooperation_rate':sum(y for _,y in cells)/n,
      'counts':cells,
      'state_share':[m/n for m in counts],
      'state_cooperation':[y/m for m,y in cells],
      'state_delta_logloss':d,
      'state_delta_brier':db,
      'state_contribution_logloss':[counts[i]*d[i]/n for i in range(4)],
      'logloss_own':two_loss/n,'logloss_joint':four_loss/n,
      'delta_logloss':(four_loss-two_loss)/n,
      'brier_own':two_br/n,'brier_joint':four_br/n,
      'delta_brier':(four_br-two_br)/n,
      'nonCC_delta_logloss':sum(counts[i]*d[i] for i in range(3))/sum(counts[:3]),
      'CC_delta_logloss':d[3],
    }


def decomposition(fix, rand):
    w0=fix['state_share'];w1=rand['state_share']
    d0=fix['state_delta_logloss'];d1=rand['state_delta_logloss']
    poolw=[(fix['counts'][i][0]+rand['counts'][i][0])/(fix['n']+rand['n']) for i in range(4)]
    common_fix=sum(poolw[i]*d0[i] for i in range(4))
    common_rand=sum(poolw[i]*d1[i] for i in range(4))
    composition=sum((w0[i]-w1[i])*(d0[i]+d1[i])/2 for i in range(4))
    within=sum((d0[i]-d1[i])*(w0[i]+w1[i])/2 for i in range(4))
    raw=fix['delta_logloss']-rand['delta_logloss']
    if abs(composition+within-raw)>1e-11:
        raise ArithmeticError('Kitagawa decomposition failed')
    return {'raw_arm_difference':raw,
            'fixed_common_state_logloss_delta':common_fix,
            'shuffled_common_state_logloss_delta':common_rand,
            'common_state_arm_difference':common_fix-common_rand,
            'state_mix_component':composition,
            'within_state_component':within,
            'state_mix_fraction_of_difference':composition/raw if abs(raw)>1e-9 else None,
            'within_state_fraction_of_difference':within/raw if abs(raw)>1e-9 else None}


def stratified_bootstrap(sessions, own, joint, window=3, reps=20000, seed=41041):
    rng=random.Random(seed)
    byarm={arm:[s for s in sessions if s['arm']==arm] for arm in ARM}
    vals={k:[] for k in ('raw_arm_difference','common_state_arm_difference','state_mix_component','within_state_component')}
    skips=0
    for _ in range(reps):
        sampled={arm:[rng.choice(byarm[arm]) for __ in range(len(byarm[arm]))] for arm in ARM}
        try:
            st={arm:summary(merge_cells(s['windows'][window] for s in selected),own,joint)
                for arm,selected in sampled.items()}
            decomp=decomposition(st['fix'], st['rand'])
        except ValueError:
            skips+=1
            continue
        for key in vals:
            vals[key].append(decomp[key])
    if any(not v for v in vals.values()):
        raise ValueError('No bootstrap draws accepted')
    result={}
    for key,arr in vals.items():
        arr.sort(); result[key]={'q025':arr[int(.025*(len(arr)-1))], 'q975':arr[int(.975*(len(arr)-1))]}
    result['attempts']=reps
    result['valid_draws']=len(vals['raw_arm_difference'])
    result['skips']=skips
    result['unit']='session; each arm sampled separately, 6 sessions with replacement'
    return result


def run(root=ROOT, reps=20000, seed=41041):
    sessions, prior_own, prior_joint, src=read_inputs(root)
    report={'meta':{'study_round':'R041','date':'2026-10-15','input_files':src['files'],
       'n_sessions':12,'n_subjects':188,'source_models':'Frozen R039 coefficients from Akata 2025',
       'test_unit':'same 188 people in already seen follow-on analysis, exploratory retrospective; no new independent sample',
       'round_windows':WINDOWS,'context_order':STATES},
       'frozen_own_probabilities':prior_own,'frozen_joint_probabilities':prior_joint,
       'windows':{},'session_leave_one_out':{},'bootstrap':None}
    for wi, name in enumerate(WINDOWS):
        stats={arm:summary(merge_cells(s['windows'][wi] for s in sessions if s['arm']==arm),prior_own,prior_joint) for arm in ARM}
        decomp=decomposition(stats['fix'],stats['rand'])
        report['windows'][name]={'by_arm':stats,'decomposition':decomp}
    for wi in [0,3]:
        key=WINDOWS[wi]
        report['session_leave_one_out'][key]={}
        for arm in ARM:
            arr=[s for s in sessions if s['arm']==arm]
            loo=[]
            for leave in arr:
                remain=[s for s in arr if s['id']!=leave['id']]
                ds=summary(merge_cells(x['windows'][wi] for x in remain),prior_own,prior_joint)
                loo.append({'excluded_session':leave['id'],'delta_logloss':ds['delta_logloss']})
            report['session_leave_one_out'][key][arm]=loo
    report['bootstrap']=stratified_bootstrap(sessions,prior_own,prior_joint,3,reps,seed)
    return report


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--reps',type=int,default=20000)
    ap.add_argument('--seed',type=int,default=41041)
    ap.add_argument('--output',default=str(ROOT / 'R041_RESULTS.json'))
    args=ap.parse_args()
    out=run(reps=args.reps,seed=args.seed)
    Path(args.output).write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    last=out['windows']['76-100']
    de=last['decomposition']
    print('R041_ANALYSIS_COMPLETE')
    print(f"n={last['by_arm']['fix']['n']+last['by_arm']['rand']['n']} ")
    print('late_fixed_delta=%.7f late_shuffled_delta=%.7f' % (last['by_arm']['fix']['delta_logloss'],last['by_arm']['rand']['delta_logloss']))
    print('composition_component=%.7f within_component=%.7f common_gap=%.7f' % (de['state_mix_component'],de['within_state_component'],de['common_state_arm_difference']))
    print('source_raw_CSV_local=NO; full GitHub blob parsed in connector before derived counts exported')

if __name__=='__main__': main()
