# R041 心理史学正式研究包

本轮主题：在两种均提供上一轮互动反馈的条件中，R040的跨研究冻结双边状态模型为何出现预测优劣反转；检查四状态分布构成、条件预测损失、4个时间窗和场次聚类不确定性。

包含：
- `R041_EVIDENCE_AUDIT.md`：完整学术审计和因果限制；
- `R040_SOURCE_DERIVED_SESSION_COUNTS.json`：从已验证R040包继承的12场次第2—25/76—100轮匿名充分计数；
- `R041_DERIVED_MIDDLE_WINDOWS.json`：从作者GitHub完整Blob由连接器读取并提取的第26—50/51—75轮匿名汇总；
- `r041_analysis.py`：仅标准库、离线可重复计算；
- `R041_RESULTS.json`：本地独立计算的完整统计与bootstrap区间；
- `tests/test_r041.py` 和 `R041_TEST_LOG.txt`：共33项本地软件测试；
- `R042_RESEARCH_GATE.md`：下轮独立验证先验门槛；
- `R041_SOURCE_LEDGER.json`：来源审计、原始字节未在本地取得的明确标志；
- `CHECKSUMS.sha256`：各文件的哈希；
- `心理史学_研究主控台_v3.2_2026-10-15.md`：研究主控台完整后继快照，放在zip根目录。

运行：

```sh
python r041_analysis.py --reps 20000 --seed 41041
python -m unittest discover -s tests -v
```

注意：本地端到端复现对象为经过GitHub连接器核查产生的匿名来源汇总，不是作者原始GitHub/Dryad CSV字节的本地端到端复现。测试不会证明社会评价或惩罚因果机制。
