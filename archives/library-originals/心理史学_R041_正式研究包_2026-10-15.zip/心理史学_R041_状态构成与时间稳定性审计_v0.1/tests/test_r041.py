import json
import math
import tempfile
import unittest
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).parents[1]))
import r041_analysis as r

class InputTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.s, cls.own, cls.joint, cls.src = r.read_inputs()

    def test_count_sessions(self): self.assertEqual(len(self.s), 12)
    def test_count_people(self): self.assertEqual(sum(v['people'] for v in self.s),188)
    def test_arm_counts(self):
        self.assertEqual(sum(v['people'] for v in self.s if v['arm']=='fix'),92)
        self.assertEqual(sum(v['people'] for v in self.s if v['arm']=='rand'),96)
    def test_train_window_length(self):
        for s in self.s:
            self.assertEqual(sum(n for n,_ in s['windows'][0]),24*s['people'])
    def test_later_windows_length(self):
        for s in self.s:
            for win in s['windows'][1:]: self.assertEqual(sum(n for n,_ in win),25*s['people'])
    def test_four_states(self):
        self.assertEqual(len(self.own),2);self.assertEqual(len(self.joint),4)
    def test_source_parameters(self):
        self.assertAlmostEqual(self.own[0],.24283154121863798)
        self.assertAlmostEqual(self.own[1],.7760586319218241)
        self.assertAlmostEqual(self.joint[3],.909375)
    def test_source_github_sha(self):
        self.assertEqual(self.src['files'][0]['blob_sha1'],'3bf78bf85f6642afee18d6f1965dca7272582f40')
        self.assertEqual(self.src['files'][1]['blob_sha1'],'f5a86cd033b739da45d3fc7c5019068f612146a2')
    def test_total_transitions(self):
        self.assertEqual(sum(sum(n for n,_ in win) for s in self.s for win in s['windows']),188*99)
    def test_corrupt_count_fails(self):
        with tempfile.TemporaryDirectory() as d:
            import shutil
            shutil.copy(r.ROOT/'R040_SOURCE_DERIVED_SESSION_COUNTS.json',Path(d)/'R040_SOURCE_DERIVED_SESSION_COUNTS.json')
            j=json.loads((r.ROOT/'R041_DERIVED_MIDDLE_WINDOWS.json').read_text())
            j['sessions']['s10n5'][0][0][0] += 1
            (Path(d)/'R041_DERIVED_MIDDLE_WINDOWS.json').write_text(json.dumps(j))
            with self.assertRaisesRegex(ValueError,'Wrong number'):r.read_inputs(Path(d))
    def test_missing_session_fails(self):
        with tempfile.TemporaryDirectory() as d:
            import shutil
            shutil.copy(r.ROOT/'R040_SOURCE_DERIVED_SESSION_COUNTS.json',Path(d)/'R040_SOURCE_DERIVED_SESSION_COUNTS.json')
            j=json.loads((r.ROOT/'R041_DERIVED_MIDDLE_WINDOWS.json').read_text())
            del j['sessions']['s10n5']
            (Path(d)/'R041_DERIVED_MIDDLE_WINDOWS.json').write_text(json.dumps(j))
            with self.assertRaisesRegex(ValueError,'Missing'):r.read_inputs(Path(d))

class StatisticalTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.s,cls.own,cls.joint,_=r.read_inputs()
        cls.results=r.run(reps=300,seed=41041)
    def test_log_loss_known(self): self.assertAlmostEqual(r.loss(2,1,.5),2*math.log(2))
    def test_brier_known(self): self.assertAlmostEqual(r.brier(2,1,.5),.5)
    def test_loss_boundary(self):
        with self.assertRaises(ValueError):r.loss(3,1,1.)
    def test_non_positive_cell(self):
        with self.assertRaises(ValueError):r.summary([[0,0],[1,0],[1,0],[1,0]],self.own,self.joint)
    def test_early_train_size(self): self.assertEqual(self.results['windows']['02-25']['by_arm']['fix']['n'],2208)
    def test_early_test_size(self): self.assertEqual(self.results['windows']['02-25']['by_arm']['rand']['n'],2304)
    def test_late_n(self):
        v=self.results['windows']['76-100']['by_arm']
        self.assertEqual(v['fix']['n'],2300);self.assertEqual(v['rand']['n'],2400)
    def test_late_cc_rates(self):
        v=self.results['windows']['76-100']['by_arm']
        self.assertAlmostEqual(v['fix']['state_share'][3],1238/2300)
        self.assertAlmostEqual(v['rand']['state_share'][3],160/2400)
    def test_late_fixed_delta(self): self.assertAlmostEqual(self.results['windows']['76-100']['by_arm']['fix']['delta_logloss'],-.05976189805166)
    def test_late_rand_delta(self): self.assertAlmostEqual(self.results['windows']['76-100']['by_arm']['rand']['delta_logloss'],+.04337982812318)
    def test_late_brier_signs(self):
        v=self.results['windows']['76-100']['by_arm']
        self.assertLess(v['fix']['delta_brier'],0)
        self.assertGreater(v['rand']['delta_brier'],0)
    def test_decomp_identity(self):
        d=self.results['windows']['76-100']['decomposition']
        self.assertAlmostEqual(d['raw_arm_difference'],d['state_mix_component']+d['within_state_component'])
    def test_decomp_known(self):
        d=self.results['windows']['76-100']['decomposition']
        self.assertAlmostEqual(d['state_mix_component'],-.05665192029)
        self.assertAlmostEqual(d['within_state_component'],-.046489805884)
    def test_common_state_standard(self):
        d=self.results['windows']['76-100']['decomposition']
        self.assertAlmostEqual(d['common_state_arm_difference'],-.04586746431753)
    def test_noncc_worse(self): self.assertGreater(self.results['windows']['76-100']['by_arm']['fix']['nonCC_delta_logloss'],0)
    def test_four_windows(self):
        for name in r.WINDOWS:
            self.assertIn(name,self.results['windows'])
    def test_timepattern(self):
        d=self.results['windows']
        for win in r.WINDOWS:
            self.assertLess(d[win]['by_arm']['fix']['delta_logloss'],0)
        for win in r.WINDOWS[1:]:
            self.assertGreater(d[win]['by_arm']['rand']['delta_logloss'],0)
    def test_loo_fixed_all_negative(self):
        for z in self.results['session_leave_one_out']['76-100']['fix']:
            self.assertLess(z['delta_logloss'],0)
    def test_loo_shuffled_all_positive(self):
        for z in self.results['session_leave_one_out']['76-100']['rand']:
            self.assertGreater(z['delta_logloss'],0)
    def test_cluster_bootstrap_replicable(self):
        x=r.stratified_bootstrap(self.s,self.own,self.joint,reps=20,seed=4)
        y=r.stratified_bootstrap(self.s,self.own,self.joint,reps=20,seed=4)
        self.assertEqual(x,y)
    def test_cluster_bootstrap_bounds(self):
        v=self.results['bootstrap']
        self.assertEqual(v['valid_draws'],300)
        self.assertLess(v['common_state_arm_difference']['q025'],v['common_state_arm_difference']['q975'])
    def test_model_freeze_not_fitted_to_target(self):
        base=json.loads((r.ROOT/'R040_SOURCE_DERIVED_SESSION_COUNTS.json').read_text())
        self.assertEqual(base['source_train_counts']['joint']['11'],[479,436])

if __name__=='__main__':unittest.main()
