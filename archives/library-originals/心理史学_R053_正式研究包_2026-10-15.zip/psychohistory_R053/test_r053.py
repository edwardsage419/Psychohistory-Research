import unittest
import numpy as np
from r053_holdout import git_blob_sha, parse_raw_csv, build_transitions, feat, fit, predict, evaluate

class R053Tests(unittest.TestCase):
    def synthetic(self):
        rows=[]
        for session in (1,2,3,4):
            ff=int(session>=3)
            for roundid in range(1,7):
                for slot in range(1,5):
                    subj=session*100+slot
                    row={'ProfileID':subj,'GameID':1,'RoundID':roundid,'Token':50,
                         'Invest':10+slot+roundid+session,'Received':0.0,'Paid':0.0,
                         'Total':50.0,'Total2':50.0,'Session':session,'Homo':1,
                         'FF':ff,'group':100+10*session+1,'slot':slot if ff else None}
                    for j in range(1,5):
                        row[f'Seq{j}']=None if j==slot or not ff else 0.0
                    rows.append(row)
        return rows
    def test_hash(self):
        self.assertEqual(git_blob_sha(b'hello'), 'b6fc4c620b67d95f953a5c1c1230aaab5db5a1b0')
    def test_missing_sha_refused(self):
        raw=b'ProfileID,FF\n1,1\n'
        with self.assertRaisesRegex(ValueError,'Git blob'):
            parse_raw_csv(raw,source_check=True)
    def test_schema_rejects(self):
        with self.assertRaisesRegex(ValueError,'columns missing'):
            parse_raw_csv(b'ProfileID,FF\n1,1\n',source_check=False)
    def test_synthetic_transitions(self):
        ts, audit=build_transitions(self.synthetic(),strict=False)
        self.assertEqual(len(ts),64)
        self.assertEqual(audit['profit_reconstruction_failures'],0)
        self.assertEqual({r['round'] for r in ts},{3,4,5,6})
    def test_group_size_rejected(self):
        with self.assertRaisesRegex(ValueError,'four members'):
            build_transitions(self.synthetic()[:-1],strict=False)
    def test_slot_rejected(self):
        rows=self.synthetic();rows[-1]['slot']=1
        with self.assertRaisesRegex(ValueError,'unique self slots'):
            build_transitions(rows,strict=False)
    def test_source_expected_full_rejected(self):
        with self.assertRaisesRegex(ValueError,'missing rounds'):
            build_transitions(self.synthetic(),strict=True)
    def test_cross_group_lag_rejected(self):
        rows=self.synthetic();rows[-1]['group']=777
        with self.assertRaises(ValueError):
            build_transitions(rows,strict=False)
    def test_punishment_reconstruction(self):
        rows=self.synthetic();group=[r for r in rows if r['Session']==3 and r['RoundID']==3]
        donor=group[0];donor['Seq2']=3.0;donor['Paid']=1.0;donor['Total2']=49.0
        subject=group[1];subject['Received']=3.0;subject['Total2']=47.0
        ts,audit=build_transitions(rows,strict=False)
        self.assertEqual(audit['received_mismatches_after_practice'],0)
        self.assertEqual(audit['profit_reconstruction_failures'],0)
        self.assertEqual(next(t for t in ts if t['subject']==302 and t['round']==4)['corrected'],3)
    def test_punishment_wrong_receipt_detected(self):
        rows=self.synthetic();group=[r for r in rows if r['Session']==3 and r['RoundID']==3]
        group[0]['Seq2']=3;group[0]['Paid']=1;group[0]['Total2']=49
        ts,audit=build_transitions(rows,strict=False)
        self.assertEqual(audit['received_mismatches_after_practice'],1)
        self.assertEqual(audit['profit_reconstruction_failures'],1)
    def test_consistent_feature_shapes(self):
        z=build_transitions(self.synthetic(),strict=False)[0][0]
        self.assertEqual(len(feat(z,'context')),6)
        self.assertEqual(len(feat(z,'orig')),7)
        self.assertEqual(len(feat(z,'corrected')),7)
    def test_persistence(self):
        z=build_transitions(self.synthetic(),strict=False)[0][0]
        self.assertEqual(predict(z,'persistence'),z['prev'])
    def test_prediction_clipped(self):
        z=build_transitions(self.synthetic(),strict=False)[0][0]
        self.assertEqual(predict(z,'context',np.array([100,0,0,0,0,0])),z['token'])
        self.assertEqual(predict(z,'context',np.array([-100,0,0,0,0,0])),0)
    def test_holdout(self):
        z=build_transitions(self.synthetic(),strict=False)[0]
        result=evaluate(z)
        self.assertEqual(len(result['folds']),4)
        self.assertEqual(result['overall']['n'],64)
        self.assertTrue(np.isfinite(result['overall']['mse']['context']))
    def test_only_one_session_refused(self):
        with self.assertRaisesRegex(ValueError,'two sessions'):
            evaluate([z for z in build_transitions(self.synthetic(),strict=False)[0] if z['session']==1])
    def test_no_label_leakage(self):
        z=build_transitions(self.synthetic(),strict=False)[0]
        f=evaluate(z)['folds']
        self.assertEqual(sum(x['n'] for x in f),64)
        self.assertTrue(all(x['n']==16 for x in f))

if __name__=='__main__': unittest.main()
