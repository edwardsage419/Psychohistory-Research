# 心理史学 R053 回溯研究包

本包在R052后继续推进，重点是以此前独立核实的真实`InequalityCPR`实验数据作八场次留出预测，明确判断受罚记录是否具有强于历史行为和环境条件的增量预测价值。

来源 `https://github.com/lrdegeest/InequalityCPR/blob/master/data/data.csv`，Git blob SHA1 `73c02176bc9e060af987149594a85f9f7b591230`。

## 完整本地重放步骤

1. 在GitHub作者官方仓库取得**原始字节** `data.csv`，不得在Excel打开并另存改变字节；本研究包刻意不含原作者个体微观数据。
2. 安装Python 3.10或更新版及numpy。
3. 运行：

```bash
python -m unittest -v test_r053.py
python r053_holdout.py --csv /path/to/original/data.csv --output R053_LOCAL_REPLAY.json
```

严格入口校验源Git blob与128人/32组/8场次/源对账，失败则不生成正式结果。

## 可得性和复现等级

真实CSV由GitHub连接器读取并在连接器端用JavaScript计算。原始CSV没有取得同一份本地字节，因而本地Python工具目前只经构造数据测试；此包的R053_RESULTS.json是连接器真实数据数值记录，不能混同于本地字节端到端复算。模型是历史事后探索，没有确认因果或前瞻性外部预测。

PESEN v0.1 继续冻结。
