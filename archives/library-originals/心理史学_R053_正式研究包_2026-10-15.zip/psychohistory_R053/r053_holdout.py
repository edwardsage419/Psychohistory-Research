#!/usr/bin/env python3
"""R053: Exploratory leave-one-session-out forecast audit of InequalityCPR.

For complete independent rerun, download author data/data.csv from
https://github.com/lrdegeest/InequalityCPR and pass it with --csv.
No synthetic inputs are allowed in the publication command unless source_check=False
is explicitly used via the unit-tested Python API.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import io
import itertools
import json
from collections import defaultdict
from pathlib import Path
import numpy as np

AUTHOR_GIT_BLOB = '73c02176bc9e060af987149594a85f9f7b591230'
FEATURES = ['intercept','lag_relative_invest','lag_group_mean_scaled','punishment_protocol','low_endowment','high_endowment']
MODES = ('persistence','context','orig','corrected')

def git_blob_sha(raw: bytes) -> str:
    return hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()

def _n(text: str):
    if text.strip() in ('', '.'):
        return None
    return float(text)

def parse_raw_csv(raw: bytes, source_check: bool = True):
    if source_check and git_blob_sha(raw) != AUTHOR_GIT_BLOB:
        raise ValueError('Original source Git blob SHA1 mismatch; no analysis.')
    f=io.StringIO(raw.decode('utf-8-sig'), newline='')
    rdr=csv.DictReader(f)
    required={'ProfileID','GameID','RoundID','Token','Invest','Received','Session','Homo','FF','Seq1','Seq2','Seq3','Seq4','Paid','Total','Total2'}
    if not rdr.fieldnames or not required.issubset(rdr.fieldnames):
        raise ValueError('Required original columns missing')
    rows=[]
    for rec in rdr:
        if not rec['ProfileID'] or not rec['ProfileID'].strip():
            continue
        vals={k:_n(rec[k] or '') for k in required}
        if any(vals[k] is None for k in ['ProfileID','GameID','RoundID','Token','Invest','Session','Homo','FF']):
            raise ValueError('Incomplete ID or behavior')
        o={k:(int(v) if k in {'ProfileID','GameID','RoundID','Token','Session','Homo','FF'} else v) for k,v in vals.items()}
        o['group']=100*o['Homo']+10*o['Session']+o['GameID']
        o['slot']=next((i for i in range(1,5) if o[f'Seq{i}'] is None), None) if o['FF']==1 else None
        rows.append(o)
    if source_check:
        if len(rows)!=2048 or len(set(z['ProfileID'] for z in rows))!=128:
            raise ValueError('Official size/person count mismatch')
        if len(set(z['group'] for z in rows))!=32:
            raise ValueError('Official group count mismatch')
        if len(set(z['Session'] for z in rows))!=8:
            raise ValueError('Official session count mismatch')
    return rows

def build_transitions(rows: list[dict], strict: bool = True):
    by_group_round=defaultdict(list)
    by_subject=defaultdict(list)
    for o in rows:
        by_group_round[(o['group'],o['RoundID'])].append(o)
        by_subject[o['ProfileID']].append(o)
    invalid_received=[]
    invalid_profit=[]
    for (g,roundid), b in by_group_round.items():
        if len(b)!=4:
            raise ValueError('Expected four members per group and round')
        ff={o['FF'] for o in b}
        if len(ff)!=1:
            raise ValueError('Mixed punishment protocol within group')
        if next(iter(ff))==1 and sorted(o['slot'] for o in b)!=[1,2,3,4]:
            raise ValueError('Punishment-directed matrix lacks four unique self slots')
        mean=sum(z['Invest'] for z in b)/4
        for o in b:
            o['mean']=mean
            if o['FF']==1:
                o['reconstructed']=sum((other.get(f"Seq{o['slot']}") or 0) for other in b if other is not o)
                if o['RoundID']>1:
                    if o['Received'] is None or abs(o['Received']-o['reconstructed'])>1e-8:
                        invalid_received.append(o)
                    if o['Paid'] is None or abs(3*o['Paid'] - sum((o.get(f'Seq{i}') or 0) for i in range(1,5)))>1e-6:
                        raise ValueError('Own punishment expense inconsistent')
                    if o['Total'] is None or o['Total2'] is None or abs(o['Total']-o['Paid']-o['reconstructed']-o['Total2'])>0.025:
                        invalid_profit.append(o)
            else:
                o['reconstructed']=0
    out=[]
    for subj,b in by_subject.items():
        b.sort(key=lambda o:o['RoundID'])
        if strict and (len(b)!=16 or [o['RoundID'] for o in b]!=list(range(1,17))):
            raise ValueError('Subject has missing rounds')
        for j in range(1,len(b)):
            prev,cur=b[j-1],b[j]
            if cur['RoundID']!=prev['RoundID']+1:
                raise ValueError('Nonconsecutive rounds')
            if cur['RoundID']<3:
                continue
            if cur['group']!=prev['group'] or cur['FF']!=prev['FF']:
                raise ValueError('Cross-group or cross-treatment lag leakage')
            out.append({'session':cur['Session'],'group':cur['group'],'subject':subj,
                'round':cur['RoundID'],'FF':cur['FF'],'Homo':cur['Homo'],'token':cur['Token'],
                'prev':prev['Invest'],'mean':prev['mean'],'orig':prev['Received'] or 0,
                'corrected':prev['reconstructed'],'y':cur['Invest']})
    if strict:
        if len(out)!=1792 or len(invalid_received)!=80 or len(invalid_profit)!=0:
            raise ValueError('Author dataset structural/source audit failed')
        if len(set(z['session'] for z in out))!=8 or set(z['round'] for z in out)!=set(range(3,17)):
            raise ValueError('Unexpected output structure')
    return out, {'n_source_rows':len(rows),'n_transitions':len(out),
                 'received_mismatches_after_practice':len(invalid_received),
                 'profit_reconstruction_failures':len(invalid_profit),
                 'affected_transition_count':sum(z['orig']!=z['corrected'] for z in out)}

def feat(z,model):
    v=[1.,z['prev']/z['token'],z['mean']/50.,float(z['FF']),
       float(z['token']==40),float(z['token']==60)]
    if model in ('orig','corrected'):
        v.append(z[model]/100.)
    return v

def fit(train,model):
    X=np.asarray([feat(o,model) for o in train],dtype=float)
    y=np.asarray([o['y']/o['token'] for o in train],dtype=float)
    penalty=np.eye(X.shape[1])*1e-6
    penalty[0,0]=0
    return np.linalg.solve(X.T@X+penalty,X.T@y)

def predict(o,model,beta=None):
    if model=='persistence':
        return o['prev']
    return float(np.clip(o['token']*(np.array(feat(o,model))@beta),0,o['token']))

def evaluate(transitions):
    sessions=sorted(set(z['session'] for z in transitions))
    if len(sessions)<2:
        raise ValueError('At least two sessions required')
    folds=[]
    for s in sessions:
        train=[o for o in transitions if o['session']!=s]
        test=[o for o in transitions if o['session']==s]
        betas={m:fit(train,m) for m in MODES if m!='persistence'}
        f={'session':s,'n':len(test),'FF':test[0]['FF'],'Homo':test[0]['Homo'], 'models':{}}
        for m in MODES:
            error=[o['y']-predict(o,m,betas.get(m)) for o in test]
            f['models'][m]={'mse':float(np.mean(np.square(error))), 'mae':float(np.mean(np.abs(error)))}
        folds.append(f)
    def summary(sub):
        a=[f for f in folds if sub(f)]
        n=sum(f['n'] for f in a)
        return {'n':n,'mse':{m:sum(f['models'][m]['mse']*f['n'] for f in a)/n for m in MODES}}
    differences=np.asarray([f['models']['corrected']['mse']-f['models']['context']['mse'] for f in folds])
    rng=np.random.default_rng(20261015)
    bs=np.mean(differences[rng.integers(0,len(differences),(20000,len(differences)))],axis=1)
    observed=abs(differences.mean())
    signflip=np.mean([abs(np.mean(differences*np.asarray(sign)))>=observed-1e-12
                      for sign in itertools.product((-1,1),repeat=len(differences))])
    return {'folds':folds,'overall':summary(lambda x:True),'punishment_only':summary(lambda x:x['FF']==1),
            'no_punishment_only':summary(lambda x:x['FF']==0),
            'corrected_minus_context_mse':float(differences.mean()),
            'improved_sessions':int(sum(differences<0)),
            'session_bootstrap_95_percentile':list(map(float,np.quantile(bs,[0.025,0.975]))),
            'eight_session_sign_flip_p':float(signflip)}

def main():
    p=argparse.ArgumentParser(description='R053 strict source-level repeated-game forecast reproduction')
    p.add_argument('--csv',type=Path,required=True,help='Official original data.csv; Git blob SHA must match')
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    raw=a.csv.read_bytes()
    rows=parse_raw_csv(raw,source_check=True)
    ts,audit=build_transitions(rows,strict=True)
    result={'study':'De Geest and Kingsley, InequalityCPR',
            'raw_git_blob_sha1':git_blob_sha(raw),'raw_sha256':hashlib.sha256(raw).hexdigest(),
            'source_audit':audit,'design':'Exploratory retrospective LO session out; no preregistration',
            'ridge_penalty':1e-6,'outcome':'next round absolute resource extraction',
            'results':evaluate(ts)}
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'source_audit':audit,'overall':result['results']['overall'],
                      'ci':result['results']['session_bootstrap_95_percentile']},ensure_ascii=False))
if __name__=='__main__':
    main()
