# 心理史学 R029 正式研究包

2026-10-14。上游R028（主控台v1.9），本轮完成资料准入审查、2016年新复合行为结局的区块稳健性再计算、以及2022作者笔记本静态审计。**2019/2020三项复制实验源数据仍未取得，本包没有新试验的原始效应复现。** PESEN v0.1 冻结。

## 复算

仅需 Python 3.9+：

```bash
python -m unittest discover -s tests -v
python r029_analysis.py --output R029_RESULTS.json
```

将使用 `BLOCK_SUMMARY_BASE36.txt`（R027从2016作者原始CSV导出的219区块匿名汇总）重新生成结果。该汇总没有单个帖子行，因此不能从此包直接执行219区块内5/10帖子重新洗牌的尖锐零效应置换检验。它足以精确重算区块平均差、派生复合结局、按区块bootstrap以及区块影响分析。

`SOURCE_ACCESS_LEDGER.json` 的六项验证全部通过时才允许把新试验标记为可执行自主实证分析。空缺不构成新实验效应为零的证据。

文件说明：

* `R029_EVIDENCE_AUDIT.md`：研究结论、限度、数学解释及下一阶段关口。
* `r029_analysis.py`：标准库可运行复算脚本。
* `R029_RESULTS.json`：机器可核查输出。
* `NOTEBOOK_TRACE.json`：GitHub元分析笔记本原始哈希与审计所用的短代码片段。
* `SOURCE_ACCESS_LEDGER.json`：源数据访问与六项准入状态。
* `BLOCK_SUMMARY_BASE36.txt`：R027已经公开的同一样本衍生区块汇总，**不是新独立实验**。
* `AUTHOR_DATA_REQUEST_DRAFT.md`：供owner决定是否使用的数据请求文本，未发送。
* `tests/test_r029.py`：12项单元测试。

科学结论和许可证仍需在再次分发数据前核验。不会写入 GitHub 或更改 PESEN v0.1。
