#!/usr/bin/env python3
# coding: utf-8
"""心理史学 R029：跨社区资料准入和2016年复合行为结局稳健性审查。

零第三方依赖。基于R027从作者原始帖子CSV生成的219个随机化区块派生统计。
没有2019/2020新实验原始数据时，程序严格拒绝输出其“独立效应复现”。
"""
import argparse
import hashlib
import json
import math
import random
import statistics
from pathlib import Path

EXPECTED_BLOCKS=219
EXPECTED_ARMS_PER_BLOCK=5
EXPECTED_RAW_BLOB='404aae15453952f9588d363c8cb7521e45a64959'
SOURCE='https://github.com/citizensandtech/CivilServant-Analysis/blob/master/papers/r_science_2016/r_science_experiment_1_posts.09.26.2016.csv'


def load_block_data(path):
    txt=Path(path).read_text(encoding='utf-8').strip()
    records=[]
    for part in txt.split('|'):
        k, vals=part.split(':', 1)
        nums=[int(v,36) for v in vals.split('.')]
        if len(nums)!=6 or any(v<0 for v in nums):
            raise ValueError('Expected six nonnegative block aggregate fields')
        # (newcomer_comment_count, deleted_count, positive_threads) for each arm
        if nums[1]>nums[0] or nums[4]>nums[3] or nums[2]>5 or nums[5]>5:
            raise ValueError('Impossible per-block aggregate')
        records.append({'block':int(k,36), 'c_y':nums[0], 'c_deleted':nums[1],
                        'c_active':nums[2], 't_y':nums[3],
                        't_deleted':nums[4], 't_active':nums[5]})
    if len(records)!=EXPECTED_BLOCKS or len(set(x['block'] for x in records))!=EXPECTED_BLOCKS:
        raise ValueError('Incomplete or duplicate blocks')
    return sorted(records,key=lambda x:x['block'])


def paired_result(records, metric):
    n=len(records)
    def values(r):
        if metric=='not_removed':
            return (r['t_y']-r['t_deleted'],r['c_y']-r['c_deleted'])
        if metric=='total_comments':
            return r['t_y'],r['c_y']
        if metric=='removed_comments':
            return r['t_deleted'],r['c_deleted']
        if metric=='any_comments':
            return r['t_active'],r['c_active']
        raise ValueError('Unknown metric')
    pairs=[values(r) for r in records]
    diffs=[(t-c)/EXPECTED_ARMS_PER_BLOCK for t,c in pairs]
    t_total=sum(t for t,c in pairs)
    c_total=sum(c for t,c in pairs)
    m=statistics.mean(diffs)
    se=statistics.stdev(diffs)/math.sqrt(n)
    return {
        'n_blocks':n,'n_posts_per_arm':n*EXPECTED_ARMS_PER_BLOCK,
        'treated_total':t_total,'control_total':c_total,
        'treated_mean':t_total/(n*EXPECTED_ARMS_PER_BLOCK),
        'control_mean':c_total/(n*EXPECTED_ARMS_PER_BLOCK),
        'difference':m,
        'mean_ratio':t_total/c_total if c_total else None,
        'block_paired_SE_exploratory':se,
        'approx_normal_95_interval':[m-1.96*se,m+1.96*se],
        'block_sign_counts':{
            'positive':sum(d>0 for d in diffs),
            'zero':sum(d==0 for d in diffs),
            'negative':sum(d<0 for d in diffs)},
    }


def block_concentration(records,top=(1,5,10,20)):
    ranked=sorted([(r['t_y']-r['t_deleted']-r['c_y']+r['c_deleted'])/5 for r in records],reverse=True)
    total=sum(ranked)
    return {'positive_block_contribution_sorted_post_hoc':{
        str(k):{'share_net_total_difference':sum(ranked[:k])/total if total else None,
                'average_diff_after_omitting_largest_positive_k':sum(ranked[k:])/(len(ranked)-k)}
        for k in top},
        'scope':'Retrospective influence diagnostic; not a prespecified trimmed ITT nor randomization p value.'}


def block_bootstrap_ci(records,metric='not_removed',draws=5000,seed=20261014):
    if draws<20:raise ValueError('draws too small')
    n=len(records)
    rng=random.Random(seed)
    deltas=[]
    for r in records:
        if metric=='not_removed':
            deltas.append((r['t_y']-r['t_deleted']-r['c_y']+r['c_deleted'])/5)
        else:raise ValueError('Only not_removed implemented')
    trials=[sum(deltas[rng.randrange(n)] for _ in range(n))/n for _ in range(draws)]
    trials.sort()
    return {'draws':draws,'seed':seed,'percentile_95_interval':[trials[int(.025*(draws-1))],trials[int(.975*(draws-1))]],
            'interpretation':'Exploratory block resampling; it is not a sharp-null randomization test.'}


def new_data_gate(manifest):
    """Separate independently verified raw data from reported numerical outputs."""
    good=[];blocked=[]
    for name in ['science_2020','ffxiv_2019','futurology_2020']:
        s=manifest.get(name,{})
        required=('raw_bytes_verified','assignment_verified','zero_outcomes_retained',
                  'exclusions_audited','outcome_dictionary_verified','analysis_frozen_before_raw_effects')
        failures=[k for k in required if s.get(k) is not True]
        (blocked if failures else good).append({'study':name,'missing_requirements':failures})
    return {'new_studies_with_all_gates':[x['study'] for x in good],
            'blocked_studies':blocked,
            'new_trial_effect_reanalyses_permitted':len(good),
            'warning':'No observed new-study numerical causal effects can be returned from author notebook outputs.'}


def audit_notebook_trace(trace):
    source_header=trace['science_2016_raw_csv_columns']
    code=trace['notebook_fragments']
    issues=[]
    if 'AMA' in code['2016_post_subset'] and 'AMA' not in source_header:
        issues.append({'id':'NOTEBOOK_SCHEMA_MISMATCH','severity':'unresolved',
                       'evidence':'2022 subset references AMA while frozen 2016 public CSV has post.ama; clean execution needs explicit mapping.'})
    if '(1|link_id/study)' in code['meta_random_effects']:
        issues.append({'id':'R_RANDOM_EFFECT_NESTING_DIRECTION','severity':'requires_reanalysis',
                       'evidence':'R nesting a/b expands to a + a:b; intended hierarchical study/post requires study/link_id if names do not already encode unique study.'})
    if 'newcomer.comments ~ treatment + visible' in code['newcomer_count_model']:
        issues.append({'id':'ADJUSTMENT_TEMPORAL_STATUS_UNKNOWN','severity':'needs_dictionary',
                       'evidence':'Need to verify if visible is post-randomization, affected by moderation, or observed before assignment.'})
    return {'reviewed_trace':True,'issues':issues,'n_issue_flags':len(issues),
            'status':'STATIC_CODE_AUDIT_ONLY; NO CLAIM_OF_AUTHOR_ERROR_CONFIRMED'}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    here=Path(__file__).resolve().parent
    p.add_argument('--aggregates',type=Path,default=here/'BLOCK_SUMMARY_BASE36.txt')
    p.add_argument('--trace',type=Path,default=here/'NOTEBOOK_TRACE.json')
    p.add_argument('--manifest',type=Path,default=here/'SOURCE_ACCESS_LEDGER.json')
    p.add_argument('--output',type=Path,default=here/'R029_RESULTS.json')
    args=p.parse_args()
    blocks=load_block_data(args.aggregates)
    meta=json.loads(args.manifest.read_text(encoding='utf-8'))
    trace=json.loads(args.trace.read_text(encoding='utf-8'))
    d={m:paired_result(blocks,m) for m in ['total_comments','removed_comments','not_removed','any_comments']}
    res={'round':'R029', 'source':SOURCE,
         'original_2016_author_csv_blob_sha1':EXPECTED_RAW_BLOB,
         'local_input':'R027 derived 219-block aggregates, NOT original source bytes',
         'descriptive_outcomes_2016':d,
         'composite_metric_definition':'newcomer.comments - newcomer.comments.removed, each randomized post, zeros included',
         'concentration':block_concentration(blocks),
         'bootstrap':block_bootstrap_ci(blocks),
         'new_study_data_gate':new_data_gate(meta['candidate_followups']),
         'notebook_static_code_audit':audit_notebook_trace(trace),
         'restrictions':['All exploratory analyses conducted after seeing 2016 main effect',
                         'Not a fresh independent experiment',
                         'No original follow-up 2019/2020 raw data has been independently downloaded',
                         'No estimation of social evaluation or punishment mechanism',
                         'R2016 social-norm intervention combines rule visibility, moderation and participation selection']}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(res,ensure_ascii=False,indent=2),encoding='utf-8')
    print('R029: NEW_FOLLOWUP_RAW_BLOCKED | 2016_BEHAVIORAL_COMPOSITE_VERIFIED_FROM_DERIVED_BLOCKS')
    print('Written:',args.output)

if __name__=='__main__':main()
