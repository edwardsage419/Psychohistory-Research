# 研究数据访问请求草案（未发送）

**Subject:** Request for de-identified replication data and codebook for the Reddit harassment-prevention field experiments (2019–2020)

Dear CAT Lab research team,

I am conducting an independent methodological review of the Reddit community norms experiments reported in your August 2022 cross-community study summary. I reviewed the public meta-analysis notebook at `natematias/harassment-prevention-replications` and the 2016 r/science study's published data and code.

Could you clarify whether de-identified post-level replication data and the associated codebooks can be shared for the r/science 2020, r/ffxiv 2019, and r/futurology 2020 experiments? In particular, I am looking for the source tables referred to in the notebook as `r-science-posts-06.19.2022.csv`, `r-ffxiv-posts-11.22.2020.csv`, and `r-futurology-posts-07.18.2022.csv`, or a publicly available equivalent. I would also appreciate the randomization block specifications, the planned versus implemented exclusions, a definition and measurement timeline for `visible`, and any documentation of moderation-log gaps.

I do not need usernames, identifiable user histories, private comments, or material that is not approved for redistribution. A reproducible aggregate at the randomization-block level, with a data dictionary and restrictions on inference, would also be valuable.

I am particularly interested in making a careful distinction between effects on total newcomer contribution, newcomer entry into discussions, and removal or compliance outcomes. The objective is independent verification of the methods and the limits of cross-community generalization.

If these data are available through an existing repository, a link and version reference would be sufficient. Please let me know about any access requirements or limitations on reuse.

Thank you for your consideration.

Sincerely,
[Researcher / affiliation, if applicable]

---

**使用说明**：这是未发送草案。研究者不得凭此自动联系作者；未经授权不共享用户个人信息。邮件内的研究组称谓和联系方式必须由用户核实。
