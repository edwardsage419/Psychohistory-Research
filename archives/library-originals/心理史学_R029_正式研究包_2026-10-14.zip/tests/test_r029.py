import sys
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from r029_analysis import load_block_data, paired_result, block_concentration, block_bootstrap_ci, new_data_gate, audit_notebook_trace
import json

class TestR029(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.blocks=load_block_data(ROOT/'BLOCK_SUMMARY_BASE36.txt')
        cls.source=json.loads((ROOT/'SOURCE_ACCESS_LEDGER.json').read_text(encoding='utf-8'))
        cls.trace=json.loads((ROOT/'NOTEBOOK_TRACE.json').read_text(encoding='utf-8'))

    def test_distinct_blocks(self):self.assertEqual(len({b['block'] for b in self.blocks}),219)
    def test_original_comment_counts(self):
        r=paired_result(self.blocks,'total_comments');self.assertEqual((r['treated_total'],r['control_total']),(11506,6758))
    def test_removed_counts(self):
        r=paired_result(self.blocks,'removed_comments');self.assertEqual((r['treated_total'],r['control_total']),(5704,3857))
    def test_not_removed_composite(self):
        r=paired_result(self.blocks,'not_removed');self.assertEqual((r['treated_total'],r['control_total']),(5802,2901));self.assertEqual(r['mean_ratio'],2.0)
    def test_diff_identity(self):
        a=paired_result(self.blocks,'total_comments')['difference']
        b=paired_result(self.blocks,'removed_comments')['difference']
        c=paired_result(self.blocks,'not_removed')['difference'];self.assertAlmostEqual(a-b,c)
    def test_zero_comments(self):
        r=paired_result(self.blocks,'any_comments');self.assertEqual((r['treated_total'],r['control_total']),(395,402))
    def test_rare_block_concentration(self):
        r=block_concentration(self.blocks);self.assertGreater(r['positive_block_contribution_sorted_post_hoc']['5']['share_net_total_difference'],.74)
    def test_bootstrap_seed_determinism(self):
        a=block_bootstrap_ci(self.blocks,draws=75,seed=123);b=block_bootstrap_ci(self.blocks,draws=75,seed=123);self.assertEqual(a,b)
    def test_gating(self):
        r=new_data_gate(self.source['candidate_followups']);self.assertEqual(len(r['blocked_studies']),3);self.assertEqual(r['new_trial_effect_reanalyses_permitted'],0)
    def test_gate_positive_case(self):
        fields=['raw_bytes_verified','assignment_verified','zero_outcomes_retained','exclusions_audited','outcome_dictionary_verified','analysis_frozen_before_raw_effects']
        p={'science_2020':{v:True for v in fields}};r=new_data_gate(p);self.assertEqual(r['new_trial_effect_reanalyses_permitted'],1)
    def test_static_audit(self):
        r=audit_notebook_trace(self.trace);self.assertEqual(r['n_issue_flags'],3)
    def test_bad_source(self):
        p=ROOT/'_temporary_bad_base36.txt';p.write_text('a:1.2.3.4.5.6',encoding='utf-8')
        try:
            with self.assertRaises(ValueError):load_block_data(p)
        finally:p.unlink()

if __name__=='__main__':unittest.main()
