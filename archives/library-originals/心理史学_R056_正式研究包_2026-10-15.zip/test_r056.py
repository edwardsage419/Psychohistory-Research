"""Only software verification and frozen derived aggregate checks, not raw-source replays."""
import csv
import hashlib
import io
import math
import tempfile
import unittest
from pathlib import Path

import r056_partisan_crowds as mod

ROOT = Path(__file__).parent

class SourceLockTests(unittest.TestCase):
    def test_git_blob_known_test_vector(self):
        self.assertEqual(mod.git_blob_sha(b"test content\n"), hashlib.sha1(b"blob 13\0test content\n").hexdigest())

    def test_refuse_wrong_bytes(self):
        with self.assertRaisesRegex(ValueError, "not authenticated"):
            mod.parse_source_bytes(b"this is not the original", locked=True)

    def test_refuse_missing_schema_unlocked(self):
        with self.assertRaisesRegex(ValueError, "missing"):
            mod.parse_source_bytes(b"a,b\n1,2\n", locked=False)

    def test_empty_source_unlocked_schema(self):
        header = ','.join(sorted(mod.INPUT_COLUMNS))+'\n'
        rows, _ = mod.parse_source_bytes(header.encode(), locked=False)
        self.assertEqual(rows, [])

    def test_empty_missing_value(self):
        self.assertIsNone(mod.valid_number(""))

    def test_na_missing(self):
        self.assertIsNone(mod.valid_number("NA"))

    def test_inf_missing(self):
        self.assertIsNone(mod.valid_number("inf"))

    def test_valid_negative_value(self):
        self.assertEqual(mod.valid_number("-46"), -46)

class ReanalysisTests(unittest.TestCase):
    def _synthetic(self):
        rows = []
        for exp in ("1", "2"):
            for set_name in "ABCD":
                for party in ("Dem", "Repub"):
                    for network in ("Control", "Social"):
                        for pid in ((1,) if network=="Control" else (1,2,3)):
                            for q in ("Q1", "Q2", "Q3", "Q4"):
                                vals = ("2","2","4","2") if exp=="1" else ("1","1","2","-2")
                                rows.append(dict(experiment=exp,set=set_name,party=party,network=network,
                                    pair_id=str(pid),q=q,response_1=vals[0],response_2=vals[1],response_3=vals[2],truth=vals[3],remove_extreme="",user_id="example"))
        return rows

    def test_synthetic_64_trials(self):
        trial, source, eligible = mod.aggregate_original(self._synthetic())
        self.assertEqual(len(trial), 64)
        self.assertEqual(source, {"1":128,"2":128})
        self.assertEqual(eligible, source)

    def test_synthetic_all_have_four_questions(self):
        trial, _, _ = mod.aggregate_original(self._synthetic())
        self.assertTrue(all(x['n']==4 for x in trial))

    def test_log_error_exp1(self):
        trial, _, _ = mod.aggregate_original(self._synthetic())
        a = next(z for z in trial if z['experiment']==1)
        self.assertAlmostEqual(a['change'], math.log(2), places=10)

    def test_ratio_error_exp2_negative_truth(self):
        trial, _, _ = mod.aggregate_original(self._synthetic())
        a = next(z for z in trial if z['experiment']==2)
        self.assertAlmostEqual(a['err1'], 1.5)
        self.assertAlmostEqual(a['err3'], 2)

    def test_exp2_flag_removal(self):
        rows = self._synthetic()
        rows.append(dict(rows[128]))
        rows[128]['remove_extreme'] = '1-2'
        trial, count, eligible = mod.aggregate_original(rows)
        self.assertEqual(eligible["2"],128)
        self.assertEqual(count["2"],129)
        self.assertEqual(len(trial),64)

    def test_exp1_zero_removal(self):
        rows = self._synthetic()
        rows.append(dict(rows[0]))
        rows[0]["response_2"]="0"
        _, _, eligible = mod.aggregate_original(rows)
        self.assertEqual(eligible["1"],128)

    def test_trials_duplicate_rejected(self):
        trials, _, _ = mod.aggregate_original(self._synthetic())
        trials[0]=dict(trials[1])
        with self.assertRaisesRegex(ValueError, 'distinct'):
            mod.trial_statistics(trials, iterations=10)

    def test_invalid_iteration_rejected(self):
        trials, _, _ = mod.aggregate_original(self._synthetic())
        with self.assertRaisesRegex(ValueError, 'positive'):
            mod.trial_statistics(trials, iterations=0)

    def test_aggregate_round_trip(self):
        trials, _, _ = mod.aggregate_original(self._synthetic())
        with tempfile.TemporaryDirectory() as d:
            file=Path(d)/"t.csv"
            mod.export_trial_csv(file,trials)
            got=mod.import_trial_csv(file)
        self.assertEqual(got,trials)

    def test_tampered_derived_change_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"bad.csv"
            p.write_text('experiment,set,pair_id,party,network,n,err1,err3,change\n1,A,1,Dem,Social,4,1,2,0\n')
            with self.assertRaisesRegex(ValueError, 'Invalid trial'):
                mod.import_trial_csv(p)

    def test_held_out_trials_1(self):
        t = mod.import_trial_csv(ROOT/'R056_TRIAL_AGGREGATES.csv')
        a = mod.trial_statistics(t,iterations=100)
        self.assertAlmostEqual(a['1']['social_minus_control'],-0.07341813297561589,places=9)

    def test_held_out_trials_2(self):
        t = mod.import_trial_csv(ROOT/'R056_TRIAL_AGGREGATES.csv')
        a = mod.trial_statistics(t,iterations=100)
        self.assertAlmostEqual(a['2']['social_minus_control'],-0.6237236558365928,places=9)

    def test_row_count(self):
        t = mod.import_trial_csv(ROOT/'R056_TRIAL_AGGREGATES.csv')
        self.assertEqual(len(t),64)
        self.assertEqual(sum(x['n'] for x in t if x['experiment']==1),4019)
        self.assertEqual(sum(x['n'] for x in t if x['experiment']==2),4114)

    def test_party_groups_balance(self):
        t = mod.import_trial_csv(ROOT/'R056_TRIAL_AGGREGATES.csv')
        for exp in (1,2):
            for party in ('Dem','Repub'):
                g=[x for x in t if x['experiment']==exp and x['party']==party]
                self.assertEqual(len(g),16)
                self.assertEqual(sum(x['network']=='Control' for x in g),4)

if __name__ == '__main__':
    unittest.main(verbosity=2)
