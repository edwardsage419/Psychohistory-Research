# R056研究包使用方法

R056对 Becker、Porter、Centola (2019)《The Wisdom of Partisan Crowds》公开匿名真人网络实验进行独立试验组级复算。

本包含来自GitHub连接器读取原作者原始CSV后生成的64组匿名汇总数据，**不包含原始个人答题CSV**。

执行本地冻结派生汇总重放：

```bash
python r056_partisan_crowds.py --trial-csv R056_TRIAL_AGGREGATES.csv --output-json replay.json
```

运行构造数据软件测试：

```bash
python -m unittest -v test_r056.py
```

如以后能通过合法途径另行取得原始CSV，执行：

```bash
python r056_partisan_crowds.py --raw-csv /path/to/original.csv --output-trials replay_trials.csv --output-json replay.json
```

原始字节必须通过Git blob SHA1准入，未通过会拒绝运行。`--allow-synthetic`仅限专门的软件构造测试，不接受作为实证准入。

重要：两个实验的指标单位不同。本轮无前瞻预测、无跨独立团队外推、无惩罚因果机制识别。
