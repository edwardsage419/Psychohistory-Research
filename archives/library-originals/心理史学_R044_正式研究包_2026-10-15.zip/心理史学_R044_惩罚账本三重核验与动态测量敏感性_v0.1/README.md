# 心理史学 R044（2026-10-15）

本研究包继承 R043，新增对作者真人四人公共资源实验的**罚款方向、到账受罚字段与最终收益的三重账本核验**。所有公开源原始CSV的处理发生在已连接的GitHub工具端；本地文件仅包含去身份、可复算的派生数据，不包含作者原始参与者行级文本。

文件：`R044_EVIDENCE_AUDIT.md`（完整研究报告）、`R044_ANOMALY_BY_GROUP.csv`（16个有偿惩罚小组可复算数据）、`R044_INDEPENDENT_RECONCILIATION.json`（三账本、次轮转移派生摘要）、`r044_analysis.py`（离线与有条件的原始源端到端核验）、`r043_analysis.py`与`R043_SOURCE_DERIVED_32_GROUPS.csv`（上轮源派生承接）、`tests/test_r044.py`（47项实际测试）、`R044_RESULTS.json`（运行结果）、`R044_TEST_LOG.txt`、`R044_SOURCE_LEDGER.json`、`R045_RESEARCH_GATE.md`、`MASTER_CONTROLLER_v3.5.md`、`CHECKSUMS.sha256`。

复算：在本目录执行 `python r044_analysis.py` 和 `python -m unittest discover -s tests -v`。可指定真实原件 `--raw path/to/data.csv`，但只有与正式Git blob SHA1和所有派生结果完全一致时才接受。**本轮没有在本地下载真实原件，不能声称已完成本机端到端复现**。

研究结论：960条最终收益均符合重建罚款；`Received`字段80条记录不符，其中9条改变“上一轮是否受罚”的二元分类；来源异常不会自动变成惩罚因果机制证明。PESEN v0.1仍冻结。
