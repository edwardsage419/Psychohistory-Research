from __future__ import annotations
import copy, csv, json, sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import r044_analysis as r
import r043_analysis as parent

class RealSourceDerivativeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.prior=parent.load_derived(ROOT/'R043_SOURCE_DERIVED_32_GROUPS.csv')
        cls.ledger=r.load_anomaly()
        cls.facts=json.loads((ROOT/'R044_INDEPENDENT_RECONCILIATION.json').read_text(encoding='utf-8'))
        cls.res=r.summarize(cls.prior,cls.ledger,cls.facts)
    def test_01_exact_32_groups(self):self.assertEqual(len(self.prior),32)
    def test_02_exact_16_sanction_groups(self):self.assertEqual(len(self.ledger),16)
    def test_03_source_sha(self):self.assertEqual(r.SOURCE_SHA,'73c02176bc9e060af987149594a85f9f7b591230')
    def test_04_prior_cross_check(self):self.assertTrue(r.validate_prior(self.prior,self.ledger))
    def test_05_sum_positive(self):self.assertEqual(sum(x['received_minus_reconstructed'] for x in self.ledger),408)
    def test_06_80_mismatch_rows(self):self.assertEqual(sum(x['mismatch_recipient_rows'] for x in self.ledger),80)
    def test_07_28_mismatch_rounds(self):self.assertEqual(sum(x['mismatch_rounds'] for x in self.ledger),28)
    def test_08_5_anomaly_groups(self):self.assertEqual(sum(x['mismatch_recipient_rows']>0 for x in self.ledger),5)
    def test_09_9_binary_flips(self):self.assertEqual(sum(x['binary_exposure_flips_in_transitions'] for x in self.ledger),9)
    def test_10_equal_recorded(self):self.assertEqual(sum(x['recorded_received'] for x in self.ledger if x['arm']=='11'),9600)
    def test_11_equal_rebuilt(self):self.assertEqual(sum(x['reconstructed_received'] for x in self.ledger if x['arm']=='11'),9192)
    def test_12_unequal_control(self):self.assertEqual(sum(x['received_minus_reconstructed'] for x in self.ledger if x['arm']=='01'),0)
    def test_13_n960(self):self.assertEqual(self.res['n_formal_punishment_records'],960)
    def test_14_payoff_consistency_all(self):self.assertEqual(self.res['n_records_final_payoff_matches_directed_inbound'],960)
    def test_15_payoff_recorded_880(self):self.assertEqual(self.res['n_records_final_payoff_matches_reported_Received'],880)
    def test_16_448_per_arm(self):self.assertEqual(self.res['lagged_observational_analyses']['11']['n'],448)
    def test_17_rebuilt_pos333(self):self.assertEqual(self.res['lagged_observational_analyses']['11']['reconstructed']['punished_n'],333)
    def test_18_reported_pos336(self):self.assertEqual(self.res['lagged_observational_analyses']['11']['recorded']['punished_n'],336)
    def test_19_mean_rebuilt(self):self.assertAlmostEqual(self.res['lagged_observational_analyses']['11']['reconstructed']['punished_mean_next_change'],-400/333)
    def test_20_mean_reported(self):self.assertAlmostEqual(self.res['lagged_observational_analyses']['11']['recorded']['punished_mean_next_change'],-230/336)
    def test_21_unequal_no_flips(self):self.assertEqual(self.res['lagged_observational_analyses']['01']['classification_flips'],0)
    def test_22_ledger_mutation_rejected(self):
        bad=copy.deepcopy(self.ledger);bad[0]['paid']+=1
        with self.assertRaisesRegex(ValueError,'DERIVATIVE'):r.validate_prior(self.prior,bad)
    def test_23_bad_delta_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'a.csv'
            with (ROOT/'R044_ANOMALY_BY_GROUP.csv').open(newline='',encoding='utf-8') as fi,p.open('w',newline='',encoding='utf-8') as fo:
                d=list(csv.DictReader(fi));d[0]['received_minus_reconstructed']='7'
                writer=csv.DictWriter(fo,fieldnames=r.ANOMALY_FIELDS);writer.writeheader();writer.writerows(d)
            with self.assertRaisesRegex(ValueError,'LEDGER_DELTA'):r.load_anomaly(p)
    def test_24_bad_group_count_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            self.temp=td
            with self.assertRaisesRegex(ValueError,'PUNISHED_GROUPS'):r.load_anomaly(self._save(self.ledger[:-1]))
    def _save(self,records):
        p=Path(self.temp)/'d.csv'
        with p.open('w',newline='',encoding='utf-8') as f:
            w=csv.DictWriter(f,fieldnames=r.ANOMALY_FIELDS);w.writeheader();w.writerows(records)
        return p
    def test_25_bad_schema_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'d.csv';p.write_text('bad\n1\n',encoding='utf-8')
            with self.assertRaisesRegex(ValueError,'SCHEMA'):r.load_anomaly(p)
    def test_26_not_causal(self):self.assertIn('not causal',self.res['level'])
    def test_27_controls_source_unavailable(self):self.assertFalse(self.res['author_raw_bytes_in_local_archive'])
    def test_28_prior_4arms(self):self.assertEqual({x['group'][:2] for x in self.prior},set(['00','01','10','11']))
    def test_29_wrong_sha_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            fake=Path(td)/'data.csv';fake.write_text('invented file\n')
            with self.assertRaisesRegex(ValueError,'RAW_SHA'):r.source_reaudit(fake,self.prior,self.ledger)

class SyntheticRoundTests(unittest.TestCase):
    def setUp(self):
        # Slot assignments rotate: A=2 B=0 C=3 D=1. Points are damage (multiples of 3).
        self.data=[
          {'id':'A','seq':['6','0','.','3'],'paid':3,'received':12,'total':100,'total2':85,'invest':20},
          {'id':'B','seq':['.','6','3','0'],'paid':3,'received':6,'total':100,'total2':91,'invest':25},
          {'id':'C','seq':['0','0','9','.'],'paid':3,'received':3,'total':100,'total2':94,'invest':30},
          {'id':'D','seq':['0','.','0','0'],'paid':0,'received':6,'total':100,'total2':94,'invest':25},
        ]
        # Original entries for B target A=3, C target A=9; A self slot2; data generator:
        # For clarity the intended rebuilt incoming values from seq are checked after setup below.
        slot={p['seq'].index('.'):p for p in self.data}
        sums={p['id']:0 for p in self.data}
        for person in self.data:
            points=0
            for j,v in enumerate(person['seq']):
                if v!='.':points+=int(v);sums[slot[j]['id']]+=int(v)
            person['paid']=points//3
            person['received']=sums.get(person['id'],0)
        for p in self.data:
            p['received']=sums[p['id']];p['total2']=p['total']-p['paid']-sums[p['id']]
    def test_30_valid_round(self):self.assertEqual(len(r.audit_round(self.data)),4)
    def test_31_zero_mismatch_on_valid(self):self.assertFalse(any(v['mismatch'] for v in r.audit_round(self.data)))
    def test_32_punishment_result_independent_order(self):
        a=r.audit_round(self.data);b=r.audit_round(self.data[::-1]);self.assertEqual(sorted(a,key=lambda x:x['id']),sorted(b,key=lambda x:x['id']))
    def test_33_incorrect_reported_detected_not_rejected(self):
        d=copy.deepcopy(self.data);d[0]['received']+=3
        z=r.audit_round(d);self.assertEqual(sum(v['mismatch'] for v in z),1)
    def test_34_positive_to_zero_flip(self):
        d=copy.deepcopy(self.data);d[0]['received']=0
        z=r.audit_round(d);self.assertTrue(next(v for v in z if v['id']=='A')['binary_flip'])
    def test_35_bad_member_count(self):
        with self.assertRaisesRegex(ValueError,'FOUR_UNIQUE'):r.audit_round(self.data[:-1])
    def test_36_duplicate_person(self):
        d=copy.deepcopy(self.data);d[1]['id']=d[0]['id']
        with self.assertRaisesRegex(ValueError,'FOUR_UNIQUE'):r.audit_round(d)
    def test_37_duplicate_self_slot(self):
        d=copy.deepcopy(self.data);d[1]['seq']=['0','0','.','9']
        with self.assertRaisesRegex(ValueError,'DUPLICATE_SELF_SLOT'):r.audit_round(d)
    def test_38_missing_self_slot(self):
        d=copy.deepcopy(self.data);d[0]['seq']=['0','0','0','0']
        with self.assertRaisesRegex(ValueError,'SELF_SLOT'):r.audit_round(d)
    def test_39_two_self_markers(self):
        d=copy.deepcopy(self.data);d[0]['seq']=['.','0','.','0']
        with self.assertRaisesRegex(ValueError,'SELF_SLOT'):r.audit_round(d)
    def test_40_negative_sanction(self):
        d=copy.deepcopy(self.data);d[0]['seq'][0]='-3'
        with self.assertRaisesRegex(ValueError,'NEGATIVE'):r.audit_round(d)
    def test_41_non_integer_sanction(self):
        d=copy.deepcopy(self.data);d[0]['seq'][0]='1.5'
        with self.assertRaisesRegex(ValueError,'NONINTEGER'):r.audit_round(d)
    def test_42_sender_paid_mismatch(self):
        d=copy.deepcopy(self.data);d[0]['paid']+=1
        with self.assertRaisesRegex(ValueError,'SENDER_COST'):r.audit_round(d)
    def test_43_final_payoff_tamper(self):
        d=copy.deepcopy(self.data);d[0]['total2']+=0.25
        with self.assertRaisesRegex(ValueError,'FINAL_PAYOFF'):r.audit_round(d)
    def test_44_valid_negative_payoff(self):
        d=copy.deepcopy(self.data);d[0]['total']=5;d[0]['total2']=5-d[0]['paid']-d[0]['received']
        self.assertEqual(len(r.audit_round(d)),4)
    def test_45_real_recipients_not_reported(self):
        d=copy.deepcopy(self.data);d[0]['received']=999
        self.assertEqual(len([v for v in r.audit_round(d) if v['mismatch']]),1)
    def test_46_no_inference_from_correct_column(self):
        self.assertNotIn('causal',str(r.audit_round(self.data)).lower())
    def test_47_nonfinite_payoff_rejected(self):
        d=copy.deepcopy(self.data);d[0]['total2']='NaN'
        with self.assertRaisesRegex(ValueError,'FINAL_PAYOFF'):r.audit_round(d)

if __name__=='__main__': unittest.main()
