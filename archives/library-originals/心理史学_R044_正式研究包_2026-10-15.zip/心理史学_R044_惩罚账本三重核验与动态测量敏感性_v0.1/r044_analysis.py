#!/usr/bin/env python3
"""R044: three-way sanction-ledger audit and descriptive lagged-response sensitivity.

Works offline using anonymized, connector-verified derived facts. The optional --raw
checks exact author Git blob bytes, reconstructs every sanction event from changing
within-round anonymous target slots, and verifies all summary numbers. No observational
association is labeled as an intervention/causal effect.
"""
from __future__ import annotations
import argparse, csv, json, math
from collections import defaultdict
from pathlib import Path
import r043_analysis as upstream

HERE=Path(__file__).resolve().parent
SOURCE_SHA=upstream.BLOB
ANOMALY_FIELDS=['group','arm','paid','recorded_received','reconstructed_received',
                'received_minus_reconstructed','mismatch_recipient_rows','mismatch_rounds',
                'nonconserving_rounds','binary_exposure_flips_in_transitions']

def load_anomaly(path=HERE/'R044_ANOMALY_BY_GROUP.csv'):
    with Path(path).open(encoding='utf-8',newline='') as f:
        rdr=csv.DictReader(f)
        if rdr.fieldnames!=ANOMALY_FIELDS: raise ValueError('R044_BAD_ANOMALY_SCHEMA')
        records=[{k:(v if k in ('group','arm') else int(v)) for k,v in r.items()} for r in rdr]
    if len(records)!=16 or len({r['group'] for r in records})!=16:raise ValueError('R044_WRONG_PUNISHED_GROUPS')
    if sum(x['arm']=='01' for x in records)!=8 or sum(x['arm']=='11' for x in records)!=8:raise ValueError('R044_WRONG_ARM_COUNT')
    for r in records:
        if r['group'][:2]!=r['arm']:raise ValueError('R044_GROUP_ARM_INCONSISTENT')
        if 3*r['paid']!=r['reconstructed_received']:raise ValueError('R044_SENDER_RECIPIENT_IMBALANCE')
        if r['recorded_received']-r['reconstructed_received']!=r['received_minus_reconstructed']:raise ValueError('R044_BAD_LEDGER_DELTA')
        if not 0<=r['binary_exposure_flips_in_transitions']<=r['mismatch_recipient_rows']<=60:raise ValueError('R044_BAD_MISMATCH_COUNT')
        if not 0<=r['mismatch_rounds']<=15:raise ValueError('R044_BAD_ROUND_COUNT')
        if r['nonconserving_rounds']>r['mismatch_rounds']:raise ValueError('R044_BAD_NONCONSERVING_COUNT')
    return records

def validate_prior(prior,ledger):
    upstream.validate_derived(prior)
    g={r['group']:r for r in prior}
    for x in ledger:
        y=g[x['group']]
        names=[('paid','punishment_paid'),('recorded_received','reported_damage_received'),
               ('mismatch_recipient_rows','mismatched_recipient_rows'),('nonconserving_rounds','nonconserving_rounds')]
        if any(x[a]!=y[b] for a,b in names):raise ValueError('R044_R043_DERIVATIVE_MISMATCH')
        if x['mismatch_rounds']<x['nonconserving_rounds']:raise ValueError('R044_INVALID_ROUNDS')
    return True

def audit_round(members):
    """4 anonymized same-group same-round participants; actual target slots vary by round.

    Columns: id, seq (four entries; one self marker '.'), paid, received, total,
    total2, invest. This function never assumes a permanent slot/person mapping.
    """
    if len(members)!=4 or len({p['id'] for p in members})!=4:raise ValueError('R044_ROUND_NOT_FOUR_UNIQUE')
    slots={}
    for p in members:
        seq=p['seq']
        if len(seq)!=4 or seq.count('.')!=1:raise ValueError('R044_BAD_SELF_SLOT')
        ix=seq.index('.')
        if ix in slots:raise ValueError('R044_DUPLICATE_SELF_SLOT')
        slots[ix]=p
        if any(s!='.' and (not str(s).isdigit() or int(s)<0) for s in seq):raise ValueError('R044_NEGATIVE_OR_NONINTEGER_PUNISHMENT')
    if len(slots)!=4:raise ValueError('R044_MISSING_TARGET')
    inbound=defaultdict(int)
    for sender in members:
        totalpts=0
        for i,s in enumerate(sender['seq']):
            if s=='.':continue
            points=int(s);totalpts+=points;inbound[slots[i]['id']]+=points
        if totalpts!=3*int(sender['paid']):raise ValueError('R044_SENDER_COST_MISMATCH')
    rows=[]
    for p in members:
        expected=inbound[p['id']]
        if not math.isclose(float(p['total'])-float(p['paid'])-expected,
                            float(p['total2']),rel_tol=0,abs_tol=1e-6):
            raise ValueError('R044_FINAL_PAYOFF_RECONSTRUCTION_FAILED')
        rows.append({'id':p['id'],'reported':int(p['received']),'reconstructed':expected,
                     'mismatch':int(p['received'])!=expected,
                     'binary_flip':(int(p['received'])>0)!=(expected>0)})
    return rows

def source_reaudit(raw_path, prior,ledger):
    """Only invoked if authentic raw bytes have been supplied independently.

    Verifies exact Git blob and R043 32-group values before computing R044 checks.
    """
    raw_path=Path(raw_path)
    if upstream.sha1_git_blob(raw_path.read_bytes())!=SOURCE_SHA:raise ValueError('R044_RAW_SHA_MISMATCH')
    if upstream.parse_source_raw(raw_path)!=sorted(prior,key=lambda v:v['group']):
        raise ValueError('R044_SOURCE_NOT_EQUAL_PRIOR_GROUPS')
    with raw_path.open(encoding='utf-8-sig',newline='') as f:src=list(csv.DictReader(f))
    src=[r for r in src if r.get('ProfileID','').strip() and r.get('RoundID','').strip()]
    rounds=defaultdict(list); persons=defaultdict(list)
    for row in src:
        gid=f"{row['Homo']}{row['FF']}_{row['Session']}_{row['GameID']}"
        p={'id':row['ProfileID'],'gid':gid,'round':int(row['RoundID']),
           'seq':[row[f'Seq{i}'] for i in range(1,5)],
           'paid':row['Paid'],'received':row['Received'],
           'total':row['Total'],'total2':row['Total2'],
           'invest':int(row['Invest'])}
        if gid[1]=='1' and p['round']>1:
            rounds[(gid,p['round'])].append(p)
            persons[p['id']].append(p)
    mismatch=0;flips=0; nonconserve=0; group_bad=defaultdict(lambda:[0,0,0,0]); recv_lookup={}; checked=0
    for (gid,r),members in rounds.items():
        z=audit_round(members)
        bad=sum(q['mismatch'] for q in z)
        mx=group_bad[gid];mx[0]+=bad;mx[1]+=int(bad>0);mx[2]+=int(sum(q['reported'] for q in z)!=sum(q['reconstructed'] for q in z))
        mismatch+=bad;nonconserve+=int(sum(q['reported'] for q in z)!=sum(q['reconstructed'] for q in z))
        for row in z:
            checked+=1;flips+=row['binary_flip'];recv_lookup[(row['id'],r)]=row
            if row['binary_flip']: mx[3]+=1
    if (checked,mismatch,flips,nonconserve)!=(960,80,9,28):
        raise ValueError('R044_OBSERVED_AUDIT_DOES_NOT_MATCH')
    group_l={d['group']:d for d in ledger}
    for gid,z in group_bad.items():
        d=group_l[gid]
        if z[:3]!=[d['mismatch_recipient_rows'],d['mismatch_rounds'],d['nonconserving_rounds']]:
            raise ValueError('R044_GROUP_AUDIT_MISMATCH')
    transition={arm:{kind:{label:{'n':0,'sum_delta_extract':0} for label in ('punished','not_punished')}
                     for kind in ('recorded','reconstructed')} for arm in ('01','11')}
    for pid,a in persons.items():
        a.sort(key=lambda p:p['round'])
        if len(a)!=15 or any(p['round']!=i+2 for i,p in enumerate(a)):raise ValueError('R044_BAD_EXPOSURE_PANEL')
        for i in range(14):
            p,n=a[i],a[i+1]
            obs=recv_lookup[(pid,p['round'])];delta=n['invest']-p['invest']
            arm=p['gid'][:2]
            for kind,v in [('recorded',obs['reported']),('reconstructed',obs['reconstructed'])]:
                cell=transition[arm][kind]['punished' if v>0 else 'not_punished']
                cell['n']+=1;cell['sum_delta_extract']+=delta
    reference=json.loads((HERE/'R044_INDEPENDENT_RECONCILIATION.json').read_text(encoding='utf-8'))
    for arm in ('01','11'):
        for kind in ('recorded','reconstructed'):
            if transition[arm][kind]!=reference['lagged_behavior'][arm][kind]:
                raise ValueError('R044_TRANSITION_REPLICATION_MISMATCH')
    return {'raw_source_sha_verified':True,'verified_punishment_records':checked,
            'mismatched_received_records':mismatch,'binary_exposure_flips':flips,
            'nonconserving_rounds':nonconserve,'lagged_transition_counts':transition}

def summarize(prior,ledger,facts):
    validate_prior(prior,ledger)
    rec=facts['reconciliation'];n0=sum(r['arm']=='01' for r in ledger)*60;n1=sum(r['arm']=='11' for r in ledger)*60
    assert n0==n1==480
    assert sum(r['mismatch_recipient_rows'] for r in ledger)==rec['recorded_received_field_mismatches']==80
    assert sum(r['mismatch_rounds'] for r in ledger)==28
    assert sum(r['nonconserving_rounds'] for r in ledger)==28
    assert sum(r['received_minus_reconstructed'] for r in ledger)==408
    assert sum(r['binary_exposure_flips_in_transitions'] for r in ledger)==9
    for arm in ('01','11'):
        d=[x for x in ledger if x['arm']==arm]
        assert sum(x['paid'] for x in d)*3==sum(x['reconstructed_received'] for x in d)
        assert sum(x['recorded_received'] for x in d)==rec['arm_'+arm+'_recorded_received']
        assert sum(x['reconstructed_received'] for x in d)==rec['arm_'+arm+'_rebuilt_received']
    lag={}
    for arm in ('01','11'):
        z=facts['lagged_behavior'][arm];lag[arm]={'n':z['n'],'classification_flips':z['classification_flips']}
        assert z['n']==sum(x['n'] for x in z['recorded'].values())==sum(x['n'] for x in z['reconstructed'].values())==448
        for kind in ('recorded','reconstructed'):
            q=z[kind];yes,no=q['punished'],q['not_punished']
            lag[arm][kind]={'punished_mean_next_change':yes['sum_delta_extract']/yes['n'],
                            'unpunished_mean_next_change':no['sum_delta_extract']/no['n'],
                            'difference_punished_minus_unpunished':yes['sum_delta_extract']/yes['n']-no['sum_delta_extract']/no['n'],
                            'punished_n':yes['n'],'unpunished_n':no['n']}
    return {'level':'three-way bookkeeping independent audit; descriptive not causal',
            'author_source_sha':SOURCE_SHA,'original_records_read_via_connector':True,
            'author_raw_bytes_in_local_archive':False,
            'n_formal_punishment_records':960,
            'n_records_final_payoff_matches_directed_inbound':960,
            'n_records_final_payoff_matches_reported_Received':880,
            'n_reported_Received_discrepancies':80,
            'n_distinct_group_rounds_with_discrepancies':28,
            'n_distinct_groups_with_discrepancies':5,
            'cumulative_Received_overstatement_in_ED':408,
            'lagged_observational_analyses':lag,
            'treatment_session_randomization':'NOT_ESTABLISHED',
            'model_state':'PESEN v0.1 FROZEN; punishment-as-causal-mediator UNIDENTIFIED'}

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--raw',type=Path,default=None)
    parser.add_argument('--out',type=Path,default=HERE/'R044_RESULTS.json')
    args=parser.parse_args()
    prior=upstream.load_derived(HERE/'R043_SOURCE_DERIVED_32_GROUPS.csv')
    ledger=load_anomaly()
    facts=json.loads((HERE/'R044_INDEPENDENT_RECONCILIATION.json').read_text(encoding='utf-8'))
    output=summarize(prior,ledger,facts)
    if args.raw:output['source_reaudit']=source_reaudit(args.raw,prior,ledger)
    args.out.write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(output,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
