#!/usr/bin/env python3
"""R043: reproducible, stdlib-only analysis of the De Geest/Kingsley CPR experiment.

Derived-group mode runs offline. --raw accepts author's CSV copied locally and verifies its
Git blob SHA1, complete source structure, treatment-session mapping, and the group summaries.
Observational associations are not punishment-as-a-mediator causal effects.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import itertools
import json
from collections import Counter, defaultdict
from pathlib import Path

BLOB = '73c02176bc9e060af987149594a85f9f7b591230'
HERE = Path(__file__).resolve().parent
HEAD = ['group','session','extraction_sum','early_sum','late_sum','punishment_paid',
        'reported_damage_received','possible_directed_links','positive_directed_links',
        'above_target_links','above_target_positive','below_target_links',
        'below_target_positive','nonconserving_rounds','mismatched_recipient_rows']


def sha1_git_blob(data: bytes) -> str:
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\x00'+data).hexdigest()


def load_derived(path: Path) -> list[dict]:
    with path.open(newline='',encoding='utf-8-sig') as f:
        r = csv.DictReader(f)
        if r.fieldnames != HEAD:
            raise ValueError('INVALID_DERIVED_SCHEMA')
        out = [{k:(v if k == 'group' else int(v)) for k,v in row.items()} for row in r]
    validate_derived(out)
    return out


def validate_derived(rows: list[dict]) -> None:
    if len(rows)!=32 or len({r['group'] for r in rows})!=32:
        raise ValueError('BAD_GROUP_COUNT')
    if len({r['session'] for r in rows})!=8:
        raise ValueError('BAD_SESSION_COUNT')
    byarm = Counter(r['group'][:2] for r in rows)
    if byarm != Counter({'00':8,'01':8,'10':8,'11':8}):
        raise ValueError('BAD_TREATMENT_COUNTS')
    for r in rows:
        arm=r['group'][:2]
        if not (r['group'].split('_')[1]==str(r['session'])): raise ValueError('BAD_ID')
        if r['early_sum']+r['late_sum']!=r['extraction_sum']: raise ValueError('BAD_WINDOW_SUM')
        if arm.endswith('1'):
            if r['possible_directed_links']!=180: raise ValueError('BAD_DIRECTED_LINKS')
        elif r['possible_directed_links'] or r['punishment_paid'] or r['reported_damage_received']:
            raise ValueError('CONTROL_HAS_PUNISHMENT')
        if r['positive_directed_links']>r['possible_directed_links']:
            raise ValueError('BAD_EVENT_COUNT')
    arm_by_sess=defaultdict(set)
    for r in rows: arm_by_sess[r['session']].add(r['group'][:2])
    if any(len(v)!=1 for v in arm_by_sess.values()): raise ValueError('SESSION_ARM_COLLISION')
    if any(sum(r['session']==s for r in rows)!=4 for s in arm_by_sess):
        raise ValueError('SESSION_GROUP_COUNT')


def session_rows(rows: list[dict]) -> list[dict]:
    a = {}
    for r in rows:
        s=r['session'];t=a.setdefault(s,{'session':s,'arm':r['group'][:2],'group_count':0,'sum_extract':0})
        t['group_count']+=1;t['sum_extract']+=r['extraction_sum']
    for d in a.values(): d['mean_extract']=d['sum_extract']/(d['group_count']*60)
    return sorted(a.values(), key=lambda x:x['session'])


def diff_punishment(rows, homo: str):
    means={}
    for ff in '01':
        sub=[r for r in rows if r['group'][:2]==homo+ff]
        means[ff]=sum(r['extraction_sum'] for r in sub)/(len(sub)*60)
    return {'no_punishment':means['0'],'punishment':means['1'],
            'punishment_minus_no_punishment':means['1']-means['0']}


def conditional_permutation_4_sessions(rows, homo: str) -> dict:
    """Hypothetical exchangeability sensitivity only: 4 sessions, 2 each, 6 allocations.
    Actual historical session randomization procedure not independently verified.
    """
    sessions=[r for r in session_rows(rows) if r['arm'][0]==homo]
    assert len(sessions)==4
    actual_p={i for i,r in enumerate(sessions) if r['arm'][1]=='1'}
    obs=sum(sessions[i]['mean_extract'] for i in actual_p)/2 - sum(
        sessions[i]['mean_extract'] for i in range(4) if i not in actual_p)/2
    null=[]
    for xx in itertools.combinations(range(4),2):
        xx=set(xx)
        null.append(sum(sessions[i]['mean_extract'] for i in xx)/2-
                    sum(sessions[i]['mean_extract'] for i in range(4) if i not in xx)/2)
    return {'observed_difference':obs, 'permutations':len(null),
            'hypothetical_two_sided_p':sum(abs(x)>=abs(obs)-1e-10 for x in null)/len(null),
            'allocation_unit':'SESSION; two sessions per treatment within endowment stratum',
            'not_actual_randomization_p':True}


def summarize(rows):
    validate_derived(rows)
    arms={}
    for arm in ('00','01','10','11'):
        g=[r for r in rows if r['group'][:2]==arm]
        a={'sessions':2,'groups':8,'people':32,'formal_round_actions':480,
           'mean_extraction':sum(r['extraction_sum'] for r in g)/480,
           'sent_cost':sum(r['punishment_paid'] for r in g),
           'received_recorded':sum(r['reported_damage_received'] for r in g),
           'positive_targeted_events':sum(r['positive_directed_links'] for r in g),
           'all_possible_directed_links':sum(r['possible_directed_links'] for r in g),
           'nonconserving_rounds':sum(r['nonconserving_rounds'] for r in g),
           'recipient_discrepancies':sum(r['mismatched_recipient_rows'] for r in g),}
        a['expected_damage_from_sent_cost']=3*a['sent_cost']
        a['damage_minus_expected']=a['received_recorded']-a['expected_damage_from_sent_cost']
        for name,num,den in [('above_target_rate','above_target_positive','above_target_links'),
                             ('below_target_rate','below_target_positive','below_target_links')]:
            d=sum(r[den] for r in g)
            a[name]=sum(r[num] for r in g)/d if d else None
        a['positive_event_rate']=a['positive_targeted_events']/a['all_possible_directed_links'] if a['all_possible_directed_links'] else None
        arms[arm]=a
    unequal=diff_punishment(rows,'0');equal=diff_punishment(rows,'1')
    return {
        'origin':'De Geest and Kingsley (2021) DOI 10.1561/102.00000099',
        'source_repo':'https://github.com/lrdegeest/InequalityCPR',
        'source_data_blob_git_sha1':BLOB,
        'evidence_level':'connector full source parsed; local authentic group derivative',
        'arm_conventions':'00=unequal/no punishment,01=unequal/punishment,10=equal/no punishment,11=equal/punishment',
        'sample':{'participants':128,'sessions':8,'groups':32,'formal_rounds':15,'group_period_action_rows':1920,
                  'directed_punishment_opportunities':2880},
        'arms':arms,
        'punishment_effect_description':{'unequal':unequal,'equal':equal,
            'diff_in_differences_equal_minus_unequal':equal['punishment_minus_no_punishment']-unequal['punishment_minus_no_punishment']},
        'session_sensitivity':{'unequal':conditional_permutation_4_sessions(rows,'0'),
                               'equal':conditional_permutation_4_sessions(rows,'1')},
        'data_quality':{'blank_physical_csv_rows':1984,'source_n_reported_in_paper':120,
                        'source_n_implied_by_32_groups':128,'recorded_received_not_equal_3x_paid_in_equal_punishment_arm':True,
                        'groups_with_recipient_discrepancies':sum(r['mismatched_recipient_rows']>0 for r in rows)},
        'decisions':{'causal_mechanism_isolated':False,'source_randomization_log_verified':False,
                     'third_independent_human_human_binary_PD':False,'PESEN_v0_1':'FROZEN'}}


def parse_source_raw(path: Path) -> list[dict]:
    buf=path.read_bytes()
    if sha1_git_blob(buf)!=BLOB: raise ValueError('SOURCE_GIT_BLOB_MISMATCH')
    with path.open(encoding='utf-8-sig',newline='') as f: src=list(csv.DictReader(f))
    src=[r for r in src if r.get('ProfileID','').strip() and r.get('RoundID','').strip()]
    if len(src)!=2048: raise ValueError('RAW_RECORD_COUNT')
    people=defaultdict(list);gp=defaultdict(list)
    for i,r in enumerate(src):
        gid=f"{r['Homo']}{r['FF']}_{r['Session']}_{r['GameID']}"
        x={'gid':gid,'arm':gid[:2],'session':int(r['Session']), 'round':int(r['RoundID']),
           'id':r['ProfileID'],'invest':int(r['Invest']),
           'seq':[r[f'Seq{j}'] for j in range(1,5)],
           'paid':r['Paid'], 'received':r['Received']}
        gp[(gid,x['round'])].append(x); people[x['id']].append(x)
    if len(people)!=128 or len(gp)!=512: raise ValueError('SOURCE_PANEL_SHAPE')
    if any(len(v)!=16 for v in people.values()) or any(len(v)!=4 for v in gp.values()):
        raise ValueError('SOURCE_SUBJECT_GROUP_ROUND_SHAPE')
    agg={}
    for (gid,period),member in gp.items():
        arm=gid[:2]; o=agg.setdefault(gid,dict(zip(HEAD, [gid,int(gid.split('_')[1])]+[0]*13)))
        if period==1:continue
        for x in member:
            o['extraction_sum']+=x['invest']
            o['early_sum' if period<=8 else 'late_sum']+=x['invest']
        if arm.endswith('0'):continue
        slots={}
        for x in member:
            ids=[j for j,v in enumerate(x['seq']) if v=='.']
            if len(ids)!=1 or ids[0] in slots: raise ValueError('BAD_SELF_SLOT')
            slots[ids[0]]=x
        if len(slots)!=4: raise ValueError('BAD_TARGET_SLOT')
        inbound=defaultdict(int); pts_total=0; recv_total=0
        avg=sum(x['invest'] for x in member)/4
        for sender in member:
            points=0
            o['punishment_paid']+=int(sender['paid'])
            o['reported_damage_received']+=int(sender['received'])
            recv_total+=int(sender['received'])
            for j,v in enumerate(sender['seq']):
                if v=='.':continue
                target=slots[j]; pts=int(v);points+=pts;pts_total+=pts
                inbound[target['id']]+=pts
                o['possible_directed_links']+=1
                o['positive_directed_links']+=int(pts>0)
                if target['invest']>avg:
                    o['above_target_links']+=1;o['above_target_positive']+=int(pts>0)
                if target['invest']<avg:
                    o['below_target_links']+=1;o['below_target_positive']+=int(pts>0)
            if points!=3*int(sender['paid']):raise ValueError('SENT_COST_DID_NOT_RECONCILE')
        if pts_total!=recv_total:o['nonconserving_rounds']+=1
        for x in member:
            if inbound[x['id']]!=int(x['received']):o['mismatched_recipient_rows']+=1
    out=list(agg.values());validate_derived(out)
    return sorted(out,key=lambda r:r['group'])


def main():
    cli=argparse.ArgumentParser()
    cli.add_argument('--raw',type=Path,default=None,help='Author GitHub data.csv (exact bytes)')
    cli.add_argument('--derived',type=Path,default=HERE/'R043_SOURCE_DERIVED_32_GROUPS.csv')
    cli.add_argument('--out',type=Path,default=HERE/'R043_RESULTS.json')
    arg=cli.parse_args()
    d=load_derived(arg.derived)
    if arg.raw:
        rr=parse_source_raw(arg.raw)
        if rr!=sorted(d,key=lambda r:r['group']):raise ValueError('DERIVED_SOURCE_MISMATCH')
    res=summarize(d)
    res['local_raw_authenticated']=arg.raw is not None
    arg.out.write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print(json.dumps({'result_path':str(arg.out),'arms_mean':{k:v['mean_extraction'] for k,v in res['arms'].items()},
                      'session_exact_sensitivity':res['session_sensitivity'], 'local_raw_authenticated':res['local_raw_authenticated']}))

if __name__=='__main__':main()
