import sys, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from r025_analysis import decode,fnv1a32,hypothetical_six_community_assignments,cluster_diagnostics,leave_one_group_out

ROOT=Path(__file__).resolve().parents[1]
class AuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.text=(ROOT/'DERIVED_NUMERIC_ROWS.txt').read_text(encoding='ascii')
        cls.df=decode(cls.text)

    def test_source_shape(self):
        self.assertEqual((len(self.df),self.df.participant.nunique(),self.df.item.nunique(),self.df.community.nunique()),(439,58,130,12))
    def test_hash(self):
        self.assertEqual(fnv1a32(''.join(self.text.split())),'d6606b70')
    def test_hash_tamper_rejected(self):
        raw=''.join(self.text.split());tampered='A'+raw[1:]
        with self.assertRaises(ValueError):decode(tampered)
    def test_record_length_rejected(self):
        with self.assertRaises(ValueError):decode(self.text+'A',verify=False)
    def test_invalid_alphabet_rejected(self):
        with self.assertRaises(ValueError):decode(self.text+'?',verify=False)
    def test_no_person_item_duplicates(self):
        self.assertFalse(self.df.duplicated(['participant','item']).any())
    def test_coding_all_records(self):
        self.assertTrue(((self.df.perceived_community_agreement<=4).astype(int)==self.df.incongruency).all())
    def test_arms_mathematical_only(self):
        a=hypothetical_six_community_assignments()
        self.assertEqual(a['balanced_labelings_if_fully_exchangeable'],90)
        self.assertIn('unverified',a['scope'])
    def test_genuine_comment_beta(self):
        x=cluster_diagnostics(self.df)
        self.assertAlmostEqual(x['beta'],-1.0894867177389,places=9)
    def test_cluster_se(self):
        x=cluster_diagnostics(self.df)
        self.assertAlmostEqual(x['se_two_way'],0.2688291525628,places=8)
    def test_intersection_identity(self):
        x=cluster_diagnostics(self.df)
        vari=x['component_variance']
        self.assertAlmostEqual(x['se_two_way']**2,vari['person']+vari['item']-vari['joint'],places=11)
    def test_community_sensitivity_not_substitute(self):
        x=cluster_diagnostics(self.df)
        self.assertAlmostEqual(x['sensitivity_se_community_only'],0.1488184756376,places=8)
        self.assertAlmostEqual(x['sensitivity_se_person_community'],0.1853693576121,places=8)
        self.assertGreater(x['se_two_way'],x['sensitivity_se_person_community'])

    def test_upvote_beta(self):
        x=cluster_diagnostics(self.df,'upvote_likelihood')
        self.assertAlmostEqual(x['beta'],-0.5122802099756,places=9)
    def test_upvote_weak(self):
        x=cluster_diagnostics(self.df,'upvote_likelihood')
        self.assertGreater(x['approx_p_two_sided'],.05)
    def test_omit_community_sign(self):
        x=leave_one_group_out(self.df,'community')
        self.assertEqual(x['nonnegative_count'],0)
        self.assertEqual(x['n_omitted_groups'],12)
    def test_omit_person_sign(self):
        x=leave_one_group_out(self.df,'participant')
        self.assertEqual(x['nonnegative_count'],0)
    def test_omit_item_sign(self):
        x=leave_one_group_out(self.df,'item')
        self.assertEqual(x['nonnegative_count'],0)

if __name__=='__main__':unittest.main()
