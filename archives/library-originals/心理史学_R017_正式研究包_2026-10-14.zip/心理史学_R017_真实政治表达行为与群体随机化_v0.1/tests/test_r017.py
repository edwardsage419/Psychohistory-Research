import csv
import sys
import tempfile
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import r017_analysis as m

class TestR017(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.real=m.load(ROOT/'GROUP_STATS.csv')
    def test_01_real_shape(self): self.assertTrue(m.validate_real_design(self.real))
    def test_02_zero_counts(self): self.assertEqual(sum(z['zeros'] for z in self.real),205)
    def test_03_total_expressions(self): self.assertEqual(sum(z['sum_expressions'] for z in self.real),8902)
    def test_04_means(self):
        x=m.stats(self.real)['condition_means']
        self.assertAlmostEqual(x['high|high'],9.270833333333334)
        self.assertAlmostEqual(x['low|low'],9.779166666666667)
    def test_05_factor_anonymity(self): self.assertAlmostEqual(m.stats(self.real)['anonymity_high_minus_low'],-.4833333333333334)
    def test_06_factor_persistence(self): self.assertAlmostEqual(m.stats(self.real)['persistence_high_minus_low'],-.025)
    def test_07_interaction(self): self.assertAlmostEqual(m.stats(self.real)['interaction'],1.008333333333333)
    def test_08_loo_count(self):self.assertEqual(len(m.leave_one_group_out(self.real)),48)
    def test_09_permutation_probability(self):
        p=m.permutation(self.real,200,1234)
        self.assertTrue(all(0<v<=1 for v in p.values()))
    def test_10_bootstrap_bounds(self):
        c=m.bootstrap(self.real,200,1234)
        self.assertTrue(all(v[0]<=v[1] for v in c.values()))
    def test_11_wrong_total_refused(self):
        bad=[dict(x) for x in self.real];bad[0]['n']=19
        with self.assertRaises(ValueError):m.validate_real_design(bad)
    def test_12_duplicate_refused(self):
        with tempfile.TemporaryDirectory() as d:
            src=ROOT/'GROUP_STATS.csv'; text=src.read_text(encoding='utf8')
            p=Path(d)/'bad.csv';p.write_text(text+'\n'+text.splitlines()[1]+'\n')
            with self.assertRaises(ValueError):m.load(p)
    def test_13_cost_respondent_count(self): self.assertEqual(sum(z['cost_respondents'] for z in self.real),705)

if __name__=='__main__':unittest.main()
