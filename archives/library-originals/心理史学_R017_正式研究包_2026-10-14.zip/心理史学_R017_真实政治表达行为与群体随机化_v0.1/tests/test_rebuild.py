import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import fetch_and_rebuild as r

class TestRebuild(unittest.TestCase):
    def test_14_sha_calc(self):
        import hashlib
        self.assertEqual(r.git_blob_hash(b'ok'),hashlib.sha1(b'blob 2\0ok').hexdigest())
    def test_15_pinned_sha_check(self):
        with self.assertRaises(ValueError):r.build(b'not actual paper data')
    def test_16_canonical_columns(self):
        self.assertEqual(len(r.COLUMNS),11)
    def test_17_reported_file_available(self):
        self.assertTrue((Path(__file__).resolve().parents[1]/'GROUP_STATS.csv').is_file())
if __name__=='__main__':unittest.main()
