#!/usr/bin/env python3
"""Reconstruct R017 group-level source from the authors' real CSV.

Only run --fetch when network access is available. Exact source git blob is
pinned and checked. Raw individual-level data are NOT bundled in R017 release.
"""
import argparse
import base64
import csv
import hashlib
import io
import json
import urllib.request
from collections import defaultdict
from pathlib import Path

SHA='62166267c925c2bc6b8f9f1b87db59c28868b262'
REPO='tdienlin/persistence_and_anonymity'
URL=f'https://api.github.com/repos/{REPO}/git/blobs/{SHA}'
COLUMNS=('id','topic','anonymity','persistence','n','sum_expressions','zeros',
         'cost_respondents','cost_sum','benefit_respondents','benefit_sum')

def git_blob_hash(raw):
    return hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()

def fetch_raw():
    req=urllib.request.Request(URL, headers={'Accept':'application/vnd.github+json',
        'User-Agent':'Psychohistory-R017-Reanalysis'})
    with urllib.request.urlopen(req,timeout=40) as response:
        r=json.load(response)
    if r.get('encoding')!='base64':
        raise ValueError('GitHub blob encoding unexpectedly not base64')
    return base64.b64decode(r['content'])

def build(raw):
    if git_blob_hash(raw)!=SHA:
        raise ValueError('Git blob SHA mismatch: version is not the pinned source')
    records=list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig'))))
    by=defaultdict(lambda:{'n':0,'sum_expressions':0,'zeros':0,
       'cost_respondents':0,'cost_sum':0.,'benefit_respondents':0,'benefit_sum':0.})
    labels={}
    for r in records:
        if not all(k in r for k in ('roles','topic','anonymity','persistence','n_OE','costs','benefits')):
            raise ValueError('Unexpected data dictionary')
        key=r['roles']
        lbl=(r['topic'],r['anonymity'],r['persistence'])
        if key in labels and labels[key]!=lbl:raise ValueError('Group labels inconsistent')
        labels[key]=lbl
        s=by[key];n=int(r['n_OE']);s['n']+=1;s['sum_expressions']+=n;s['zeros']+=n==0
        for name in ('costs','benefits'):
            if r[name] not in ('NA',''):
                s['cost_respondents' if name=='costs' else 'benefit_respondents']+=1
                s['cost_sum' if name=='costs' else 'benefit_sum']+=float(r[name])
    out=[]
    for key in sorted(labels, key=lambda k:(labels[k][0],k)):
        topic,a,p=labels[key];s=by[key]
        out.append(dict(id=key,topic=topic,anonymity=a,persistence=p,**s))
    return out

def serialize(summary):
    buf=io.StringIO(newline='')
    writer=csv.DictWriter(buf, fieldnames=COLUMNS,lineterminator='\n')
    writer.writeheader()
    for x in summary:
        v={**x,'cost_sum':f"{x['cost_sum']:.7f}",
               'benefit_sum':f"{x['benefit_sum']:.7f}"}
        writer.writerow(v)
    return buf.getvalue()

def compare(rebuilt: str, existing: Path):
    # CRLF differences are irrelevant, comparisons are content/number based.
    left=list(csv.DictReader(io.StringIO(rebuilt)))
    right=list(csv.DictReader(io.StringIO(existing.read_text(encoding='utf-8'))))
    if len(left)!=len(right):raise ValueError('Group count mismatch')
    for x,y in zip(left,right):
        for col in COLUMNS:
            if col in ('cost_sum','benefit_sum'):
                if abs(float(x[col])-float(y[col])) > 1e-5:
                    raise ValueError(f'Recomputed {col} mismatch: {x["id"]}')
            elif x[col]!=y[col]:
                raise ValueError(f'Recomputed {col} mismatch: {x["id"]}')
    return True

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--fetch',action='store_true')
    p.add_argument('--raw',type=Path)
    p.add_argument('--verify',type=Path,default=Path(__file__).with_name('GROUP_STATS.csv'))
    p.add_argument('--out',type=Path)
    a=p.parse_args()
    if not a.fetch and not a.raw:p.error('Use --fetch or --raw')
    if a.fetch and a.raw:p.error('Choose either --fetch or --raw')
    raw=fetch_raw() if a.fetch else a.raw.read_bytes()
    summary=build(raw)
    text=serialize(summary)
    print(f"source_sha={git_blob_hash(raw)} records={sum(x['n'] for x in summary)} groups={len(summary)}")
    compare(text,a.verify)
    print('R017 derived GROUP_STATS.csv agrees with source, verified.')
    if a.out:a.out.write_text(text,encoding='utf8')
