# R017 研究设计、推断边界及数据契约

日期：2026-10-14。独立探索性再分析，**并非预注册，亦非原论文 brms 嵌套随机效应计数模型的严格复现**。

## 数据来源与材料读取等级

- Frauhammer, Dienlin et al. (2026), *The Effects of Technological Affordances on Political Opinion Expression in Social Media: A Field Experiment*, Media Psychology, DOI `10.1080/15213269.2025.2546108`。https://doi.org/10.1080/15213269.2025.2546108
- 作者公开仓库 https://github.com/tdienlin/persistence_and_anonymity ，其中 `data/data.csv` 当前 `master` Git blob SHA-1 `62166267c925c2bc6b8f9f1b87db59c28868b262`。本轮经 GitHub 连接器 **读取了完整的960条参与者数据**并当场完成分组充分统计量及探索性推断。代码 `analyses.qmd`、`deviations.qmd` 同样来自作者仓库。
- 原始逐人 CSV 未被写入本地 Python 容器，本包仅保存 48 个讨论小组汇总统计量，因此“原始CSV到Python的独立端到端全链条复现”尚未通过。
- `fetch_and_rebuild.py` 可在联网环境经原作者 Git blob API 下载固定版本、验证Git blob SHA后独立再造 `GROUP_STATS.csv`。原始数据受作者提供的使用条款约束，原记录没有包含在本包内。

## 单位与估计目标

- 960 名参与者，一人一行；48 个 Discord 讨论小组，每组20人，3个讨论主题 × 4个处理条件 × 每单元4组。
- 因小组内存在信息共享及潜在相互影响，**小组而非参与者记录**用于此处的重抽样与标签置换。每个小组的主要结果为成员 `n_OE` （实际政治观点表达条数）之均值。
- 在四条件等权下，因子主效应为高匿名－低匿名、 高留存－低留存的均值差，交互项定义为 `(HH−LH)−(HL−LL)`，H/L分别表示高/低匿名和高/低留存。
- 分议题、分条件的小组cluster bootstrap，组内完整保留。可视为探索性的不确定性区间，非严格随机化置信区间。
- 附加的标签置换在每个议题内部、以讨论小组为单位保留每个实验单元4组。**其p值成立需要该组别标签满足相应交换性假设；仅凭公开数据的四组均衡无法证明作者使用过完全相同的群组分配程序。不得标榜为研究原随机化机制下的exact p值。**
- 因原分析包含性别/年龄/基线政治立场与group嵌套topic等项，本轮描述性contrast不能替代原论文模型。预注册偏离已由作者记录在 `deviations.qmd`。

## 不能推断的事

1. 该数据没有按具体立场话题逐项同时配对“私人真实回答、公开表述文字内容”。事前政治立场是个人背景测量，不能由 `n_OE` 反推偏好伪装率。
2. `costs`/`benefits` 是后续自报心理量表，仅 705/960 有 `costs` 值。条件化分析容易遇到非随机缺失；不能声称识别了从匿名性到主观风险再到公开表达的因果中介。
3. R016 Ma 等（2016）自我披露意愿实验和本轮 Discord 真实表达行为是 **不同人、不同议题和不同实验情境**。两项结果方向的差异只能形成待检验假说，不能计算为同一人 intention–behavior gap。
4. 文章关于“匿名性可能改变感知成本”的理论解释尚不等于本轮的客观网络规范压制的实证识别。

## 后续优先数据

Braghieri (2024), *Political Correctness, Social Image, and Information Transmission*, AER DOI `10.1257/aer.20210039`；其公开 openICPSR E208243V1 https://www.openicpsr.org/openicpsr/project/208243/version/V1/view 和官方实验调查工具可验证。论文设计直接涉及私人/公开敏感社会政治态度与受众信息，但**本轮尚未取得其原始数据字节**，不可把摘要结论当独立复算。
