#!/usr/bin/env python3
"""R038: prospective-rule retrospective cross-study stress test.

Offline run uses anonymized source-derived per-person history patterns and original
train sufficient stats. No personal identifiers or raw participants needed.
Optional --raw exactly verifies the real original Git blob and source-derived
sufficient statistics; this is a separate provenance path, not the default.
"""
import argparse
import csv
import hashlib
import io
import json
import math
import random
from pathlib import Path

HERE = Path(__file__).resolve().parent
RAW_SHA1 = '2dd67c6ff80f2d7aa07a70b470e26fe3592c6d95'
R037_SHA1 = 'bd4c1550002621bee7dfb50e0d15d317764d1ea9'
# Source R037 states: 134 people, 6 sessions, rounds2-7, isCC strategy category.
R037_PARENT_STATS = {0: (345, 50), 1: (459, 390)}
# Source R038 PD action: 195 human participants x 10 rounds against GPT-4.
EXTERNAL_TRAIN_TOTAL = (1365, 705)
EXTERNAL_TRAIN_ARMS = {0: (679, 367), 1: (686, 338)}
EXTERNAL_TRAIN_TRANSITIONS = {0: (557, 135), 1: (613, 476)}
ARM_LABEL = {0: 'Base', 1: 'Prompted'}
MODEL_NAMES = ['constant_50', 'pooled_external', 'arm_external', 'personal_first7', 'markov_external', 'r037_frozen_transfer']


def posterior(n, y):
    if n <= 0 or not (0 <= y <= n):
        raise ValueError('invalid binomial count')
    return (y + 0.5) / (n + 1)


def probs():
    return {
        'frozen': {z: posterior(*R037_PARENT_STATS[z]) for z in (0, 1)},
        'local': {z: posterior(*EXTERNAL_TRAIN_TRANSITIONS[z]) for z in (0, 1)},
        'pooled': posterior(*EXTERNAL_TRAIN_TOTAL),
        'arm': {z: posterior(*EXTERNAL_TRAIN_ARMS[z]) for z in (0, 1)},
    }


def decode(code):
    if not 0 <= code <= 255:
        raise ValueError('code out of range')
    arm = code >> 7
    k = (code >> 4) & 7
    last7 = (code >> 3) & 1
    y = tuple((code >> i) & 1 for i in (2, 1, 0))
    if k < last7 or (k == 0 and last7 == 1) or (k == 7 and last7 == 0):
        raise ValueError('impossible first7 summary')
    return (arm, k, last7, y)


def encode(arm, k, last7, ys):
    if arm not in (0, 1) or k not in range(8) or last7 not in (0, 1) or len(ys) != 3 or any(y not in (0, 1) for y in ys):
        raise ValueError('invalid encoding')
    code = arm << 7 | k << 4 | last7 << 3 | ys[0] << 2 | ys[1] << 1 | ys[2]
    if decode(code) != (arm, k, last7, tuple(ys)):
        raise ValueError('invalid encoded first7')
    return code


def read_histogram(path=HERE / 'DERIVED_PATTERN_COUNTS.txt'):
    parts = ' '.join(s.split('#', 1)[0] for s in Path(path).read_text(encoding='utf-8').splitlines()).split()
    out = {}
    for tok in parts:
        code, count = tok.split(':')
        k = int(code, 16)
        if k in out or int(count) <= 0:
            raise ValueError('invalid histogram row')
        decode(k)
        out[k] = int(count)
    return out


def iter_participants(hist):
    for code, count in sorted(hist.items()):
        z = decode(code)
        for _ in range(count):
            yield z


def validate_histogram(hist):
    persons = list(iter_participants(hist))
    if len(persons) != 195:
        raise ValueError('expected 195 participants')
    arm_count = [sum(1 for a in persons if a[0] == z) for z in (0, 1)]
    if arm_count != [97, 98]:
        raise ValueError('wrong treatment group size')
    if sum(p[1] for p in persons) != 705:
        raise ValueError('training cooperation count mismatch')
    for arm in (0, 1):
        if sum(p[1] for p in persons if p[0] == arm) != EXTERNAL_TRAIN_ARMS[arm][1]:
            raise ValueError('treatment group train cooperation mismatch')
    test_yes = sum(sum(p[3]) for p in persons)
    if test_yes != 226:
        raise ValueError('test cooperation mismatch')
    prev = {0: [0, 0], 1: [0, 0]}
    for arm, k, last, ys in persons:
        for y in ys:
            prev[last][0] += 1
            prev[last][1] += y
            last = y
    if prev != {0: [326, 36], 1: [259, 190]}:
        raise ValueError('test transition mismatch')
    return {'n_people': len(persons), 'arm_counts': arm_count, 'test_n': len(persons) * 3,
            'test_y': test_yes, 'test_transitions': prev}


def make_losses(hist):
    p = probs()
    people = []
    for arm, k, last, ys in iter_participants(hist):
        person = {'arm': ARM_LABEL[arm], 'k': k, 'loss': {name: 0.0 for name in MODEL_NAMES},
                  'brier': {name: 0.0 for name in MODEL_NAMES}, 'n': 3}
        for y in ys:
            forecasts = {
                'constant_50': 0.5,
                'pooled_external': p['pooled'],
                'arm_external': p['arm'][arm],
                'personal_first7': (k + 0.5) / 8,
                'markov_external': p['local'][last],
                'r037_frozen_transfer': p['frozen'][last],
            }
            for name, prob in forecasts.items():
                person['loss'][name] -= y * math.log(prob) + (1-y)*math.log(1-prob)
                person['brier'][name] += (y-prob)**2
            last = y
        people.append(person)
    return people


def score(people):
    n = sum(p['n'] for p in people)
    return {name: {'n': n, 'logloss': sum(p['loss'][name] for p in people)/n,
                   'brier': sum(p['brier'][name] for p in people)/n} for name in MODEL_NAMES}


def bootstrap_differences(people, seed=38038, replicates=10000):
    if not people or not (replicates > 10):
        raise ValueError('empty participants or too few replicates')
    r = random.Random(seed)
    terms = [
        ('frozen_minus_personal', 'r037_frozen_transfer', 'personal_first7'),
        ('frozen_minus_local_markov', 'r037_frozen_transfer', 'markov_external'),
        ('local_markov_minus_pooled', 'markov_external', 'pooled_external'),
    ]
    n=len(people);means={tag: [] for tag,_,_ in terms}
    for _ in range(replicates):
        ix=[r.randrange(n) for _ in range(n)]
        for tag, left, right in terms:
            means[tag].append(sum(people[i]['loss'][left] - people[i]['loss'][right] for i in ix)/(3*n))
    return {tag: {'point':sum(p['loss'][left] - p['loss'][right] for p in people)/(3*n),
                  'bootstrap_percentile_95': [sorted(means[tag])[int(.025*replicates)],
                                              sorted(means[tag])[int(.975*replicates)]]} for tag,left,right in terms}


def verify_raw(path):
    raw = Path(path).read_bytes()
    sha = hashlib.sha1(b'blob ' + str(len(raw)).encode('ascii') + b'\0' + raw).hexdigest()
    if sha != RAW_SHA1:
        raise ValueError('raw Git blob SHA mismatch')
    decoded=raw.decode('utf-8-sig')
    rows=list(csv.DictReader(io.StringIO(decoded)))
    if len(rows)!=3900 or set(rows[0]) != {'id','game','action','score','opponent','guess','coordination'}:
        raise ValueError('unexpected raw schema')
    dic={};anom=[]
    for line_number,r in enumerate(rows,start=2):
        if r['game']!='PD':
            continue
        if r['action'] not in ('0','1') or r['opponent'] not in ('Base','Prompted'):
            raise ValueError('unexpected values')
        dic.setdefault(r['id'], []).append(r)
        if (r['action']=='1' and r['score'] not in ('0','8')) or (r['action']=='0' and r['score'] not in ('5','10')):
            anom.append(line_number)
    if len(dic)!=195:
        raise ValueError('wrong participants')
    hist={}
    for subj in dic.values():
        if len(subj)!=10 or len({r['opponent'] for r in subj})!=1:
            raise ValueError('unexpected PD participant sequence')
        arm=int(subj[0]['opponent']=='Prompted')
        decisions=[int(r['action']) for r in subj]
        code=encode(arm,sum(decisions[:7]),decisions[6],decisions[7:])
        hist[code]=hist.get(code,0)+1
    if hist != read_histogram():
        raise ValueError('raw->histogram mismatch')
    return {'git_blob_sha1':sha,'rows':len(rows),'n_pd_participants':len(dic),
            'payoff_action_discrepant_csv_lines':anom,'histogram_verification':'PASS'}


def run(hist=None, bootstrap_reps=10000):
    hist=read_histogram() if hist is None else hist
    check=validate_histogram(hist);people=make_losses(hist)
    s=score(people)
    by_arm={arm:score([p for p in people if p['arm']==arm]) for arm in ('Base','Prompted')}
    calib={'observed_cooperation_rate':226/585,
           'frozen_predicted_cooperation_rate':(326*probs()['frozen'][0]+259*probs()['frozen'][1])/585,
           'by_prev': {str(prev): {'n': cnt,'observed': yes/cnt, 'frozen':probs()['frozen'][prev]}
                       for prev,(cnt,yes) in check['test_transitions'].items()}}
    return {'source':{'repo':'eliaka/repeatedgames', 'path':'human_experiment/analysis/repgames.csv',
                      'git_blob_sha1':RAW_SHA1,'derivative':'63-pattern aggregated histogram, no participant IDs'},
            'validation':check,'training_sufficient_stats':{'pooled':EXTERNAL_TRAIN_TOTAL,
              'by_arm':EXTERNAL_TRAIN_ARMS,'by_prev':EXTERNAL_TRAIN_TRANSITIONS},
            'frozen_R037_parameters':probs()['frozen'], 'R037_measure':'isCC conditional strategy classification',
            'R038_measure':'PD actual action=1 cooperation, human plays GPT-4',
            'models':s,'by_arm':by_arm,'calibration':calib,
            'paired_participant_bootstrap':bootstrap_differences(people,replicates=bootstrap_reps),
            'analysis_classification':'posthoc transport stress test, no measurement invariance, no causal identification'}


def main():
    p=argparse.ArgumentParser();p.add_argument('--raw',type=Path,help='optional full original CSV for SHA and data audit');p.add_argument('--output',type=Path,default=HERE/'R038_RESULTS.json');p.add_argument('--bootstrap-reps',type=int,default=10000)
    args=p.parse_args()
    output=run(bootstrap_reps=args.bootstrap_reps)
    if args.raw:
        output['raw_source_verification']=verify_raw(args.raw)
    args.output.write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'n':output['validation']['test_n'],'scores':output['models'],
                      'source_raw_local_verified':bool(args.raw)},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
