"""R038 independent arithmetic/invariant tests on anonymized derived evidence."""
import importlib.util
import math
import sys
import tempfile
import unittest
from pathlib import Path

BASE=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('r038',BASE/'r038_analysis.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

class TestSchema(unittest.TestCase):
    def test_hist_loaded(self): self.assertEqual(len(m.read_histogram()),63)
    def test_hist_people(self): self.assertEqual(sum(m.read_histogram().values()),195)
    def test_arms(self): self.assertEqual(m.validate_histogram(m.read_histogram())['arm_counts'],[97,98])
    def test_train_yes(self): self.assertEqual(sum(k for _,k,_,_ in m.iter_participants(m.read_histogram())),705)
    def test_test_yes(self): self.assertEqual(m.validate_histogram(m.read_histogram())['test_y'],226)
    def test_test_transitions(self): self.assertEqual(m.validate_histogram(m.read_histogram())['test_transitions'],{0:[326,36],1:[259,190]})
    def test_malformed_code(self):
        for code in [-1,256]:
            with self.assertRaises(ValueError):m.decode(code)
    def test_encoding_all(self):
        for code in m.read_histogram():
            arm,k,last,y=m.decode(code)
            self.assertEqual(m.encode(arm,k,last,y),code)
    def test_invalid_sequence(self):
        with self.assertRaises(ValueError):m.encode(1,0,1,(0,0,0))
    def test_invalid_hist_duplicate(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'bad.txt';p.write_text('00:1 00:2\n')
            with self.assertRaises(ValueError):m.read_histogram(p)
    def test_invalid_hist_n(self):
        with self.assertRaises(ValueError):m.validate_histogram({0:1})
    def test_hist_sha256(self):
        self.assertEqual(len(__import__('hashlib').sha256((BASE/'DERIVED_PATTERN_COUNTS.txt').read_bytes()).hexdigest()),64)

class TestForecasts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.people=m.make_losses(m.read_histogram());cls.s=m.score(cls.people)
    def test_heldout_n(self):self.assertEqual(self.s['r037_frozen_transfer']['n'],585)
    def test_external_train(self):self.assertEqual(m.EXTERNAL_TRAIN_TOTAL,(1365,705))
    def test_imported_p0(self):self.assertAlmostEqual(m.probs()['frozen'][0],50.5/346,14)
    def test_imported_p1(self):self.assertAlmostEqual(m.probs()['frozen'][1],390.5/460,14)
    def test_newstudy_markov(self):self.assertAlmostEqual(m.probs()['local'][0],135.5/558,14)
    def test_external_brier(self):self.assertAlmostEqual(self.s['r037_frozen_transfer']['brier'],0.14786018249285,11)
    def test_fixed_brier(self):self.assertAlmostEqual(self.s['constant_50']['brier'],0.25,13)
    def test_frozen_loss(self):self.assertAlmostEqual(self.s['r037_frozen_transfer']['logloss'],0.47275015138958,11)
    def test_personal_loss(self):self.assertAlmostEqual(self.s['personal_first7']['logloss'],0.43690227301706,11)
    def test_other_losses(self):
        self.assertAlmostEqual(self.s['markov_external']['logloss'],0.48383396894948,10)
        self.assertAlmostEqual(self.s['pooled_external']['logloss'],0.70118238574666,10)
    def test_byarm(self):
        o=m.run(bootstrap_reps=120)
        self.assertEqual(o['by_arm']['Base']['pooled_external']['n'],291)
        self.assertEqual(o['by_arm']['Prompted']['pooled_external']['n'],294)
        self.assertLess(o['by_arm']['Base']['personal_first7']['logloss'],o['by_arm']['Base']['r037_frozen_transfer']['logloss'])
        self.assertLess(o['by_arm']['Prompted']['personal_first7']['logloss'],o['by_arm']['Prompted']['r037_frozen_transfer']['logloss'])
    def test_calibration(self):
        o=m.run(bootstrap_reps=120)
        self.assertAlmostEqual(o['calibration']['observed_cooperation_rate'],226/585,12)
        self.assertGreater(o['calibration']['frozen_predicted_cooperation_rate'],o['calibration']['observed_cooperation_rate'])
    def test_bootstrap_repeatability(self):
        a=m.bootstrap_differences(self.people,seed=9,replicates=55)
        b=m.bootstrap_differences(self.people,seed=9,replicates=55)
        self.assertEqual(a,b)
    def test_bootstrap_sign(self):
        o=m.bootstrap_differences(self.people,seed=9,replicates=55)
        self.assertGreater(o['frozen_minus_personal']['point'],0)
    def test_raw_missing(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'fake.csv';p.write_text('id,game,action,score,opponent,guess,coordination\n1,PD,0,5,Base,LLM,1\n')
            with self.assertRaisesRegex(ValueError,'SHA'):m.verify_raw(p)
    def test_invalid_posterior(self):
        for n,y in [(0,0),(1,2),(4,-1)]:
            with self.assertRaises(ValueError):m.posterior(n,y)

if __name__=='__main__':unittest.main()
