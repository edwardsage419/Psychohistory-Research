import hashlib
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from r027_analysis import git_blob_sha1,load_aggregates,descriptives,raw_audit,winsor_audit

class TestR027(unittest.TestCase):
    def test_git_blob(self):
        s=b"test\n"
        self.assertEqual(git_blob_sha1(s),hashlib.sha1(b"blob 5\0test\n").hexdigest())
    def test_true_block_count(self):
        a=load_aggregates(Path(__file__).resolve().parents[1]/"BLOCK_SUMMARY_BASE36.txt")
        self.assertEqual(len(a),219)
    def test_raw_comment_sums(self):
        a=load_aggregates(Path(__file__).resolve().parents[1]/"BLOCK_SUMMARY_BASE36.txt")
        r=descriptives(a)
        self.assertEqual(r['control_comments'],6758)
        self.assertEqual(r['treated_comments'],11506)
        self.assertEqual(r['control_removed'],3857)
        self.assertEqual(r['treated_removed'],5704)
        self.assertEqual(r['positive_discussions_in_csv'],797)
    def test_means(self):
        a=load_aggregates(Path(__file__).resolve().parents[1]/"BLOCK_SUMMARY_BASE36.txt")
        r=descriptives(a)
        self.assertAlmostEqual(r['comment_count']['ratio'],1.7025747262503699)
        self.assertAlmostEqual(r['comment_count']['treated_minus_control'],4.33607305936073)
    def test_missing_invalid_aggregate(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"bad.txt";p.write_text('1:0.0.0.0.0.0')
            with self.assertRaises(ValueError):load_aggregates(p)
    def test_raw_length_guard(self):
        with self.assertRaises(ValueError):raw_audit([])
    def test_zephyr_winsor_guard(self):
        # Minimum example: values 3, 0, 6, 1, arbitrary arms; outliers deliberately capped.
        arr=[{'newcomer.comments':str(v),'treatment':t} for v,t in [(3,'0'),(0,'0'),(6,'1'),(1,'1')]]
        r=winsor_audit(arr)
        self.assertTrue(r['exploratory_q99_cap']>=0)

if __name__=='__main__':unittest.main()
