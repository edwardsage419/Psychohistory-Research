#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""R027: reproduce Matias 2019 non-AMA post-level descriptive and randomization audit.

Run with the provided block aggregates to verify descriptive numbers without network.
Supply the original posts CSV to perform raw-byte SHA verification, exclusion audit,
post-level sensitivity analysis and Fisher sharp-null randomization inference.
This is an independent computational analysis, not the author's fitted model.
"""
import argparse
import csv
import hashlib
import json
import math
import random
import statistics
from collections import Counter, defaultdict
from pathlib import Path
from urllib.request import urlopen

REPO = "https://github.com/citizensandtech/CivilServant-Analysis"
POSTS = "r_science_experiment_1_posts.09.26.2016.csv"
SOURCE_URL = ("https://raw.githubusercontent.com/citizensandtech/"
              "CivilServant-Analysis/master/papers/r_science_2016/" + POSTS)
BLOB_SHA1 = "404aae15453952f9588d363c8cb7521e45a64959"
EXCLUDE = frozenset({"nonama.block058", "nonama.block222", "nonama.block037"})
SEED = 38413


def git_blob_sha1(data):
    """Actual Git blob hash, includes Git's object type and size header."""
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def load_aggregates(path):
    """Every record encodes block and (sum comments, sum removed, active posts) by arm."""
    txt = Path(path).read_text(encoding="utf-8").strip()
    items = []
    for item in txt.split("|"):
        key, six = item.split(":", 1)
        v = [int(x, 36) for x in six.split(".")]
        if len(v) != 6:
            raise ValueError("Block does not contain six sufficient statistics")
        items.append((int(key, 36), v))
    if len(items) != 219 or len(set(b for b, _ in items)) != 219:
        raise ValueError("Expected 219 distinct non-AMA randomization blocks")
    return items


def descriptives(items):
    d = {"n_blocks": len(items), "n_discussions_per_arm": len(items) * 5}
    sums = [sum(v[j] for _, v in items) for j in range(6)]
    keys = ("control_comments", "control_removed", "control_active_discussions",
            "treated_comments", "treated_removed", "treated_active_discussions")
    d.update(dict(zip(keys, sums)))
    N = len(items) * 5
    metrics = {"comment_count": (3, 0), "comment_removed": (4, 1),
               "at_least_one_comment": (5, 2)}
    for name, (a, b) in metrics.items():
        mean1, mean0 = sums[a]/N, sums[b]/N
        diffs = [(x[a] - x[b])/5 for _, x in items]
        se = statistics.stdev(diffs) / math.sqrt(len(diffs))
        d[name] = {
            "treat_mean": mean1, "control_mean": mean0,
            "treated_minus_control": mean1 - mean0,
            "ratio": mean1 / mean0 if mean0 else None,
            "exploratory_block_SD_SE": se,
            "normal_95_range": [(mean1-mean0)-1.96*se,(mean1-mean0)+1.96*se],
        }
    d["positive_discussions_in_csv"] = sums[2] + sums[5]
    d["paper_positive_discussions"] = 804
    d["unresolved_count_difference"] = d["positive_discussions_in_csv"] - 804
    return d


def load_raw(path):
    content=Path(path).read_bytes()
    actual_sha=git_blob_sha1(content)
    if actual_sha!=BLOB_SHA1:
        raise ValueError(f"Git blob hash mismatch: {actual_sha} expected {BLOB_SHA1}")
    with Path(path).open("r",encoding="utf-8-sig",newline="") as f:
        rows=list(csv.DictReader(f))
    required={"block.id","post.ama","treatment","newcomer.comments","newcomer.comments.removed"}
    if not rows or not required.issubset(rows[0]):
        raise ValueError("Required post-level columns missing")
    return rows


def raw_audit(rows):
    excluded=[x for x in rows if x["block.id"] in EXCLUDE]
    main=[x for x in rows if x["block.id"] not in EXCLUDE]
    q_and_a=[x for x in main if x["post.ama"]=="TRUE"]
    nonama=[x for x in main if x["post.ama"]=="FALSE"]
    if len(rows)!=2238 or len(excluded)!=24 or len(main)!=2214 or len(q_and_a)!=24 or len(nonama)!=2190:
        raise ValueError("Source sizes unexpectedly differ from inspected baseline")
    blocks=defaultdict(list)
    for x in nonama:
        z=int(x["treatment"])
        if z not in (0,1):
            raise ValueError("treatment value is not 0 or 1")
        y=int(x["newcomer.comments"])
        removed=int(x["newcomer.comments.removed"])
        if not 0<=removed<=y:
            raise ValueError("removed count exceeds comments in source")
        blocks[x["block.id"]].append((z,y,removed,int(y>0)))
    if len(blocks)!=219 or any(len(v)!=10 or sum(x[0] for x in v)!=5 for v in blocks.values()):
        raise ValueError("Blocked randomization dimensions differ from expected")
    ag=[]
    for block, rec in sorted(blocks.items()):
        z0=[x for x in rec if x[0]==0];z1=[x for x in rec if x[0]==1]
        six=[sum(x[k] for x in z0) for k in (1,2,3)] + [sum(x[k] for x in z1) for k in (1,2,3)]
        ag.append((int(block.rsplit("block",1)[1]),six))
    # Each treated and control arm contains five actual randomized discussions per block.
    result={"source_row_count":len(rows),"excluded_rows":len(excluded),
            "retained_rows":len(main),"retained_AMA":len(q_and_a),
            "retained_non_AMA":len(nonama),"excluded_block_names":sorted(EXCLUDE),
            "author_original_blob_sha1":BLOB_SHA1}
    return result, ag, blocks, nonama


def randomization_test(blocks, sims=20000, seed=SEED):
    """Fisher sharp-null permutation under five-of-ten assignment within each block.

    Our statistic is the unstudentized difference of means. This may differ
    from the historical ri2 package's statistics and sampled assignment draws.
    """
    rng = random.Random(seed)
    all_blocks=[blocks[x] for x in sorted(blocks)]
    obs=[]
    for k in (1,2,3):
        t=sum(v[k] for group in all_blocks for v in group if v[0]==1)
        c=sum(v[k] for group in all_blocks for v in group if v[0]==0)
        obs.append((t-c)/1095)
    extreme=[0,0,0]
    totals=[[sum(z[k] for z in group) for k in (1,2,3)] for group in all_blocks]
    for _ in range(sims):
        diffs=[0,0,0]
        for group, total in zip(all_blocks,totals):
            drawn=rng.sample(range(10),5)
            for j in range(3):
                treated=sum(group[i][j+1] for i in drawn)
                diffs[j]+=2*treated-total[j]
        for j in range(3):
            if diffs[j]/1095 >= obs[j]-1e-12:
                extreme[j]+=1
    return {"simulations":sims,"seed":seed,"statistic":"unstudentized treated-control mean difference",
            "null":"sharp no-effect; block-restricted five-of-ten permutations",
            "alternative":"greater", "monte_carlo_p_with_plus_one":{
            name:(n+1)/(sims+1) for name,n in zip(("comment_count","comment_removed","at_least_one_comment"),extreme)},
            "multiple_testing_adjustment":"none", "notes":"Exploratory method audit; not the author's reported significance levels"}


def winsor_audit(nonama):
    all_y=sorted(int(x["newcomer.comments"]) for x in nonama)
    cap=all_y[int((len(all_y)-1)*0.99)]
    treat=sum(min(cap,int(x["newcomer.comments"])) for x in nonama if x["treatment"]=="1")
    control=sum(min(cap,int(x["newcomer.comments"])) for x in nonama if x["treatment"]=="0")
    return {"exploratory_q99_cap":cap,"max_original_count":max(all_y),"w_treat_mean":treat/1095,
            "w_control_mean":control/1095,"w_ratio":treat/control,
            "explanation":"Outcome winsorization is post hoc and changes estimand; do not use for confirmatory significance."}


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--raw",type=Path,help="Unmodified original author CSV; validates Git blob sha1")
    ap.add_argument("--fetch",action="store_true",help="Try to download source CSV from public GitHub")
    ap.add_argument("--sims",type=int,default=20000)
    ap.add_argument("--output",type=Path,default=Path("R027_RESULTS.json"))
    ap.add_argument("--aggregates",type=Path,default=Path(__file__).parent/"BLOCK_SUMMARY_BASE36.txt")
    args=ap.parse_args()
    stats=descriptives(load_aggregates(args.aggregates))
    res={"round":"R027","source":SOURCE_URL,"source_blob_sha1":BLOB_SHA1,
         "basis":"Github connector decoded the original 2,238-row CSV; only anonymized 219-block aggregate locally archived",
         "aggregate_analysis":stats,"raw_local_verified":False,"raw_audit":None,"monte_carlo_local":None,
         "prior_connector_computation":{"n":20000,"seed":"xorshift32 38413", "comments_upper_p":0.03729813509324534,
         "removed_upper_p":0.11409429528523574,"any_comment_upper_p":0.6363181840907954,
         "note":"Computed directly in the connector's JS environment; not independently rerun from full raw CSV on local Python"},
         "limitations":["Comment-level removal data are not locally available; cannot independently reproduce H1 logistic model",
         "Author's 8.4 percentage point compliance effect is not replicated here",
         "2022 followup did not observe the same participation growth", "R027 not an independent real-world replication; it reanalyzes the same 2016 experiment"]}
    if args.fetch:
        target=Path(__file__).parent/POSTS
        with urlopen(SOURCE_URL,timeout=50) as stream:
            data=stream.read()
        if git_blob_sha1(data)!=BLOB_SHA1:
            raise ValueError("Downloaded file Git blob does not match frozen source SHA1")
        target.write_bytes(data)
        args.raw=target
    if args.raw:
        raw=load_raw(args.raw)
        audit,ag,bl,nonama=raw_audit(raw)
        if sorted(ag)!=sorted(load_aggregates(args.aggregates)):
            raise ValueError("Rebuilt 219 block summaries do not match connector-derived archived statistics")
        res["raw_audit"]=audit
        res["raw_local_verified"]=True
        res["winsorized"]=winsor_audit(nonama)
        res["monte_carlo_local"]=randomization_test(bl,args.sims)
    args.output.write_text(json.dumps(res,ensure_ascii=False,indent=2),encoding="utf-8")
    print(f"R027 {'ORIGINAL_CSV_VERIFIED' if res['raw_local_verified'] else 'AGGREGATES_ONLY'} | {args.output}")


if __name__=="__main__":
    main()
