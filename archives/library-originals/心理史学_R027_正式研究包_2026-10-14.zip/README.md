# 心理史学 R027 独立再分析研究包

日期：2026-10-14。方法状态：真实公开原始帖子CSV已通过GitHub连接器完整读取、解析，并完成描述性与模拟随机化推断；本地只保存219区块派生聚合数据。本包**不包含**原始2,238行CSV，不能据此说本地原始字节端到端复现。

## 本地离线校验

要求 Python 3.9 或更高版本，所有功能使用标准库。

```bash
python -m unittest discover -s tests -v
python r027_analysis.py --output R027_RESULTS.json
```

## 若你的电脑能访问 GitHub 原始文件

```bash
python r027_analysis.py --fetch --sims 20000 --output R027_RESULTS_RAW.json
```

这将自动从公开作者仓库下载原始帖子CSV，验证Git blob SHA1，重新计算正式过滤、完整区块、长尾稳健性及区块内置换检验。如果已有原文件，可运行：

```bash
python r027_analysis.py --raw /path/to/r_science_experiment_1_posts.09.26.2016.csv --sims 20000
```

蒙特卡洛p值会随伪随机数算法和种子不同而微变。代码提供的是自行明确的设计审查而非2008至2019年`ri2`原软件程序的位级复现；不得据此改写原论文官方统计推断。

`BLOCK_SUMMARY_BASE36.txt`每条采用 `随机化区块编号:控制组(评论,删除,活跃帖子).处理组(评论,删除,活跃帖子)` 的六个 base36 整数，按十进制还原并使用每处理五帖，合计219个区块。此文件不包含用户账号或评论文本。

引用源：Matias (2019) PNAS DOI 10.1073/pnas.1813486116；GitHub `citizensandtech/CivilServant-Analysis`；2022复现公开汇报 <https://citizensandtech.org/2022/08/harassment-prevention-across-communities/>。
