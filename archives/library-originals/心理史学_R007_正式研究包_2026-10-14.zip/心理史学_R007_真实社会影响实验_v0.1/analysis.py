#!/usr/bin/env python3
"""R007: public trial-level social-influence experiment analysis.

Python 3.10+; only standard library. Source data are supplied by the research
authors. No individual rows or participant identifiers are emitted as outputs.
"""
from __future__ import annotations
import argparse
import csv
from collections import defaultdict
import hashlib
import json
import math
from pathlib import Path
import random
from statistics import mean
from urllib.request import urlopen

SOURCE_URL = (
    "https://raw.githubusercontent.com/joshua-a-becker/wisdom-of-partisan-crowds/"
    "79d7658da169d9a943b0cbd221c38f47ffa7c11a/"
    "Becker%20Centola%20Porter%20-%20Wisdom%20of%20Partisan%20Crowds%20-%20Supplementary%20Dataset.csv"
)
GIT_BLOB_SHA1 = "2fc18cefd211727e560b05d60c1289f1f4891969"


def git_blob_sha(raw: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\x00" + raw).hexdigest()


def fetch_public_dataset(path: Path) -> None:
    # Explicit opt-in network download, no credentials or cookies.
    with urlopen(SOURCE_URL, timeout=45) as response:
        raw = response.read()
    if git_blob_sha(raw) != GIT_BLOB_SHA1:
        raise ValueError("Data file git SHA mismatch: source may have changed")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)


def read_records(path: Path) -> tuple[list[dict[str, str]], str]:
    raw = path.read_bytes()
    sha = git_blob_sha(raw)
    if sha != GIT_BLOB_SHA1:
        raise ValueError(f"Unexpected Git blob SHA {sha}; expected {GIT_BLOB_SHA1}")
    import io
    items = list(csv.DictReader(io.StringIO(raw.decode("utf-8-sig"), newline="")))
    return items, sha


def valid_exp1(row: dict[str, str], trim_extremes: bool = False) -> bool:
    if row["experiment"] != "1":
        return False
    try:
        t = float(row["truth"])
        x = [float(row[f"response_{i}"]) for i in (1, 2, 3)]
    except (ValueError, TypeError):
        return False
    if not math.isfinite(t) or t <= 0 or not all(math.isfinite(v) and v > 0 for v in x):
        return False
    return (not trim_extremes) or all(v <= 10 * t for v in x)


def prepare_trials(records: list[dict[str, str]], trim_extremes: bool = False):
    # All 3 rounds must be observed for the same row (author's Experiment 1 prep).
    selected = [r for r in records if valid_exp1(r, trim_extremes)]
    by_question = defaultdict(list)
    for r in selected:
        key = (r["party"], r["set"], r["pair_id"], r["network"], r["q"])
        by_question[key].append(r)
    by_trial = defaultdict(list)
    for (party, question_set, pair_id, network, q), rows in by_question.items():
        truth = math.log(float(rows[0]["truth"]))
        errors = []
        for round_id in (1, 2, 3):
            logmean = mean(math.log(float(r[f"response_{round_id}"])) for r in rows)
            errors.append(abs(logmean - truth))
        by_trial[(party, question_set, pair_id, network)].append(
            {"question": q, "n": len(rows), "err1": errors[0], "err3": errors[2]}
        )
    trials = []
    for (party, question_set, pair_id, network), qs in by_trial.items():
        if len(qs) != 4:
            raise ValueError("Incomplete trial with fewer than four questions")
        a, b = mean(q["err1"] for q in qs), mean(q["err3"] for q in qs)
        trials.append({"party": party, "set": question_set, "pair_id": pair_id,
                       "network": network, "n_questions": len(qs),
                       "n_rows": sum(q["n"] for q in qs),
                       "mean_error_round_1": a, "mean_error_round_3": b,
                       "change": b - a})
    trials.sort(key=lambda t: (t["network"], t["party"], t["set"], int(t["pair_id"])))
    return selected, trials, len(by_question)


def bootstrap_block_contrast(trials: list[dict], nboot: int = 20000,
                             seed: int = 20261014) -> dict:
    strata = defaultdict(list)
    for row in trials:
        strata[(row["party"], row["set"])].append(row)
    contrasts = []
    for key, rows in sorted(strata.items()):
        social = [r["change"] for r in rows if r["network"] == "Social"]
        control = [r["change"] for r in rows if r["network"] == "Control"]
        if len(social) != 3 or len(control) != 1:
            raise ValueError(f"Expected 3 social trials and 1 control in stratum {key}")
        contrasts.append(mean(social) - control[0])
    rng = random.Random(seed)
    n = len(contrasts)
    draws = sorted(mean(contrasts[rng.randrange(n)] for _ in range(n))
                   for _ in range(nboot))
    return {"estimate": mean(contrasts), "bootstrap95": [draws[int(.025*nboot)],
                                                           draws[int(.975*nboot)-1]],
            "stratum_contrasts": contrasts,
            "warning": "Exploratory percentile bootstrap over eight party × set strata; not design-exact randomization inference."}


def report(records: list[dict[str, str]], trim_extremes: bool = False) -> tuple[dict, list]:
    subset, trials, nq = prepare_trials(records, trim_extremes)
    out = {"experiment": 1,
           "description": "group-level absolute error of arithmetic mean of log estimates",
           "filter": "complete positive 3-round observations" + ("; <=10x truth" if trim_extremes else ""),
           "experiment1_raw_rows": sum(r["experiment"] == "1" for r in records),
           "valid_rows": len(subset), "question_groups": nq, "n_trials": len(trials)}
    for network in ("Social", "Control"):
        ts = [t for t in trials if t["network"] == network]
        if not ts:
            continue
        start = mean(t["mean_error_round_1"] for t in ts)
        end = mean(t["mean_error_round_3"] for t in ts)
        out[network] = {"n_trials": len(ts), "mean_error_1": start,
                        "mean_error_3": end, "mean_error_change": end-start,
                        "fraction_reduced": (start-end)/start}
    if len(trials) == 32:
        out["stratified_exploratory_comparison"] = bootstrap_block_contrast(trials)
    return out, trials


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data", type=Path, default=Path("original_data.csv"))
    p.add_argument("--download", action="store_true", help="Download public authors' CSV with integrity check")
    p.add_argument("--out", type=Path, default=Path("results"))
    args = p.parse_args()
    if args.download:
        fetch_public_dataset(args.data)
    if not args.data.is_file():
        p.error("Provide --data path or pass --download on a network-connected computer")
    records, sha = read_records(args.data)
    main_out, trial_data = report(records)
    extreme_out, _ = report(records, trim_extremes=True)
    args.out.mkdir(parents=True, exist_ok=True)
    content = {"data_rows": len(records), "git_blob_sha1": sha,
               "main": main_out, "sensitivity_10x_truth": extreme_out,
               "analysis_limits": [
                   "Only Experiment 1; no private-preference or normative-expectation measurement",
                   "Main analysis matches author's finite-three-response data-prep transformation",
                   "Extreme filter is a separate sensitivity analysis based on author's table code",
                   "Bootstrap is exploratory; no original-paper p-value replication claimed"]}
    (args.out/"summary.json").write_text(json.dumps(content, ensure_ascii=False, indent=2), encoding="utf-8")
    with (args.out/"trials.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(trial_data[0]))
        w.writeheader(); w.writerows(trial_data)
    print(json.dumps({"rows": len(records), "main": main_out["Social"],
                      "control": main_out["Control"], "output": str(args.out)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
