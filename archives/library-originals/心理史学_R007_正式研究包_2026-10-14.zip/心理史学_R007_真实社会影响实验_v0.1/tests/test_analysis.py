import math
import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from analysis import git_blob_sha, valid_exp1, prepare_trials, report


class TestAnalysis(unittest.TestCase):
    def row(self, **kw):
        x = {"experiment": "1", "party": "Dem", "set": "A", "pair_id": "1",
             "network": "Social", "q": "Q1", "truth": "10", "response_1": "20",
             "response_2": "15", "response_3": "10"}
        x.update(kw)
        return x

    def test_blob(self):
        self.assertEqual(git_blob_sha(b"hello"), "b6fc4c620b67d95f953a5c1c1230aaab5db5a1b0")

    def test_invalid(self):
        self.assertTrue(valid_exp1(self.row()))
        self.assertFalse(valid_exp1(self.row(response_2="NA")))
        self.assertFalse(valid_exp1(self.row(response_3="0")))
        self.assertFalse(valid_exp1(self.row(response_1="-4")))
        self.assertFalse(valid_exp1(self.row(experiment="2")))

    def test_extreme(self):
        self.assertTrue(valid_exp1(self.row(response_1="100"), True))
        self.assertFalse(valid_exp1(self.row(response_1="101"), True))

    def test_trial(self):
        a = [self.row(q=f"Q{i}") for i in range(4)]
        rows, trials, nq = prepare_trials(a)
        self.assertEqual(len(rows), 4)
        self.assertEqual(nq, 4)
        self.assertEqual(len(trials), 1)
        self.assertAlmostEqual(trials[0]["mean_error_round_1"], math.log(2))
        self.assertAlmostEqual(trials[0]["mean_error_round_3"], 0.0)

    def test_report(self):
        a = [self.row(q=f"Q{i}") for i in range(4)]
        b, _ = report(a)
        self.assertEqual(b["Social"]["n_trials"], 1)
        self.assertAlmostEqual(b["Social"]["fraction_reduced"], 1)

if __name__ == "__main__":
    unittest.main()
