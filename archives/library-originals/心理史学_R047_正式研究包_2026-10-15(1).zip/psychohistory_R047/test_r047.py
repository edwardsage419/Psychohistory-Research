"""Constructed-data tests; these do not count as original Stata source replay."""
import unittest
import numpy as np
from r047_replay import git_blob_sha1, rebuild_transitions, clustered_ols, SOURCE_URL


class R047SyntheticTests(unittest.TestCase):
    def test_git_hash(self):
        self.assertEqual(git_blob_sha1(b'test\n'), '9daeafb9864cf43055ae93beb0afd6c7d144bfa4')

    def test_transition_counts(self):
        rows=[]
        # One four-player, punishment-enabled group, 3 observed rounds.
        for rd in [1,2,3,4]:
            for subject in range(4):
                rows.append(dict(subject=subject+1, game=1, round=rd,
                                 invest=20+3*subject+rd, received=subject,
                                 session=5, homo=0, ff=1, token=40))
        kept, t = rebuild_transitions(rows)
        self.assertEqual((len(kept),len(t)), (12,8))
        self.assertTrue(all(r['y']==1 for r in t))
        self.assertTrue(all(r['period']>=2 for r in t))
        self.assertTrue(all(np.isfinite(r['lag_dev']) for r in t))

    def test_ols_recovers_coefficients(self):
        rng=np.random.default_rng(47)
        rows=[]
        for group in range(12):
            homo=int(group>=6)
            for i in range(28):
                d=rng.normal(0,3)
                p=abs(rng.normal(4,2))
                y=2.0+0.6*d+((-0.3) if homo==0 else 0.2)*p
                rows.append(dict(group=group,homo=homo,lag_dev=d,lag_received=p,y=y))
        out=clustered_ols(rows,'lag_dev')
        self.assertEqual(out['n'],336)
        self.assertTrue(np.allclose(out['coefficient'],[2.0,0.6,-0.3,0.2],atol=1e-10))
        self.assertAlmostEqual(out['equal_minus_unequal'],0.5,places=9)

    def test_group_se_finite(self):
        rng=np.random.default_rng(4); rows=[]
        for group in range(10):
            for i in range(20):
                h=int(group>=5); d=float(rng.normal()); p=float(abs(rng.normal()))
                rows.append(dict(group=group,homo=h,dev=d,lag_received=p,
                                 y=float(2+.3*d+.1*p+rng.normal())))
        z=clustered_ols(rows,'dev')
        self.assertTrue(all(np.isfinite(z['group_clustered_se'])))
        self.assertEqual(z['clusters'],10)

    def test_source_url(self):
        self.assertIn('InequalityCPR',SOURCE_URL)


if __name__=='__main__':
    unittest.main(verbosity=2)
