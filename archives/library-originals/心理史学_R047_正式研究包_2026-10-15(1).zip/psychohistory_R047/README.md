# 心理史学 R047 正式研究包（独立增量）

这是基于用户已确认R046完结和R047启动的新增研究增量包，并非早先研究主控台 v3.7 的完整替代品。R001至R046结果仅继承现有归档，不改变其冻结状态。

## 文件

* `R047_REPORT.md`：研究结论、证据级别、时序敏感性表、场次审计和限制。
* `R048_RESEARCH_GATE.md`：R048研究执行顺序和禁止跨越的验证关口。
* `r047_replay.py`：有源码Git blob哈希检查的原始CSV重算程序，八个OLS敏感性回归和组聚类误差。
* `test_r047.py`：以构造数据测试数学及软件逻辑，不能当作真实源端到端复现。
* `SOURCE_LEDGER.json`：来源哈希、读取级别、缺失项。
* `GOLDEN_RESULTS.json`：连接器侧直接计算出的已核验数值，用于验证未来独立重算。

## 环境和运行

需安装 Python 3.10+、NumPy：

```bash
python -m pip install numpy
python -m unittest discover -s . -p 'test_r047.py' -v
python r047_replay.py --csv /path/to/author/data.csv --output R047_REPLAY_OUTPUT.json
```

在可联网环境，可明确指定 `--download` 从公开Github原始源获取CSV，校验Git blob失败会立即终止。

```bash
python r047_replay.py --download --output R047_REPLAY_OUTPUT.json
```

本次所处容器受网络/DNS限制，没有获得原始CSV本地字节。因此本包不包含原始CSV、本地原始回归运行日志或已成功的Stata随机效应估计。原创主数据请从作者官方仓库合法获取并自行核验。

## 科学边界

来自已见研究的事后再分析，8项结果是OLS相关结构，绝非真实世界历史事件预测、独立因果识别、或新独立研究的复制成功。`PESEN v0.1=FROZEN`。
