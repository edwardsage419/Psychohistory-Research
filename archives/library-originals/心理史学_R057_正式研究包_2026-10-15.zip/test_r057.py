import csv
import json
import math
import tempfile
import unittest
from pathlib import Path

import r057_audit as m

SOURCE = Path(__file__).parent / 'R056_TRIAL_AGGREGATES_INHERITED.csv'


def fixture_rows():
    data = []
    for exp in (1, 2):
        for q in ('Q1', 'Q2', 'Q3', 'Q4'):
            for party in ('Dem', 'Repub'):
                for condition, pid in (('Control', 1), ('Social', 1), ('Social', 2), ('Social', 3)):
                    for k in range(3):
                        data.append(dict(experiment=str(exp), q=q, user_id=f'{exp}-{party}-{condition}-{pid}-{k}',
                                         party=party, response_1='2', response_2='2.4',
                                         response_3=('3' if condition=='Social' else '2'),
                                         truth='3', set='A', network=condition, pair_id=str(pid),
                                         remove_extreme=''))
    return data


class Identity(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.trials = m.import_trials(SOURCE)

    def test_raw_blob_hash_formula(self):
        x = b'hello\n'
        self.assertEqual(m.sha_git_blob(x), 'ce013625030ba8dba906f756967f9e9ca394464a')

    def test_forged_raw_is_rejected(self):
        text = ','.join(sorted(m.REQUIRED)) + '\n'
        with self.assertRaisesRegex(ValueError, 'authentication FAILED'):
            m.read_original(text.encode())

    def test_wrong_schema_rejected_in_fixture(self):
        with self.assertRaisesRegex(ValueError, 'Missing required'):
            m.read_original(b'x,y\n1,2\n', locked=False)

    def test_numeric_accepts_negative_truth(self):
        self.assertEqual(m.numeric('-46'), -46.0)

    def test_numeric_rejects_missing(self):
        self.assertIsNone(m.numeric('NA'))
        self.assertIsNone(m.numeric(''))

    def test_numeric_rejects_nonfinite(self):
        self.assertIsNone(m.numeric('inf'))
        self.assertIsNone(m.numeric('nan'))

    def test_grouping_sample(self):
        self.assertEqual(len(self.trials), 64)
        m.validate_trials(self.trials)

    def test_duplicate_trial_rejected(self):
        d = [dict(t) for t in self.trials]
        d[0] = dict(d[1])
        with self.assertRaisesRegex(ValueError, 'Duplicated trial'):
            m.validate_trials(d)

    def test_misassignment_rejected(self):
        d = [dict(t) for t in self.trials]
        ix = next(i for i,z in enumerate(d) if z['network'] == 'Control')
        d[ix]['network'] = 'Social'
        with self.assertRaisesRegex(ValueError, 'Duplicated trial|condition in stratum'):
            m.validate_trials(d)

    def test_inconsistent_change_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / 'bad.csv'
            with p.open('w', newline='') as f:
                w = csv.DictWriter(f, fieldnames=m.TRIAL_FIELDS)
                w.writeheader()
                for i, t in enumerate(self.trials):
                    q = {k:t[k] for k in m.TRIAL_FIELDS}
                    if i == 0:
                        q['change'] += 1
                    w.writerow(q)
            with self.assertRaisesRegex(ValueError, 'inconsistent'):
                m.import_trials(p)

    def test_locked_metrics_comparable(self):
        res = m.summary(self.trials, 'change', B=500)
        self.assertAlmostEqual(res['1']['difference'], -.073418132971, places=9)
        self.assertAlmostEqual(res['2']['difference'], -.623723655829, places=9)

    def test_stratum_signs(self):
        res = m.summary(self.trials, 'change', B=500)
        self.assertEqual(res['1']['favorable_strata'], 6)
        self.assertEqual(res['2']['favorable_strata'], 8)

    def test_invalid_metric_cannot_be_inferred_from_aggregates(self):
        with self.assertRaisesRegex(ValueError, 'Metric requires original'):
            m.summary(self.trials, 'median_change', B=500)

    def test_bootstrap_deterministic(self):
        self.assertEqual(m.summary(self.trials, B=500), m.summary(self.trials, B=500))

    def test_requires_positive_bootstrap(self):
        with self.assertRaises(ValueError):
            m.summary(self.trials, B=10)

    def test_baseline_adjusted_coeff(self):
        a = m.baseline_adjusted_coeff(self.trials, 1)
        b = m.baseline_adjusted_coeff(self.trials, 2)
        self.assertAlmostEqual(a['social_effect_coef'], -.073887296, places=7)
        self.assertAlmostEqual(b['social_effect_coef'], -.698801498, places=7)

    def test_baseline_regression_has_32_independent_trials(self):
        self.assertEqual(m.baseline_adjusted_coeff(self.trials, 1)['n_trials'], 32)

    def test_fixture_aggregates(self):
        rows = fixture_rows()
        trials, counted = m.groups_from_source(rows)
        self.assertEqual(len(trials), 16)
        self.assertEqual(counted, {1: 96, 2: 96})
        self.assertTrue(all(t['individual_change'] <= 0 for t in trials))

    def test_fixture_median_in_exp2(self):
        trials,_ = m.groups_from_source(fixture_rows())
        self.assertTrue(any(t['experiment']==2 and t['network']=='Social' and
                            t['median_change'] < 0 for t in trials))

    def test_fixture_extreme_tag_removed_only_in_exp2(self):
        rows = fixture_rows()
        rows[0]['remove_extreme'] = '1'
        exp2 = next(z for z in rows if z['experiment']=='2' and z['network']=='Control')
        exp2['remove_extreme']='2'
        t, n = m.groups_from_source(rows, 'author')
        self.assertEqual(n[1], 96)
        self.assertEqual(n[2], 95)
        t2,n2=m.groups_from_source(rows,'all_finite')
        self.assertEqual(n2[2], 96)

    def test_fixture_nonnumeric_discard(self):
        rows=fixture_rows()
        rows[0]['response_3']='NA'
        _,n=m.groups_from_source(rows)
        self.assertEqual(n[1], 95)

    def test_fixture_exp1_log_zero_discard(self):
        rows=fixture_rows()
        rows[0]['response_3']='0'
        _,n=m.groups_from_source(rows)
        self.assertEqual(n[1], 95)

    def test_mean_median_divergence(self):
        x=[1,2,3,100]
        self.assertGreater(m.mean(x), m.statistics.median(x))

    def test_empty_mean_rejected(self):
        with self.assertRaises(ValueError):
            m.mean([])

    def test_unknown_extreme_policy_rejected(self):
        with self.assertRaises(ValueError):
            m.groups_from_source([], extreme_mode='unknown')

    def test_inherited_aggregate_does_not_claim_raw_authentication(self):
        a=json.loads((Path(__file__).parent/'R057_LOCAL_GROUP_AUDIT.json').read_text())
        self.assertFalse(a['provenance']['original_bytes_authenticated'])


if __name__=='__main__':
    unittest.main(verbosity=2)
