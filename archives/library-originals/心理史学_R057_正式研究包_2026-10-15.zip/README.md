# 心理史学 R057 正式研究包

R057重用R056的 Becker/Porter/Centola 真实来源派生64组汇总，研究聚合统计指标的适用边界。主结论不构成新增独立团队验证。

## 完全离线运行（不需外部依赖）

```bash
cd psychohistory_R057
python -m unittest test_r057 -v
python r057_audit.py --trial-csv R056_TRIAL_AGGREGATES_INHERITED.csv --output-json R057_LOCAL_GROUP_AUDIT.json
```

## 如果取得原作者完整CSV

```bash
python r057_audit.py --raw-csv /path/to/ORIGINAL.csv --output-json FULL_REPLAY.json --output-trials FULL_TRIALS.csv
python r057_audit.py --raw-csv /path/to/ORIGINAL.csv --extreme-mode all_finite --output-json SENSITIVITY.json
```

程序默认对原CSV验证Git blob SHA1 `2fc18cefd211727e560b05d60c1289f1f4891969`。不能将匿名汇总模式输出的 `original_bytes_authenticated=false` 改写为 true。

`R057_CONNECTOR_METRICS.json` 保存原作者源在GitHub连接器侧读取后得出的追加指标与不确定性，**并非本地源字节复算输出**。有关未解决的中位数改善计数细节见报告。PESEN v0.1继续冻结。
