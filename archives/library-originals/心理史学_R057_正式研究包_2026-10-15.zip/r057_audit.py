#!/usr/bin/env python3
"""R057: original-source-locked group-level outcome and measurement audit.

Commands:
  python r057_audit.py --trial-csv R056_TRIAL_AGGREGATES_INHERITED.csv
  python r057_audit.py --raw-csv AUTHOR_ORIGINAL.csv

The trial-csv path supports only inherited mean-of-responses group-error data.
The raw-csv path verifies the exact official Git blob bytes and additionally
computes individual error, within-group dispersion, and median error.
No individual network-exposure edges are in the source CSV.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import itertools
import json
import math
import random
import statistics
from collections import defaultdict
from pathlib import Path

ORIGINAL_BLOB = "2fc18cefd211727e560b05d60c1289f1f4891969"
REQUIRED = {"q", "user_id", "party", "response_1", "response_2",
            "response_3", "truth", "set", "network", "pair_id",
            "experiment", "remove_extreme"}
SOURCE_EXPECTED = {1: 4353, 2: 4468}
EXPECTED_VALID_AUTHOR = {1: 4019, 2: 4114}
TRIAL_FIELDS = ["experiment", "set", "pair_id", "party", "network",
                "n", "err1", "err3", "change"]


def sha_git_blob(raw: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(raw)).encode("ascii") + b"\0" + raw).hexdigest()


def read_original(raw: bytes, locked: bool = True):
    blob = sha_git_blob(raw)
    if locked and blob != ORIGINAL_BLOB:
        raise ValueError("Original source blob authentication FAILED: " + blob)
    f = io.StringIO(raw.decode("utf-8-sig"), newline="")
    reader = csv.DictReader(f)
    if not REQUIRED.issubset(set(reader.fieldnames or [])):
        raise ValueError("Missing required original CSV columns")
    rows = list(reader)
    if locked and (len(rows) != 8821 or
                   {e: sum(r["experiment"] == str(e) for r in rows)
                    for e in (1, 2)} != SOURCE_EXPECTED):
        raise ValueError("Invalid original-source sample identity")
    return rows, blob


def numeric(x):
    if x is None or str(x).strip().upper() in ("", "NA", "NAN"):
        return None
    try:
        v = float(x)
    except ValueError:
        return None
    return v if math.isfinite(v) else None


def mean(values):
    if not values:
        raise ValueError("Empty mean")
    return statistics.fmean(values)


def groups_from_source(rows, extreme_mode: str = "author"):
    """Return 64 trial rows with both original and exploratory outcomes.

    extreme_mode 'author' follows the authors' experiment-2 filter;
    extreme_mode 'all_finite' only removes invalid/missing answers.
    """
    if extreme_mode not in ("author", "all_finite"):
        raise ValueError("Unknown extreme policy")
    cells = defaultdict(list)
    valid_count = {1: 0, 2: 0}
    for r in rows:
        try:
            exp = int(r["experiment"])
            pair_id = int(r["pair_id"])
        except (ValueError, TypeError) as exc:
            raise ValueError("Invalid experimental identifiers") from exc
        if exp not in (1, 2):
            raise ValueError("Unknown experiment")
        if r["network"] not in ("Social", "Control") or r["party"] not in ("Dem", "Repub"):
            raise ValueError("Unknown condition or party")
        if exp == 2 and extreme_mode == "author" and r["remove_extreme"] != "":
            continue
        numbers = [numeric(r[f]) for f in ("response_1", "response_2", "response_3", "truth")]
        if any(v is None for v in numbers):
            continue
        if exp == 1 and any(v <= 0 for v in numbers):
            continue
        if numbers[3] == 0:
            continue
        valid_count[exp] += 1
        v = ([math.log(z) for z in numbers] if exp == 1
             else [z / numbers[3] for z in numbers])
        cells[(exp, r["set"], pair_id, r["party"], r["network"], r["q"])].append(v)

    question_by_trial = defaultdict(list)
    for (exp, question_set, pair_id, party, condition, q), a in cells.items():
        truth = a[0][3]
        if any(abs(z[3] - truth) > 1e-10 for z in a):
            raise ValueError("Question truth inconsistent")
        m1, m3 = mean([z[0] for z in a]), mean([z[2] for z in a])
        med1 = statistics.median(z[0] for z in a)
        med3 = statistics.median(z[2] for z in a)
        qresults = {
            "n": len(a),
            "err1": abs(m1 - truth), "err3": abs(m3 - truth),
            "median_err1": abs(med1 - truth), "median_err3": abs(med3 - truth),
            "individual_err1": mean([abs(z[0] - truth) for z in a]),
            "individual_err3": mean([abs(z[2] - truth) for z in a]),
            "dispersion1": mean([abs(z[0] - m1) for z in a]),
            "dispersion3": mean([abs(z[2] - m3) for z in a]),
        }
        question_by_trial[(exp, question_set, pair_id, party, condition)].append(qresults)

    trials = []
    pairs = [("err1", "err3", "change"),
             ("median_err1", "median_err3", "median_change"),
             ("individual_err1", "individual_err3", "individual_change"),
             ("dispersion1", "dispersion3", "dispersion_change")]
    for (exp, question_set, pair_id, party, condition), parts in question_by_trial.items():
        if len(parts) != 4:
            raise ValueError("Trial must have exactly four questions")
        trial = {"experiment": exp, "set": question_set, "pair_id": pair_id,
                 "party": party, "network": condition, "n": sum(z["n"] for z in parts)}
        for first, third, change in pairs:
            trial[first] = mean([z[first] for z in parts])
            trial[third] = mean([z[third] for z in parts])
            trial[change] = trial[third] - trial[first]
        trials.append(trial)
    trials.sort(key=lambda t: (t["experiment"], t["set"], t["party"], t["network"], t["pair_id"]))
    return trials, valid_count


def import_trials(path: Path):
    with path.open(newline="", encoding="utf-8") as f:
        data = list(csv.DictReader(f))
    if len(data) != 64:
        raise ValueError("Expected 64 trial aggregates")
    out = []
    for r in data:
        if not set(TRIAL_FIELDS).issubset(r):
            raise ValueError("Trial fields missing")
        r = dict(r)
        for k in ("experiment", "pair_id", "n"):
            r[k] = int(r[k])
        for k in ("err1", "err3", "change"):
            r[k] = float(r[k])
        if abs(r["err3"] - r["err1"] - r["change"]) > 2e-8:
            raise ValueError("Trial change is inconsistent")
        out.append(r)
    return out


def validate_trials(trials):
    for exp in (1, 2):
        a = [z for z in trials if z["experiment"] == exp]
        if len(a) != 32:
            raise ValueError("Must have 32 independent trials per experiment")
        keys = {(z["set"], z["party"], z["network"], z["pair_id"]) for z in a}
        if len(keys) != 32:
            raise ValueError("Duplicated trial")
        for s in ("A", "B", "C", "D"):
            for party in ("Dem", "Repub"):
                sub = [z for z in a if z["set"] == s and z["party"] == party]
                if len(sub) != 4 or sum(z["network"] == "Social" for z in sub) != 3 or sum(z["network"] == "Control" for z in sub) != 1:
                    raise ValueError("Missing or duplicated condition in stratum")


def summary(trials, metric="change", B=20000, seed=57115):
    if B < 100:
        raise ValueError("At least 100 bootstrap iterations required")
    validate_trials(trials)
    out = {}
    for exp in (1, 2):
        group = [z for z in trials if z["experiment"] == exp]
        if any(metric not in z for z in group):
            raise ValueError("Metric requires original source data: " + metric)
        arms = {k: [z[metric] for z in group if z["network"] == k]
                for k in ("Social", "Control")}
        diffs = []
        strata = []
        for s in ("A", "B", "C", "D"):
            for party in ("Dem", "Repub"):
                subset = [z for z in group if z["set"] == s and z["party"] == party]
                d = mean([z[metric] for z in subset if z["network"] == "Social"]) - next(
                    z[metric] for z in subset if z["network"] == "Control")
                diffs.append(d)
                strata.append({"question_set": s, "party": party, "difference": d})
        obs = mean(diffs)
        rng = random.Random(seed + exp)
        draws = sorted(mean([diffs[rng.randrange(8)] for _ in range(8)]) for _ in range(B))
        loo = [mean([z for j, z in enumerate(diffs) if j != i]) for i in range(8)]
        out[str(exp)] = {
            "metric": metric, "n_trials": 32,
            "social_mean_change": mean(arms["Social"]),
            "control_mean_change": mean(arms["Control"]),
            "difference": obs,
            "social_improved_trials": sum(x < 0 for x in arms["Social"]),
            "control_improved_trials": sum(x < 0 for x in arms["Control"]),
            "favorable_strata": sum(z < 0 for z in diffs),
            "strata": strata,
            "strata_bootstrap95_exploratory": [draws[int(.025 * B)], draws[int(.975 * B) - 1]],
            "leave_one_stratum_out_range": [min(loo), max(loo)],
            "bootstrap_draws": B,
            "note": "Block bootstrap is exploratory. Not an author-preregistered randomization inference."
        }
    return out


def baseline_adjusted_coeff(trials, exp):
    """OLS of trial error CHANGE on social indicator, initial error, seven stratum dummies.

    Returns coefficients only, as exploratory descriptive diagnostics.
    """
    subset = [z for z in trials if z["experiment"] == exp]
    fixed = [("A", "Dem"), ("A", "Repub"), ("B", "Dem"), ("B", "Repub"),
             ("C", "Dem"), ("C", "Repub"), ("D", "Dem")]
    X = []
    Y = []
    for z in subset:
        X.append([1., float(z["network"] == "Social"), float(z["err1"])] +
                 [float((z["set"], z["party"]) == t) for t in fixed])
        Y.append(float(z["change"]))
    k = len(X[0]); C = [[sum(row[i] * row[j] for row in X) for j in range(k)] +
                         [sum(row[i] * Y[t] for t, row in enumerate(X))] for i in range(k)]
    for i in range(k):
        p = max(range(i, k), key=lambda z: abs(C[z][i]))
        if abs(C[p][i]) < 1e-12:
            raise ValueError("Rank-deficient adjustment")
        C[i], C[p] = C[p], C[i]
        f = C[i][i]
        C[i] = [v / f for v in C[i]]
        for j in range(k):
            if j != i:
                z = C[j][i]
                C[j] = [C[j][t] - z * C[i][t] for t in range(k + 1)]
    return {"social_effect_coef": C[1][-1], "initial_error_coef": C[2][-1],
            "n_trials": len(subset),
            "disclaimer": "Exploratory baseline-adjusted coefficient, no causal interpretation without design audit."}


def main():
    p = argparse.ArgumentParser()
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument("--raw-csv", type=Path)
    g.add_argument("--trial-csv", type=Path)
    p.add_argument("--output-json", type=Path)
    p.add_argument("--output-trials", type=Path)
    p.add_argument("--allow-fixture", action="store_true", help="Only for constructed unit tests")
    p.add_argument("--extreme-mode", choices=("author", "all_finite"), default="author",
                   help="Only for --raw-csv. all_finite is an exploratory sensitivity analysis")
    args = p.parse_args()
    if args.raw_csv:
        rows, blob = read_original(args.raw_csv.read_bytes(), locked=not args.allow_fixture)
        trials, valid = groups_from_source(rows, extreme_mode=args.extreme_mode)
        if blob == ORIGINAL_BLOB and args.extreme_mode == "author" and valid != EXPECTED_VALID_AUTHOR:
            raise ValueError("Source selection count unexpected")
        provenance = {"source": str(args.raw_csv), "git_blob": blob,
                      "original_bytes_authenticated": blob == ORIGINAL_BLOB,
                      "valid_rows": valid, "extreme_mode": args.extreme_mode}
        if args.output_trials:
            with args.output_trials.open("w", newline="", encoding="utf-8") as f:
                w = csv.DictWriter(f, fieldnames=list(trials[0]))
                w.writeheader(); w.writerows(trials)
    else:
        if args.extreme_mode != "author":
            p.error("--extreme-mode only valid with --raw-csv")
        trials = import_trials(args.trial_csv)
        provenance = {"source": str(args.trial_csv), "original_bytes_authenticated": False,
                      "basis": "R056 original-source-derived aggregate; median and individual metrics unavailable"}
    metrics = ["change"] if not args.raw_csv else ["change", "median_change", "individual_change", "dispersion_change"]
    report = {"provenance": provenance,
              "metrics": {metric: summary(trials, metric) for metric in metrics},
              "baseline_adjustment": {str(exp): baseline_adjusted_coeff(trials, exp) for exp in (1, 2)}}
    text = json.dumps(report, ensure_ascii=False, indent=2)
    if args.output_json:
        args.output_json.write_text(text + "\n", encoding="utf-8")
    print(text)


if __name__ == "__main__":
    main()
