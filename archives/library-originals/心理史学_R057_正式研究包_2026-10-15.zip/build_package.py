#!/usr/bin/env python3
"""Deterministic ZIP of the R057 research outputs, with SHA256 of packaged files."""
import hashlib
import json
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OUTPUT = ROOT / '心理史学_R057_正式研究包_2026-10-15.zip'
FILES = [
    'README.md', 'PROJECT_STATE_R057.md', 'R057_REPORT.md',
    'R058_RESEARCH_GATE.md', 'SOURCE_LEDGER.json',
    'R057_CONNECTOR_METRICS.json', 'R057_LOCAL_GROUP_AUDIT.json',
    'R056_TRIAL_AGGREGATES_INHERITED.csv', 'r057_audit.py', 'test_r057.py',
    'TEST_OUTPUT.txt', 'build_package.py'
]
assert all((HERE / path).is_file() for path in FILES)
manifest = {'round': 'R057', 'created': '2026-10-15', 'verified_original_bytes_locally': False,
            'files': {p: {'sha256': hashlib.sha256((HERE/p).read_bytes()).hexdigest(),
                           'bytes': (HERE/p).stat().st_size} for p in FILES}}
(HERE / 'MANIFEST.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
with zipfile.ZipFile(OUTPUT, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in FILES + ['MANIFEST.json']:
        z.write(HERE / p, arcname=p)
with zipfile.ZipFile(OUTPUT) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(FILES) + 1
    for path, x in manifest['files'].items():
        assert hashlib.sha256(z.read(path)).hexdigest() == x['sha256']
print(f'PACKAGE_OK={OUTPUT}, files={len(FILES)+1}, bytes={OUTPUT.stat().st_size}')
