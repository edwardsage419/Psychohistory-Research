import math
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from r033_analysis import *

class TestR033(unittest.TestCase):
    def test_validation(self): validate()
    def test_groups(self): self.assertEqual(set(STUDY_2019),{'positive','negative','control'})
    def test_2019_counts(self): self.assertEqual(sum(v['days'] for v in STUDY_2019.values()),77)
    def test_2019_drinks(self): self.assertEqual(sum(v['drinks'] for v in STUDY_2019.values()),11346)
    def test_2019_straws(self): self.assertEqual(sum(v['straws'] for v in STUDY_2019.values()),1597)
    def test_pilot_days(self):self.assertEqual(PILOT_2018['valid_days']+PILOT_2018['lost_days'],72)
    def test_period_count(self):self.assertEqual(FULL_2019['scheduled_days']//3,29)
    def test_correct_pooled_control(self):self.assertAlmostEqual(618/3847,0.16064465817520146)
    def test_control_day_vs_pooled_distinct(self):self.assertGreater(.172-618/3847,.011)
    def test_welch_anova(self):
        r=welch_anova(STUDY_2019);self.assertAlmostEqual(r['F'],5.823864490194383,places=10)
    def test_df(self):self.assertAlmostEqual(welch_anova(STUDY_2019)['df2'],45.38453249105411,places=9)
    def test_pair_effect(self):
        p=welch_pair(STUDY_2019['positive'],STUDY_2019['control']);self.assertAlmostEqual(p['difference'],-.061)
    def test_pair_p(self):
        p=welch_pair(STUDY_2019['positive'],STUDY_2019['control']);self.assertTrue(.004<p['p_two_sided']<.007)
    def test_deff_zero(self):
        p=welch_pair(STUDY_2019['positive'],STUDY_2019['control']);self.assertAlmostEqual(dependency_sensitivity(p,0)['deff_assumed'],1)
    def test_deff_half(self):
        p=welch_pair(STUDY_2019['positive'],STUDY_2019['control']);self.assertAlmostEqual(dependency_sensitivity(p,.5)['deff_assumed'],2)
    def test_increasing_robust_se_effect(self):
        p=welch_pair(STUDY_2019['positive'],STUDY_2019['control']);q0=dependency_sensitivity(p,0);q1=dependency_sensitivity(p,1)
        self.assertGreater(q1['p_with_df_proxy'],q0['p_with_df_proxy'])
    def test_invalid_rho(self):
        p=welch_pair(STUDY_2019['positive'],STUDY_2019['control']);self.assertRaises(ValueError,dependency_sensitivity,p,-.1)
    def test_has_no_false_raw_claim(self):self.assertIn('NO_ORIGINAL_DAILY_WORKBOOK',run()['level'])
    def test_source_metadata(self):self.assertEqual(run()['source_locks']['figshare_file_id'],'31324114')

if __name__=='__main__':unittest.main()
