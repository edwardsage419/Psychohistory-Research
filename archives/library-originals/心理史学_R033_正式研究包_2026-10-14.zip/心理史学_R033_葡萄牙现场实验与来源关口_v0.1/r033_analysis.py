#!/usr/bin/env python3
"""R033: paper-summary audit for Salazar et al. (2021/2024), not daily-data replication.

Independent re-derivation from published per-condition n, mean and SD. Never treats
sales or straws as separately randomized visitors. Three-day message assignments
are the experimental randomization unit. Dependency scenarios are hypothetical,
not estimated ICC values. Requires scipy for Welch distributions.
"""
import argparse
import json
import math
from pathlib import Path
from scipy.stats import f, t

STUDY_2019 = {
 'positive': {'days':25,'drinks':3888,'straws':431,'daily_ratio_mean':.111,'daily_ratio_sd':.045},
 'negative': {'days':26,'drinks':3611,'straws':548,'daily_ratio_mean':.152,'daily_ratio_sd':.076},
 'control': {'days':26,'drinks':3847,'straws':618,'daily_ratio_mean':.172,'daily_ratio_sd':.094},
}
PILOT_2018={'scheduled_days':72,'valid_days':65,'lost_days':7,'drinks':15279,'straws':4684}
FULL_2019={'scheduled_days':87,'valid_days':77,'lost_days':10,'drinks':11346,'straws':1597,'assignment_days':3}


def validate():
    a=STUDY_2019
    assert set(a)=={'positive','negative','control'}
    assert sum(v['days'] for v in a.values())==FULL_2019['valid_days']
    assert sum(v['drinks'] for v in a.values())==FULL_2019['drinks']
    assert sum(v['straws'] for v in a.values())==FULL_2019['straws']
    assert FULL_2019['valid_days']+FULL_2019['lost_days']==FULL_2019['scheduled_days']
    assert FULL_2019['scheduled_days']%FULL_2019['assignment_days']==0
    for item in a.values():
        assert 0 <= item['straws'] <= item['drinks']
        assert 0 < item['daily_ratio_sd'] < 1


def welch_anova(groups):
    """Welch summary-statistics ANOVA, standard unequal-variance formula."""
    n=[v['days'] for v in groups.values()]
    mu=[v['daily_ratio_mean'] for v in groups.values()]
    sd=[v['daily_ratio_sd'] for v in groups.values()]
    k=len(n)
    w=[ni/si**2 for ni,si in zip(n,sd)]
    sw=sum(w)
    avg=sum(a*b for a,b in zip(w,mu))/sw
    lam=sum((1-wi/sw)**2/(ni-1) for wi,ni in zip(w,n))
    numerator=sum(wi*(m-avg)**2 for wi,m in zip(w,mu))/(k-1)
    df1=k-1
    df2=(k*k-1)/(3*lam)
    val=numerator/(1+2*(k-2)*lam/(k*k-1))
    return {'F':val,'df1':df1,'df2':df2,'p':float(f.sf(val,df1,df2)),
            'note':'Approximation uses published daily means and SD rounded to 3 decimals'}


def welch_pair(x,y):
    delta=x['daily_ratio_mean']-y['daily_ratio_mean']
    a=x['daily_ratio_sd']**2/x['days']; b=y['daily_ratio_sd']**2/y['days']
    se=math.sqrt(a+b)
    df=(a+b)**2/(a*a/(x['days']-1)+b*b/(y['days']-1))
    stat=delta/se
    return {'difference':delta,'se':se,'t':stat,'df':df,
            'p_two_sided':float(2*t.sf(abs(stat),df)),
            'ci95':[delta-float(t.ppf(.975,df))*se,delta+float(t.ppf(.975,df))*se]}


def dependency_sensitivity(pair, rho, m=3, df_proxy=17):
    """Illustrative compound symmetry design effect; not actual cluster analysis."""
    if not 0 <= rho <= 1 or m<1 or df_proxy<1:
        raise ValueError('rho or design settings outside valid range')
    deff=1+(m-1)*rho
    stat=pair['t']/math.sqrt(deff)
    return {'rho_assumed':rho,'deff_assumed':deff,'t_illustrative':stat,
            'p_with_df_proxy':float(2*t.sf(abs(stat),df_proxy))}


def run():
    validate()
    a=STUDY_2019
    primary=welch_pair(a['positive'],a['control'])
    ratios={key:{'per_day_mean':v['daily_ratio_mean'],
                 'pooled_count_ratio':v['straws']/v['drinks'],
                 'ratio_definition_gap':v['daily_ratio_mean']-v['straws']/v['drinks'],
                 'n_days':v['days'],'n_drinks':v['drinks'],'n_straws':v['straws']}
            for key,v in a.items()}
    crit=float(t.ppf(.975,17))
    rho_crit=( (abs(primary['t'])/crit)**2 - 1)/2
    return {'study':'R033 Portuguese Zoomarine paper summary audit',
            'level':'PUBLISHED_AGGREGATE_RECALCULATION_ONLY_NO_ORIGINAL_DAILY_WORKBOOK',
            'published_summary_used':'2024 corrected Table 3, 2021 paper daily means and SD',
            'study_2018_pilot':PILOT_2018,
            'study_2019_full':{**FULL_2019,'scheduled_randomization_periods':29},
            'weighted_vs_unweighted_ratios':ratios,
            'welch_anova_from_rounded_stats':welch_anova(a),
            'positive_vs_control_day_level_welch':primary,
            'positive_vs_control_pooled_rate_difference':ratios['positive']['pooled_count_ratio']-ratios['control']['pooled_count_ratio'],
            'hypothetical_dependency':{'model':'equicorrelated three-day assigned periods, group design effect 1+2rho; df=17 illustrative only',
                'examples':[dependency_sensitivity(primary,rho) for rho in [0,0.05,.1,.2,.3,.5,1]],
                'rho_where_illustrative_two_sided_p_crosses_0_05':rho_crit},
            'lost_days_share_2019':10/87,
            'source_locks':{'doi_paper':'10.1371/journal.pone.0261734',
                            'doi_correction':'10.1371/journal.pone.0303709',
                            'doi_data':'10.6084/m9.figshare.15134754.v1',
                            'figshare_file_id':'31324114',
                            'figshare_file_name':'StrawStudyData_FigShare.xlsx'},
            'blocked_checks':['2021 and 2024 original daily workbook bytes not obtained',
                'random assignment by three-day period and sequences unverified',
                'operator error 10 excluded days unknown by period and exact time',
                'no longitudinal demand or individual psychological measures',
                'pre-registration text for R032 Credamo and MTurk not retrieved']}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,default=Path(__file__).parent/'R033_RESULT.json')
    a=p.parse_args()
    result=run()
    a.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('R033_RESULTS_CREATED',a.output)
    print('SUMMARY_ONLY_REPLICATION: daily workbook bytes not obtained')
if __name__=='__main__':main()
