# 心理史学 R033 正式研究包 v0.1

*日期：2026-10-14。内容性质：论文汇总数独立统计复算＋实验设计与2024勘误审计。*

## 文件

- `R033_EVIDENCE_AUDIT.md`：来源、随机化时段、校正数据、两种比率估计对象、实验识别与局限。
- `SOURCE_ACCESS_LEDGER.json`：来源可达性、可证实内容及原始数据不可达声明。
- `r033_analysis.py`：以论文2024纠正后公开汇总值重算Welch ANOVA、组对比与**假设**时段相关性敏感性。依赖`scipy`。
- `R033_RESULT.json`：脚本输出。绝无模拟个体/每日数据冒充实证。
- `tests/test_r033.py`：19项构造/代数软件测试。
- `R034_RESEARCH_GATE.md`：下一轮来源和随机化级复现门槛。

运行：

```bash
python -m pip install scipy
python r033_analysis.py
python -m unittest discover -s tests -v
```

原始Excel公开地址：https://figshare.com/articles/dataset/Straw_Experiment_Dataset/15134754 。下载需要实际可联网环境，当前研究包不包含原始Excel、不声称读过每日级数据；也没有获取2018/2019随机化原始安排或R032 OSF正文。项目不修改PESEN v0.1，不向外部仓库写入。
