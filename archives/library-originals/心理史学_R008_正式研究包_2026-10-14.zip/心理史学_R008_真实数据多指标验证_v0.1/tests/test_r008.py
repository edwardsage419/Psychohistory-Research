import math, sys, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from r008_analysis import valid, question_metrics, assess_missingness, analyze

class TestR008(unittest.TestCase):
    def row(self, **kw):
        d=dict(experiment='1',network='Social',party='Dem',set='A',pair_id='1',q='Taxes',
               truth='10',response_1='20',response_2='15',response_3='10')
        d.update(kw)
        return d
    def test_invalid_and_extreme(self):
        self.assertTrue(valid(self.row()))
        self.assertFalse(valid(self.row(response_1='NA')))
        self.assertFalse(valid(self.row(response_2='0')))
        self.assertFalse(valid(self.row(truth='-5')))
        self.assertTrue(valid(self.row(response_1='100'),True))
        self.assertFalse(valid(self.row(response_1='101'),True))
    def test_question_metrics(self):
        a=[self.row(response_1='20',response_3='10'),self.row(response_1='5',response_3='10')]
        x=question_metrics(a)
        self.assertAlmostEqual(x['grp1'],0.0)
        self.assertAlmostEqual(x['grp3'],0.0)
        self.assertAlmostEqual(x['ind1'],math.log(2))
        self.assertAlmostEqual(x['ind3'],0.0)
        self.assertGreater(x['sd1'],0.0)
        self.assertEqual(x['sd3'],0.0)
    def test_missingness(self):
        d=[self.row(),self.row(response_2='NA'),self.row(network='Control'),self.row(network='Control',response_1='NA')]
        x=assess_missingness(d)
        self.assertEqual(x['Social']['retained'],1)
        self.assertEqual(x['Control']['excluded'],1)
        self.assertEqual(x['Social']['excluded_with_valid_first_count'],1)
    def test_full_fixture(self):
        # eight strata, each with three social trial groups and one control; four questions per trial.
        data=[]
        for party in ('Dem','Repub'):
            for s in 'ABCD':
                for condition in ('Control','Social'):
                    for j in (['1'] if condition=='Control' else ['1','2','3']):
                        for q in ('q1','q2','q3','q4'):
                            data.append(self.row(party=party,set=s,network=condition,pair_id=j,q=q,
                                                 response_3=('10' if condition=='Social' else '20')))
        d=analyze(data)
        self.assertEqual(d['trial_count'],32)
        self.assertEqual(d['rows_retained'],128)
        self.assertAlmostEqual(d['metrics']['grp']['contrast'],-math.log(2))
        self.assertAlmostEqual(d['metrics']['ind']['contrast'],-math.log(2))
        self.assertAlmostEqual(d['metrics']['med']['contrast'],-math.log(2))
        self.assertAlmostEqual(d['metrics']['sd']['contrast'],0.0)

if __name__=='__main__':unittest.main()
