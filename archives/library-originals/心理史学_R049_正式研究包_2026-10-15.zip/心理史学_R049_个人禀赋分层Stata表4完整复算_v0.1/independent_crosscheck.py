"""An independent second backend for R049's quasi-demeaned regression step."""
import json, pathlib
import numpy as np
import statsmodels.api as sm
import r049_analysis as a
import r047_analysis as base
ROOT=pathlib.Path(__file__).resolve().parent

def crosscheck():
    panel=base.decode_panel();r=base.longitudinal_design(panel);types=a.derived_types();res={}
    for t in ('current','previous'):
        for st in ('B','A'):
            for rc in ('raw','verified'):
                key=f'{t}_{st}_{rc}'
                d=a.design(r,types,t,rc,st);z=a.gls_estimate(d,return_internal=True)['internal']
                fit=sm.OLS(z['yT'],z['xT']).fit(cov_type='cluster',cov_kwds={'groups':z['g'],'use_correction':True})
                e1=float(max(abs(fit.params-z['beta'])));e2=float(max(abs(fit.bse-z['se'])))
                if max(e1,e2)>1e-8:raise ValueError('Statsmodels independent method mismatch '+key)
                res[key]={'max_beta_abs_difference':e1,'max_cluster_se_abs_difference':e2,'n':len(d)}
    return {'backend':'statsmodels OLS on GLS transformed arrays, independent covariance estimator',
            'all_eight_specifications_passed':True,'models':res,'original_stata_binary_examined':False}

if __name__=='__main__':
    r=crosscheck();(ROOT/'R049_CROSSCHECK.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');
    print('8 R049 GLS specs statsmodels crosschecked; max error',max(max(v['max_beta_abs_difference'],v['max_cluster_se_abs_difference']) for v in r['models'].values()))
