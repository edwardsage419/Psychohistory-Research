import copy,json,pathlib,sys
import numpy as np, pytest
import statsmodels.api as sm
BASE=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE))
import r049_analysis as a, r047_analysis as up, r048_analysis as older
RESULTS=json.loads((BASE/'R049_RESULTS.json').read_text())
TYPES=a.derived_types()
ROWS=up.longitudinal_design(up.decode_panel())

@pytest.mark.parametrize('arm,cnt',[(40,16),(50,32),(60,16)])
def test_endowment_counts(arm,cnt):assert sum(x==arm for x in TYPES.values())==cnt

def test_64_subjects():assert len(TYPES)==64 and set(TYPES)==set(range(64))

def test_source_git_sha():assert json.loads(a.MAP.read_text())['source_git_blob_sha1']==up.SOURCE_SHA

@pytest.mark.parametrize('st,n', [('B',451),('A',414)])
def test_published_sample(st,n):
    m=RESULTS['published_precision_matches'][st]
    assert m['n_matches'] and m['reproduced']['n']==n

@pytest.mark.parametrize('st,i',[(s,i) for s in 'BA' for i in range(5)])
def test_all_ten_coefficients_match(st,i):
    m=RESULTS['published_precision_matches'][st]
    assert m['coefficients_at_paper_precision'][a.COLUMNS[i]]

@pytest.mark.parametrize('st,i',[(s,i) for s in 'BA' for i in range(5)])
def test_all_ten_standard_errors_match(st,i):
    m=RESULTS['published_precision_matches'][st]
    assert m['standard_errors_at_paper_precision'][a.COLUMNS[i]]

@pytest.mark.parametrize('st',list('BA'))
def test_variances_positive(st):
    r=RESULTS['models'][f'current_{st}_raw']
    assert r['variance_components']['sigma_u2']>0 and r['variance_components']['sigma_e2']>0
    assert r['group_clusters']==16 and r['session_clusters']==4

@pytest.mark.parametrize('time,st,receipt',[(t,s,r) for t in ('current','previous') for s in 'BA' for r in ('raw','verified')])
def test_all_eight_historical_and_corrected_models(time,st,receipt):
    d=a.design(ROWS,TYPES,time,receipt,st);now=a.gls_estimate(d)
    expected=RESULTS['models'][f'{time}_{st}_{receipt}']
    assert now['n']==expected['n']
    for k in a.COLUMNS:
        assert abs(now['coefficients'][k]-expected['coefficients'][k])<1e-8
        assert abs(now['cluster_standard_errors'][k]-expected['cluster_standard_errors'][k])<1e-8

@pytest.mark.parametrize('st',list('BA'))
def test_independent_statsmodels_current(st):
    d=a.design(ROWS,TYPES,'current','raw',st);r=a.gls_estimate(d,return_internal=True)['internal']
    fit=sm.OLS(r['yT'],r['xT']).fit(cov_type='cluster',cov_kwds={'groups':r['g'],'use_correction':True})
    np.testing.assert_allclose(fit.params,r['beta'],atol=1e-9,rtol=0)
    np.testing.assert_allclose(fit.bse,r['se'],atol=1e-9,rtol=0)

@pytest.mark.parametrize('st',list('BA'))
def test_robustness_receipt_corrected_changes_equal_estimate(st):
    q=RESULTS['models'];a1=q[f'current_{st}_raw']['coefficients']['sanction_equal_50'];a2=q[f'current_{st}_verified']['coefficients']['sanction_equal_50']
    assert abs(a1-a2)>.005

@pytest.mark.parametrize('st',list('BA'))
def test_sa_and_default_differ(st):
    q=RESULTS['models'][f'current_{st}_raw']['coefficients']
    s=RESULTS['robustness'][st]['sa_option']['coefficients']
    assert max(abs(q[k]-s[k]) for k in a.COLUMNS)>.001

@pytest.mark.parametrize('st',list('BA'))
def test_leave_one_group_effect(st):
    base=RESULTS['models'][f'current_{st}_raw']['coefficients']['sanction_high_60']
    r=RESULTS['robustness'][st]['leave_one_group']
    assert len(r)==16 and any(abs(x['coefficients']['sanction_high_60']-base)>.01 for x in r.values())

@pytest.mark.parametrize('st',list('BA'))
def test_leave_one_session(st):assert len(RESULTS['robustness'][st]['leave_one_session'])==4

@pytest.mark.parametrize('st',list('BA'))
def test_original_model_1_3_is_not_rewritten(st):
    # R049 enriches types for Table 4 columns (2,4), does not silently replace (1,3)
    p=older.estimate(up.prepare(ROWS,'current','raw',st))
    assert p['n']==RESULTS['models'][f'current_{st}_raw']['n']

@pytest.mark.parametrize('st',list('BA'))
def test_known_temporal_misalignment(st):
    assert RESULTS['models'][f'current_{st}_raw']['n']!=RESULTS['models'][f'previous_{st}_raw']['n']

def test_no_new_study_claim():
    q=RESULTS['provenance']
    assert q['new_independent_experimental_sample'] is False
    assert q['native_stata_software_executed'] is False
    assert q['local_original_csv_bytes_read'] is False
    assert q['stata_original_dta_bytes_read'] is False

def test_map_wrong_hash_rejected(tmp_path):
    data=json.loads(a.MAP.read_text());data['source_git_blob_sha1']='0'*40
    p=tmp_path/'m.json';p.write_text(json.dumps(data))
    with pytest.raises(ValueError,match='SHA'):a.derived_types(p)

def test_map_wrong_endowment_rejected(tmp_path):
    data=json.loads(a.MAP.read_text());data['endowment_values_by_group_order'][1][0]=50
    p=tmp_path/'m.json';p.write_text(json.dumps(data))
    with pytest.raises(ValueError,match='Invalid unequal'):a.derived_types(p)

def test_map_wrong_equal_rejected(tmp_path):
    data=json.loads(a.MAP.read_text());data['endowment_values_by_group_order'][12][0]=60
    p=tmp_path/'m.json';p.write_text(json.dumps(data))
    with pytest.raises(ValueError,match='Invalid equal'):a.derived_types(p)

def test_map_not_export_id_rejected(tmp_path):
    data=json.loads(a.MAP.read_text());data['original_id_exported']=True
    p=tmp_path/'m.json';p.write_text(json.dumps(data))
    with pytest.raises(ValueError,match='privacy'):a.derived_types(p)

def test_full_csv_fingerprint_gate_rejects_fake(tmp_path):
    p=tmp_path/'data.csv';p.write_text('spoof author data')
    with pytest.raises(ValueError,match='fingerprint'):a.verify_endowment_map_original_csv(p)

def test_dta_fingerprint_gate_rejects_fake():
    assert up.DTA_SHA!='0'*40 and len(up.DTA_SHA)==40

def test_source_panel_alignment_types_all_groups():
    panel=up.decode_panel()
    assert all((z['arm']=='01')==(TYPES[z['person']] in (40,60)) for z in panel)
    assert all((z['arm']=='11')==(TYPES[z['person']]==50) for z in panel)

def test_invalid_predictor_factor_alignment_rejected():
    c=dict(TYPES);c[0]=50
    with pytest.raises(ValueError,match='conflicts'):a.design(ROWS,c,'current','raw','B')

@pytest.mark.parametrize('bad',[("current","raw","unknown"),("nope","raw","B"),("current","fake","B")])
def test_invalid_spec_rejected(bad):
    with pytest.raises(ValueError):a.design(ROWS,TYPES,*bad)

@pytest.mark.parametrize('meth,cluster', [('bad','group'),('default','bad')])
def test_bad_method_and_cluster(meth,cluster):
    with pytest.raises(ValueError):a.gls_estimate(a.design(ROWS,TYPES),cluster=cluster,method=meth)

def test_rank_deficiency_rejected():
    data=a.design(ROWS,TYPES)
    broken=[(p,g,s,y,[x[0],x[1],x[2],x[2],x[2]]) for p,g,s,y,x in data]
    with pytest.raises(ValueError,match='rank'):a.gls_estimate(broken)

def test_broken_factor_levels_rejected():
    d=a.design(ROWS,TYPES)
    data=[(p,g,s,y,[x[0],x[1],x[2],x[3],np.nan]) for p,g,s,y,x in d]
    with pytest.raises(ValueError,match='rank'):a.gls_estimate(data)

def test_ledger_has_no_binary_claim():
    assert RESULTS['provenance']['stata_original_dta_bytes_read'] is False
