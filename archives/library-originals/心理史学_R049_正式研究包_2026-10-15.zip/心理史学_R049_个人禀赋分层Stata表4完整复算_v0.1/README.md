# R049 心理史学正式研究包

主题：新增匿名初始禀赋映射，按Stata默认GLS重建De Geest/Kingsley(2021)表4(2)(4)，继承R048表4(1)(3)。

核心文件：`R049_EVIDENCE_AUDIT.md`、`R049_RESULTS.json`、`R049_EXECUTIVE_RESULTS.json`、`R049_PUBLISHED_COMPARE.csv`、`R049_FIELD_SENSITIVITY.csv`、`R049_ENDOWMENT_SOURCE_MAP.json`、`R049_SOURCE_LEDGER.json`、`R049_CROSSCHECK.json`、`r049_analysis.py`、`tests/test_r049.py`、`R050_RESEARCH_GATE.md`、`MASTER_CONTROLLER_v4.0.md`。

运行：`pip install numpy scipy statsmodels pytest`; `python r049_analysis.py`; `python independent_crosscheck.py`; `pytest -q tests/test_r049.py`。

`r047_analysis.py`、`r048_analysis.py`、`panel_derivative.b64.txt`为合法复算依赖，随包附上，未对上游实现作任何修改。无原始参与者身份、无原作者CSV或Stata DTA字节。来源哈希按Git规范`sha1("blob <size>\0" + contents)`验收。

**所有四项模型达到发表印刷精度；不代表原生Stata、完整来源二进制或因果机制验证。PESEN v0.1冻结。**
