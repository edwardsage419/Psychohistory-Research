#!/usr/bin/env python3
"""R049 complete published-table numerical reconstruction from source derivatives.

Frozen provenance: De Geest & Kingsley (2021), author repo `lrdegeest/InequalityCPR`,
`data/data.csv` Git blob SHA1 73c02176bc9e060af987149594a85f9f7b591230.
The individual token map is an anonymous derived variable exported after GitHub connector
full original CSV reading and independently aligned with R047 packed subject order.
NOT an original Stata binary read, native Stata run, or randomized punishment analysis.
"""
from __future__ import annotations
import argparse, hashlib, json, pathlib
import numpy as np
from scipy.stats import chi2
import r047_analysis as upstream
import r048_analysis as old

ROOT=pathlib.Path(__file__).resolve().parent
MAP=ROOT/'R049_ENDOWMENT_SOURCE_MAP.json'
COLUMNS=('constant','deviation_current','sanction_equal_50','sanction_low_40','sanction_high_60')
PUBLISHED={
    'B':{'model':2,'n':451,'coef':[3.127,-.852,-.064,-.045,-.160],'se':[1.05,.12,.01,.01,.04]},
    'A':{'model':4,'n':414,'coef':[-2.593,-1.175,.001,.438,-.482],'se':[.92,.13,.04,.28,.08]},
}

def verify_endowment_map_original_csv(path, mapping_path=MAP):
    """Future gate: independently match 64 local token types to verified source CSV bytes."""
    import csv
    raw=pathlib.Path(path).read_bytes()
    if upstream.git_blob_sha(raw)!=upstream.SOURCE_SHA:
        raise ValueError('Author CSV Git blob source fingerprint mismatch')
    original=list(csv.DictReader(raw.decode('utf-8-sig').splitlines()))
    original=[z for z in original if z.get('ProfileID') and z.get('RoundID')]
    if len(original)!=2048:raise ValueError('Invalid number of valid author CSV records')
    bygroup={}
    for z in original:
        if z['FF']!='1':continue
        name=z['Homo']+z['FF']+'_'+z['Session']+'_'+z['GameID']
        bygroup.setdefault(name,{}).setdefault(z['ProfileID'],set()).add(int(z['Token']))
    local=derived_types(mapping_path)
    for i,name in enumerate(upstream.GROUP_NAMES):
        if name not in bygroup:raise ValueError('Missing original source group '+name)
        participants=sorted(bygroup[name].items())
        if len(participants)!=4:raise ValueError('Wrong count of original group participants')
        for j,(original_id,values) in enumerate(participants):
            if len(values)!=1 or next(iter(values))!=local[i*4+j]:
                raise ValueError('Original source endowment/person alignment mismatch')
    return {'original_csv_git_blob_verified':True,'participants_derived':64,
            'groups':len(upstream.GROUP_NAMES),'participant_identifiers_exported':False}


def derived_types(mapping_path=MAP):
    meta=json.loads(pathlib.Path(mapping_path).read_text())
    if meta.get('source_git_blob_sha1')!=upstream.SOURCE_SHA:
        raise ValueError('Source Git blob SHA mismatch for endowment map')
    if meta.get('original_id_exported') is not False or meta.get('source_binary_dta_verified') is not False:
        raise ValueError('Map privacy or binary provenance flags inconsistent')
    a=meta.get('endowment_values_by_group_order')
    if not isinstance(a,list) or len(a)!=len(upstream.GROUP_NAMES) or any(not isinstance(g,list) or len(g)!=4 for g in a):
        raise ValueError('One four-person endowment map required for each source group')
    for i,(group,vals) in enumerate(zip(upstream.GROUP_NAMES,a)):
        if group.startswith('01'):
            if sorted(vals)!=[40,40,60,60]:raise ValueError(f'Invalid unequal endowments group {i}')
        elif group.startswith('11'):
            if vals!=[50,50,50,50]:raise ValueError(f'Invalid equal endowments group {i}')
        else:raise ValueError('Unexpected experimental group')
    return {i*4+j:val for i,grp in enumerate(a) for j,val in enumerate(grp)}


def design(rows,types,timing='current',receipt='raw',stratum='B'):
    if timing not in ('current','previous') or receipt not in ('raw','verified') or stratum not in ('B','A'):
        raise ValueError('Invalid model specification')
    out=[]
    for z in rows:
        d=z['dev_'+timing]
        if (stratum=='B' and d<=0) or (stratum=='A' and d>=0):continue
        if z['person'] not in types:raise ValueError('Missing participant type')
        token=types[z['person']]
        if (z['arm']=='01')!=(token in (40,60)) or (z['arm']=='11')!=(token==50):
            raise ValueError('Participant endowment conflicts with group treatment')
        r=float(z[receipt]);x=[1.,float(d),r if token==50 else 0.,r if token==40 else 0.,r if token==60 else 0.]
        out.append((z['person'],z['group'],z['session'],float(z['y']),x))
    if len(out)<20 or len({r[0] for r in out})<5:raise ValueError('Too few observations')
    return out


def gls_estimate(data,cluster='group',method='default',return_internal=False):
    if cluster not in ('group','session','person'):raise ValueError('Invalid cluster label')
    if method not in ('default','sa'):raise ValueError('Invalid GLS variance component method')
    X=np.array([z[4] for z in data],dtype=float);y=np.array([z[3] for z in data],dtype=float)
    people=np.array([z[0] for z in data]);grp=np.array([z[1] for z in data]);sessions=np.array([z[2] for z in data]);
    if X.ndim!=2 or X.shape[1]!=5 or not np.isfinite(X).all() or not np.isfinite(y).all():
        raise ValueError('Invalid rank, size or finite design')
    if np.linalg.matrix_rank(X)!=5:raise ValueError('Invalid rank, size or finite design')
    if not np.allclose(X[:,0],1):raise ValueError('Intercept omitted')
    vc=old.variance_components(X,y,people,method=method)
    qt=vc['theta'][vc['people_idx']];xT=X-qt[:,None]*vc['xmeans'][vc['people_idx']];yT=y-qt*vc['ymeans'][vc['people_idx']]
    inv=np.linalg.inv(xT.T@xT);beta=inv@(xT.T@yT);eps=yT-xT@beta
    groups={'group':grp,'session':sessions,'person':people}[cluster];unique=np.unique(groups)
    if len(unique)<3:raise ValueError('Insufficient clusters')
    meat=np.zeros((5,5))
    for label in unique:
        u=xT[groups==label].T@eps[groups==label];meat+=np.outer(u,u)
    dfc=len(unique)/(len(unique)-1)*(len(y)-1)/(len(y)-X.shape[1]);cov=inv@meat@inv*dfc
    se=np.sqrt(np.diag(cov));res={
        'n':int(len(y)), 'people':int(len(np.unique(people))),'group_clusters':int(len(np.unique(grp))),
        'session_clusters':int(len(np.unique(sessions))),'method':method,'cluster':cluster,
        'coefficients':dict(zip(COLUMNS,[float(b) for b in beta])),
        'cluster_standard_errors':dict(zip(COLUMNS,[float(v) for v in se])),
        'variance_components':{k:float(vc[k]) for k in ('sigma_e2','sigma_u2','harmonic_nrounds')},
        'cluster_variance_correction':float(dfc),
        'estimate_numerically_author_software':False,
    }
    if return_internal:res['internal']={'xT':xT,'yT':yT,'g':grp,'beta':beta,'se':se,'cov':cov}
    return res


def full_results():
    panel=upstream.decode_panel();rows=upstream.longitudinal_design(panel);types=derived_types()
    if len(panel)!=1024 or len(rows)!=896 or len(types)!=64:raise ValueError('Existing source panel shape mismatch')
    result={'research_round':'R049','date':'2026-10-15','provenance':{
        'csv_git_blob_sha':upstream.SOURCE_SHA,'endowment_map_from_full_csv_connector':True,
        'local_original_csv_bytes_read':False,'stata_original_dta_bytes_read':False,
        'native_stata_software_executed':False,'new_independent_experimental_sample':False,
        'same_experimental_subjects_R043_R048':True},'quality':{
        'all_punishment_persons':len(types),'equal_endowment':sum(t==50 for t in types.values()),
        'low_endowment':sum(t==40 for t in types.values()),'high_endowment':sum(t==60 for t in types.values()),
        'transitions':len(rows),'original_vs_bookkeeping_received_bad_cells':sum(x['raw']!=x['verified'] for x in panel if x['t']>=2)
    },'models':{},'published_precision_matches':{},'robustness':{}}
    for t in ('current','previous'):
        for st in ('B','A'):
            for p in ('raw','verified'):
                key=f'{t}_{st}_{p}';d=design(rows,types,t,p,st);q=gls_estimate(d);result['models'][key]=q
                if t=='current' and p=='raw':
                    paper=PUBLISHED[st];result['published_precision_matches'][st]={
                        'model_number':paper['model'],'n_matches':q['n']==paper['n'],
                        'coefficients_at_paper_precision':{k:round(q['coefficients'][k],3)==v for k,v in zip(COLUMNS,paper['coef'])},
                        'standard_errors_at_paper_precision':{k:round(q['cluster_standard_errors'][k],2)==v for k,v in zip(COLUMNS,paper['se'])},
                        'reproduced':q,'paper':paper}
    for st in ('B','A'):
        d=design(rows,types,'current','raw',st)
        r={'default_group':gls_estimate(d),'sa_option':gls_estimate(d,method='sa'),
           'session_cluster_diagnostic_no_valid_p':gls_estimate(d,cluster='session'),
           'leave_one_group':{},'leave_one_session':{}}
        for gr in sorted({x[1] for x in d}):
            filt=[x for x in d if x[1]!=gr]
            r['leave_one_group'][gr]=gls_estimate(filt)
        for sess in sorted({x[2] for x in d}):
            filt=[x for x in d if x[2]!=sess]
            r['leave_one_session'][str(sess)]=gls_estimate(filt)
        result['robustness'][st]=r
    return result

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--audit-original-csv')
    ap.add_argument('--audit-original-dta')
    ap.add_argument('--output',default='R049_RESULTS.json')
    args=ap.parse_args()
    if args.audit_original_csv:
        print(upstream.compare_original_source(args.audit_original_csv))
        print(verify_endowment_map_original_csv(args.audit_original_csv))
    if args.audit_original_dta:
        b=pathlib.Path(args.audit_original_dta).read_bytes()
        if upstream.git_blob_sha(b)!=upstream.DTA_SHA:raise ValueError('Unverified original DTA Git blob checksum')
        import pandas as pd
        df=pd.read_stata(args.audit_original_dta,convert_categoricals=False)
        print('Verified public original Stata binary',len(df),'rows')
    r=full_results();(ROOT/args.output).write_text(json.dumps(r,indent=2,ensure_ascii=False)+'\n')
    for st in 'BA':
        cmp=r['published_precision_matches'][st];o=cmp['reproduced'];print('Model',cmp['model_number'],'N',o['n'],'point estimates',o['coefficients'],'SE',o['cluster_standard_errors']);print('matches',cmp['coefficients_at_paper_precision'],cmp['standard_errors_at_paper_precision'])
    print('saved',ROOT/args.output)
if __name__=='__main__':main()
