from __future__ import annotations
import hashlib,json,zipfile
from pathlib import Path
import r058_replay as r

P=Path(__file__).resolve().parent
RUNS=r.read_counts()
res=r.run_main(P/'R058_CONNECTOR_COUNTS.tsv')
(P/'R058_RESULTS.json').write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
ledger={
 'date':'2026-10-15',
 'source_name':'Priniski et al. (2026), Network structure shapes consensus dynamics through individual decisions',
 'article_doi':'10.1073/pnas.2520483123',
 'repository':'https://github.com/jpriniski/NetCom',
 'github_tree_sha':'8a50d76ea86394ab9e2d3902fbb6a9c685d6e42d',
 'source_mode':'GitHub connector fetch_file, all 26 CSV text records read and aggregated via independent connector-side JS',
 'physical_local_raw_bytes':False,
 'source_rows':res['source']['source_rows'],
 'eligible_rows':res['source']['eligible'],
 'file_blobs':{r['name']:r['sha'] for r in RUNS},
 'reproduction_level':'Connector-side raw-source calculation; on-disk audit uses faithful anonymized aggregates. Python --raw-dir has mandatory full Git blob SHA validation. Not claimed local raw end-to-end.'
}
(P/'SOURCE_LEDGER.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

import random
sensitivity={}
for content in ('face','hashtag'):
 strata=[]
 for structure in ('homogeneous','spatial'):
  rr=[]
  for g in RUNS:
   if g['content']!=content or g['structure']!=structure:continue
   n=sum(v[0] for (phase,a),v in g['cells'].items() if not a)
   c=sum(v[2] for (phase,a),v in g['cells'].items() if not a)
   rr.append((n,c))
  strata.append(rr)
 obs=sum(c for n,c in strata[1])/sum(n for n,c in strata[1])-sum(c for n,c in strata[0])/sum(n for n,c in strata[0])
 rng=random.Random(5802);vv=[]
 for _ in range(20000):
  rates=[]
  for group in strata:
   sample=rng.choices(group,k=len(group));rates.append(sum(z[1] for z in sample)/sum(z[0] for z in sample))
  vv.append(rates[1]-rates[0])
 vv.sort();sensitivity[content]={'spatial_minus_homogeneous_copy_rate':obs,'run_bootstrap95':[vv[499],vv[19499]],'run_counts':[len(g) for g in strata],'caveat':'Posthoc group-level descriptive contrast; assignment and mechanism not causally identified.'}
(P/'R058_TOPOLOGY_SENSITIVITY.json').write_text(json.dumps(sensitivity,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

files=[x for x in P.iterdir() if x.is_file() and x.name not in ('MANIFEST.json',)]
manifest={'artifact_round':'R058','creation_date':'2026-10-15','source_raw_local':False,'items':{q.name:{'bytes':q.stat().st_size,'sha256':hashlib.sha256(q.read_bytes()).hexdigest()} for q in sorted(files)}}
(P/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
Z=P.parent/'心理史学_R058_正式研究包_2026-10-15.zip'
with zipfile.ZipFile(Z,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(P.iterdir()):
  if f.is_file() and f.name!='build_package.pyc':z.write(f,arcname='R058/'+f.name)
with zipfile.ZipFile(Z) as z:
 assert z.testzip() is None
 assert len(z.namelist())>=9
print(json.dumps({'zip':str(Z),'size':Z.stat().st_size,'files':len(z.namelist()),'raw_locally_verified':False},ensure_ascii=False))
