import copy
import json
import math
import tempfile
import unittest
from pathlib import Path
import r058_replay as r

class ReplayTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.runs=r.read_counts()
        cls.output=r.run_main(r.ROOT/'R058_CONNECTOR_COUNTS.tsv')

    def test_01_run_count(self):self.assertEqual(len(self.runs),26)
    def test_02_distinct_run_ids(self):self.assertEqual(len({a['name'] for a in self.runs}),26)
    def test_03_source_rows(self):self.assertEqual(r.source_summary(self.runs)['source_rows'],39619)
    def test_04_eligible(self):self.assertEqual(r.source_summary(self.runs)['eligible'],36780)
    def test_05_actor_nodes(self):self.assertEqual(r.source_summary(self.runs)['actors_observed_per_network_sum'],1002)
    def test_06_copy_count(self):self.assertEqual(r.source_summary(self.runs)['partner_copy_disagreement'],5101)
    def test_07_disagreement_count(self):self.assertEqual(r.source_summary(self.runs)['disagreement'],27272)
    def test_08_no_bad_counts(self):
        for run in self.runs:
            for (phase,agree),(n,s,c) in run['cells'].items():
                self.assertLessEqual(s,n);self.assertLessEqual(c,n)
                if not agree:self.assertLessEqual(s+c,n)
                else:self.assertEqual(s,c)
    def test_09_four_phases_two_agreements(self):
        self.assertTrue(all(len(x['cells'])==8 for x in self.runs))
    def test_10_zero_count_state(self):
        self.assertEqual(self.runs[14]['cells'][(1,1)],(0,0,0))
    def test_11_git_sha(self):
        b=b'hello';import hashlib
        self.assertEqual(r.git_sha(b),hashlib.sha1(b'blob 5\0hello').hexdigest())
    def test_12_tampered_git_hash_fails(self):
        runs=[copy.deepcopy(self.runs[0])]
        with tempfile.TemporaryDirectory() as td:
            Path(td,'f20h1.csv').write_text('any,thing\n',encoding='utf-8')
            with self.assertRaisesRegex(ValueError,'GIT_BLOB_MISMATCH'):
                r.verify_raw(runs,td)
    def test_13_missing_raw_fails(self):
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaises(FileNotFoundError):r.verify_raw(self.runs,td)
    def test_14_synthetic_raw_temporal_consistency(self):
        data=("id,TrialNumber,Response,prev_response,partner_prev_response,partner_response\n"
              "1,1,alpha,nan,,beta\n"
              "1,2,gamma,alpha,,delta\n"
              "1,3,delta,gamma,delta,zeta\n").encode()
        v=r.recount_raw_bytes(data)
        self.assertEqual(v['cells'][(0,0)],(1,0,1))
        self.assertEqual(v['checks']['self_mismatch'],0)
        self.assertEqual(v['checks']['partner_mismatch'],0)
    def test_15_synthetic_raw_time_mismatch_detected(self):
        data=("id,TrialNumber,Response,prev_response,partner_prev_response,partner_response\n"
              "1,2,gamma,alpha,,delta\n"
              "1,3,delta,WRONG,delta,zeta\n").encode()
        v=r.recount_raw_bytes(data)
        self.assertEqual(v['checks']['self_mismatch'],1)
    def test_16_synthetic_raw_partner_time_mismatch_detected(self):
        data=("id,TrialNumber,Response,prev_response,partner_prev_response,partner_response\n"
              "1,2,gamma,alpha,,delta\n"
              "1,3,delta,gamma,WRONG,zeta\n").encode()
        v=r.recount_raw_bytes(data)
        self.assertEqual(v['checks']['partner_mismatch'],1)
    def test_17_duplicate_actor_trial_rejected(self):
        data=("id,TrialNumber,Response,prev_response,partner_prev_response,partner_response\n"
              "1,3,yes,no,no,yes\n1,3,no,no,no,yes\n").encode()
        with self.assertRaisesRegex(ValueError,'duplicate'):r.recount_raw_bytes(data)
    def test_18_lagged_partner_missing_is_excluded(self):
        data=("id,TrialNumber,Response,prev_response,partner_prev_response,partner_response\n"
              "1,1,a,nan,,b\n1,2,b,a,,c\n1,3,a,b,,d\n").encode()
        v=r.recount_raw_bytes(data)
        self.assertEqual(sum(k[0] for k in v['cells'].values()),0)
    def test_19_lag_from_current_round_is_not_used(self):
        data=("id,TrialNumber,Response,prev_response,partner_prev_response,partner_response\n"
              "1,2,b,a,,c\n1,3,b,b,c,NEW_CURRENT_PEER\n").encode()
        v=r.recount_raw_bytes(data)
        self.assertEqual(v['cells'][(0,0)],(1,1,0))
    def test_20_probabilities_are_valid(self):
        for k in self.runs:
            ps=r.probs([x for x in self.runs if x['name']!=k['name']],k,2,1)
            self.assertTrue(all(0<p<1 for p in ps))
    def test_21_heldout_not_in_training(self):
        held=self.runs[0];train=self.runs[1:]
        original=r.probs(train,held,2,1)
        spoof=copy.deepcopy(held);spoof['cells'][(2,1)]=(60,0,0)
        self.assertEqual(original,r.probs(train,spoof,2,1))
    def test_22_cv_rows(self):
        self.assertEqual(len(r.run_cv(self.runs)),26)
    def test_23_cv_n(self):
        self.assertEqual(r.aggregate_cv(r.run_cv(self.runs))['n'],36780)
    def test_24_loss_orders(self):
        o=self.output['cv']
        self.assertLess(o['m1_logloss'],o['m0_logloss'])
        self.assertLess(o['m3_logloss'],o['m2_logloss'])
    def test_25_brier_bounds(self):
        o=self.output['cv'];self.assertTrue(all(0<o[f'm{i}_brier']<1 for i in range(4)))
    def test_26_bootstrap_reproducible(self):
        cv=r.run_cv(self.runs)
        self.assertEqual(r.bootstrap_diff(cv,repetitions=130,seed=44),r.bootstrap_diff(cv,repetitions=130,seed=44))
    def test_27_crossrun_previous_agreement_effect_not_all_runs(self):
        self.assertEqual(self.output['bootstrap_m3_vs_m2']['improved_runs'],25)
    def test_28_m2_plus_network_does_not_improve_aggregate(self):
        self.assertGreater(self.output['cv']['m2_logloss'],self.output['cv']['m1_logloss'])
    def test_29_duplicate_counts_file_rejected(self):
        p=r.ROOT/'R058_CONNECTOR_COUNTS.tsv'
        with tempfile.TemporaryDirectory() as td:
            q=Path(td)/'dup.tsv';v=p.read_text();q.write_text(v+'\n'+v.splitlines()[2]+'\n')
            with self.assertRaisesRegex(ValueError,'duplicate run'):r.read_counts(q)
    def test_30_corrupted_count_gate(self):
        p=r.ROOT/'R058_CONNECTOR_COUNTS.tsv'
        with tempfile.TemporaryDirectory() as td:
            q=Path(td)/'bad.tsv';q.write_text(p.read_text().replace('144,54,33','144,140,40',1))
            with self.assertRaises(ValueError):r.read_counts(q)

if __name__=='__main__':unittest.main(verbosity=2)
