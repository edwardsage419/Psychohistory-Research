# R058 研究包说明

本包针对Priniski et al. (2026), PNAS, DOI 10.1073/pnas.2520483123。官方公开仓库 https://github.com/jpriniski/NetCom 。

核心报告 `R058_REPORT.md`，数据来源账本 `SOURCE_LEDGER.json`，26个独立网络的匿名衍生计数 `R058_CONNECTOR_COUNTS.tsv`，可运行Python复算代码 `r058_replay.py`，26组留出结果 `R058_RESULTS.json`，网络结构敏感性 `R058_TOPOLOGY_SENSITIVITY.json`，30项测试 `test_r058.py`。

本地重算：`python r058_replay.py --counts R058_CONNECTOR_COUNTS.tsv --json-out R058_RESULTS.json`；质量测试：`python -m unittest -v test_r058.py`。

**真正从原始字节复现**：另行合法下载作者26个 `Data/Network Interactions/*.csv` 文件到同一个目录，执行 `python r058_replay.py --raw-dir /path/to/csvs`。该模式逐文件核对Git blob SHA1，重建全部匿名计数，发现错位/缺失/内容改动立即报错。本包不含完整原始个人决策文件，不能伪称本地从真实原始CSV端到端重放。

重要限制：已观察数据事后设定预测特征；网络上一轮匹配同时对应奖励反馈，不支持独立社会模仿因果解释。PESEN v0.1仍冻结。
