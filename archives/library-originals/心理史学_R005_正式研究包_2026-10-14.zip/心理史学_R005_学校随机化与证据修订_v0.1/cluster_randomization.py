#!/usr/bin/env python3
"""R005 synthetic school-randomized trial methods audit. Python >= 3.10, standard library only.

Data here are generated artificially, never taken from ICPSR or students.
"""
import argparse
import csv
import json
import math
import random
from pathlib import Path
from itertools import combinations
from statistics import median

BASE_SEED = 20261014
BLOCKS = 14
SCHOOLS_PER_BLOCK = 4
WITHIN_SD = 0.9
SCHOOL_SD = 0.7
BLOCK_SD = 0.4
ALL_ASSIGNMENTS = tuple(combinations(range(4), 2))


def draw_trial(rng, tau):
    """Generate school-level sufficient summaries and block randomized treatment."""
    schools = []
    for block in range(BLOCKS):
        block_shift = rng.gauss(0.0, BLOCK_SD)
        treated_positions = set(rng.sample(range(SCHOOLS_PER_BLOCK), 2))
        for j in range(SCHOOLS_PER_BLOCK):
            n = rng.randint(280, 600)
            # Equivalent mean distribution for n iid Gaussian student residuals.
            mean = block_shift + rng.gauss(0.0, SCHOOL_SD)
            mean += rng.gauss(0.0, WITHIN_SD / math.sqrt(n))
            treat = int(j in treated_positions)
            schools.append({"block": block, "school": block * 4 + j,
                            "n": n, "treat": treat, "mean": mean + tau * treat,
                            "within_variance": WITHIN_SD ** 2})
    return schools


def school_block_effect(schools):
    """One school gets one vote in its 4-school randomization block."""
    differences = []
    for b in range(BLOCKS):
        rows = [s for s in schools if s["block"] == b]
        treated = [s["mean"] for s in rows if s["treat"]]
        untreated = [s["mean"] for s in rows if not s["treat"]]
        if len(treated) != 2 or len(untreated) != 2:
            raise ValueError("Expected 2 treated and 2 control schools in every block")
        differences.append(sum(treated) / 2 - sum(untreated) / 2)
    return sum(differences) / BLOCKS


def randomization_p(schools, rng, permutations=399):
    """Two-sided Fisher sharp-null Monte Carlo randomization p, fixed outcomes."""
    if permutations < 1:
        raise ValueError("permutations must be positive")
    observed = school_block_effect(schools)
    options = []
    for b in range(BLOCKS):
        v = [s["mean"] for s in schools if s["block"] == b]
        per_block = []
        for picked in ALL_ASSIGNMENTS:
            remaining = [j for j in range(4) if j not in picked]
            per_block.append((v[picked[0]] + v[picked[1]]
                              - v[remaining[0]] - v[remaining[1]]) / 2)
        options.append(per_block)
    extreme = 0
    for _ in range(permutations):
        value = sum(rng.choice(per_block) for per_block in options) / BLOCKS
        if abs(value) >= abs(observed) - 1e-12:
            extreme += 1
    return (extreme + 1) / (permutations + 1)


def naive_independent_student_p(schools):
    """Student-level pooled large-sample z statistic from approximate sufficient stats.

    This is intentionally misspecified because assignments were clustered.
    """
    groups = []
    for treat in (0, 1):
        r = [s for s in schools if s["treat"] == treat]
        n_total = sum(s["n"] for s in r)
        mean = sum(s["n"] * s["mean"] for s in r) / n_total
        ss = sum((s["n"] - 1) * s["within_variance"]
                 + s["n"] * (s["mean"] - mean) ** 2 for s in r)
        groups.append((n_total, mean, ss))
    n0, mean0, ss0 = groups[0]
    n1, mean1, ss1 = groups[1]
    pooled_variance = (ss0 + ss1) / (n0 + n1 - 2)
    se = math.sqrt(pooled_variance * (1/n0 + 1/n1))
    z = (mean1 - mean0) / se
    # erfc gives two-sided standard Gaussian tail.
    return math.erfc(abs(z) / math.sqrt(2))


def wilson_interval(successes, trials, z=1.96):
    if trials <= 0:
        raise ValueError("trials must be positive")
    p = successes / trials
    denom = 1 + z*z/trials
    center = (p + z*z/(2*trials)) / denom
    radius = z*math.sqrt(p*(1-p)/trials + z*z/(4*trials*trials))/denom
    return [round(max(0, center-radius), 4), round(min(1, center+radius), 4)]


def evaluate(trials=240, permutations=399, seed=BASE_SEED):
    rng = random.Random(seed)
    records = []
    aggregate = []
    for label, effect in (("null", 0.0), ("effect", -0.35)):
        ps_naive, ps_block = [], []
        for rep in range(trials):
            school_data = draw_trial(rng, effect)
            p_naive = naive_independent_student_p(school_data)
            p_block = randomization_p(school_data, rng, permutations)
            ps_naive.append(p_naive)
            ps_block.append(p_block)
            records.append({"scenario": label, "rep": rep, "tau": effect,
                            "block_estimate": round(school_block_effect(school_data), 9),
                            "naive_student_p": round(p_naive, 10),
                            "blocked_school_randomization_p": round(p_block, 10)})
        for name, ps in (("naive_student", ps_naive), ("blocked_school", ps_block)):
            rejected = sum(p <= 0.05 for p in ps)
            aggregate.append({"scenario": label, "true_effect": effect,
                              "test": name, "trials": trials,
                              "rejections": rejected,
                              "rejection_fraction": round(rejected/trials, 4),
                              "wilson_95_interval": wilson_interval(rejected, trials),
                              "median_p": round(median(ps), 6)})
    return {"seed": seed, "trials_per_scenario": trials,
            "permutation_draws_per_trial": permutations,
            "design": {"blocks": BLOCKS, "schools_per_block": 4,
                       "treated_schools_per_block": 2,
                       "school_sd": SCHOOL_SD, "within_sd": WITHIN_SD,
                       "block_sd": BLOCK_SD, "student_n_range": [280, 600],
                       "real_data": False},
            "summary": aggregate, "records": records}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--trials", type=int, default=240)
    ap.add_argument("--permutations", type=int, default=399)
    ap.add_argument("--seed", type=int, default=BASE_SEED)
    ap.add_argument("--out", type=Path, default=Path("results"))
    args = ap.parse_args()
    result = evaluate(args.trials, args.permutations, args.seed)
    args.out.mkdir(parents=True, exist_ok=True)
    json_path = args.out / "r005_results.json"
    json_path.write_text(json.dumps({k: v for k, v in result.items() if k != "records"},
                                    ensure_ascii=False, indent=2), encoding="utf-8")
    with (args.out / "per_trial_results.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(result["records"][0]))
        writer.writeheader()
        writer.writerows(result["records"])
    print(json.dumps(result["summary"], ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
