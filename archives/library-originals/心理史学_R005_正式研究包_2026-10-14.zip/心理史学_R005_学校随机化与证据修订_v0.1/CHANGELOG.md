# R005 变更日志

2026-10-14 / R005

- ADDED 研究协议 `PROTOCOL.md`，于主实验前冻结。
- ADDED 无第三方依赖的学校区组随机化示范 `cluster_randomization.py`。
- ADDED 7项软件测试，运行通过。
- ADDED 240×2组独立完整模拟，每组399次随机化检验结果。
- ADDED 原论文的2018年效果值更正、2019年基金致谢更正及证据溯源。
- ADDED `REAL_DATA_GATES.md`，禁止公共版数据与原始作者复现数据未经审核混用。
- PRESERVED PESEN v0.1 原始模型，不增加没有现实证据支持的心理机制。
- PENDING 公共版代码本、数据下载和真实ITT分析。
