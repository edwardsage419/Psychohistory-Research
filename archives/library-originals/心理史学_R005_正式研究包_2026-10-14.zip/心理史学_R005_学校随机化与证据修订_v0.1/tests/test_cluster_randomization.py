import math
import random
import unittest
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import cluster_randomization as m

class RandomizationTests(unittest.TestCase):
    def test_design(self):
        s = m.draw_trial(random.Random(2), 0)
        self.assertEqual(len(s), 56)
        for b in range(14):
            row = [x for x in s if x['block'] == b]
            self.assertEqual(len(row), 4)
            self.assertEqual(sum(x['treat'] for x in row), 2)
    def test_block_shift_invariance(self):
        s = m.draw_trial(random.Random(3), 0)
        shift = m.school_block_effect(s)
        for x in s:
            x['mean'] += 5 * (x['block'] + 1)
        self.assertAlmostEqual(shift, m.school_block_effect(s))
    def test_constant_effect(self):
        r1 = random.Random(9)
        r2 = random.Random(9)
        a = m.draw_trial(r1, 0)
        b = m.draw_trial(r2, -0.35)
        self.assertAlmostEqual(m.school_block_effect(b) - m.school_block_effect(a), -0.35)
    def test_monotone_randomization_p(self):
        s = m.draw_trial(random.Random(4), 0)
        p = m.randomization_p(s, random.Random(7), 99)
        self.assertGreaterEqual(p, 0.01)
        self.assertLessEqual(p, 1)
    def test_identical_outcome_p_one(self):
        s = m.draw_trial(random.Random(5), 0)
        for school in s:
            school['mean'] = 0.0
        self.assertEqual(m.randomization_p(s, random.Random(6), 99), 1.0)
        self.assertEqual(m.naive_independent_student_p(s), 1.0)
    def test_repeatability(self):
        a = m.evaluate(2, 19, 123)
        b = m.evaluate(2, 19, 123)
        self.assertEqual(a, b)
    def test_ci_contains_estimate(self):
        for k in (0, 2, 15, 29, 30):
            lo, hi = m.wilson_interval(k, 30)
            self.assertLessEqual(lo, k/30)
            self.assertGreaterEqual(hi, k/30)

if __name__ == '__main__':
    unittest.main()
