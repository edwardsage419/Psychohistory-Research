"""Synthetic unit tests for R048 software; never mislabel as real-data replay."""
import csv
import io
import math
import unittest
from pathlib import Path
import sys
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
from r048_replay import (git_blob_sha,read_source,optional_numeric,
    audit_and_transitions,design,fit_re,build_report,PUBLISHED_TABLE4)


def synthetic_source():
    """32 people, eight 4-person groups, 6 periods, full directed ledger."""
    items=[]
    for session in (5,6,7,8):
        homo=0 if session<7 else 1
        for game in (1,2):
            group=100*homo+10*session+game
            ids=[10000+group*10+j for j in range(4)]
            for period in range(2,8):
                for j,uid in enumerate(ids):
                    slot=j+1
                    sent={k:float(3*((period+2*j+3*k+game)%4)) for k in range(1,5) if k!=slot}
                    invest=float((20+4*j+period*2+game+session)%44)
                    paid=sum(sent.values())/3
                    row={'ProfileID':uid,'group':group,'Session':session,'GameID':game,'Homo':homo,
                         'RoundID':period,'Token':50 if homo else (40 if j<2 else 60),
                         'FF':1,'Invest':invest,'Paid':paid,
                         **{f'Seq{k}':sent.get(k) for k in range(1,5)}}
                    items.append(row)
    by={}
    for o in items:
        by.setdefault((o['group'],o['RoundID']),[]).append(o)
    for arr in by.values():
        for o in arr:
            slot=next(j for j in range(1,5) if o[f'Seq{j}'] is None)
            received=sum(t[f'Seq{slot}'] or 0 for t in arr if t is not o)
            o['Received']=received
            o['Total']=100.0
            o['Total2']=100-o['Paid']-received
    return items

class BasicTest(unittest.TestCase):
    def test_git_blob_is_not_file_sha(self):
        import hashlib
        value=git_blob_sha(b'hello world\n')
        self.assertEqual(value,'3b18e512dba79e4c8300dd08aeb37f8e728b8dad')
        self.assertNotEqual(value,hashlib.sha1(b'hello world\n').hexdigest())

    def test_numeric_missing_dot(self):
        self.assertIsNone(optional_numeric('.'))

    def test_numeric_missing_blank(self):
        self.assertIsNone(optional_numeric('  '))

    def test_numeric_negative(self):
        self.assertEqual(optional_numeric('-12.5'),-12.5)

    def test_sha_guard(self):
        with self.assertRaisesRegex(ValueError,'SHA mismatch'):
            read_source(b'anything',require_sha=True)

    def test_required_fields_guard(self):
        with self.assertRaisesRegex(ValueError,'Required source fields'):
            read_source(b'ProfileID\n1\n',require_sha=False)

    def test_data_roundtrip_layout(self):
        rows=synthetic_source()
        audit,trans=audit_and_transitions(rows)
        self.assertEqual(audit['subject_count'],32)
        self.assertEqual(audit['punishment_groups'],8)
        self.assertEqual(audit['punishment_rows_after_practice'],192)
        self.assertEqual(audit['transitions'],160)
        self.assertEqual(audit['received_disagreements'],0)

    def test_correct_payout(self):
        audit,_=audit_and_transitions(synthetic_source())
        self.assertEqual(audit['wrong_paid'],0)
        self.assertEqual(audit['wrong_original_payout'],0)
        self.assertEqual(audit['wrong_reconstructed_payout'],0)

    def test_isolate_one_received_problem(self):
        rows=synthetic_source()
        rows[0]['Received']+=3
        audit,_=audit_and_transitions(rows)
        self.assertEqual(audit['received_disagreements'],1)
        self.assertEqual(audit['wrong_original_payout'],1)
        self.assertEqual(audit['wrong_reconstructed_payout'],0)

    def test_separate_payout_problem(self):
        rows=synthetic_source()
        rows[0]['Total2']+=4
        audit,_=audit_and_transitions(rows)
        self.assertEqual(audit['received_disagreements'],0)
        self.assertEqual(audit['wrong_original_payout'],1)
        self.assertEqual(audit['wrong_reconstructed_payout'],1)

    def test_reject_ambiguous_slot(self):
        rows=synthetic_source()
        rows[0]['Seq2']=None
        with self.assertRaises(ValueError):
            audit_and_transitions(rows)

    def test_reject_incomplete_group(self):
        rows=synthetic_source()[1:]
        with self.assertRaisesRegex(ValueError,'Invalid group'):
            audit_and_transitions(rows)

    def test_four_way_re_design(self):
        _,t=audit_and_transitions(synthetic_source())
        x,y,terms=design(t,'lag_dev',False,True)
        self.assertEqual(x.shape,(160,4))
        self.assertEqual(len(y),160)
        self.assertEqual(terms[-1],'punishment_equal')
        self.assertTrue(np.allclose(x[:,0],1))

    def test_five_way_re_design(self):
        _,t=audit_and_transitions(synthetic_source())
        x,y,terms=design(t,'dev',True,False)
        self.assertEqual(x.shape,(160,5))
        self.assertEqual(len(terms),5)

    def test_random_effects_finite(self):
        _,t=audit_and_transitions(synthetic_source())
        model=fit_re(t,'dev',False,False)
        self.assertEqual(model['n'],160)
        self.assertEqual(model['panels'],32)
        self.assertEqual(model['clusters'],8)
        self.assertTrue(all(np.isfinite(model['coefficient'])))
        self.assertTrue(all(np.isfinite(model['clustered_se'])))

    def test_variance_nonnegative(self):
        _,t=audit_and_transitions(synthetic_source())
        model=fit_re(t,'dev',True,False)
        self.assertGreaterEqual(model['sigma_e'],0)
        self.assertGreaterEqual(model['sigma_u'],0)

    def test_no_stata_claim(self):
        _,t=audit_and_transitions(synthetic_source())
        model=fit_re(t,'lag_dev',False,True)
        self.assertIn('session',model['cluster_warning'])

    def test_predefined_journal_reference(self):
        self.assertEqual(len(PUBLISHED_TABLE4),4)
        self.assertEqual(len(PUBLISHED_TABLE4['above_selftype']['coef']),5)

    def test_sha_guard_in_build(self):
        with self.assertRaisesRegex(ValueError,'SHA mismatch'):
            build_report(b'ProfileID\n1\n',strict=True)

if __name__=='__main__':
    unittest.main(verbosity=2)
