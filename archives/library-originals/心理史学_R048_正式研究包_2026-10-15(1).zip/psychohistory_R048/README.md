# 心理史学 R048 独立研究包

原始研究：De Geest 与 Kingsley（2021）， DOI `10.1561/102.00000099`。

内容：

* `R048_REPORT.md`：本轮正式研究记录。
* `CONNECTOR_REPLAY_RESULTS.json`：GitHub连接器真实CSV的数值运算结果；由连接器侧JS程序产生，不得误认为本地Python原始字节重算。
* `SOURCE_LEDGER.json`：源Git blob身份、访问程度和复现限制。
* `r048_replay.py`：独立Python复算程序；合法获得作者原始CSV后可在本地复算。
* `test_r048.py`：19项构造数据的数学和程序一致性测试。
* `R049_RESEARCH_GATE.md`：下一轮研究关口与新数据优先顺序。

运行环境：Python ≥3.10，NumPy。

```bash
pip install numpy
python -m unittest -v test_r048.py
python r048_replay.py --csv /path/to/original/data.csv --output R048_REPLAY_RESULTS.json
```

如果系统允许直接联网，从GitHub下载原作者数据并校验Git blob：

```bash
python r048_replay.py --download --output R048_REPLAY_RESULTS.json
```

脚本只做本地读取、统计、生成结果文件，不发送数据或修改外部仓库。

**现有执行等级**：GitHub连接器侧已经对原作者实际CSV完成独立数值计算。当前沙盒没有取得真实CSV字节，所以19项本地单元测试是模拟／构造数据测试。可公开原始数据来源指纹见`SOURCE_LEDGER.json`。PESEN v0.1持续冻结。
