#!/usr/bin/env python3
"""Psychohistory R048: source-locked peer-punishment replication.

Python 3.10+, NumPy only. Loads the Git-verified author CSV and reproduces the
Stata xtreg,re *default moment-variance* GLS coefficients. Cluster sandwich SE
are an independent implementation, whose printed precision is validated against
Table 4. This is not execution of the original Stata program or DTA byte replay.

Usage:
    python r048_replay.py --csv data.csv --output R048_REPLAY_RESULTS.json
    python r048_replay.py --download --output R048_REPLAY_RESULTS.json
    python r048_replay.py --csv data.csv --output results.json --strict
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
from collections import defaultdict
from pathlib import Path
from urllib.request import urlopen

import numpy as np

SOURCE_URL = 'https://raw.githubusercontent.com/lrdegeest/InequalityCPR/master/data/data.csv'
GIT_SHA = '73c02176bc9e060af987149594a85f9f7b591230'
SOURCE_N = 2048
PAID_SCALE = 3
# Coefficients and SE rounded to journal Table 4. Order: intercept, deviation,
# then punishment slopes, with treatment grouping specified by design().
PUBLISHED_TABLE4 = {
    'below_homo': {'coef': (3.117, -.839, -.123, -.065),
                   'se2': (1.07, .12, .04, .01)},
    'below_selftype': {'coef': (3.127, -.852, -.064, -.045, -.160),
                       'se2': (1.05, .12, .01, .01, .04)},
    'above_homo': {'coef': (-1.932, -1.128, -.305, -.003),
                   'se2': (.96, .12, .11, .04)},
    'above_selftype': {'coef': (-2.593, -1.175, .001, .438, -.482),
                       'se2': (.92, .13, .04, .28, .08)},
}


def git_blob_sha(content: bytes) -> str:
    return hashlib.sha1(f'blob {len(content)}\0'.encode() + content).hexdigest()


def optional_numeric(s: str | None) -> float | None:
    if s is None or s.strip() in ('', '.'):
        return None
    return float(s)


def read_source(raw: bytes, require_sha: bool = True) -> list[dict]:
    if require_sha and git_blob_sha(raw) != GIT_SHA:
        raise ValueError('Original CSV Git blob SHA mismatch: refuse real results')
    reader = csv.DictReader(io.StringIO(raw.decode('utf-8-sig')))
    rows: list[dict] = []
    required = ['ProfileID', 'GameID', 'RoundID', 'Token', 'Invest', 'Received',
                'Paid', 'Total', 'Total2', 'Session', 'Homo', 'FF']
    if not set(required).issubset(reader.fieldnames or ()):
        raise ValueError('Required source fields absent')
    for line in reader:
        if len(rows) == SOURCE_N:
            break  # author's label_main_data.do explicitly truncates at 2048
        if not line.get('ProfileID'):
            raise ValueError('Unexpected blank participant before row 2048')
        x: dict = {}
        for name in required + ['Seq1', 'Seq2', 'Seq3', 'Seq4']:
            x[name] = optional_numeric(line[name])
        if any(x[name] is None for name in ('ProfileID', 'RoundID', 'Invest', 'FF')):
            raise ValueError('Missing essential field in source')
        for name in ('ProfileID', 'GameID', 'RoundID', 'Token', 'Session', 'Homo', 'FF'):
            x[name] = int(x[name])
        x['group'] = 100*x['Homo'] + 10*x['Session'] + x['GameID']
        rows.append(x)
    if require_sha and len(rows) != SOURCE_N:
        raise ValueError('Unexpected source row count')
    return rows


def audit_and_transitions(source: list[dict]) -> tuple[dict, list[dict]]:
    raw = [dict(r) for r in source if r['FF'] == 1 and r['RoundID'] >= 2]
    cells: dict[tuple[int,int], list[dict]] = defaultdict(list)
    for r in raw:
        r['slot'] = [j for j in range(1,5) if r[f'Seq{j}'] is None]
        if len(r['slot']) != 1:
            raise ValueError('Ambiguous target slot')
        r['slot'] = r['slot'][0]
        cells[r['group'],r['RoundID']].append(r)
    discrepancies=[]
    wrong_paid=[]
    wrong_payout=[]
    wrong_reconstructed_payout=[]
    for key, members in cells.items():
        if len(members) != 4 or {r['slot'] for r in members} != {1,2,3,4}:
            raise ValueError(f'Invalid group/period layout: {key}')
        avg = sum(r['Invest'] for r in members)/4
        for row in members:
            row['dev'] = avg-row['Invest']
            row['reconstructed_received'] = sum(
                sender[f'Seq{row["slot"]}'] or 0.0
                for sender in members if sender is not row
            )
            sent = sum(row[f'Seq{j}'] or 0.0 for j in range(1,5))
            if abs(sent - PAID_SCALE*row['Paid']) > 1e-7:
                wrong_paid.append((row['group'],row['RoundID'],row['ProfileID']))
            if abs(row['Received']-row['reconstructed_received']) > 1e-7:
                discrepancies.append(row)
            if abs(row['Total'] - row['Paid'] - row['Received'] - row['Total2']) > 0.021:
                wrong_payout.append(row)
            if abs(row['Total'] - row['Paid'] - row['reconstructed_received'] - row['Total2']) > 0.021:
                wrong_reconstructed_payout.append(row)
    people: dict[int,list[dict]] = defaultdict(list)
    for row in raw:
        people[row['ProfileID']].append(row)
    transitions=[]
    for person, rows in people.items():
        rows.sort(key=lambda r:r['RoundID'])
        for prev,now in zip(rows,rows[1:]):
            if now['RoundID'] != prev['RoundID']+1:
                continue
            new = dict(now)
            new['lag_dev'] = prev['dev']
            new['lag_received'] = prev['Received']
            new['lag_reconstructed_received'] = prev['reconstructed_received']
            new['delta_invest'] = now['Invest']-prev['Invest']
            transitions.append(new)
    audit={
        'punishment_rows_after_practice':len(raw),
        'subject_count':len(people),
        'punishment_groups':len({r['group'] for r in raw}),
        'transitions':len(transitions),
        'received_disagreements':len(discrepancies),
        'received_disagreement_groups':sorted({r['group'] for r in discrepancies}),
        'received_disagreement_subjects':len({r['ProfileID'] for r in discrepancies}),
        'wrong_paid':len(wrong_paid),
        'wrong_original_payout':len(wrong_payout),
        'wrong_reconstructed_payout':len(wrong_reconstructed_payout),
        'disagreement_when_original_binary_changes':sum((r['Received']>0)!=(r['reconstructed_received']>0) for r in discrepancies),
        'original_received_total':sum(r['Received'] for r in raw),
        'reconstructed_received_total':sum(r['reconstructed_received'] for r in raw),
        'lag_dev_category_changes':sum(np.sign(r['dev'])!=np.sign(r['lag_dev']) for r in transitions),
    }
    return audit,transitions


def design(rows: list[dict], deviation: str, by_type: bool, repaired: bool):
    if not rows:
        raise ValueError('Empty model sample')
    lag = 'lag_reconstructed_received' if repaired else 'lag_received'
    y=np.asarray([o['delta_invest'] for o in rows],dtype=float)
    if by_type:
        columns=('constant','deviation','punishment_equal','punishment_low','punishment_high')
        x=np.asarray([[1.,o[deviation],
            o[lag] if o['Homo']==1 else 0.,
            o[lag] if o['Token']==40 else 0.,
            o[lag] if o['Token']==60 else 0.] for o in rows],dtype=float)
    else:
        columns=('constant','deviation','punishment_unequal','punishment_equal')
        x=np.asarray([[1.,o[deviation],
            o[lag] if o['Homo']==0 else 0.,
            o[lag] if o['Homo']==1 else 0.] for o in rows],dtype=float)
    return x,y,columns


def fit_re(rows: list[dict], deviation: str = 'dev', by_type: bool=False, repaired: bool=False) -> dict:
    """Stata xtreg,re default variance estimator and group-cluster sandwich.

    For each panel i, theta_i=1-sqrt(s2_e/(T_i*s2_u+s2_e)). Default
    s2_u uses *unweighted between OLS* plus harmonic T. This reproduces
    published coefficients, unlike 'sa' (different for unbalanced panels).
    The cluster correction G/(G-1) * (N-1)/(N-K) follows standard OLS VCE.
    The original Stata build remains the authority for exact runtime identity.
    """
    x,y,cols=design(rows,deviation,by_type,repaired)
    N,K=x.shape
    ids=np.asarray([r['ProfileID'] for r in rows],dtype=int)
    group=np.asarray([r['group'] for r in rows],dtype=int)
    uids=np.unique(ids)
    ni=len(uids)
    if N-ni-K+1<=0 or ni<=K:
        raise ValueError('Insufficient panel degrees of freedom')
    means_x={i:x[ids==i].mean(axis=0) for i in uids}
    means_y={i:y[ids==i].mean() for i in uids}
    counts={i:int(np.sum(ids==i)) for i in uids}
    xw=np.vstack([x[j,1:]-means_x[ids[j]][1:] for j in range(N)])
    yw=np.asarray([y[j]-means_y[ids[j]] for j in range(N)])
    bw=np.linalg.lstsq(xw,yw,rcond=None)[0]
    sigma2_e=float(np.sum((yw-xw@bw)**2)/(N-ni-K+1))
    xb=np.vstack([means_x[i] for i in uids])
    yb=np.array([means_y[i] for i in uids])
    bb=np.linalg.lstsq(xb,yb,rcond=None)[0]
    ssrb=float(np.sum((yb-xb@bb)**2))
    harmonic_T=ni/sum(1/counts[i] for i in uids)
    sigma2_u=max(0.0,ssrb/(ni-K)-sigma2_e/harmonic_T)
    theta={i:1-math.sqrt(sigma2_e/(counts[i]*sigma2_u+sigma2_e)) for i in uids}
    xt=np.vstack([x[j]-theta[ids[j]]*means_x[ids[j]] for j in range(N)])
    yt=np.asarray([y[j]-theta[ids[j]]*means_y[ids[j]] for j in range(N)])
    beta=np.linalg.lstsq(xt,yt,rcond=None)[0]
    residual=yt-xt@beta
    bread=np.linalg.inv(xt.T@xt)
    clusters=np.unique(group)
    G=len(clusters)
    if G<=1:
        raise ValueError('Too few independent groups')
    meat=np.zeros((K,K))
    for cluster in clusters:
        mask=(group==cluster)
        score=xt[mask].T @ residual[mask]
        meat+=np.outer(score,score)
    scale=(G/(G-1))*((N-1)/(N-K))
    vcov=scale*bread@meat@bread
    se=np.sqrt(np.maximum(0,np.diag(vcov)))
    result={
        'n':N,'panels':ni,'clusters':G,'terms':cols,
        'coefficient':[float(t) for t in beta],
        'clustered_se':[float(v) for v in se],
        'sigma_e':math.sqrt(sigma2_e),'sigma_u':math.sqrt(sigma2_u),
        'harmonic_T':harmonic_T,'repaired':repaired,'deviation':deviation,
        'cluster_warning':'Group-robust uncertainty may not protect against shared session shocks: four punishment sessions, treatment nested in sessions.'
    }
    if not by_type:
        d=float(beta[3]-beta[2])
        sd=math.sqrt(max(0.,float(vcov[2,2]+vcov[3,3]-2*vcov[2,3])))
        result['equal_minus_unequal']=d
        result['difference_wald_chi2']= (d/sd)**2 if sd else None
    return result


def journal_round(value: float, decimals: int) -> float:
    """Use decimal place tolerance; do not claim more precision than published."""
    return round(float(value),decimals)


def build_report(raw: bytes, strict: bool=True) -> dict:
    records=read_source(raw,require_sha=strict)
    audit,turns=audit_and_transitions(records)
    if strict:
        expected={'punishment_rows_after_practice':960,'subject_count':64,
                  'punishment_groups':16,'transitions':896,
                  'received_disagreements':80,'received_disagreement_subjects':20,
                  'wrong_paid':0,'wrong_original_payout':80,
                  'wrong_reconstructed_payout':0,
                  'disagreement_when_original_binary_changes':9,
                  'lag_dev_category_changes':315}
        for k,v in expected.items():
            if audit[k]!=v:
                raise ValueError(f'Golden source audit failed: {k}: {audit[k]} != {v}')
    models={}
    for temporal in ('dev','lag_dev'):
        for side in ('below','above'):
            selected=[r for r in turns if (r[temporal]>0 if side=='below' else r[temporal]<0)]
            for model in ('homo','selftype'):
                for source in ('original','reconstructed'):
                    key=f'{temporal}_{side}_{model}_{source}'
                    models[key]=fit_re(selected,temporal,by_type=(model=='selftype'),repaired=(source=='reconstructed'))
            if strict and temporal=='dev':
                for model in ('homo','selftype'):
                    base=models[f'dev_{side}_{model}_original']
                    published=PUBLISHED_TABLE4[f'{side}_{model}']
                    if any(journal_round(v,3)!=p for v,p in zip(base['coefficient'],published['coef'])):
                        raise ValueError(f'Journal coefficient mismatch in {side}_{model}')
                    if any(journal_round(v,2)!=p for v,p in zip(base['clustered_se'],published['se2'])):
                        raise ValueError(f'Journal clustered SE mismatch in {side}_{model}')
    return {
        'status':'Author CSV exact Git blob; independent coefficient and cluster-SE formula replay; no native Stata run',
        'source_git_blob_sha1':git_blob_sha(raw),
        'audit':audit,'models':models,
        'limitations':[
            'Author DTA has not been byte-checked or executed in Stata locally',
            'Four punishment sessions are insufficient for conventional treatment-level clustered causal inference',
            'Reconstructed Received is backed by Seq and Total2 but original hardware execution logs are unavailable',
            'The audit of previously examined data is exploratory; no prospective validation',
        ]
    }


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    g=parser.add_mutually_exclusive_group(required=True)
    g.add_argument('--csv',type=Path)
    g.add_argument('--download',action='store_true')
    parser.add_argument('--output',type=Path,default=Path('R048_REPLAY_RESULTS.json'))
    parser.add_argument('--strict',action='store_true',help='Explicit strict mode; strict is default')
    args=parser.parse_args()
    payload=urlopen(SOURCE_URL,timeout=30).read() if args.download else args.csv.read_bytes()
    result=build_report(payload,strict=True)
    args.output.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(f"PASS author CSV RE replay; 4 journal models; Received mismatches={result['audit']['received_disagreements']}; output={args.output}")

if __name__=='__main__':
    main()
