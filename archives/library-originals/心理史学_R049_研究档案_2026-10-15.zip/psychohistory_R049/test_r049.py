"""Constructed-fixture tests only; these are NOT an external data replication."""
import itertools
import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

from r049_replay import (
    SourceGateError, analysis_rows, conditional_randomization,
    exact_balanced_session_assignments, factorial_contrasts,
    leave_session_out, run, score, smoothed_rate, source_checks,
)


def fake_data():
    """Construct a clearly artificial 8-session × 20-subject × 9-round dataset."""
    out=[]
    combos=list(itertools.product((0,1),(0,1)))
    for session in range(8):
        high,social=combos[session//2]
        for subject in range(20):
            prev=None
            for round_ in range(1,10):
                b=(session+subject+round_)%2
                a=1-b
                out.append({
                    'subject_id': session*20+subject+1,'sesid':session+1,
                    'Match':1+subject//10,'Block':1,'Round':round_,
                    'Period':round_, 'strategyA':a,'strategyB':b,
                    'strategyB_old':np.nan if prev is None else prev,
                    'social':social,'financial':1-social,'low':1-high,'high':high,
                    'message':int(a and social and subject%3==0),
                    'punish':int(a and not social and subject%3==0),
                    'badmess':int(prev == 1 and social and subject%3==1),
                    'badpun':int(prev == 1 and not social and subject%3==1),
                    'countA':5,'countB':5,
                })
                prev=b
    return pd.DataFrame(out)


class TestR049(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.df=fake_data()

    def test_fixture_size(self):
        self.assertEqual(len(self.df),1440)

    def test_balanced_cells(self):
        v=source_checks(self.df,strict=False)
        self.assertEqual(v['sessions'],8)
        self.assertEqual(sorted(v['treatment_cell_sessions'].values()),[2,2,2,2])

    def test_strict_gates_real_sample_size(self):
        with self.assertRaisesRegex(SourceGateError,'Published rows'):
            source_checks(self.df,strict=True)

    def test_valid_lag_rows(self):
        self.assertEqual(source_checks(self.df,False)['valid_lag_rows'],1280)

    def test_missing_column_rejected(self):
        with self.assertRaisesRegex(SourceGateError,'Missing mandatory'):
            source_checks(self.df.drop(columns=['badpun']),False)

    def test_missing_one_block_row_rejected(self):
        df=self.df.drop(index=[0])
        with self.assertRaisesRegex(SourceGateError,'nine rounds'):
            source_checks(df,False)

    def test_wrong_round_start_lag_rejected(self):
        df=self.df.copy();df.loc[df.index[0],'strategyB_old']=1
        with self.assertRaisesRegex(SourceGateError,'First round'):
            source_checks(df,False)

    def test_wrong_prior_lag_rejected(self):
        df=self.df.copy();df.loc[df.index[1],'strategyB_old']=1-df.loc[df.index[1],'strategyB_old']
        with self.assertRaisesRegex(SourceGateError,'lag action'):
            source_checks(df,False)

    def test_treatment_changed_within_session_rejected(self):
        df=self.df.copy();df.loc[df.index[0],'social']=1-df.loc[df.index[0],'social'];df.loc[df.index[0],'financial']=1-df.loc[df.index[0],'social']
        with self.assertRaisesRegex(SourceGateError,'Session varies'):
            source_checks(df,False)

    def test_sender_eligibility_rejected(self):
        df=self.df.copy();i=df.index[(df.strategyB==1)&(df.social==1)][0];df.loc[i,'message']=1
        with self.assertRaisesRegex(SourceGateError,'high effort'):
            source_checks(df,False)

    def test_group_count_rejected(self):
        df=self.df.copy();df.loc[df.index[0],'countB']=9
        with self.assertRaisesRegex(SourceGateError,'counts'):
            source_checks(df,False)

    def test_duplicate_rejected(self):
        df=pd.concat([self.df,self.df.iloc[[0]]],ignore_index=True)
        with self.assertRaisesRegex(SourceGateError,'Duplicate'):
            source_checks(df,False)

    def test_prev_received_only(self):
        w=analysis_rows(self.df)
        self.assertEqual(len(w),1280)
        self.assertTrue(((w.lag_sanction_received==1) <= (w.strategyB_old==1)).all())

    def test_probability_smoothing_unseen(self):
        tr=pd.DataFrame({'strategyB':[1,0,1],'strategyB_old':[0,0,0]})
        te=pd.DataFrame({'strategyB_old':[1,0]})
        p=smoothed_rate(tr,['strategyB_old'],te)
        self.assertTrue(np.all((p>0)&(p<1)))
        self.assertAlmostEqual(p[0],3/5)

    def test_score_perfect(self):
        x=score(np.array([0.,1.]),np.array([0.01,0.99]))
        self.assertLess(x['logloss'],0.011)
        self.assertLess(x['brier'],0.00011)

    def test_session_loocv_eight_folds(self):
        res=leave_session_out(self.df)
        self.assertEqual(len(res['eight_session_folds']),8)
        self.assertEqual(res['n_prediction_records'],1280)
        self.assertEqual(len(res['candidate_models']),4)

    def test_exact_2520_assignments(self):
        self.assertEqual(sum(1 for _ in exact_balanced_session_assignments()),2520)

    def test_contrasts_correct(self):
        m={(0,0):0.,(0,1):2.,(1,0):1.,(1,1):4.}
        c=factorial_contrasts(m)
        self.assertAlmostEqual(c['high_minus_low'],1.5)
        self.assertAlmostEqual(c['social_minus_financial'],2.5)
        self.assertAlmostEqual(c['resource_by_punishment_interaction'],1.)

    def test_randomization_range(self):
        x=conditional_randomization(self.df)
        self.assertEqual(x['assignments'],2520)
        self.assertTrue(all(0<=v['two_sided_conditional_p']<=1 for v in x['statistics'].values()))

    def test_missing_file_fail_closed(self):
        with tempfile.TemporaryDirectory() as p:
            with self.assertRaisesRegex(SourceGateError,'Original DTA missing'):
                run(Path(p)/'alldata.dta')

    def test_fake_file_not_accepted_full(self):
        with tempfile.TemporaryDirectory() as p:
            f=Path(p)/'synthetic_fixture.dta'
            self.df.to_stata(f,write_index=False,version=118)
            with self.assertRaisesRegex(SourceGateError,'Published rows'):
                run(f)

    def test_incorrect_received_sanction_rejected(self):
        d=self.df.copy()
        i=d.index[(d.Round>1)&(d.strategyB_old==0)][0]
        d.loc[i,'badmess' if d.loc[i,'social']==1 else 'badpun']=1
        with self.assertRaisesRegex(SourceGateError,'inconsistent'):
            analysis_rows(d)

    def test_full_shape_synthetic_does_not_prove_origin(self):
        # Deliberately constructed data can satisfy published shapes. It must
        # never be labeled authenticated original research data.
        frame=self.df.copy()
        chunks=[frame]
        for s in range(1,9):
            addition=frame.loc[frame.sesid==s].copy()
            addition['Block']=2
            addition['Period']=addition['Period']+9
            chunks.append(addition)
        extra=frame.loc[frame.sesid==1].copy()
        extra['Block']=3
        extra['Period']=extra['Period']+18
        chunks.append(extra)
        fake=pd.concat(chunks,ignore_index=True)
        self.assertEqual(len(fake),3060)
        self.assertEqual(source_checks(fake,True)['subject_blocks'],340)
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'alldata.dta'
            fake.to_stata(path,write_index=False,version=118)
            result=run(path)
            self.assertEqual(result['publisher_authenticity'],
                             'NOT_VERIFIED_BY_SCHEMA_OR_SHA_ALONE')
            self.assertFalse(result['supplied_reference_sha256_matched'])
            self.assertEqual(len(result['session_held_out']['eight_session_folds']),8)
            self.assertEqual(result['session_randomization']['assignments'],2520)

    def test_supplied_wrong_sha_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'synthetic.dta'
            self.df.to_stata(path,write_index=False,version=118)
            with self.assertRaisesRegex(SourceGateError,'Source bytes differ'):
                run(path,expected_sha256='0'*64)


if __name__ == '__main__':
    unittest.main(verbosity=2)
