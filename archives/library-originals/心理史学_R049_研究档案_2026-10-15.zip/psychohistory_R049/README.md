# 心理史学 R049 研究包

这是另一个研究团队的**来源审计与严格检验准备包**。来源文件 `alldata.dta` 未取得，未进行真实样本回测。它不会捏造研究结果，也不会替代原始数据。

### 文件

- `R049_REPORT.md`：研究、来源、机制差异、17区块约束、识别边界。
- `r049_replay.py`：数据准入、跨区块时序检查、留一场次预测、条件随机化枚举。
- `test_r049.py`：24项构造数据测试。
- `SOURCE_LEDGER.json`：来源和取得状态。
- `R050_RESEARCH_GATE.md`：下一轮研究计划。
- `PROJECT_STATE_R049.md`：阶段接续状态。
- `VERIFICATION_STATUS.txt`：实际验证等级。

### 本地运行

需要 Python ≥3.10、pandas 和 NumPy。

```bash
python -m pip install pandas numpy
python -m unittest -v test_r049.py
python r049_replay.py --dta /path/to/alldata.dta --output R049_REPLAY_RESULTS.json
# 如果另有来源独立证明的发布方SHA256，还可加：
# --expected-sha256 <64位十六进制哈希>
```

运行前自行合法取得原作者 https://data.mendeley.com/datasets/c2z95m5gty/1 的 `alldata.dta`；程序不会联网下载，不会写入远程位置。只生成聚合统计结果。原始来源身份还需要独立核验，结构、字段以及自报SHA256均不足以证明发布方身份。不能把合成数据当作外部验证。
