#!/usr/bin/env python3
"""R049 independent experiment replication gate.

Input: author's original alldata.dta from Mendeley DOI 10.17632/c2z95m5gty.1.
Outputs only aggregated quality, cross-session prediction, and randomization results.
No downloaded or synthetic data are substituted for original experimental records.

Install: pip install pandas numpy
Usage: python r049_replay.py --dta /path/to/alldata.dta --output r049_results.json
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

REQUIRED = (
    "subject_id", "sesid", "Match", "Block", "Round", "Period",
    "strategyA", "strategyB", "strategyB_old", "low", "high",
    "financial", "social", "message", "punish", "badmess", "badpun",
    "countA", "countB",
)
LAMBDA = 8.0


class SourceGateError(ValueError):
    pass


def require(flag: bool, msg: str) -> None:
    if not flag:
        raise SourceGateError(msg)


def num(df: pd.DataFrame, cols: tuple[str, ...]) -> pd.DataFrame:
    for c in cols:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    return df


def source_checks(df: pd.DataFrame, strict: bool = True) -> dict[str, Any]:
    """Fail closed on mutually inconsistent schema, timing, and assignment.

    strict=True additionally enforces published full-source dimensions.
    """
    missing = [c for c in REQUIRED if c not in df.columns]
    require(not missing, f"Missing mandatory schema columns: {missing}")
    df = df.copy()
    num(df, REQUIRED)
    require(df[list(REQUIRED)].notna().any().all(), "At least one required field has no observed values")
    require(df["subject_id"].notna().all() and df["sesid"].notna().all(), "Missing IDs")
    require(df["Round"].notna().all() and (df["Round"] >= 1).all(), "Invalid Round")
    # Round is stated to be 1..9 within each block. Never infer prior history
    # by simply shifting subject_id rows across game/block boundaries.
    require((df["Round"] <= 9).all(), "Round exceeds the published nine-round block")
    for c in ("strategyA", "strategyB", "social", "financial", "low", "high"):
        require(df[c].isin([0, 1]).all(), f"Nonbinary or missing {c}")
    require((df["strategyA"] + df["strategyB"] == 1).all(), "Strategy A/B complement violated")
    require((df["social"] + df["financial"] == 1).all(), "Punishment-arm complement violated")
    require((df["low"] + df["high"] == 1).all(), "Inflow-arm complement violated")
    require((df["countA"] + df["countB"] == 10).all(), "Group strategy counts differ from 10")
    for k in ("message", "punish"):
        require(df[k].isin([0, 1]).all(), f"Nonbinary or missing {k}")
    require((df.loc[df["message"] == 1, "strategyA"] == 1).all(), "Message sent by high effort")
    require((df.loc[df["punish"] == 1, "strategyA"] == 1).all(), "Fine sent by high effort")
    require((df.loc[df["message"] == 1, "social"] == 1).all(), "Message sent under wrong treatment")
    require((df.loc[df["punish"] == 1, "financial"] == 1).all(), "Fine sent under wrong treatment")
    key = ["subject_id", "Match", "Block", "Round"]
    require(not df.duplicated(key).any(), "Duplicate subject/match/block/round records")
    subject_blocks = df.groupby(["subject_id", "Match", "Block"])["Round"]
    require((subject_blocks.size() == 9).all(), "A subject block does not contain exactly nine rounds")
    require((subject_blocks.nunique() == 9).all(), "A subject block has missing or repeated round numbers")
    require(df.groupby("subject_id")["sesid"].nunique().max() == 1, "Subject switches sessions")
    sess = df.groupby("sesid")
    # Assigned treatment must be constant throughout an entire session.
    for c in ("low", "high", "social", "financial"):
        require((sess[c].nunique() == 1).all(), f"Session varies on {c}")
    treatment = sess[["high", "social"]].first()
    cells = treatment.groupby(["high", "social"]).size()
    require(len(cells) == 4, "A treatment factorial cell is absent")
    if strict:
        require(len(df) == 3060, f"Published rows 3060, observed {len(df)}")
        require(df["subject_id"].nunique() == 160, "Published 160 unique subjects expected")
        require(df["sesid"].nunique() == 8, "Published 8 sessions expected")
        require((sess["subject_id"].nunique() == 20).all(), "A session lacks 20 subjects")
        require((cells == 2).all(), "Expected two sessions for each factorial cell")
        require(int((df["Round"] == 1).sum()) == 340, "Published 340 block-first observations expected")
        require(int(df["strategyB_old"].notna().sum()) == 2720, "Published 2720 lag outcomes expected")
    require(df.loc[df["Round"] == 1, "strategyB_old"].isna().all(),
            "First round of a block contains previous-round value: leakage risk")
    active = df.loc[df["Round"] > 1]
    require(active["strategyB_old"].isin([0, 1]).all(),
            "Nonfirst-round previous strategy missing or invalid")
    # Audit previous strategy at the individual/match/block level.
    lookup = df.set_index(key)["strategyB"]
    prior = []
    for row in active[key].itertuples(index=False, name=None):
        ix = (row[0], row[1], row[2], row[3] - 1)
        require(ix in lookup.index, "Missing previous round within subject/match/block")
        prior.append(float(lookup.loc[ix]))
    require(np.array_equal(np.asarray(prior), active["strategyB_old"].to_numpy(float)),
            "Provided lag action fails within-block check")
    return {
        "rows": int(len(df)), "subjects": int(df["subject_id"].nunique()),
        "sessions": int(df["sesid"].nunique()), "first_round_rows": int((df["Round"] == 1).sum()),
        "valid_lag_rows": int(active.shape[0]),
        "subject_blocks": int(subject_blocks.ngroups),
        "treatment_cell_sessions": {f"high={int(h)},social={int(s)}": int(n) for (h, s), n in cells.items()},
        "status": "PASS",
        "published_scope_enforced": strict,
    }


def analysis_rows(df: pd.DataFrame) -> pd.DataFrame:
    work = df.loc[df["Round"] > 1].copy()
    work["lag_sanction_received"] = np.where(work["social"] == 1, work["badmess"], work["badpun"])
    require(work["lag_sanction_received"].isin([0, 1]).all(),
            "Previous recipient sanction flag missing or nonbinary")
    require((work.loc[work["lag_sanction_received"] == 1, "strategyB_old"] == 1).all(),
            "Punished previous action inconsistent with high effort")
    return work


def smoothed_rate(train: pd.DataFrame, cols: list[str], test: pd.DataFrame) -> np.ndarray:
    """Prediction lookup with a fixed empirical prior; never reads test outcome."""
    p0 = (float(train["strategyB"].sum()) + 1) / (len(train) + 2)
    if not cols:
        return np.full(len(test), p0)
    tab = train.groupby(cols, dropna=False)["strategyB"].agg(["sum", "count"])
    table = {tuple(k) if isinstance(k, tuple) else (k,): (float(row["sum"]), float(row["count"]))
             for k, row in tab.iterrows()}
    out = []
    for values in test[cols].itertuples(index=False, name=None):
        s, n = table.get(tuple(values), (0.0, 0.0))
        out.append((s + LAMBDA * p0) / (n + LAMBDA))
    return np.asarray(out, dtype=float)


def score(y: np.ndarray, p: np.ndarray) -> dict[str, float]:
    require(len(y) and len(y) == len(p), "Invalid scoring sample")
    p = np.clip(p, 1e-12, 1-1e-12)
    return {
        "logloss": float(np.mean(-y*np.log(p) - (1-y)*np.log(1-p))),
        "brier": float(np.mean((p-y)**2)),
        "observed_rate": float(y.mean()),
        "predicted_rate": float(p.mean()),
    }


def leave_session_out(df: pd.DataFrame) -> dict[str, Any]:
    w = analysis_rows(df)
    specs = {
        "B0_global": [],
        "B1_prev_action": ["strategyB_old"],
        "B2_prev_action_plus_received_sanction": ["strategyB_old", "lag_sanction_received"],
        "B3_previous_plus_institution": ["strategyB_old", "lag_sanction_received", "high", "social"],
    }
    folds = []
    for sid in sorted(w["sesid"].unique()):
        tr = w.loc[w["sesid"] != sid]
        te = w.loc[w["sesid"] == sid]
        require(len(tr)>0 and len(te)>0, "Empty session-fold")
        y = te["strategyB"].to_numpy(float)
        metrics = {model: score(y, smoothed_rate(tr, cols, te)) for model, cols in specs.items()}
        folds.append({"session": int(sid), "n_test": int(len(te)), "high": int(te["high"].iloc[0]),
                      "social": int(te["social"].iloc[0]), "scores": metrics})
    avgs = {k: {metric: float(np.mean([f["scores"][k][metric] for f in folds]))
                for metric in ("logloss", "brier", "observed_rate", "predicted_rate")}
            for k in specs}
    diff = [f["scores"]["B2_prev_action_plus_received_sanction"]["logloss"]-
            f["scores"]["B1_prev_action"]["logloss"] for f in folds]
    return {
        "candidate_models": specs,
        "smoothing": {"lambda": LAMBDA, "global_prior": "(sum_train_y+1)/(n_train+2)"},
        "n_prediction_records": int(len(w)),
        "eight_session_folds": folds,
        "equal_session_weight_mean_scores": avgs,
        "incremental_received_sanction_logloss_B2_minus_B1": {
            "mean": float(np.mean(diff)), "session_deltas": [float(x) for x in diff],
            "sessions_improved": int(sum(x<0 for x in diff)),
        },
        "interpretation": "Retrospectively designed leave-one-session-out, not preregistered or causal validation",
    }


def factorial_contrasts(cell_means: dict[tuple[int, int], float]) -> dict[str, float]:
    # High vs low resource inflow, social vs financial, difference in differences.
    return {
        "high_minus_low": 0.5 * (cell_means[1, 0] + cell_means[1, 1] - cell_means[0, 0] - cell_means[0, 1]),
        "social_minus_financial": 0.5 * (cell_means[0, 1] + cell_means[1, 1] - cell_means[0, 0] - cell_means[1, 0]),
        "resource_by_punishment_interaction": ((cell_means[1, 1]-cell_means[0, 1]) -
                                               (cell_means[1, 0]-cell_means[0, 0])),
    }


def exact_balanced_session_assignments(n: int = 8):
    """Enumerate 8!/(2!^4) = 2520 equally sized allocations."""
    require(n == 8, "This test is defined for eight sessions")
    cells = ((0, 0), (0, 1), (1, 0), (1, 1))
    idx = tuple(range(n))
    for a in itertools.combinations(idx, 2):
        others1 = tuple(v for v in idx if v not in a)
        for b in itertools.combinations(others1, 2):
            others2 = tuple(v for v in others1 if v not in b)
            for c in itertools.combinations(others2, 2):
                d = tuple(v for v in others2 if v not in c)
                yield {cell: list(members) for cell, members in zip(cells, (a, b, c, d))}


def conditional_randomization(df: pd.DataFrame) -> dict[str, Any]:
    """Session-level sharp-null reference distribution, conditional on cell sizes.

    Descriptive only unless original allocation was exchangeable at session level.
    """
    sess = df.groupby("sesid").agg(rate=("strategyB", "mean"), high=("high", "first"), social=("social", "first"))
    require(len(sess) == 8, "Permutation test requires eight complete sessions")
    require((sess.groupby(["high", "social"]).size()==2).all(), "Requires two sessions per cell")
    vals = sess["rate"].to_numpy(float)
    labels = list(zip(sess["high"].astype(int), sess["social"].astype(int)))
    actual = {c: float(np.mean([v for v, lab in zip(vals,labels) if lab==c]))
              for c in ((0,0),(0,1),(1,0),(1,1))}
    obs = factorial_contrasts(actual)
    exceed = {k:0 for k in obs}
    nperm = 0
    for assignment in exact_balanced_session_assignments():
        cellmean = {cell: float(np.mean(vals[inds])) for cell, inds in assignment.items()}
        perm = factorial_contrasts(cellmean)
        for k in obs:
            exceed[k] += abs(perm[k]) >= abs(obs[k])-1e-12
        nperm += 1
    require(nperm==2520,"Allocation enumeration mismatch")
    return {
        "n_sessions": 8, "assignments": nperm,
        "statistics": {k:{"session_level_effect":float(v),"two_sided_conditional_p":exceed[k]/nperm}
                       for k,v in obs.items()},
        "assumption": "Complete exchangeability of session treatment assignment conditional on exactly 2 per cell",
        "warning": "Eight sessions, only two per treatment cell; no participant-level randomization inference",
    }


def run(path: Path, strict: bool=True, expected_sha256: str | None = None) -> dict[str, Any]:
    require(path.is_file(), f"Original DTA missing: {path}")
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if expected_sha256 is not None:
        require(len(expected_sha256) == 64 and all(ch in "0123456789abcdef" for ch in expected_sha256.lower()),
                "Expected SHA256 should be 64 hex characters")
        require(digest == expected_sha256.lower(), "Source bytes differ from expected SHA256")
    df = pd.read_stata(path, convert_categoricals=False)
    qc = source_checks(df, strict=strict)
    pred = leave_session_out(df)
    perm = conditional_randomization(df)
    return {
        "study": "Abatayo & Lynham (2023), Mendeley c2z95m5gty.1",
        "source_file": path.name,
        "source_sha256": digest,
        "source_bytes": path.stat().st_size,
        "local_stata_bytes_read": True,
        "schema_validation": "PASSED",
        "publisher_authenticity": "NOT_VERIFIED_BY_SCHEMA_OR_SHA_ALONE",
        "supplied_reference_sha256_matched": expected_sha256 is not None,
        "authenticity_note": "Verify source URL and publisher version independently; data shape or a self-supplied hash never establishes origin",
        "quality": qc,
        "session_held_out": pred,
        "session_randomization": perm,
        "model_policy": "PESEN v0.1 FROZEN",
        "independent_causal_psychological_mechanism": "UNIDENTIFIED",
    }


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--dta", type=Path, required=True, help="Original alldata.dta from Mendeley Data")
    ap.add_argument("--output", type=Path, required=True, help="Aggregate JSON results path")
    ap.add_argument("--expected-sha256", type=str, default=None,
                    help="Externally sourced expected SHA256, if available; still document provenance")
    args = ap.parse_args()
    result = run(args.dta, expected_sha256=args.expected_sha256)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False)+"\n",encoding="utf-8")
    print(f"DTA schema checked, publisher provenance requires independent verification: {result['source_sha256']} | JSON: {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
