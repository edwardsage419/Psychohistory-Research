#!/usr/bin/env python3
"""R010: recorded-signal social information analysis and identification diagnostics.

Run: python3 r010_analysis.py --demo
     python3 r010_analysis.py --main Data_Main.csv [--isolated Data_Isolated.csv]

Readme/provenance: DOI 10.6084/m9.figshare.12522527 (Jayles et al. 2020).
This script does NOT assume receipt of those files until explicitly supplied.
All tests and demonstration data are synthetic, generated with a fixed seed.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import math
import random
from collections import Counter
from pathlib import Path
from statistics import mean

DATA_URL = "https://figshare.com/articles/dataset/The_impact_of_incorrect_social_information_on_collective_wisdom_in_human_groups/12522527"
RESEARCH_DOI = "10.1098/rsif.2020.0496"
DATA_DOI = "10.6084/m9.figshare.12522527"


def _num(val):
    try:
        v = float(val)
        return v if math.isfinite(v) else None
    except (ValueError, TypeError):
        return None


def read_figshare(path: Path, kind: str = "main"):
    """Read source-positioned CSV columns from Figshare data page, without guessing names.

    main positional schema: alpha,rho,tau,question,truth,order,Ep,G,E2
    isolated positional schema: alpha,Ep,G,E2,truth,question
    An influencer (missing order) is counted separately and excluded.
    """
    if kind not in ("main", "isolated"):
        raise ValueError('kind must be main or isolated')
    items, reasons = [], Counter()
    with path.open(encoding='utf-8-sig', newline='') as fh:
        for line_no, cols in enumerate(csv.reader(fh), 1):
            if not cols or all(not c.strip() for c in cols):
                continue
            if len(cols) != (9 if kind == 'main' else 6):
                if line_no == 1 and any(c.isalpha() for c in cols[0]):
                    reasons['header_skipped'] += 1
                    continue
                reasons['bad_column_count'] += 1
                continue
            if kind == 'main':
                a,rho,tau,question,truth,order,ep,g,e2 = cols
                if _num(order) is None:
                    if line_no==1 and _num(a) is None:
                        reasons['header_skipped'] += 1
                    else:
                        reasons['no_order_or_influencer'] += 1
                    continue
                meta={'alpha':_num(a),'rho':_num(rho),'tau':_num(tau),'order':_num(order)}
            else:
                a,ep,g,e2,truth,question = cols
                meta={'alpha':_num(a),'rho':None,'tau':None,'order':None}
            ep, g, e2, truth = map(_num, (ep,g,e2,truth))
            if None in (ep,g,e2,truth) or min(ep,g,e2,truth) <= 0:
                if line_no == 1 and ep is None and g is None:
                    reasons['header_skipped'] += 1
                else:
                    reasons['invalid_nonpositive_or_missing'] += 1
                continue
            d = math.log(g/ep)
            y = math.log(e2/ep)
            if abs(d) < 1e-8:
                reasons['near_zero_signal_distance'] += 1
                continue
            items.append(dict(kind=kind,question=str(question).strip(),x=math.log(ep),
                              g=math.log(g),r=math.log(e2),truth=math.log(truth),
                              d=d,y=y,**meta))
    if not items:
        raise ValueError(f'No usable observations in {path}; rejected={dict(reasons)}')
    return items, dict(reasons)


def fit_model(observations, model):
    if not observations:
        raise ValueError('No training observations')
    if model=='M0_inertia':
        return {'model':model,'coefficients':{}}
    if model=='M1_constant_drift':
        return {'model':model,'coefficients':{'intercept':mean(r['y'] for r in observations)}}
    if model=='M2_signal_attraction':
        xx=sum(r['d']*r['d'] for r in observations)
        if xx < 1e-10: raise ValueError('No signal variation')
        return {'model':model,'coefficients':{'beta':sum(r['d']*r['y'] for r in observations)/xx}}
    if model=='M3_signed_asymmetry':
        pos=[r for r in observations if r['d']>0]
        neg=[r for r in observations if r['d']<0]
        if not pos or not neg: raise ValueError('Both signal directions required')
        return {'model':model,'coefficients':{
            'beta_up':fit_model(pos,'M2_signal_attraction')['coefficients']['beta'],
            'beta_down':fit_model(neg,'M2_signal_attraction')['coefficients']['beta']}}
    raise ValueError(f'Unknown model: {model}')


def predict(fit, record):
    co=fit['coefficients']; model=fit['model']; d=record['d']
    if model=='M0_inertia':return 0.0
    if model=='M1_constant_drift':return co['intercept']
    if model=='M2_signal_attraction':return co['beta']*d
    if model=='M3_signed_asymmetry':return (co['beta_up'] if d>0 else co['beta_down'])*d
    raise ValueError(model)


def cross_validate(observations, models=None):
    """Hold out entire questions; group leak prevention, descriptive OOS test.

    Question-level independence is not assumed, and this is not randomization inference.
    """
    if models is None: models=['M0_inertia','M1_constant_drift','M2_signal_attraction','M3_signed_asymmetry']
    questions=sorted({r['question'] for r in observations})
    if len(questions)<4:raise ValueError('At least four distinct questions required')
    out={}
    for model in models:
        total=0.0;n=0;folds=0
        for q in questions:
            train=[r for r in observations if r['question']!=q]
            test=[r for r in observations if r['question']==q]
            fitted=fit_model(train,model)
            total+=sum((r['y']-predict(fitted,r))**2 for r in test)
            n+=len(test);folds+=1
        out[model]={'holdout_question_mse':total/n,'n_predictions':n,'n_questions':folds}
    return out


def summarize(items, reasons, path, kind):
    fit={m:fit_model(items,m) for m in ('M0_inertia','M1_constant_drift','M2_signal_attraction','M3_signed_asymmetry')}
    cv=cross_validate(items)
    eligible=[r for r in items if abs(r['d'])>=0.05]
    bounded=[r for r in items if abs(r['d'])<=4 and abs(r['y'])<=4]
    with path.open('rb') as fh: sha=hashlib.sha256(fh.read()).hexdigest()
    res={'source_file':str(path),'source_sha256':sha,'dataset_kind':kind,
         'n_valid':len(items),'rejected_counts':reasons,'n_questions':len(set(x['question'] for x in items)),
         'fraction_toward_signal':(sum(r['d']*r['y']>0 for r in eligible)/len(eligible) if eligible else None),
         'median_ratio_not_reported':'Individual y/d unstable when signal distance is near zero',
         'fit_full_sample':fit,'holdout_question_cv':cv,
         'sensitivity_abs_log_dy_lte_4':{'n':len(bounded),'beta':fit_model(bounded,'M2_signal_attraction')['coefficients']['beta']} if bounded else None,
         'interpretation':'Associational response to a recorded signal; cannot identify Bayesian cognition or norms.'}
    return res


def generate_synthetic(n=12000, seed=20261014, beta=0.0):
    """Measurement-error counterexample with randomized displayed signal component.

    theta latent belief; x1 = theta+e1; G = theta+Z+u;
    x2 = theta+e2+beta*(G-x1). Thus under beta=0: no causal signal effect.
    Z independent random shift; ordinary y~d slope suffers shared baseline noise.
    """
    rng=random.Random(seed); out=[]
    for i in range(n):
        theta=rng.gauss(0,.8); e1=rng.gauss(0,.65);e2=rng.gauss(0,.65)
        z=.9 if rng.random()<.5 else -.9
        x=theta+e1;g=theta+z+rng.gauss(0,.15); d=g-x
        y=e2-e1+beta*d
        out.append({'question':str(i%20),'d':d,'y':y,'z':z})
    return out


def iv_ratio(rows):
    """Synthetic-only IV moment: valid only if Z exogenous and affects Y solely through D."""
    zbar=mean(r['z'] for r in rows);dbar=mean(r['d'] for r in rows);ybar=mean(r['y'] for r in rows)
    den=sum((r['z']-zbar)*(r['d']-dbar) for r in rows)
    if abs(den)<1e-10: raise ValueError('weak first stage')
    num=sum((r['z']-zbar)*(r['y']-ybar) for r in rows)
    return num/den


def demo():
    results={}
    for label,beta in [('no_causal_signal',0.0),('causal_signal_beta_0.35',0.35)]:
        rows=generate_synthetic(beta=beta)
        results[label]={'true_beta':beta,
                        'ordinary_signal_slope':fit_model(rows,'M2_signal_attraction')['coefficients']['beta'],
                        'randomized_shift_iv':iv_ratio(rows),
                        'question_holdout_cv':cross_validate(rows)}
    return {'status':'SYNTHETIC_ONLY','n_per_condition':12000,
            'demonstration':results,
            'warning':'IV requires randomized exclusion restriction, and can NOT be applied to real Figshare alpha/tau without verifying design.'}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--main',type=Path,help='Downloaded Figshare Data_Main.csv')
    parser.add_argument('--isolated',type=Path,help='Downloaded Figshare Data_Isolated.csv')
    parser.add_argument('--demo',action='store_true',help='Run reproducible SYNTHETIC identification example')
    parser.add_argument('--output',type=Path,help='JSON output; defaults to stdout')
    args=parser.parse_args()
    if not any((args.main,args.isolated,args.demo)):
        parser.error('Supply --main, --isolated or --demo. No real data is bundled.')
    result={'research_id':'R010','source_doi':DATA_DOI,'article_doi':RESEARCH_DOI}
    if args.demo: result['synthetic_identification']=demo()
    if args.main:
        data,rejected=read_figshare(args.main,'main')
        result['main_real_data']=summarize(data,rejected,args.main,'main')
    if args.isolated:
        data,rejected=read_figshare(args.isolated,'isolated')
        result['isolated_real_data']=summarize(data,rejected,args.isolated,'isolated')
    result['status']='REAL_DATA_PROCESSED' if args.main or args.isolated else 'SYNTHETIC_ONLY'
    txt=json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(txt+'\n',encoding='utf-8')
    else:print(txt)


if __name__=='__main__':main()
