# 心理史学 R010：真实信息暴露与伪社会学习识别反例

日期：2026-10-14。性质：**新真实数据定位与分析程序准备 + 已执行的合成识别压力测试**。PESEN 维持 v0.1，未新增已验证心理机制。

## 0. 本轮一句话结论

已定位到真正记录个体 `初始估计 Ep`、`显示的社会信息 G`、`修正估计 E2` 的公开实验数据，解决了 R009 的数据字段缺口。**本轮实际尝试下载失败，尚未取得这些记录的字节，因此没有对 Jayles 数据进行实证参数估计**。已经编写可运行的分析程序与 8 项测试，并独立运行 2 组各 12,000 条的合成因果识别反例。

## 1. 原始来源和许可

- Jayles, B., Escobedo, R., Cezera, S., Blanchet, A., Kameda, T., Sire, C., Theraulaz, G. (2020). *The impact of incorrect social information on collective wisdom in human groups*. *Journal of the Royal Society Interface* 17(170), 20200496. DOI: https://doi.org/10.1098/rsif.2020.0496
- 作者 Figshare 数据条目 DOI: https://doi.org/10.6084/m9.figshare.12522527 ； https://figshare.com/articles/dataset/The_impact_of_incorrect_social_information_on_collective_wisdom_in_human_groups/12522527
- 许可：Figshare 条目标记 CC BY 4.0。使用时需保留作者和来源署名。
- 源说明的主实验 `Data_Main.csv` 位置列：`alpha` 信息质量参数、`rho` 影响者比例、`tau` 信息来源数量、问题ID、真实值、回答顺序（影响者无值）、个人初始估计 Ep、展示的几何平均社会信息 G、第二次估计 E2。
- 源说明的孤立参与者实验 `Data_Isolated.csv` 六列：`alpha`、Ep、G、E2、真实值、问题ID。

本轮以 Figshare 数据页面与开放获取论文为可核验来源；该 Figshare 页面不是已经下载的实际数据文件。尝试在执行容器通过公开 ZIP 地址下载时失败（容器外网 DNS 受限）。**原始 `Data_Main.csv`、`Data_Isolated.csv` 均未获取，未计算真实样本量与真实系数**。

## 2. 预注册前的分析计划 v0.1（尚不能称已完成的论文复现）

只对 `Ep, G, E2, T` 为正且有效的记录取自然对数。剔除没有真实参与者回答顺序的虚拟影响者条目以及 `|log(G/Ep)| < 10^-8` 的数值不可辨认条目。保留每类排除数量。主分析不过滤极端值；次要敏感性检查限定 `|log(G/Ep)| <=4` 和 `|log(E2/Ep)|<=4`。后者是事先声明的操作阈值，尚无文献依据支持它是最合适阈值。

设 `d = log(G/Ep)`，`y = log(E2/Ep)`。

- M0 原判断保持：`y_hat=0`。
- M1 与社会信号无关的恒定漂移：`y_hat=c`。
- M2 单系数向信息靠拢：`y_hat=beta*d`。
- M3 有方向非对称：`y_hat=beta_up*d (d>0)` 或 `beta_down*d (d<0)`。

四个模型均比较**整道问题留出**的均方预测误差，并报告样本数、来源文件 SHA256、完整数据内的模型系数及事先声明的敏感性结果。这个留出单位可能仍无法捕获实验场次/组别相关性；如果原始数据补充具体场次，应优先采用其实际随机化/信息暴露单位进行统计推断。M2 和 M3 在有实验操纵时可以作为响应函数候选，不能自动证明心理的贝叶斯计算。

**特别注意**：已公开的数据字段说明没有个人独立测量的先验方差，也未保证记录每人后续各轮完整网络节点，因此无法在单一数据集内直接建立私人偏好、规范性预期或历史演化机制。

## 3. 合成反例：初始回答误差制造的假靠拢

让真实潜在判断 `theta ~ Normal(0,0.8²)`；初始回答 `x=theta+e1`、下一次回答基线 `theta+e2`，其中 `e1,e2 ~ Normal(0,0.65²)` 独立。实验操纵 `Z` 独立等概率取 `+0.9/-0.9`；显示信号 `g=theta+Z+u`，`u ~ Normal(0,0.15²)`。研究响应差异：

`d=g-x=Z+u-e1`

`y=(theta+e2+beta*d)-x=e2-e1+beta*d`

真实 `beta=0` 时，个体完全没有因信号改变其潜在判断，但回归 `y~d` 不加截距的总体斜率是

`beta_OLS = beta + Var(e1)/(Var(Z)+Var(u)+Var(e1))`

在当前设定下，伪斜率理论值为 `0.4225/(0.81+0.0225+0.4225)=0.33665`。原因是 `d` 与 `y` 都包含 `-e1`。合成实验的随机操纵 `Z` 是一个排除限制被刻意保证成立的工具变量：`Cov(Z,y)/Cov(Z,d) = beta`。真实世界不能未经论证使用 alpha、rho 或 tau 代替这里的 Z。

| 已知真值 beta | 样本量 | OLS | 随机操纵工具变量法 |
| ---: | ---: | ---: | ---: |
| 0.00 | 12,000 | 0.335275 | -0.000237 |
| 0.35 | 12,000 | 0.685275 | 0.349763 |

两组使用同一固定种子 `20261014`，结果来自 `python3 r010_analysis.py --demo --output synthetic_results.json`，可重复运行。

**绝不可将此结果称为 Jayles 研究中观察到的偏差或社会影响系数。**

## 4. 验证和限制

- 8 项本地 Python 单元测试全部通过，包括读取位置列、过滤无序号影响者、线性恢复、上下方向系数恢复、留题交叉验证边界及工具变量反例。
- 这些测试仅覆盖人工生成数据或手写的小样本 CSV，**尚未在源数据真实列值上完成兼容性检验**。
- 已执行 `--demo` 完整运行。没有对 Figshare 原始文件进行端到端运行，原因是数据文件尚未被下载到本地。
- 任何基于新真实数据的模型结果，在运行之前需要先核实来源版本、文件指纹、样本删除逻辑与实验分配方式。
- 四种候选规则都是短期数值判断响应模型。这里没有把它们认定为获得实证验证的心理学因果机制，更不能直接推广至规范变化或长期历史。

## 5. 在 Linux Mint 上接入真实文件

打开 Figshare 官方数据链接，在浏览器点击 `Download all`，将压缩包保存到本目录，解压并检查是否包含 `Data_Main.csv` 与 `Data_Isolated.csv`。若页面当前版本变动，应记录下载日期、文件名及许可。

或者在网络可用的终端尝试：

```bash
curl -fL 'https://figshare.com/ndownloader/articles/12522527/versions/1' -o figshare_12522527.zip
unzip -l figshare_12522527.zip
unzip -o figshare_12522527.zip -d source_data
sha256sum source_data/*.csv
python3 -m unittest discover -s tests -v
python3 r010_analysis.py --main source_data/Data_Main.csv --isolated source_data/Data_Isolated.csv --output r010_real_results.json
```

若下载路径、ZIP 内文件名或内容有差异，停止并人工检查，**不要默默当作相同数据版本**。程序输入数据来自原始 Figshare 文件，不应手工把生成的模拟数据复制为真实数据文件。

## 6. 项目决策和后续

- 对 R009 的实际新进展：候选真实数据来源已从“同组均值代理”转向直接记录 `G` 的来源；识别风险已从仅有“共同因素与自然回归”扩大到**被解释变量和自变量共享初始测量误差**。
- PESEN v0.1 冻结，不增添新机制。
- R011 优先完成真实 Figshare CSV 获取、核实操纵程序与潜在实验单元、成功运行此脚本；随后采用独立数据比较 M0 至 M3，并尝试找出自然均值回归的有效实验基线。需要确认是否真实存在满足工具变量识别假设的随机化信号。
