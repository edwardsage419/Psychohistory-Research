import sys, tempfile, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import r010_analysis as m

class TestR010(unittest.TestCase):
    def test_signal_linear_recovery(self):
        a=[dict(question=str(i%6),d=(-1)**i*(i+2)/100.0,y=.42*((-1)**i)*(i+2)/100.0) for i in range(120)]
        f=m.fit_model(a,'M2_signal_attraction')
        self.assertAlmostEqual(f['coefficients']['beta'],.42,places=8)
        self.assertLess(m.cross_validate(a)['M2_signal_attraction']['holdout_question_mse'],1e-18)
    def test_signed_asymmetric_recovery(self):
        a=[dict(question=str(i%6),d=(-1)**i*((i%8)+1),y=((-1)**i*((i%8)+1))*(.7 if i%2==0 else .1)) for i in range(120)]
        f=m.fit_model(a,'M3_signed_asymmetry')
        self.assertAlmostEqual(f['coefficients']['beta_up'],.7,places=8)
        self.assertAlmostEqual(f['coefficients']['beta_down'],.1,places=8)
    def test_invalid_rows_and_influencers_are_excluded(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'Data_Main.csv'
            p.write_text('1,10,3,Q1,100,1,20,40,30\n1,10,3,Q1,100,,20,40,30\n1,10,3,Q2,100,3,0,40,20\n',encoding='utf8')
            rows,c=m.read_figshare(p)
            self.assertEqual(len(rows),1)
            self.assertEqual(c['no_order_or_influencer'],1)
            self.assertEqual(c['invalid_nonpositive_or_missing'],1)
    def test_header_and_isolated_schema(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'Data_Isolated.csv'
            p.write_text('alpha,ep,g,e2,truth,q\n1,15,20,17,18,7\n',encoding='utf8')
            rows,c=m.read_figshare(p,'isolated')
            self.assertEqual(len(rows),1)
            self.assertEqual(c['header_skipped'],1)
    def test_no_causal_signal_mechanical_slope(self):
        a=m.generate_synthetic(n=12000,beta=0.0)
        ols=m.fit_model(a,'M2_signal_attraction')['coefficients']['beta']
        iv=m.iv_ratio(a)
        self.assertGreater(ols,.2)
        self.assertLess(abs(iv),.06)
    def test_causal_signal_iv_recovery(self):
        a=m.generate_synthetic(n=12000,beta=.35)
        iv=m.iv_ratio(a)
        self.assertAlmostEqual(iv,.35,delta=.06)
    def test_cv_blocks_question(self):
        data=[dict(question=str(i%3),d=i+1.0,y=.1*(i+1)) for i in range(12)]
        with self.assertRaisesRegex(ValueError,'At least four'):m.cross_validate(data)
    def test_empty_data_fails(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'empty.csv';p.write_text('alpha,ep,g,e2,truth,q\n')
            with self.assertRaisesRegex(ValueError,'No usable observations'):
                m.read_figshare(p,'isolated')

if __name__=='__main__':unittest.main()
