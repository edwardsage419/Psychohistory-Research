import datetime as dt
import json
import math
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import r034_analysis as m


def constructed_ledger():
    # SYNTHETIC, not drawn from the Figshare XLSX. Choose 9,10,10 randomized periods.
    pattern=['positive']*9+['negative']*10+['control']*10
    invalid_needed={'positive':2,'negative':4,'control':4}
    rows=[]; ix=0
    for b,g in enumerate(pattern):
        for j in range(3):
            valid=invalid_needed[g]==0
            if not valid:invalid_needed[g]-=1
            rows.append({'date':str(dt.date(2019,6,24)+dt.timedelta(days=ix)),
                         'period_id':'period_'+str(b),'treatment':g,
                         'is_valid':valid,'drinks':100 if valid else None,
                         'straws':10 if valid else None})
            ix+=1
    # Allocate group totals to exactly match the corrected table while ratios are synthetic.
    by={g:[r for r in rows if r['treatment']==g and r['is_valid']] for g in pattern[:1]+pattern[9:10]+pattern[19:20]}
    for g,rs in by.items():
        n=len(rs); D=m.PUBLISHED[g]['drinks']; S=m.PUBLISHED[g]['straws']
        for i,r in enumerate(rs):
            r['drinks']=D//n+(i<D%n)
            r['straws']=S//n+(i<S%n)
    return rows

class TestR034(unittest.TestCase):
    def test_calendar_discrepancy(self):self.assertEqual(m.calendar_audit()['unresolved_gap_days'],2)
    def test_planned_periods(self):self.assertEqual(len(m.planned_period_allocations()),6)
    def test_period_sums(self):
        for x in m.planned_period_allocations():
            self.assertEqual(sum(x['periods'].values()),29)
            self.assertEqual(sum(x['missing_days'].values()),10)
    def test_six_missing_patterns(self):
        allocations=[tuple(a['missing_days'][g] for g in ('positive','negative','control')) for a in m.planned_period_allocations()]
        self.assertEqual(set(allocations),{(2,1,7),(2,4,4),(2,7,1),(5,1,4),(5,4,1),(8,1,1)})
    def test_unrestricted_bounds(self):
        b=m.weak_bounds()
        self.assertAlmostEqual(b['lower'],-.291)
        self.assertAlmostEqual(b['upper'],.193)
    def test_conditional_lower(self):self.assertAlmostEqual(m.period_bounds()['lower'],-.24485858585858586)
    def test_conditional_upper(self):self.assertAlmostEqual(m.period_bounds()['upper'],.16088552188552194)
    def test_both_intervals_include_zero(self):
        for b in [m.weak_bounds(),m.period_bounds()]:self.assertLess(b['lower'],0);self.assertGreater(b['upper'],0)
    def test_upper_cannot_be_below_observed_group_mean(self):
        with self.assertRaises(ValueError):m.contrast_range({'positive':0,'control':0},.1)
    def test_zero_missing(self):
        b=m.weak_bounds(0);self.assertAlmostEqual(b['lower'],-.061);self.assertEqual(b['lower'],b['upper'])
    def test_weak_widens_with_missing(self):
        self.assertLess(m.weak_bounds(10)['lower'],m.weak_bounds(5)['lower'])
        self.assertGreater(m.weak_bounds(10)['upper'],m.weak_bounds(5)['upper'])
    def test_upper_sensitivity(self):
        b=m.period_bounds(.3);self.assertLessEqual(b['upper'],m.period_bounds(1)['upper'])
        self.assertGreaterEqual(b['lower'],m.period_bounds(1)['lower'])
    def test_invalid_missing_count(self):
        with self.assertRaises(ValueError):m.weak_bounds(-1)
    def test_parse_dates(self):
        self.assertEqual(m.parse_date('2019-06-24'),dt.date(2019,6,24))
        self.assertEqual(m.parse_date('24/06/2019'),dt.date(2019,6,24))
        self.assertEqual(m.parse_date(dt.date(2019,6,24)),dt.date(2019,6,24))
    def test_excel_serial_date(self):
        self.assertEqual(m.parse_date((dt.date(2019,6,24)-dt.date(1899,12,30)).days),dt.date(2019,6,24))
    def test_bad_date(self):
        with self.assertRaises(ValueError):m.parse_date('year 2019')
    def test_missing_original_period(self):
        rows=constructed_ledger();rows[0]['period_id']=None
        with self.assertRaises(ValueError):m.validate_daily_records(rows)
    def test_wrong_2018_date(self):
        rows=constructed_ledger();rows[0]['date']='2018-06-24'
        with self.assertRaises(ValueError):m.validate_daily_records(rows)
    def test_duplicate_date(self):
        rows=constructed_ledger();rows[1]['date']=rows[0]['date']
        with self.assertRaises(ValueError):m.validate_daily_records(rows)
    def test_wrong_valid_status_type(self):
        rows=constructed_ledger();rows[3]['is_valid']='yes'
        with self.assertRaises(ValueError):m.validate_daily_records(rows)
    def test_changed_assignment_inside_period(self):
        rows=constructed_ledger();rows[1]['treatment']='control'
        with self.assertRaises(ValueError):m.validate_daily_records(rows)
    def test_missing_ledger_row(self):
        rows=constructed_ledger()[:-1]
        with self.assertRaises(ValueError):m.validate_daily_records(rows)
    def test_bad_corrected_totals(self):
        rows=constructed_ledger();next(r for r in rows if r['is_valid'])['drinks']+=1
        with self.assertRaises(ValueError):m.validate_daily_records(rows)
    def test_constructed_valid_ledger(self):
        rows=constructed_ledger();by,blocks,bad=m.validate_daily_records(rows)
        self.assertEqual(sum(len(x) for x in by.values()),77)
        self.assertEqual(len(blocks),29);self.assertEqual(len(bad),10)
        result=m.summarize_validated(by,blocks,bad)
        self.assertEqual(result['stage'],'END_TO_END_XLSX_VALIDATED')
        self.assertNotIsInstance(result['effect_equal_observed_period_means'],str)
    def test_output_stage_summary_only(self):
        obj=m.summary_audit()
        self.assertFalse(obj['figshare']['original_workbook_local_read'])
        self.assertIn('ONLY',obj['stage'])
        self.assertIsNone(obj['figshare']['original_file_sha256'])
    def test_source_exact_file_id(self):self.assertEqual(m.summary_audit()['figshare']['file_id'],31324114)
    def test_negative_straws_fails(self):
        rows=constructed_ledger();next(r for r in rows if r['is_valid'])['straws']=-1
        with self.assertRaises(ValueError):m.validate_daily_records(rows)
    def test_xlsx_parser_on_constructed_fixture(self):
        from artifact_tool import Workbook, SpreadsheetFile
        rows=constructed_ledger()
        wb=Workbook.create();sh=wb.worksheets.add('Synthetic2019')
        headers=['date','treatment','drinks','straws','is_valid','period_id']
        sheet_rows=[headers]+[[str(x['date']),x['treatment'],x['drinks'],x['straws'],
                               'yes' if x['is_valid'] else 'no',x['period_id']] for x in rows]
        sh.get_range('A1:F88').values=sheet_rows
        cfg={'sheet':'Synthetic2019','range':'A1:F88','header_rows':1,
             'columns':dict(zip(headers,range(6))),
             'conditions':{'positive':'positive','negative':'negative','control':'control'},
             'valid_values':['yes'],'invalid_values':['no']}
        with tempfile.TemporaryDirectory() as temp:
            f=Path(temp)/'SYNTHETIC_NOT_ORIGINAL.xlsx'
            SpreadsheetFile.export_xlsx(wb).save(str(f))
            read=m.ingest_xlsx(f,cfg)
            self.assertEqual(len(read),87)
            by,blocks,bad=m.validate_daily_records(read)
            self.assertEqual(len(blocks),29)
            self.assertEqual(len(bad),10)
            self.assertEqual(len(by['positive']),25)

    def test_observed_valid_day_gate(self):
        rows=constructed_ledger()
        subset=[{k:v for k,v in r.items() if k!='period_id'} for r in rows if r['is_valid']]
        res=m.validate_valid_days_only(subset)
        self.assertEqual(res['n_valid_daily_rows'],77)
        self.assertFalse(res['original_period_assignment_validated'])
    def test_valid_day_gate_rejects_unmatched_drink_totals(self):
        rows=[r for r in constructed_ledger() if r['is_valid']]
        rows[0]['drinks']+=1
        with self.assertRaises(ValueError):m.validate_valid_days_only(rows)
    def test_undocumented_missing_days_fail_audit(self):
        rows=[r for r in constructed_ledger() if r['is_valid']][:-1]
        with self.assertRaises(ValueError):m.validate_valid_days_only(rows)

    def test_empty_fails(self):
        with self.assertRaises(ValueError):m.validate_daily_records([])

if __name__=='__main__':unittest.main()
