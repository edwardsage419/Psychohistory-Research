#!/usr/bin/env python3
"""R034. Published-summaries missing-day bounds; optional strict XLSX gate.

Daily original Figshare workbook NOT obtained as of 2026-10-14.
Never label constructed/test data as empirical replication.
Dependencies: Python stdlib for summary analysis; artifact_tool for --workbook only.
"""
import argparse
import datetime as dt
import hashlib
import json
import math
from pathlib import Path

PUBLISHED = {
    'positive': {'n':25, 'mean':0.111, 'sd':0.045, 'drinks':3888, 'straws':431},
    'negative': {'n':26, 'mean':0.152, 'sd':0.076, 'drinks':3611, 'straws':548},
    'control': {'n':26, 'mean':0.172, 'sd':0.094, 'drinks':3847, 'straws':618}
}
EXPECTED = {'total_periods':29,'period_days':3,'planned_days':87,'valid_days':77,'lost_days':10,
            'drinks':11346,'straws':1597}
PAPER = 'https://doi.org/10.1371/journal.pone.0261734'
CORRECTION = 'https://doi.org/10.1371/journal.pone.0303709'
DATA = 'https://doi.org/10.6084/m9.figshare.15134754.v1'
DOWNLOAD = 'https://figshare.com/ndownloader/files/31324114'


def calendar_audit():
    start=dt.date(2019,6,24); end=dt.date(2019,9,20)
    return {'paper_start':str(start),'paper_end':str(end),
            'inclusive_calendar_days':(end-start).days+1,
            'paper_scheduled_days':87,
            'unresolved_gap_days':(end-start).days+1-87,
            'interpretation':'Calendar span discrepancy only; nonoperating dates not observed'}


def planned_period_allocations(groups=PUBLISHED, periods=29, days_per_period=3):
    """Enumerate feasible planned arm-period counts given reported observed days.

    Assumptions: all 29 scheduled message periods have exactly 3 operating days,
    each period has one assigned treatment, no missing records outside ten errors.
    The paper's 89-calendar-day endpoint gap means these require independent validation.
    """
    arms=('positive','negative','control')
    minima=[math.ceil(groups[g]['n']/days_per_period) for g in arms]
    solutions=[]
    for p in range(minima[0],periods+1):
        for n in range(minima[1],periods-p+1):
            c=periods-p-n
            if c<minima[2]:continue
            alloc=dict(zip(arms,(p,n,c)))
            missing={k:alloc[k]*days_per_period-groups[k]['n'] for k in arms}
            if sum(missing.values())!=EXPECTED['lost_days'] or min(missing.values())<0:
                continue
            solutions.append({'periods':alloc,'missing_days':missing})
    return solutions


def contrast_range(missing, upper=1., groups=PUBLISHED):
    """Sharp algebraic bounds conditional on arm missing counts and 0<=daily ratio<=upper.
    Requires all planned days to have well-defined ratios; upper is an assumption.
    """
    if not (math.isfinite(upper) and upper>=max(x['mean'] for x in groups.values())):
        raise ValueError('Ratio upper bound must be >= reported means and finite')
    P,C=groups['positive'],groups['control']
    p,c=missing['positive'],missing['control']
    if p<0 or c<0:raise ValueError('Negative missing-day count')
    lo=P['n']*P['mean']/(P['n']+p) - (C['n']*C['mean']+c*upper)/(C['n']+c)
    hi=(P['n']*P['mean']+p*upper)/(P['n']+p) - C['n']*C['mean']/(C['n']+c)
    return (lo,hi)


def weak_bounds(lost=10,upper=1.):
    """All allocations of missing days, including allocation to the third arm."""
    if not isinstance(lost,int) or lost<0:raise ValueError('lost should be a nonnegative integer')
    cases=[]
    for p in range(lost+1):
        for c in range(lost-p+1):
            m={'positive':p,'control':c,'negative':lost-p-c}
            lo,hi=contrast_range(m,upper=upper)
            cases.append((lo,hi,m))
    l=min(cases,key=lambda x:x[0]);u=max(cases,key=lambda x:x[1])
    return {'lower':l[0],'upper':u[1], 'lower_allocation':l[2],
            'upper_allocation':u[2], 'allocation_count':len(cases)}


def period_bounds(upper=1.):
    cases=[]
    for a in planned_period_allocations():
        lo,hi=contrast_range(a['missing_days'],upper)
        cases.append({**a,'lower':lo,'upper':hi})
    low=min(cases,key=lambda x:x['lower']);hi=max(cases,key=lambda x:x['upper'])
    return {'lower':low['lower'],'upper':hi['upper'],
            'lower_case':low,'upper_case':hi,
            'feasible_cases':cases}


def summary_audit():
    assert sum(x['n'] for x in PUBLISHED.values())==77
    assert sum(x['drinks'] for x in PUBLISHED.values())==11346
    assert sum(x['straws'] for x in PUBLISHED.values())==1597
    allocations=planned_period_allocations()
    assert len(allocations)==6
    return {'stage':'PUBLISHED_SUMMARY_BOUNDS_ONLY',
            'source_urls':{'paper':PAPER,'correction':CORRECTION,'data':DATA,'file_download':DOWNLOAD},
            'figshare':{'file_id':31324114,'file_name':'StrawStudyData_FigShare.xlsx',
                        'original_workbook_local_read':False,'official_remote_sha256_verified':False,'original_file_sha256':None},
            'reported_groups':PUBLISHED,'calendar':calendar_audit(),
            'observed_positive_minus_control':PUBLISHED['positive']['mean']-PUBLISHED['control']['mean'],
            'unrestricted_missing_day_bounds':weak_bounds(),
            'three_day_period_conditional_bounds':period_bounds(),
            'assumptions':['daily straw/drink ratio lies in [0,1] for ALL days including failed days',
                           'missing-day allocation may depend on treatment and outcomes',
                           '29x3 periods analysis further assumes every planned period has exactly three days',
                           'published three-decimal mean ratios used as exact inputs for bounds'],
            'not_verified':['actual Excel bytes','sheets/column dictionary','original 29 treatment-period allocation','10 error-day dates and labels','2-day calendar-span difference','experimental ICC / time series','original randomization protocol'],
            'claims_forbidden':['original-daily-data-replication','causal missingness corrected effect','estimated ICC','confirmed social sanction mechanism']}


def parse_date(x):
    if isinstance(x,dt.datetime):return x.date()
    if isinstance(x,dt.date):return x
    if isinstance(x,(float,int)) and not isinstance(x,bool) and math.isfinite(x):
        return (dt.datetime(1899,12,30)+dt.timedelta(days=float(x))).date()
    s=str(x).strip()
    for fmt in ('%Y-%m-%d','%Y/%m/%d','%d/%m/%Y','%m/%d/%Y'):
        try:return dt.datetime.strptime(s,fmt).date()
        except ValueError:continue
    raise ValueError(f'Unrecognized date {s!r}. Explicit canonical mapping needed.')


def validate_daily_records(records):
    """Strict fail-closed validation of externally mapped records; no original available.

    Each mapped dict: date, treatment in positive/negative/control, drinks, straws,
    is_valid boolean, and **observed original** period_id (not imputed).
    """
    if not records:raise ValueError('Empty records')
    dayset=set();blocks={};by={'positive':[],'negative':[],'control':[]};invalid=[]
    for idx,r in enumerate(records):
        for k in ('date','treatment','is_valid','period_id'):
            if k not in r:raise ValueError(f'row {idx}: missing required {k}')
        date=parse_date(r['date'])
        if date.year!=2019:raise ValueError(f'row {idx}: not year 2019')
        if date in dayset:raise ValueError('Duplicate date in daily data')
        dayset.add(date)
        g=r['treatment'];pid=r['period_id']
        if g not in by:raise ValueError(f'Unknown condition {g!r}')
        if pid in (None,''):raise ValueError('Missing ORIGINAL randomization-period ID')
        if type(r['is_valid']) is not bool:raise ValueError('is_valid must be an explicit bool')
        b=blocks.setdefault(str(pid),{'treatment':g,'dates':[],'ratios':[]})
        if b['treatment']!=g:raise ValueError('Treatment changed within a randomized period')
        b['dates'].append(date)
        if len(b['dates'])>3:raise ValueError('More than three dates for a period')
        if not r['is_valid']:
            invalid.append({'date':str(date),'treatment':g,'period_id':str(pid)})
            continue
        try:drinks=float(r['drinks']);straws=float(r['straws'])
        except (TypeError,ValueError):raise ValueError('Invalid valid-day counts')
        if not drinks.is_integer() or not straws.is_integer() or drinks<=0 or straws<0:
            raise ValueError('Counts must be integer, nonnegative, drinks > 0 on valid day')
        ratio=straws/drinks
        # Ratio >1 is not automatically rejected; missing-data [0,1] bound then not applicable
        rec={'date':str(date),'drinks':int(drinks),'straws':int(straws),
             'ratio':ratio,'period_id':str(pid)}
        by[g].append(rec);b['ratios'].append(ratio)
    # Do not silently declare a complete replication if source excludes failed days.
    if len(records)!=87 or len(invalid)!=10:
        raise ValueError('Observed daily ledger does not enumerate all 87 intended days / 10 errors; source audit incomplete')
    if len(blocks)!=29:
        raise ValueError('Observed period IDs do not establish 29 randomized periods')
    if any(len(b['dates'])!=3 for b in blocks.values()):
        raise ValueError('Each 3-day period must have three ledger dates')
    # Crucial: compare against 2024 corrected totals, independent of row rates.
    for g,expected in PUBLISHED.items():
        if len(by[g])!=expected['n'] or sum(x['drinks'] for x in by[g])!=expected['drinks'] or sum(x['straws'] for x in by[g])!=expected['straws']:
            raise ValueError(f'Corrected 2024 published-group totals mismatch for {g}')
    return by,blocks,invalid



def validate_valid_days_only(records):
    """Validate 77 published non-error days from the workbook, without period claims.

    This mode is useful when Excel contains only the 77 analyzed dates or does
    not include the actual assignment-period ledger. Keeps the original unit
    issue unresolved while allowing an honest original-date descriptive check.
    """
    groups={'positive':[],'negative':[],'control':[]}
    all_dates=set()
    skipped=0
    for i,r in enumerate(records):
        d=parse_date(r['date'])
        if d.year!=2019:raise ValueError('Unexpected year in explicit study-2019 range')
        if d in all_dates:raise ValueError('Duplicate date')
        all_dates.add(d)
        g=r['treatment']
        if g not in groups:raise ValueError('Unrecognized treatment')
        if r.get('is_valid',True) is False:
            skipped+=1
            continue
        try:a=float(r['drinks']);b=float(r['straws'])
        except (TypeError,ValueError):raise ValueError('Missing or malformed valid-day counts')
        if not (a>0 and b>=0 and a.is_integer() and b.is_integer()):
            raise ValueError('Daily count must be integer with drinks>0 and straws>=0')
        groups[g].append({'date':str(d),'drinks':int(a),'straws':int(b),'ratio':b/a})
    if sum(map(len,groups.values()))!=77:
        raise ValueError('Analyzed 2019 dates must be 77 to match corrected paper')
    for g,v in groups.items():
        e=PUBLISHED[g]
        if len(v)!=e['n'] or sum(x['drinks'] for x in v)!=e['drinks'] or sum(x['straws'] for x in v)!=e['straws']:
            raise ValueError(f'Corrected Table3 count check failed: {g}')
    return {'stage':'ORIGINAL_DAILY_OBSERVED_ONLY_PERIOD_INFERENCE_BLOCKED',
            'n_valid_daily_rows':77,'n_other_invalid_rows_explicitly_flagged':skipped,
            'original_period_assignment_validated':False,
            'groups':{g:{'n_valid':len(v),
                         'mean_daily_ratio':sum(r['ratio'] for r in v)/len(v),
                         'pooled_total_ratio':sum(r['straws'] for r in v)/sum(r['drinks'] for r in v)}
                      for g,v in groups.items()},
            'note':'Not a randomization inference; 10 missing-day allocation and 29 periods unresolved.'}

def summarize_validated(by,blocks,invalid):
    """Descriptive periodic contrast only. Original allocation mechanism unverified."""
    group={}
    for name,rs in by.items():
        daymean=sum(x['ratio'] for x in rs)/len(rs)
        totalratio=sum(x['straws'] for x in rs)/sum(x['drinks'] for x in rs)
        group[name]={'n':len(rs),'daily_mean':daymean,'pooled_ratio':totalratio}
    period_groups={g:[] for g in group}
    for pid,b in blocks.items():
        if len(b['ratios']):period_groups[b['treatment']].append(sum(b['ratios'])/len(b['ratios']))
    if not period_groups['positive'] or not period_groups['control']:
        raise ValueError('No effective periods in primary groups')
    period_est=sum(period_groups['positive'])/len(period_groups['positive']) - sum(period_groups['control'])/len(period_groups['control'])
    return {'stage':'END_TO_END_XLSX_VALIDATED',
            'n_daily_records':sum(len(x) for x in by.values())+len(invalid),
            'n_randomized_periods':len(blocks),
            'invalid_days':invalid,
            'groups':group,
            'effect_equal_daily_means':group['positive']['daily_mean']-group['control']['daily_mean'],
            'effect_pooled_transactions':group['positive']['pooled_ratio']-group['control']['pooled_ratio'],
            'effect_equal_observed_period_means':period_est,
            'period_counts':{k:len(v) for k,v in period_groups.items()},
            'randomization_p':'NOT_ESTIMATED_ALLOCATION_LOG_AND_MISSINGNESS_PROCESS_NEEDED',
            'note':'Period-level estimate is DESCRIPTIVE because treatment-dependent exclusions may bias randomization comparisons.'}


def ingest_xlsx(path, schema):
    """Read one official workbook via artifact_tool. Explicit index mapping required.

    schema example: {"sheet":"2019","range":"A1:Q150","columns":{"date":0,"treatment":1,
    "drinks":2,"straws":3,"is_valid":4,"period_id":5},
    "conditions":{"N4":"positive","N3":"negative","Control":"control"},
    "valid_values":["yes",1,true], "invalid_values":["no",0,false], "header_rows":1}
    Validity and period columns may be omitted for a 77-day descriptive audit.
    Omitting them permanently blocks 29-period randomization analysis.

    User must inspect source and supply mapping. Never infer or backfill period IDs.
    """
    from artifact_tool import Blob, SpreadsheetFile
    if not isinstance(schema,dict) or not all(k in schema for k in ('sheet','range','columns','conditions')):
        raise ValueError('Explicit XLSX schema incomplete')
    required={'date','treatment','drinks','straws'}
    if not required.issubset(schema['columns']):raise ValueError('Missing column mapping')
    if not path.exists():raise FileNotFoundError(path)
    wb=SpreadsheetFile.import_xlsx(Blob.load(str(path)))
    sheet=wb.worksheets.get_item(schema['sheet'])
    arr=sheet.get_range(schema['range']).values
    if not arr:raise ValueError('Empty sheet')
    data=arr[int(schema.get('header_rows',1)):]
    result=[]
    for row in data:
        if not row or all(v is None or str(v).strip()=='' for v in row):continue
        record={k:row[i] for k,i in schema['columns'].items()}
        c=str(record['treatment']).strip()
        if c not in schema['conditions']:raise ValueError(f'Unmapped original treatment label {c!r}')
        record['treatment']=schema['conditions'][c]
        if 'is_valid' in record:
            if 'valid_values' not in schema or 'invalid_values' not in schema:
                raise ValueError('Validity field mapping requires valid_values and invalid_values')
            v=record['is_valid']
            if v in schema['valid_values']:record['is_valid']=True
            elif v in schema['invalid_values']:record['is_valid']=False
            else:raise ValueError(f'Unmapped validity status {v!r}')
        else:record['is_valid']=True  # only reported valid rows can be audited
        result.append(record)
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,default=Path(__file__).parent/'R034_RESULT.json')
    p.add_argument('--workbook',type=Path,help='Optional locally acquired original Figshare XLSX')
    p.add_argument('--schema',type=Path,help='Required with --workbook: manually checked explicit mapping')
    args=p.parse_args()
    obj=summary_audit()
    if args.workbook or args.schema:
        if not args.workbook or not args.schema:raise SystemExit('Both --workbook and --schema are required')
        mapped=json.loads(args.schema.read_text('utf-8'))
        records=ingest_xlsx(args.workbook,mapped)
        observed=validate_valid_days_only(records)
        obj['new_actual_xlsx_results']={'valid_days_descriptive':observed}
        obj['figshare']['original_workbook_local_read']=True
        obj['figshare']['original_file_sha256']=hashlib.sha256(args.workbook.read_bytes()).hexdigest()
        obj['stage']='ORIGINAL_XLSX_VALID_DAY_DESCRIPTIVE_ONLY'
        if all(r.get('period_id') not in (None,'') for r in records):
            if len(records)==87 and sum(r['is_valid'] is False for r in records)==10:
                groups,blocks,invalid=validate_daily_records(records)
                obj['new_actual_xlsx_results']['period_descriptive']=summarize_validated(groups,blocks,invalid)
                obj['stage']='ORIGINAL_XLSX_DAILY_AND_PERIOD_DESCRIPTIVE'
            else:
                obj['new_actual_xlsx_results']['period_gate']='BLOCKED_INCOMPLETE_87_DAY_LOG'
        else:
            obj['new_actual_xlsx_results']['period_gate']='BLOCKED_MISSING_ORIGINAL_PERIOD_IDS'
    args.output.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('R034_DONE',obj['stage'],str(args.output))

if __name__=='__main__':main()
