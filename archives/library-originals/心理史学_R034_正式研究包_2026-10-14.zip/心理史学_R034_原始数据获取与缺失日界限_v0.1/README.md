# R034 正式研究包

日期：2026-10-14。本包只用 Salazar et al. 2021论文与2024勘误公布的汇总数据，推导了错误日的条件性可行区间。**未获得 Figshare 原始每日Excel，也未复现真实29个随机化时段。**

## 无外部依赖复算

```bash
python r034_analysis.py --output R034_RESULT.json
python -m unittest discover -s tests -v
```

32项测试应通过，其中1项使用自行构造的模拟 Excel 校验 artifact_tool 导入。**测试数据不是论文真实记录。**

## 如以后合法取得Excel

官方页面：https://figshare.com/articles/dataset/Straw_Experiment_Dataset/15134754
直接下载入口：https://figshare.com/ndownloader/files/31324114
文件名：StrawStudyData_FigShare.xlsx。需对其实际工作表/列名/处理编码进行核实后，独立编写你的 `schema_actual.json`（请勿原样使用模板）。

```bash
python r034_analysis.py \
    --workbook /path/to/StrawStudyData_FigShare.xlsx \
    --schema /path/to/schema_actual.json \
    --output /path/to/R034_ACTUAL_RESULTS.json
```

必须提供日期、处理、饮料数、吸管数列映射。若原版Excel只有77个有效日期，则程序只检查实际日级描述和2024勘误后的合计，保持时段推断为阻塞。若拥有完整87天（10失误日也在表中），可以另明确 `is_valid` 与实际 `period_id`、处理编码后，开展**时段层描述性**分析；源码不擅自倒推出原始时段序列。只有额外取得原始分配方案和缺失过程后，才能设计真正的随机化P值算法。

## 文件

`R034_EVIDENCE_AUDIT.md`: 完整审计、日期矛盾和6种时段约束方案。
`SOURCE_ACCESS_LEDGER.json`: 来源取得与障碍的可机读记录。
`R034_RESULT.json`: 数学复算，明确PUBLISHED_SUMMARY_BOUNDS_ONLY。
`r034_analysis.py`: 可执行无依赖界限计算与可选artifact_tool导入。
`tests/test_r034.py`: 32项软件测试。
`SCHEMA_TEMPLATE_NOT_REAL_MAPPING.json`: 仅形式示例，不含真实映射。
`R035_RESEARCH_GATE.md`: 下一阶段证据进入条件。

没有原始xlsx，也未写入用户资料库或外部代码仓库。
