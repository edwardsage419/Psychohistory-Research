# R003：PESEN 模型恢复与参数识别研究（v0.1）

研究日期：2026-10-14  
项目基线：2026-10-13《心理史学研究总纲》  
状态：**已实现并运行的合成数据研究，未进行真实数据验证**  
上游依赖：`PESEN_v0_1/pesen.py`，必须与本目录相邻。

## 问题

在已知网络与个体逐轮公开表达的条件下，观测数据能否区分三个候选行为生成机制：

* M0：私人倾向及外部制度因素决定公开表达，无网络社会影响。
* M1：使用当轮邻居公开表达比例进行即时网络响应。
* M2：根据过去邻居公开表达维护经验预期，再影响个体表达。

重要区分：R003 检验给定模型族内的**统计机制恢复**，并不构成因果识别，也不能证实真实世界采用了该机制。

## 方法

完全继承 PESEN v0.1 更新公式与环形网络结构，加入个体逐轮观测导出模块，逐条检查其群体表达率是否与原模拟器一致。

对每个生成机制、制度条件（始终高压力/中途降压）以及私人倾向是否可观测的组合：

1. 用固定的训练种子生成多份合成个体面板数据。
2. 分别拟合 M0、M1 和 M2 的条件逻辑回归方程。
3. M2 的经验预期更新速度只在训练集选取：`α∈{0.05, 0.10, 0.18, 0.30, 0.50, 0.80, 1.00}`。
4. 使用训练集的简化 BIC 指标选择模型，同时报告独立种子测试集的人均时间点对数损失。
5. 再改变社会影响系数或学习速度，检查错误选择是否出现。

主实验：90 人，固定度6，32轮，第14轮降压，6个训练重复、3个测试重复，训练与测试随机种子完全分离。

主实验还使用 3 组不同的随机种子划分进行稳健性检查。请注意，3组次数过少，**不能据此推断可靠的成功概率**。

## 可复现结果

主实验单次种子划分：三种数据生成机制在所有主要配置下由训练集的简化 BIC 正确选中。

改变参数后，M2 数据生成机制的恢复结果如下（私人倾向被准确观察，3组独立种子）：

| 配置 | 制度压力变化 | 制度压力不变 |
|---|---:|---:|
| 标准参数，β_social=2.20、α=0.18 | 3/3 选择 M2 | 3/3 选择 M2 |
| 弱社会影响，β_social=0.35、α=0.18 | 3/3 选择 M2 | 1/3 选择 M2 |
| 慢学习，β_social=2.20、α=0.05 | 3/3 选择 M2 | 1/3 选择 M2 |

这是某个具体人工数据生成方案下的现象。变换其他网络、测量误差、样本规模、偏好异质性或参数范围后，结论可能改变。

**发现的结构性识别问题：** 当 S 恒定时，模型中的截距 `β0` 和制裁项 `-βs × S` 存在代数混淆。给定任意 Δ，令 `β0' = β0 + ΔS` 和 `βs' = βs + Δ`，所有线性预测值完全相同。真实数据若没有 S 的足够变异，则无法从该设计分别估计两项。

## 文件

- `recovery.py`：生成与原始 PESEN 模型一致的面板数据，拟合与比较三候选机制。
- `robustness.py`：跨多个随机种子重复对比，保存每轮机制选择结果。
- `tests/test_recovery.py`：验证同步更新、延迟经验预期、输出结构、随机重复性。
- `results/recovery.json` 和 `results/recovery.csv`：主实验含训练 BIC、测试 log loss、系数和 α 估计。
- `results/weak_social.json` 和 `results/slow_learning.json`：第一轮参数压力测试。
- `results/robustness.json` 和 `results/robustness.csv`：3组独立随机划分的结果。
- `PROTOCOL.md`：研究设计、方法限制与进入真实研究的证据关口。

## 运行

项目目录结构：

```text
psych-history-study/
  PESEN_v0_1/
    pesen.py
    tests/
  心理史学_R003_机制识别实验_v0.1/
    recovery.py
    robustness.py
    tests/
    requirements.txt
```

Python 3.10+：

```bash
cd 心理史学_R003_机制识别实验_v0.1
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m unittest discover -s tests -v
OPENBLAS_NUM_THREADS=1 .venv/bin/python recovery.py --out results
OPENBLAS_NUM_THREADS=1 .venv/bin/python robustness.py --seeds 3 --out results
```

可将 `--seeds 3` 改为更大值，但运算时间相应增加。

## 不能得出的结论

1. 无法据此证明私人偏好真实存在为某种固定二元值。
2. 无法据此判断真实世界因果影响的强度与方向。
3. 无法证明群体规范形成；没有规范性预期测量。
4. 不能声称 PESEN 的学术独创性、预测准确度或历史可推广性已成立。
5. 当前评估假设知道候选模型家族且完整观测公开表达。未知网络、误测、共同冲击、社会选择等都可改变结果。

## 原始文献和方法学依据

1. Wilson & Collins (2019), *Ten simple rules for the computational modeling of behavioral data*. https://doi.org/10.7554/eLife.49547
2. Shalizi & Thomas (2011), *Homophily and Contagion Are Generically Confounded in Observational Social Network Studies*. https://doi.org/10.1177/0049124111404820
3. Grimm et al. (2020), *The ODD protocol for describing agent-based and other simulation models: A second update*. https://www.usgs.gov/publications/odd-protocol-describing-agent-based-and-other-simulation-models-a-second-update
4. Hofman et al. (2021), *Integrating explanation and prediction in computational social science*. https://doi.org/10.1038/s41586-021-03659-0
5. Paluck, Shepherd & Aronow (2016), *Changing climates of conflict: A social network experiment in 56 schools*. https://doi.org/10.1073/pnas.1514483113
6. ICPSR (2020), *Changing Climates of Conflict ... 56 Schools*, dataset 37070 v2. https://doi.org/10.3886/ICPSR37070.v2
7. Bicchieri & Xiao (2009), *Do the right thing: but only if others do so*. https://doi.org/10.1002/bdm.621

本轮仅核对了以上文献的公开页面及摘要或概要，未宣称逐篇完成原文所有论证与配套代码复现。
