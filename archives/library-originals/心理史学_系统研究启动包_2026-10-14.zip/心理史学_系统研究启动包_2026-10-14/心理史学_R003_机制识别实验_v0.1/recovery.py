#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""R003: Synthetic recovery/identifiability stress test for PESEN v0.1.

Only synthetic observations. Conditional predictive comparisons, NOT causal
identification, empirical validity, or a validation of private preferences.

Run: python recovery.py --out results
Test: python -m unittest discover -s tests -v
Requires Python >=3.10, numpy and scipy.
"""
from __future__ import annotations
import argparse
import csv
import json
import math
import sys
from dataclasses import asdict, replace
from pathlib import Path

import numpy as np
from scipy.optimize import minimize

SOURCE = Path(__file__).resolve().parents[1] / 'PESEN_v0_1'
if not SOURCE.is_dir():
    raise RuntimeError('Required PESEN_v0_1 baseline missing next to R003 directory')
sys.path.insert(0, str(SOURCE))
from pesen import Config, setup, simulate, sigmoid  # noqa: E402

MODELS = ('M0', 'M1', 'M2')
ALPHAS = (0.05, 0.10, 0.18, 0.30, 0.50, 0.80, 1.00)


def neigh_fraction(x: np.ndarray, degree: int) -> np.ndarray:
    """Undirected ring neighbor means at one observed time step."""
    half = degree // 2
    return sum((np.roll(x, k) for k in range(-half, half + 1) if k), np.zeros_like(x, dtype=float)) / degree


def generate_panel(cfg: Config, source: str, seeds: list[int], shock: bool) -> dict:
    """Individual observations consistent with the v0.1 update order."""
    blocks = []
    for seed in seeds:
        p, initial, uniforms = setup(cfg, seed)
        x = np.asarray(initial, dtype=float)
        p = np.asarray(p, dtype=float)
        e = np.full(cfg.population, cfg.initial_expressing_fraction, dtype=float)
        hist = [float(x.mean())]
        q_store, y_store, p_store, s_store, x_store = [], [], [], [], []
        for t in range(cfg.rounds):
            q = neigh_fraction(x, cfg.degree)
            s = cfg.sanction_after if shock and t >= cfg.shock_round else cfg.sanction_before
            z = cfg.base_intercept + cfg.private_weight*(2*p-1) - cfg.sanction_weight*s
            if source == 'M1':
                z = z + cfg.social_weight*(2*q-1)
            elif source == 'M2':
                z = z + cfg.social_weight*(2*e-1)
            elif source != 'M0':
                raise ValueError('bad source')
            proba = 1 / (1 + np.exp(-np.clip(z, -40, 40)))
            nxt = (np.asarray(uniforms[t]) < proba).astype(float)
            q_store.append(q)
            x_store.append(x.copy())
            y_store.append(nxt)
            p_store.append(p)
            s_store.append(np.full(cfg.population, s, dtype=float))
            if source == 'M2':
                e = (1-cfg.learning_rate)*e + cfg.learning_rate*q
            x = nxt
            hist.append(float(x.mean()))
        # Important regression assertion: panel reproduces the original v0.1 simulator.
        original = simulate(cfg, source, p.astype(int).tolist(), initial, uniforms, shock)
        if not np.allclose(hist, [r['public_share'] for r in original], atol=1e-12):
            raise AssertionError('v0.1 behavior not reproduced')
        blocks.append({'q': np.stack(q_store), 'x': np.stack(x_store), 'y': np.stack(y_store),
                       'p': np.stack(p_store), 's': np.stack(s_store)})
    return {key: np.stack([block[key] for block in blocks]) for key in blocks[0]}


def empirical_expectation(q: np.ndarray, alpha: float, initial: float) -> np.ndarray:
    """E(t) is computed only from observed q up to t-1."""
    e = np.full_like(q, initial, dtype=float)
    state = np.full(q.shape[::2], initial, dtype=float)  # replicate x individual
    for t in range(q.shape[1]):
        e[:, t, :] = state
        state = (1-alpha)*state + alpha*q[:, t, :]
    return e


def features(panel: dict, model: str, include_private: bool, alpha: float, initial: float) -> np.ndarray:
    columns = [np.ones(panel['y'].size)]
    if include_private:
        columns.append((2*panel['p']-1).reshape(-1))
    columns.append(-panel['s'].reshape(-1))
    if model == 'M1':
        columns.append((2*panel['q']-1).reshape(-1))
    elif model == 'M2':
        columns.append((2*empirical_expectation(panel['q'], alpha, initial)-1).reshape(-1))
    return np.column_stack(columns)


def fit_model(panel: dict, model: str, include_private: bool, initial: float) -> dict:
    y = panel['y'].reshape(-1)
    alpha_options = ALPHAS if model == 'M2' else (0.0,)
    options = []
    for alpha in alpha_options:
        X = features(panel, model, include_private, alpha, initial)
        # Logistic likelihood, analytically differentiated. Weak training penalty
        # aids numerical stability. Model selection uses unpenalized BIC.
        def objective(beta):
            z = X @ beta
            nll = float((np.logaddexp(0.0, z) - y*z).sum())
            prob = 1/(1+np.exp(-np.clip(z, -40, 40)))
            grad = X.T @ (prob-y)
            ridge = 1e-5*np.dot(beta[1:], beta[1:])
            grad[1:] += 2e-5*beta[1:]
            return nll+ridge, grad
        r = minimize(objective, np.zeros(X.shape[1]), method='L-BFGS-B', jac=True,
                     bounds=[(-8,8)]*X.shape[1], options={'maxiter':180, 'ftol':1e-11})
        if not r.success and np.linalg.norm(r.jac) > 1e-2:
            raise RuntimeError(f'fit failed: {r.message}')
        z = X@r.x
        unpenalized_nll = float((np.logaddexp(0.0, z)-y*z).sum())
        k = X.shape[1] + (1 if model == 'M2' else 0)
        bic = 2*unpenalized_nll + k*math.log(len(y))
        options.append({'mode':model, 'alpha':alpha if model=='M2' else None,
                        'betas':[float(b) for b in r.x], 'train_nll':unpenalized_nll,
                        'train_bic':bic})
    return min(options, key=lambda r: r['train_bic'])


def evaluate(panel: dict, fit: dict, include_private: bool, initial: float) -> float:
    X = features(panel, fit['mode'], include_private, fit['alpha'] or 0.0, initial)
    z = X @ np.asarray(fit['betas'])
    y = panel['y'].reshape(-1)
    return float(np.mean(np.logaddexp(0.0,z)-y*z))


def experiment(cfg: Config, train_reps: int, test_reps: int) -> dict:
    if train_reps < 2 or test_reps < 2:
        raise ValueError('at least two independent replicates per split')
    train_seeds = [cfg.seed+31*i for i in range(train_reps)]
    test_seeds = [cfg.seed+100003+31*i for i in range(test_reps)]
    records = []
    for observed_private in (True, False):
        for regime in ('relief','constant'):
            for true_source in MODELS:
                train = generate_panel(cfg, true_source, train_seeds, shock=(regime=='relief'))
                test = generate_panel(cfg, true_source, test_seeds, shock=(regime=='relief'))
                fitted = [fit_model(train, m, observed_private, cfg.initial_expressing_fraction)
                          for m in MODELS]
                chosen = min(fitted, key=lambda f:f['train_bic'])['mode']
                scores = {f['mode']:evaluate(test, f, observed_private,
                                               cfg.initial_expressing_fraction) for f in fitted}
                for f in fitted:
                    records.append({'private_measured':observed_private, 'regime':regime,
                                    'generating_model':true_source, 'fitted_model':f['mode'],
                                    'chosen_train_bic':chosen, 'train_bic':round(f['train_bic'],3),
                                    'test_log_loss':round(scores[f['mode']],6),
                                    'estimated_alpha':f['alpha'],
                                    'coefficients': [round(v,5) for v in f['betas']],
                                    'test_best_descriptive':min(scores,key=scores.get)})
    return {'protocol': 'R003 synthetic model & parameter recovery, pre-registered candidate menu',
            'configuration':asdict(cfg), 'alpha_grid':list(ALPHAS),
            'train_replicates':train_reps, 'test_replicates':test_reps,
            'train_seed_rule':'seed + 31*k', 'test_seed_rule':'seed + 100003 + 31*k',
            'comparison_rule':'select best training BIC, report heldout per-observation log loss',
            'assumptions': ['true network is known','all x_i(t) observed','institutional signal S_t observed',
                            'known generative model family', 'private p_i either exactly known (oracle) or omitted',
                            'e(0) known','all 3 models share same other model structure'],
            'evidence_level':'SYNTHETIC_ONLY', 'records':records}


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument('--out', type=Path, default=Path('results'))
    p.add_argument('--train-reps',type=int,default=6)
    p.add_argument('--test-reps',type=int,default=3)
    args=p.parse_args()
    cfg=Config(population=90,degree=6,rounds=32,replicates=1,shock_round=14,seed=20261014)
    result=experiment(cfg,args.train_reps,args.test_reps)
    args.out.mkdir(parents=True,exist_ok=True)
    with (args.out/'recovery.json').open('w',encoding='utf-8') as f:
        json.dump(result,f,indent=2,ensure_ascii=False)
    with (args.out/'recovery.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=[k for k in result['records'][0] if k != 'coefficients']+['coefficients'])
        writer.writeheader()
        writer.writerows(result['records'])
    for known in (True,False):
        for regime in ('relief','constant'):
            rows=[r for r in result['records'] if r['private_measured']==known and r['regime']==regime]
            print('private observed=',known,'regime=',regime)
            for g in MODELS:
                row=next(r for r in rows if r['generating_model']==g)
                losses={r['fitted_model']:r['test_log_loss'] for r in rows if r['generating_model']==g}
                print('  truth=',g,'train BIC choice=',row['chosen_train_bic'],'heldout log-loss=',losses)


if __name__=='__main__':
    main()
