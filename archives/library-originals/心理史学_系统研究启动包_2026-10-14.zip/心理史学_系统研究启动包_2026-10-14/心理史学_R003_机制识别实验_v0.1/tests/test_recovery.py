import sys
import unittest
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from recovery import Config, generate_panel, empirical_expectation, features, experiment

class TestR003(unittest.TestCase):
    def setUp(self):
        self.cfg=Config(population=24,degree=4,rounds=7,shock_round=3,seed=9)

    def test_original_equivalence_all_models_and_regimes(self):
        for source in ('M0','M1','M2'):
            for shock in (True,False):
                p=generate_panel(self.cfg,source,[42],shock)
                self.assertEqual(p['y'].shape,(1,7,24))
                self.assertTrue(np.isin(p['y'],[0,1]).all())

    def test_expectations_strictly_lagged(self):
        q=np.array([[[0.0],[1.0],[0.0]]])
        e=empirical_expectation(q,0.5,0.2)
        np.testing.assert_allclose(e.ravel(),[0.2,0.1,0.55])

    def test_private_measurement_changes_features(self):
        p=generate_panel(self.cfg,'M1',[9],True)
        self.assertEqual(features(p,'M1',True,0,0.06).shape[1],4)
        self.assertEqual(features(p,'M1',False,0,0.06).shape[1],3)

    def test_constant_sanction_nonidentification(self):
        # With constant sanction S, intercept and sanction weight are aliased.
        from scipy.special import expit
        s = 0.95
        b0, bs, shift = -0.45, 1.35, 0.81
        self.assertAlmostEqual(expit(b0-bs*s),
                               expit((b0+shift*s)-(bs+shift)*s))

    def test_repeated_panel_determinism(self):
        a=generate_panel(self.cfg,'M2',[42,45],True)
        b=generate_panel(self.cfg,'M2',[42,45],True)
        for k in a: np.testing.assert_array_equal(a[k],b[k])

if __name__=='__main__': unittest.main()
