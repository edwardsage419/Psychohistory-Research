#!/usr/bin/env python3
"""Repeat the pre-specified synthetic model recovery experiment over new seeds."""
from __future__ import annotations
import argparse
import csv
import json
from collections import defaultdict
from dataclasses import replace
from pathlib import Path
from recovery import Config, experiment


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--seeds',type=int,default=8)
    p.add_argument('--out',type=Path,default=Path('results'))
    a=p.parse_args()
    config=Config(population=90,degree=6,rounds=32,replicates=1,shock_round=14,seed=20261014)
    changes={'standard':{},'weak_social':{'social_weight':0.35},
             'slow_learning':{'learning_rate':0.05}}
    rows=[]
    for design,overrides in changes.items():
        for i in range(a.seeds):
            cfg=replace(config,seed=config.seed+i*1000007,**overrides)
            out=experiment(cfg,train_reps=6,test_reps=3)
            for rec in out['records']:
                if rec['generating_model']!=rec['fitted_model']: continue
                rows.append({'design':design,'split':i,'private_measured':rec['private_measured'],
                             'regime':rec['regime'],'truth':rec['generating_model'],
                             'selected':rec['chosen_train_bic'],
                             'correct':int(rec['chosen_train_bic']==rec['generating_model']),
                             'fitted_alpha_for_true_model':rec['estimated_alpha']})
        print('finished',design, flush=True)
    a.out.mkdir(parents=True,exist_ok=True)
    with (a.out/'robustness.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]))
        w.writeheader(); w.writerows(rows)
    grouped=defaultdict(list)
    for row in rows:
        grouped[(row['design'],row['private_measured'],row['regime'],row['truth'])].append(row)
    table=[]
    for (design,private,regime,truth),arr in sorted(grouped.items()):
        table.append({'design':design,'private_measured':private,'regime':regime,'truth':truth,
                      'successes':sum(row['correct'] for row in arr),'trials':len(arr),
                      'success_rate':sum(row['correct'] for row in arr)/len(arr),
                      'choices':{m:sum(row['selected']==m for row in arr) for m in ('M0','M1','M2')}})
    with (a.out/'robustness.json').open('w',encoding='utf-8') as f:
        json.dump({'seed_splits':a.seeds,'designs':changes,'table':table,
                   'statement':'Synthetic model family recovery only; no empirical or causal validation'},
                  f,ensure_ascii=False,indent=2)
    for row in table:
        if row['truth']=='M2' and row['private_measured']:
            print(row['design'],row['regime'],'M2 correct',row['successes'],'/',row['trials'])

if __name__=='__main__':main()
