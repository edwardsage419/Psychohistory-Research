#!/usr/bin/env python3
"""Small sensitivity grid for PESEN M2. Synthetic evidence only."""
from __future__ import annotations
import csv
from dataclasses import replace
from pathlib import Path
from pesen import Config, setup, simulate


def main():
    cfg = Config(replicates=8)
    out = Path('results')
    out.mkdir(parents=True, exist_ok=True)
    rows = []
    for beta_e in (0.0, 1.1, 2.2, 3.3):
        for alpha in (0.05, 0.18, 0.50):
            c = replace(cfg, social_weight=beta_e, learning_rate=alpha)
            diffs = []
            for i in range(c.replicates):
                p, x, uniforms = setup(c, c.seed + i * 101)
                relief = simulate(c,'M2',p,x,uniforms,True)
                constant = simulate(c,'M2',p,x,uniforms,False)
                # Last 10 rounds are post-shock for this configuration.
                mean_relief = sum(r['public_share'] for r in relief[-10:]) / 10
                mean_constant = sum(r['public_share'] for r in constant[-10:]) / 10
                diffs.append(mean_relief - mean_constant)
            rows.append({'social_weight':beta_e,'learning_rate':alpha,
                         'mean_paired_late_effect':round(sum(diffs)/len(diffs),5),
                         'min_effect':round(min(diffs),5), 'max_effect':round(max(diffs),5),
                         'replicates':len(diffs)})
    with (out/'sensitivity.csv').open('w', encoding='utf-8', newline='') as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    for r in rows: print(r)

if __name__ == '__main__':
    main()
