#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""PESEN v0.1: private preference, public expression and social expectation.

Exploratory synthetic simulation. NOT a validated psychological theory.
Requires only Python 3.10+ standard library.

Usage:
  python3 pesen.py --output results
  python3 pesen.py --replicates 40 --output results
  python3 -m unittest discover -s tests -v
"""
from __future__ import annotations
import argparse
import csv
import json
import math
import random
from dataclasses import dataclass, asdict, replace
from pathlib import Path

MODES = ("M0", "M1", "M2")

@dataclass(frozen=True)
class Config:
    population: int = 180
    degree: int = 6
    rounds: int = 60
    replicates: int = 40
    support_fraction: float = 0.70
    initial_expressing_fraction: float = 0.06
    base_intercept: float = -0.45
    private_weight: float = 1.65
    social_weight: float = 2.20
    sanction_weight: float = 1.35
    sanction_before: float = 0.95
    sanction_after: float = 0.10
    shock_round: int = 22
    learning_rate: float = 0.18
    seed: int = 20261014


def validate(cfg: Config) -> None:
    if cfg.population < 5 or cfg.degree < 2 or cfg.degree % 2 != 0 or cfg.degree >= cfg.population:
        raise ValueError("population >= 5, even degree >= 2 and degree < population required")
    if cfg.rounds < 1 or cfg.replicates < 1 or not 0 <= cfg.shock_round <= cfg.rounds:
        raise ValueError("invalid rounds, replicates or shock_round")
    for name in ("support_fraction", "initial_expressing_fraction", "learning_rate", "sanction_before", "sanction_after"):
        val = getattr(cfg, name)
        if not 0 <= val <= 1:
            raise ValueError(f"{name} must be in [0,1]")


def sigmoid(x: float) -> float:
    if x >= 0:
        return 1.0 / (1.0 + math.exp(-x))
    ex = math.exp(x)
    return ex / (1.0 + ex)


def ring(n: int, degree: int) -> list[tuple[int, ...]]:
    """Undirected fixed-degree ring. No self ties."""
    result = []
    for i in range(n):
        result.append(tuple(sorted({(i + d) % n for d in range(-degree // 2, degree // 2 + 1) if d != 0})))
    return result


def setup(cfg: Config, seed: int):
    rng = random.Random(seed)
    n = cfg.population
    preference = [1 if rng.random() < cfg.support_fraction else 0 for _ in range(n)]
    supporters = [i for i, p in enumerate(preference) if p]
    rng.shuffle(supporters)
    k = min(len(supporters), round(n * cfg.initial_expressing_fraction))
    initial = [0] * n
    for i in supporters[:k]:
        initial[i] = 1
    # Identical random innovations across all model/regime comparisons.
    uniforms = [[rng.random() for _ in range(n)] for _ in range(cfg.rounds)]
    return preference, initial, uniforms


def simulate(cfg: Config, mode: str, preference: list[int], initial: list[int],
             uniforms: list[list[float]], shock_enabled: bool = True) -> list[dict]:
    if mode not in MODES:
        raise ValueError("mode must be one of M0, M1, M2")
    n = cfg.population
    graph = ring(n, cfg.degree)
    x = initial.copy()
    e = [cfg.initial_expressing_fraction] * n
    out = []

    def record(t: int, sanction: float):
        support_n = sum(preference)
        hidden = sum(1 for pi, xi in zip(preference, x) if pi == 1 and xi == 0)
        out.append({
            "round": t,
            "public_share": sum(x) / n,
            "private_support_share": support_n / n,
            "hidden_support_share": hidden / n,
            "hidden_given_support": hidden / support_n if support_n else 0.,
            "mean_empirical_expectation": sum(e) / n if mode == "M2" else None,
            "sanction": sanction,
        })

    record(0, cfg.sanction_before)
    for t in range(cfg.rounds):
        sanction = cfg.sanction_after if shock_enabled and t >= cfg.shock_round else cfg.sanction_before
        local = [sum(x[j] for j in graph[i]) / cfg.degree for i in range(n)]
        next_x = []
        for i in range(n):
            z = (cfg.base_intercept + cfg.private_weight * (2 * preference[i] - 1)
                 - cfg.sanction_weight * sanction)
            if mode == "M1":
                z += cfg.social_weight * (2 * local[i] - 1)
            elif mode == "M2":
                z += cfg.social_weight * (2 * e[i] - 1)
            next_x.append(int(uniforms[t][i] < sigmoid(z)))
        # Synchronous updates: e(t+1) only uses the previous x(t).
        if mode == "M2":
            e = [(1 - cfg.learning_rate) * e[i] + cfg.learning_rate * local[i] for i in range(n)]
        x = next_x
        record(t + 1, sanction)
    return out


def summarize(cfg: Config):
    validate(cfg)
    all_runs = []
    rows = []
    for replicate in range(cfg.replicates):
        preference, initial, uniforms = setup(cfg, cfg.seed + replicate * 101)
        for mode in MODES:
            for shock in (False, True):
                history = simulate(cfg, mode, preference, initial, uniforms, shock)
                for row in history:
                    rows.append({"replicate": replicate, "mode": mode,
                                 "regime": "relief" if shock else "constant", **row})
                start = min(cfg.rounds, cfg.shock_round + 15)
                tail = history[start:] or history[-1:]
                public = sum(h["public_share"] for h in tail) / len(tail)
                hidden = sum(h["hidden_support_share"] for h in tail) / len(tail)
                all_runs.append({"replicate": replicate, "mode": mode,
                                 "regime": "relief" if shock else "constant",
                                 "late_public_share": public, "late_hidden_support_share": hidden})
    by_pair = {}
    for mode in MODES:
        a = [r for r in all_runs if r["mode"] == mode and r["regime"] == "relief"]
        b = [r for r in all_runs if r["mode"] == mode and r["regime"] == "constant"]
        differences = [x["late_public_share"] - y["late_public_share"] for x, y in zip(a, b)]
        by_pair[mode] = {
            "late_public_relief_mean": round(sum(x["late_public_share"] for x in a) / len(a), 5),
            "late_public_constant_mean": round(sum(x["late_public_share"] for x in b) / len(b), 5),
            "late_hidden_relief_mean": round(sum(x["late_hidden_support_share"] for x in a) / len(a), 5),
            "paired_effect_mean": round(sum(differences) / len(differences), 5),
            "paired_effect_min": round(min(differences), 5),
            "paired_effect_max": round(max(differences), 5),
        }
    return {"configuration": asdict(cfg), "results": by_pair,
            "interpretation": "Synthetic model implications only. No empirical validation, no identification of norms."}, rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("results"))
    parser.add_argument("--population", type=int, default=180)
    parser.add_argument("--replicates", type=int, default=40)
    parser.add_argument("--rounds", type=int, default=60)
    args = parser.parse_args()
    cfg = Config(population=args.population, replicates=args.replicates, rounds=args.rounds)
    summary, rows = summarize(cfg)
    args.output.mkdir(parents=True, exist_ok=True)
    with (args.output / "summary.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    with (args.output / "trajectories.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
