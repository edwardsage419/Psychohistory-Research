import sys
import unittest
from dataclasses import replace
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from pesen import Config, ring, setup, simulate, summarize, validate

class TestPESEN(unittest.TestCase):
    def setUp(self):
        self.cfg = Config(population=40, degree=4, rounds=12, replicates=3, shock_round=6)
        self.p, self.x, self.u = setup(self.cfg, 19)

    def test_reproducible(self):
        self.assertEqual(simulate(self.cfg, 'M2', self.p, self.x, self.u),
                         simulate(self.cfg, 'M2', self.p, self.x, self.u))

    def test_network(self):
        g = ring(40,4)
        self.assertTrue(all(len(nbrs) == 4 for nbrs in g))
        self.assertTrue(all(i not in nbrs for i,nbrs in enumerate(g)))
        self.assertTrue(all(i in g[j] for i,nbrs in enumerate(g) for j in nbrs))

    def test_private_invariant(self):
        h = simulate(self.cfg, 'M2', self.p, self.x, self.u)
        self.assertEqual(len(h), self.cfg.rounds + 1)
        self.assertEqual({row['private_support_share'] for row in h}, {sum(self.p)/len(self.p)})
        self.assertTrue(all(0 <= row['public_share'] <= 1 for row in h))
        self.assertTrue(all(0 <= row['hidden_given_support'] <= 1 for row in h))

    def test_social_ablation(self):
        cfg0 = replace(self.cfg, social_weight=0)
        for m in ('M1','M2'):
            self.assertEqual(
                [r['public_share'] for r in simulate(cfg0, m, self.p, self.x, self.u)],
                [r['public_share'] for r in simulate(cfg0, 'M0', self.p, self.x, self.u)])

    def test_shock_null_under_zero_sanction_weight(self):
        cfg = replace(self.cfg, sanction_weight=0)
        for m in ('M0','M1','M2'):
            a = simulate(cfg, m, self.p, self.x, self.u, True)
            b = simulate(cfg, m, self.p, self.x, self.u, False)
            self.assertEqual([x['public_share'] for x in a], [x['public_share'] for x in b])

    def test_summary(self):
        summary, rows = summarize(self.cfg)
        self.assertEqual(set(summary['results']), {'M0','M1','M2'})
        self.assertEqual(len(rows), self.cfg.replicates * 3 * 2 * (self.cfg.rounds+1))

    def test_invalid_config(self):
        with self.assertRaises(ValueError): validate(replace(self.cfg, degree=3))

if __name__ == '__main__':
    unittest.main()
