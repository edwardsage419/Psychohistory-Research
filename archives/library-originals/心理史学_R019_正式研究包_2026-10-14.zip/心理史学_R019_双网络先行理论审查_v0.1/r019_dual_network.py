#!/usr/bin/env python3
"""R019: independently implement equations (2)-(5) from Anufriev et al. (2026).

A theoretical benchmark only; not source authors' software, not fitted to humans,
and not a change to PESEN-v0.1. Python 3.10+ stdlib, deterministic.

Semantics: b(t-1) = private beliefs; s(t) = audience-tuned public statements;
b(t) = belief update using public statements. D/G are weighted nonnegative,
zero-diagonal matrices. The minimizations have unit own-belief coefficient.
"""
from __future__ import annotations
import json
import argparse
from pathlib import Path


def validate_network(D, G, b):
    n = len(b)
    if n == 0 or len(D) != n or len(G) != n:
        raise ValueError("network/belief size mismatch")
    for matrix in (D,G):
        for i, row in enumerate(matrix):
            if len(row) != n: raise ValueError("non-square weights")
            for j, val in enumerate(row):
                if not isinstance(val,(int,float)) or not (0 <= val < float('inf')):
                    raise ValueError("weights must be finite nonnegative")
                if i == j and val != 0: raise ValueError("diagonal must be zero")
    for z in b:
        if not isinstance(z,(int,float)) or not -float('inf') < z < float('inf'):
            raise ValueError("beliefs must be finite")


def linear_solve(matrix, y):
    n=len(y)
    a=[list(map(float,row))+[float(y[i])] for i,row in enumerate(matrix)]
    for i in range(n):
        pivot=max(range(i,n),key=lambda j:abs(a[j][i]))
        if abs(a[pivot][i])<1e-12:raise ValueError("singular linear system")
        a[i],a[pivot]=a[pivot],a[i]
        p=a[i][i]
        for j in range(i,n+1):a[i][j]/=p
        for k in range(n):
            if k==i:continue
            mult=a[k][i]
            for j in range(i,n+1):a[k][j]-=mult*a[i][j]
    return [row[n] for row in a]


def public_statements(b, D):
    """Nash equilibrium of (s_i-b_i)^2+sum_j d_ij(s_i-s_j)^2.

    FOC: (1+sum_j d_ij)*s_i-sum_j d_ij*s_j=b_i.
    """
    n=len(b)
    system=[[(1+sum(D[i]) if i==j else 0)-D[i][j] for j in range(n)] for i in range(n)]
    return linear_solve(system,b)


def belief_update(b,s,G):
    """Argmin own-belief deviation + weighted difference to other's statements."""
    return [(b[i]+sum(G[i][j]*s[j] for j in range(len(b))))/(1+sum(G[i]))
            for i in range(len(b))]


def trajectory(D,G,initial,steps=100):
    if steps<0: raise ValueError("steps must be nonnegative")
    validate_network(D,G,initial)
    b=list(map(float,initial))
    out=[]
    for t in range(steps):
        s=public_statements(b,D)
        future=belief_update(b,s,G)
        out.append({"period":t+1,"belief_before":b,"public_statement":s,
                    "belief_after":future,"max_discrepancy":max(abs(si-bi) for si,bi in zip(s,future))})
        b=future
    return out


def examples():
    # Strongest possible counterexample: no belief update and stable public distortion.
    two=trajectory([[0,1],[0,0]],[[0,0],[0,0]],[0,1],steps=40)
    # Same as the four-node topology described at Fig. 2: D12=D34=1, G13=G31=1.
    D=[[0,1,0,0],[0,0,0,0],[0,0,0,1],[0,0,0,0]]
    G=[[0,0,1,0],[0,0,0,0],[1,0,0,0],[0,0,0,0]]
    four=trajectory(D,G,[0,0,0,1],steps=160)
    # Observational equivalence at t=1: the same (0.5,1) public statements arise
    # from private (0,1) with D12=1 or private (0.5,1) and no audience pressure.
    observational={"case_A":{"b0":[0.0,1.0],"D":[[0,1],[0,0]],"observed_statement":public_statements([0,1],[[0,1],[0,0]])},
                   "case_B":{"b0":[0.5,1.0],"D":[[0,0],[0,0]],"observed_statement":public_statements([0.5,1],[[0,0],[0,0]])}}
    return {
        "status":"THEORETICAL_NUMERICAL_BENCHMARK_NOT_HUMAN_DATA",
        "paper":"Anufriev, Borissov, Pakhnin (2026), CESifo WP 12700, eqs (2)-(5)",
        "two_agent":{"private_beliefs_at_end":two[-1]["belief_after"],"public_statements_at_end":two[-1]["public_statement"],"gap":two[-1]["max_discrepancy"]},
        "four_agent":{"private_beliefs_at_end":four[-1]["belief_after"],"public_statements_at_end":four[-1]["public_statement"],"max_gap":four[-1]["max_discrepancy"],"expected_analytical":{"b1":2/3,"b3":1/3,"s1":1/3,"s3":2/3}},
        "observational_equivalence":observational,
        "observational_equivalence_all_periods": {
          "A": [r["public_statement"] for r in trajectory([[0,1],[0,0]],[[0,0],[0,0]],[0,1],4)],
          "B": [r["public_statement"] for r in trajectory([[0,0],[0,0]],[[0,0],[0,0]],[0.5,1],4)]},
        "testable_difference":"Without paired beliefs, observed statements alone cannot determine audience weights even in 2-agent toy example."
    }


def main():
    p=argparse.ArgumentParser();p.add_argument("--out",type=Path,default=Path("results/theory_examples.json"));args=p.parse_args()
    result=examples();args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({"two_agent_gap":result["two_agent"]["gap"],"four_agent_gap":result["four_agent"]["max_gap"],"result":str(args.out)},ensure_ascii=False))
if __name__=="__main__":main()
