import sys,unittest,random,math
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from r019_dual_network import public_statements, belief_update, trajectory, linear_solve, examples
class ModelTests(unittest.TestCase):
 def test_identity_D(self):
  b=[.2,.5,1];self.assertEqual(public_statements(b,[[0]*3 for _ in range(3)]),b)
 def test_no_influence_static_private(self):
  ts=trajectory([[0,2],[0,0]],[[0,0],[0,0]],[0,1],40)
  self.assertEqual(ts[-1]['belief_after'],[0,1])
 def test_two_agent_s_half(self):
  x=examples()['two_agent'];self.assertAlmostEqual(x['public_statements_at_end'][0],.5,places=12);self.assertAlmostEqual(x['gap'],.5,places=12)
 def test_four_agent_steady(self):
  x=examples()['four_agent'];b=x['private_beliefs_at_end'];s=x['public_statements_at_end'];self.assertAlmostEqual(b[0],2/3,places=10);self.assertAlmostEqual(b[2],1/3,places=10);self.assertAlmostEqual(s[0],1/3,places=10);self.assertAlmostEqual(s[2],2/3,places=10)
 def test_two_matched_public_different_private(self):
  obs=examples()['observational_equivalence'];self.assertEqual(obs['case_A']['observed_statement'],obs['case_B']['observed_statement']);self.assertNotEqual(obs['case_A']['b0'],obs['case_B']['b0'])
 def test_repeated_observation_equivalence(self):
  o=examples()["observational_equivalence_all_periods"];self.assertEqual(o["A"],o["B"])
 def test_belief_update_exact(self):
  self.assertAlmostEqual(belief_update([0,1],[.5,1],[[0,2],[0,0]])[0],2/3)
 def test_G_equal_D_connected_final_gap_zero(self):
  d=[[0,1],[1,0]];r=trajectory(d,d,[0,1],180)[-1];self.assertLess(r['max_discrepancy'],1e-11)
 def test_random_convex_hull(self):
  rng=random.Random(91)
  for _ in range(20):
   n=5;D=[[0 if i==j else rng.random() for j in range(n)] for i in range(n)]
   G=[[0 if i==j else rng.random() for j in range(n)] for i in range(n)]
   b=[rng.random()*2-1 for _ in range(n)];s=public_statements(b,D);bn=belief_update(b,s,G)
   self.assertTrue(all(min(b)-1e-10<=z<=max(b)+1e-10 for z in s+bn))
 def test_extreme_D_cannot_escape_belief_range(self):
  s=public_statements([-2,2],[[0,1000],[0,0]]);self.assertTrue(-2<=s[0]<=2)
 def test_reject_negative(self):
  with self.assertRaises(ValueError):trajectory([[0,-1],[0,0]],[[0,0],[0,0]],[0,1])
 def test_reject_diagonal(self):
  with self.assertRaises(ValueError):trajectory([[1,0],[0,0]],[[0,0],[0,0]],[0,1])
 def test_reject_infinite(self):
  with self.assertRaises(ValueError):trajectory([[0,float('inf')],[0,0]],[[0,0],[0,0]],[0,1])
 def test_bad_size(self):
  with self.assertRaises(ValueError):trajectory([[0]],[[0,0]],[0,1])
 def test_bad_steps(self):
  with self.assertRaises(ValueError):trajectory([[0]],[[0]],[0],-1)
 def test_solve_small(self):
  self.assertAlmostEqual(linear_solve([[2,1],[1,2]],[3,3])[0],1)
 def test_reproducible(self):
  a=examples();b=examples();self.assertEqual(a,b)
if __name__=='__main__':unittest.main()
