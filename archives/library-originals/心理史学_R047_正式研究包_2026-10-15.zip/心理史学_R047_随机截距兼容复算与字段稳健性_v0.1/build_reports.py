"""Materialize R047 comparison and robustness from independently computed local ML results."""
from __future__ import annotations
import csv, json, pathlib, hashlib
from r047_analysis import summarize, decode_panel, longitudinal_design, prepare, fit_ml_re, PUBLISHED
root=pathlib.Path(__file__).resolve().parent
results=summarize()
(root/'R047_RESULTS.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
pub_rows=[]
for stratum,pub in [('B',PUBLISHED['current_B_source']),('A',PUBLISHED['current_A_source'])]:
  a=results['models'][f'current_{stratum}_raw']
  b=results['models'][f'current_{stratum}_verified']
  for key,target,paper_key in [('intercept','intercept','intercept'),('deviation_ed','deviation_ed','deviation_ed'),('punishment_unequal','unequal','unequal'),('punishment_equal','equal','equal')]:
    pub_rows.append({'stratum':stratum,'n':a['n'],'coefficient':key,
      'published_stata_xtreg_re':pub[paper_key],
      'independent_gaussian_intercept_ml_source':round(a['coefficients'][key],9),
      'independent_gaussian_intercept_ml_verified':round(b['coefficients'][key],9),
      'ml_minus_paper':round(a['coefficients'][key]-pub[paper_key],9),
      'verified_minus_source_ml':round(b['coefficients'][key]-a['coefficients'][key],9)})
with (root/'R047_PUBLISHED_COMPARISON.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(pub_rows[0]));w.writeheader();w.writerows(pub_rows)
rows=longitudinal_design(decode_panel())
robust={'status':'exploratory leave-one-out; no p-values; same 64 source participants',
        'n_sessions_total':4,'n_punishment_groups_total':16,'models':{}}
for stratum in ('B','A'):
 for variant in ('raw','verified'):
  name=f'current_{stratum}_{variant}'
  d=prepare(rows,'current',variant,stratum)
  gresults={g:fit_ml_re([r for r in d if r[1]!=g])['coefficients'] for g in sorted(set(r[1] for r in d))}
  sresults={str(s):fit_ml_re([r for r in d if r[2]!=s])['coefficients'] for s in (5,6,7,8)}
  robust['models'][name]={
     'included_n':len(d),'leave_one_group':gresults,'leave_one_session':sresults,
     'equal_slope_LOO_group_range':[min(x['punishment_equal'] for x in gresults.values()),max(x['punishment_equal'] for x in gresults.values())],
     'unequal_slope_LOO_group_range':[min(x['punishment_unequal'] for x in gresults.values()),max(x['punishment_unequal'] for x in gresults.values())]
  }
(root/'R047_ROBUSTNESS.json').write_text(json.dumps(robust,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('written reports',len(pub_rows),'comparator rows,',len(robust['models']),'robust models')
