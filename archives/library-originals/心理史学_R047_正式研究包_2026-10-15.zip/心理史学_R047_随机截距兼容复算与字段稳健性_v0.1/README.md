# 心理史学 R047 实验研究包

日期：2026-10-15；PESEN v0.1保持冻结。研究对象为2021年 De Geest & Kingsley 的128人公共资源实验之64名惩罚臂参与者，**不是新独立实验**。

### 复算方式

需要 Python 3.10+、numpy、scipy，独立交叉检验另需要 statsmodels、pytest。建议：

```bash
python -m pip install numpy scipy statsmodels pytest
OPENBLAS_NUM_THREADS=1 python r047_analysis.py
OPENBLAS_NUM_THREADS=1 python statsmodels_crosscheck.py
OPENBLAS_NUM_THREADS=1 python -m pytest -q tests/test_r047.py
```

`r047_analysis.py`读取 `panel_derivative.b64.txt`（在已连接 GitHub 工具端从来源数据构造的匿名压缩衍生物），执行八组 Gaussian random-intercept ML 并写出 `R047_RESULTS.json`。`statsmodels_crosscheck.py`用第二套实现复核八套模型。`build_reports.py`生成公开发表表4对照及留组留场敏感性。测试涵盖来源格式、对手事件账本、更正记录、时间分层、ML目标、跨实现一致性和来源反例。源码保留原始 Git SHA，**压缩衍生物不是原始CSV字节**。

如果依法获得作者源CSV，请运行：

```bash
python r047_analysis.py --audit-csv /path/to/author_original_data.csv
```

它必须精确匹配作者Git blob SHA，再核验32个四人组数据结构、惩罚目标逐轮位置、全部惩罚支出和最终收益，并与匿名衍生物逐字节重建比对。`.dta` 的 `--audit-dta` 目前**仅校验原始 Git blob**，不是 Stata 模型执行。

### 文件

`R047_EVIDENCE_AUDIT.md`：正式科学审计；`R047_SOURCE_LEDGER.json`：来源证据分级；`R047_PUBLISHED_COMPARISON.csv`：发表表4与兼容ML比较；`R047_ROBUSTNESS.json`：留一组与留一场；`R047_INDEPENDENT_CROSSCHECK.json`：statsmodels交叉验证；`R047_RESULTS.json`：八模型完整数值；`R048_RESEARCH_GATE.md`：下一轮严格准入；`MASTER_CONTROLLER_v3.8.md`：继承主控台。

注意：研究不包含原作者CSV/DTA，未生成原作者Stata RE与其群组聚类标准误，没有新样本，没有社会惩罚因果识别。
