#!/usr/bin/env python3
"""R047: source-derived anonymous panel, ML random intercept robustness.

IMPORTANT: NOT Stata xtreg,re nor a replication of its covariance/s.e. It uses a
GitHub-connector-derived compact behavioral derivative; no original CSV or DTA
bytes are stored in the research package. Endowments/subject IDs are not included.
"""
from __future__ import annotations
import base64, collections, csv, hashlib, json, math, pathlib, sys
import numpy as np
from scipy.optimize import minimize_scalar

ROOT=pathlib.Path(__file__).resolve().parent
PACKED=ROOT/'panel_derivative.b64.txt'
SOURCE_SHA='73c02176bc9e060af987149594a85f9f7b591230'
DTA_SHA='7f846841aa2e23a0699614473dfef1f809a519b3'
GROUP_NAMES=('01_5_1','01_5_2','01_5_3','01_5_4','01_6_5','01_6_6','01_6_7','01_6_8','11_7_1','11_7_2','11_7_3','11_7_4','11_8_5','11_8_6','11_8_7','11_8_8')
PUBLISHED={
 'current_B_source':{'n':451,'intercept':3.117,'deviation_ed':-.839,'unequal':-.123,'equal':-.065},
 'current_A_source':{'n':414,'intercept':-1.932,'deviation_ed':-1.128,'unequal':-.305,'equal':-.003},
}

def git_blob_sha(data:bytes):
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()


def decode_panel(path=PACKED):
    """Only *derived* person-round records. First-round receipts are not analysed."""
    lines=dict(s.split('=',1) for s in pathlib.Path(path).read_text().splitlines())
    data=base64.b64decode(lines['DATA'],validate=True)
    corrections=base64.b64decode(lines['CORR'],validate=True)
    if len(data)!=2048 or len(corrections)!=240:
        raise ValueError('Unexpected source-derivative size')
    panel=[]
    for i in range(1024):
        group_idx=i//64; person_idx=i//16; t=i%16+1
        invest=data[i*2];reported=data[i*2+1]*3
        if invest>60 or invest<0 or reported>765:raise ValueError('Invalid source values')
        panel.append(dict(group=GROUP_NAMES[group_idx],arm=GROUP_NAMES[group_idx][:2],session=int(GROUP_NAMES[group_idx].split('_')[1]),person=person_idx,t=t,invest=invest,raw=reported,verified=reported))
    seen=set()
    for i in range(0,len(corrections),3):
        j=256*corrections[i]+corrections[i+1]
        if j>=1024 or j in seen or panel[j]['t']==1:raise ValueError('Invalid corrected index')
        seen.add(j);panel[j]['verified']=corrections[i+2]*3
    if len(seen)!=80:raise ValueError('Must recover exactly 80 anomalous cells')
    if len({x['person'] for x in panel})!=64 or len({x['group'] for x in panel})!=16:
        raise ValueError('Participant/arm count mismatch')
    return panel


def longitudinal_design(panel):
    bygrp=collections.defaultdict(list); byperson=collections.defaultdict(list)
    for z in panel:bygrp[(z['group'],z['t'])].append(z); byperson[z['person']].append(z)
    if len(bygrp)!=256 or any(len(v)!=4 for v in bygrp.values()):raise ValueError('Four people per group-round required')
    means={key:sum(z['invest'] for z in rows)/4 for key,rows in bygrp.items()}
    rows=[]
    for person,observations in byperson.items():
        obs=sorted(observations,key=lambda z:z['t'])
        if len(obs)!=16 or [z['t'] for z in obs]!=list(range(1,17)):
            raise ValueError('Incomplete participant trajectory')
        for t in range(3,17):
            now=obs[t-1];prev=obs[t-2]
            if now['group']!=prev['group']:raise ValueError('Participant changed group')
            dy=now['invest']-prev['invest']
            rows.append({**{k:now[k] for k in ('person','group','arm','session','t')},'y':dy,
                'dev_current':means[(now['group'],t)]-now['invest'],
                'dev_previous':means[(now['group'],t-1)]-prev['invest'],
                'raw':prev['raw'],'verified':prev['verified']})
    if len(rows)!=896:raise ValueError('Expected 896 transitions')
    return rows


def prepare(rows, timing='current',receipt='raw',stratum='B'):
    if timing not in ('current','previous') or receipt not in ('raw','verified') or stratum not in ('B','A'):
        raise ValueError('Invalid preregistered model choice')
    sel=[]
    for z in rows:
        dev=z['dev_'+timing]
        if (stratum=='B' and dev<=0) or (stratum=='A' and dev>=0):continue
        unequal=z['arm']=='01';p=z[receipt]
        x=[1.,dev,p if unequal else 0.,p if not unequal else 0.]
        sel.append((z['person'],z['group'],z['session'],float(z['y']),x))
    return sel


def collapsed_re_by_person(data):
    """Per-person Gaussian regression crossproducts. Safe anonymous sufficient stats."""
    mp=collections.defaultdict(list)
    for person,group,session,y,x in data:mp[person].append((group,session,y,np.asarray(x,float)))
    moments=[]
    for person,ar in mp.items():
        X=np.vstack([z[3] for z in ar]);y=np.array([z[2] for z in ar]);
        moments.append({'n':len(y),'xx':X.T@X,'xy':X.T@y,'yy':float(y@y),'sx':X.sum(axis=0),'sy':float(y.sum()),
                        'group':ar[0][0],'session':ar[0][1]})
    return moments


def gls_profile(moments,r):
    if r<0:raise ValueError('Variance ratio cannot be negative')
    k=4;n=sum(m['n'] for m in moments); A=np.zeros((k,k));b=np.zeros(k);yy=0.;ld=0.
    for m in moments:
        q=r/(1+r*m['n'])
        A+=m['xx']-q*np.outer(m['sx'],m['sx'])
        b+=m['xy']-q*m['sx']*m['sy']
        yy+=m['yy']-q*m['sy']**2
        ld+=np.log1p(r*m['n'])
    try:coef=np.linalg.solve(A,b)
    except np.linalg.LinAlgError as e:raise ValueError('Rank-deficient coefficients') from e
    sse=yy-coef@b
    if sse<=0:raise ValueError('Nonpositive error sum squares')
    return {'n':n,'k':k,'b':coef,'sse':sse,'relative_logdet':ld,'a':A}


def fit_ml_re(data):
    """Profile-likelihood Gaussian random intercept; differs from Stata Swamy-Arora xtreg.
    ML estimates are not cluster-robust and p-values are deliberately not generated.
    """
    moments=collapsed_re_by_person(data)
    if len(moments)<4:raise ValueError('Insufficient participant clusters')
    n=sum(m['n'] for m in moments)
    def objective(r):
        q=gls_profile(moments,r)
        return n*np.log(q['sse']/n)+q['relative_logdet']
    res=minimize_scalar(lambda z:objective(np.exp(z)),bounds=(-15,12),method='bounded',options={'xatol':1e-10})
    candidates=[0.,float(np.exp(res.x)),float(np.exp(-15)),float(np.exp(12))]
    r=min(candidates,key=objective)
    fit=gls_profile(moments,r)
    ols=gls_profile(moments,0.)
    sigma_e=fit['sse']/n
    return {'n':n,'subjects':len(moments),'groups':len(set(m['group'] for m in moments)),
            'session_clusters':len(set(m['session'] for m in moments)),
            'coefficients':dict(zip(('intercept','deviation_ed','punishment_unequal','punishment_equal'),map(float,fit['b']))),
            'variance_ratio_random_intercept':r,
            'residual_variance_ml':sigma_e,'intercept_variance_ml':r*sigma_e,
            'boundary_zero_random_intercept':r==0.,
            'pooled_ols_coefficients':dict(zip(('intercept','deviation_ed','punishment_unequal','punishment_equal'),map(float,ols['b']))),
            'profile_obj':objective(r),
            'model':'Gaussian subject-random-intercept profile maximum-likelihood; not Stata xtreg,re; no clustered SE'}


def summarize():
    panel=decode_panel();rows=longitudinal_design(panel)
    result={'provenance':{'repo':'lrdegeest/InequalityCPR','file':'data/data.csv','git_blob_sha1':SOURCE_SHA,
                'source_access':'full original public CSV via GitHub connector; local anonymous lossy derivative',
                'dta_source_sha1_unread':DTA_SHA},'qc':{
                   'panel_rows':len(panel),'persons':64,'punishment_groups':16,'transitions':len(rows),
                   'raw_vs_verified_received_disagreements':sum(z['raw']!=z['verified'] for z in panel if z['t']>=2),
                   'transitions_with_changed_prior_receipt':sum(z['raw']!=z['verified'] for z in rows)},'models':{}}
    for timing in ('current','previous'):
        for stratum in ('B','A'):
            for receipt in ('raw','verified'):
                key=f'{timing}_{stratum}_{receipt}'
                result['models'][key]=fit_ml_re(prepare(rows,timing,receipt,stratum))
    return result




def build_derived_from_verified_csv(raw_path):
    """Exact end-to-end provenance gate, intended for later lawful access to original CSV.

    No original UUIDs/subject labels survive this conversion. This function is
    not used to create the current source derivative, which was independently
    computed in a live GitHub connector and transferred as anonymous bytes.
    """
    content=pathlib.Path(raw_path).read_bytes()
    if git_blob_sha(content)!=SOURCE_SHA:raise ValueError('Original author CSV Git blob hash mismatch')
    readers=list(csv.DictReader(content.decode('utf-8-sig').splitlines()))
    rows=[x for x in readers if x.get('ProfileID') and x.get('RoundID')]
    if len(rows)!=2048:raise ValueError('Expected 2048 original records')
    grouped=collections.defaultdict(list);subjects=collections.defaultdict(list)
    all_groups=set();all_subjects=set()
    for v in rows:
        name='_'.join(v[x] for x in ('Homo','FF','Session','GameID'))
        subj=v['ProfileID'];t=int(v['RoundID'])
        all_groups.add(name);all_subjects.add(subj)
        if v['FF']!='1':continue
        grouped[(name,t)].append(v);subjects[(name,subj)].append(v)
    if len(all_groups)!=32 or len(all_subjects)!=128 or len(grouped)!=256:
        raise ValueError('Invalid source group/subject count')
    inbound={};bad=0
    for (name,t),rr in grouped.items():
        if len(rr)!=4 or len({z['ProfileID'] for z in rr})!=4:
            raise ValueError('Four participants per group-round required')
        if t==1:continue
        slots={}
        for z in rr:
            vals=[j for j,k in enumerate(('Seq1','Seq2','Seq3','Seq4')) if z[k]=='.']
            if len(vals)!=1 or vals[0] in slots:raise ValueError('Ambiguous per-round target slots')
            slots[vals[0]]=z['ProfileID']
        local={p:0 for p in slots.values()}
        for z in rr:
            q=0
            for j,k in enumerate(('Seq1','Seq2','Seq3','Seq4')):
                if z[k]=='.':continue
                pts=int(z[k]);q+=pts
                local[slots[j]]+=pts
            if int(z['Paid'])*3!=q:raise ValueError('Punishment outflow does not reconcile')
        for z in rr:
            actual=float(z['Total'])-float(z['Paid'])-local[z['ProfileID']]
            if abs(float(z['Total2'])-actual)>1e-4:
                raise ValueError('Final earnings do not reconcile')
            inbound[(name,z['ProfileID'],t)]=local[z['ProfileID']]
    points=[]; corrections=[];k=0
    for name in GROUP_NAMES:
        ppl=sorted([z for z in subjects if z[0]==name],key=lambda z:z[1])
        if len(ppl)!=4:raise ValueError('Incorrect group participants')
        for sid in ppl:
            rr=sorted(subjects[sid],key=lambda z:int(z['RoundID']))
            if len(rr)!=16 or [int(z['RoundID']) for z in rr]!=list(range(1,17)):
                raise ValueError('Incomplete per-person history')
            for z in rr:
                t=int(z['RoundID']);invest=int(z['Invest'])
                raw=0 if z['Received']=='.' else int(z['Received'])
                verified=raw if t==1 else inbound[(name,z['ProfileID'],t)]
                if not 0<=invest<=255 or raw%3 or verified%3 or not 0<=raw//3<=255 or not 0<=verified//3<=255:
                    raise ValueError('Unpackable donation/penalty')
                points.extend((invest,raw//3))
                if t>1 and verified!=raw:
                    corrections.extend((k>>8,k&255,verified//3))
                k+=1
    if len(points)!=2048 or len(corrections)!=240:
        raise ValueError('Unexpected number of corrected cells')
    return {'DATA':base64.b64encode(bytes(points)).decode(),
            'CORR':base64.b64encode(bytes(corrections)).decode()}


def compare_original_source(raw_path, packed_path=PACKED):
    actual=build_derived_from_verified_csv(raw_path)
    expected=dict(x.split('=',1) for x in pathlib.Path(packed_path).read_text().splitlines())
    if actual != expected:
        raise ValueError('Source provenance valid but anonymous derivative differs')
    return {'sha':SOURCE_SHA,'rows_source':2048,'derived_person_round_rows':1024,
            'corrected_round_receipt_cells':80,'end_to_end_original_csv_verified':True}


def main():
    import argparse
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--results',default='R047_RESULTS.json');p.add_argument('--audit-csv',default=None);p.add_argument('--audit-dta',default=None)
    args=p.parse_args()
    if args.audit_dta:
        contents=pathlib.Path(args.audit_dta).read_bytes()
        if git_blob_sha(contents)!=DTA_SHA:raise ValueError('Stata binary Git blob mismatch')
        print('DTA blob fingerprint verified, columns still NOT audited',len(contents))
    if args.audit_csv:
        b=pathlib.Path(args.audit_csv).read_bytes()
        if git_blob_sha(b)!=SOURCE_SHA:raise ValueError('Original CSV blob mismatch')
        print(json.dumps(compare_original_source(args.audit_csv)))
    z=summarize(); out=ROOT/args.results;out.write_text(json.dumps(z,ensure_ascii=False,indent=2)+'\n');print('Wrote',out)
    for k,v in z['models'].items():print(k,'N',v['n'],'dev',round(v['coefficients']['deviation_ed'],5),'uneq',round(v['coefficients']['punishment_unequal'],5),'eq',round(v['coefficients']['punishment_equal'],5),'r',round(v['variance_ratio_random_intercept'],4))

if __name__=='__main__':main()
