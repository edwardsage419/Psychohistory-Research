"""Independent second implementation for selected random-intercept ML point estimates."""
from __future__ import annotations
import json,pathlib, numpy as np, statsmodels.api as sm
import r047_analysis as a

out={}
rows=a.longitudinal_design(a.decode_panel());z=a.summarize()
for time in ('current','previous'):
 for s in ('B','A'):
  for receipt in ('raw','verified'):
   case=f'{time}_{s}_{receipt}';data=a.prepare(rows,time,receipt,s)
   X=np.asarray([r[4] for r in data]);y=np.asarray([r[3] for r in data]);group=np.asarray([r[0] for r in data]);
   fit=sm.MixedLM(y,X,groups=group).fit(reml=False,method='powell',maxiter=400,disp=False)
   reference=z['models'][case]['coefficients'];vals=np.array(list(reference.values()))
   delta=float(np.max(np.abs(fit.fe_params-vals)))
   out[case]={'converged':bool(fit.converged),'statmodels_fe_params':list(map(float,fit.fe_params)),
              'max_abs_diff_vs_analytic_profile_ML':delta,
              'statsmodels_random_intercept_variance':float(fit.cov_re[0,0]),
              'statsmodels_residual_variance':float(fit.scale)}
   if not fit.converged or delta>1e-4:raise RuntimeError(f'Independent ML discrepancy in {case}: {delta}')
pathlib.Path('R047_INDEPENDENT_CROSSCHECK.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('all independent statsmodels checks passed; models:',len(out),'max_error',max(q['max_abs_diff_vs_analytic_profile_ML'] for q in out.values()))
