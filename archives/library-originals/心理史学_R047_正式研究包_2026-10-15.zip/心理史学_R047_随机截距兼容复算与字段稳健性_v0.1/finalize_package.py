#!/usr/bin/env python3
"""Create a reproducible checksum manifest and R047 archive; verify ZIP integrity."""
from __future__ import annotations
import datetime, hashlib, json, pathlib, zipfile
root=pathlib.Path(__file__).resolve().parent
allow={
    'README.md','requirements.txt','R047_EVIDENCE_AUDIT.md','R047_SOURCE_LEDGER.json',
    'R047_PUBLISHED_COMPARISON.csv','R047_ROBUSTNESS.json','R047_RESULTS.json',
    'R047_INDEPENDENT_CROSSCHECK.json','R047_TEST_LOG.txt','R048_RESEARCH_GATE.md',
    'MASTER_CONTROLLER_v3.8.md','r047_analysis.py','build_reports.py',
    'statsmodels_crosscheck.py','panel_derivative.b64.txt',
    'tests/test_r047.py','finalize_package.py',
}
assert all((root/x).is_file() for x in allow),[str(x) for x in allow if not (root/x).is_file()]
files=sorted(allow)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
check=''.join(f'{sha(root/f)}  {f}\n' for f in files)
(root/'CHECKSUMS.sha256').write_text(check,encoding='utf-8')
manifest={
  'round':'R047','date':'2026-10-15','version':'v0.1',
  'title':'随机截距兼容复算与罚款字段稳健性',
  'controller_version':'v3.8','PESEN_v0.1':'FROZEN',
  'original_csv_binaries_in_archive':False,
  'project_source_data_level':'connected GitHub source full read, local anonymized lossy panel, optional original strict source SHA gate',
  'stata_re_published_exactly_reproduced':False,
  'models_random_intercept_gaussian_ml':8,
  'distinct_subjects_reused':64,'experiment_subjects_total':128,
  'tests_pytest_passed':55,
  'independent_statsmodels_crosscheck':8,
  'files':[{'path':f,'sha256':sha(root/f),'size_bytes':(root/f).stat().st_size} for f in files],
}
(root/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
archive=root.parent/'心理史学_R047_正式研究包_2026-10-15.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for file in files+['CHECKSUMS.sha256','MANIFEST.json']:
        z.write(root/file,arcname=root.name+'/'+file)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(files)+2
    for f in files:
        assert hashlib.sha256(z.read(root.name+'/'+f)).hexdigest()==sha(root/f)
controller=root.parent/'心理史学_研究主控台_v3.8_2026-10-15.md'
assert (root/'MASTER_CONTROLLER_v3.8.md').read_bytes()==controller.read_bytes()
old=(root.parent/'心理史学_研究主控台_v3.7_2026-10-15.md').read_text(encoding='utf-8')
assert controller.read_text(encoding='utf-8').startswith(old.rstrip())
print('archive',archive,archive.stat().st_size,'bytes; verified',len(files)+2,'files; controller',controller,'verified',controller.stat().st_size,'bytes')
print('sha256 zip',sha(archive))
