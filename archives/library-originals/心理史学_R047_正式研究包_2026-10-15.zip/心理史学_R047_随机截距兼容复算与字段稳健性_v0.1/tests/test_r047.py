import base64
import json
import os
import pathlib
import sys
from collections import Counter
from unittest import mock
import numpy as np
import pytest

ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import r047_analysis as a

@pytest.fixture(scope='module')
def panel():return a.decode_panel()

@pytest.fixture(scope='module')
def rows(panel):return a.longitudinal_design(panel)

@pytest.fixture(scope='module')
def results():return a.summarize()

@pytest.mark.parametrize('group_count', [16])
def test_group_count(panel,group_count):assert len({x['group'] for x in panel})==group_count

def test_exact_source_blob_sha():assert len(a.SOURCE_SHA)==40 and a.DTA_SHA!=a.SOURCE_SHA

def test_hash_known():assert a.git_blob_sha(b'hello')=='b6fc4c620b67d95f953a5c1c1230aaab5db5a1b0'

def test_decode_counts(panel):assert len(panel)==1024 and len({p['person'] for p in panel})==64

def test_16_periods_each(panel):assert all(sum(z['person']==pid for z in panel)==16 for pid in range(64))

def test_each_period_once(panel):assert all({z['t'] for z in panel if z['person']==pid}==set(range(1,17)) for pid in range(64))

def test_each_group_has_four(panel):assert set(Counter(x['group'] for x in panel).values())=={64}

def test_each_group_has_one_treatment(panel):assert all(len({x['arm'] for x in panel if x['group']==g})==1 for g in a.GROUP_NAMES)

def test_source_receipts_multiples_three(panel):assert all(z['raw']%3==0 and z['verified']%3==0 for z in panel)

def test_exact_80_mismatches(panel):assert sum(z['raw']!=z['verified'] for z in panel if z['t']>=2)==80

def test_equal_case_only_anomalies(panel):assert all(z['arm']=='11' for z in panel if z['raw']!=z['verified'] and z['t']>=2)

def test_group_specific_anomalies(panel):assert {z['group'] for z in panel if z['raw']!=z['verified'] and z['t']>=2}=={'11_7_4','11_8_5','11_8_6','11_8_7','11_8_8'}

def test_896_transitions(rows):assert len(rows)==896

def test_transition_lag_y(rows):assert all(isinstance(z['y'],int) for z in rows)

def test_transition_excludes_future_receipts(rows,panel):
    m={(z['person'],z['t']):z for z in panel}
    assert all(z['raw']==m[(z['person'],z['t']-1)]['raw'] for z in rows)

def test_lag_receipt_mismatch_count(rows):assert sum(z['raw']!=z['verified'] for z in rows)==80-(sum(z['raw']!=z['verified'] for z in a.decode_panel() if z['t']==16))

@pytest.mark.parametrize('timing,stratum,n', [('current','B',451),('current','A',414),('previous','B',450),('previous','A',417)])
def test_sample_size(rows,timing,stratum,n):assert len(a.prepare(rows,timing,'raw',stratum))==n
@pytest.mark.parametrize('timing,stratum', [('current','B'),('current','A'),('previous','B'),('previous','A')])
def test_error_variant_sample_same(rows,timing,stratum):assert len(a.prepare(rows,timing,'raw',stratum))==len(a.prepare(rows,timing,'verified',stratum))

@pytest.mark.parametrize('timing,receipt,stratum',[('fake','raw','B'),('current','foo','B'),('current','raw','none')])
def test_invalid_models_rejected(rows,timing,receipt,stratum):
    with pytest.raises(ValueError):a.prepare(rows,timing,receipt,stratum)

@pytest.mark.parametrize('key,reference',[
  ('current_B_raw',(-.7815277895799978,-.12244509313773339,-.06321710183537477)),
  ('current_B_verified',(-.7706275419152097,-.12422250730782965,-.07317472769056052)),
  ('current_A_raw',(-.9483632760711553,-.21524319357993826,-.019401087198993694)),
  ('current_A_verified',(-.9930565852950983,-.23464013337347694,-.06104909359077931)),
  ('previous_B_raw',(.9532906303814601,-.07446649159393007,.035829657301171595)),
  ('previous_B_verified',(.9591785508598561,-.08532475523899362,-.007411236281152464)),
  ('previous_A_raw',(.47839088520075324,-.10232619493351847,-.04946295610727139)),
  ('previous_A_verified',(.4305608287247536,-.10977126200019065,-.06824465111548329)),
])
def test_ols_exact_independent_previous_round(key,reference,results):
    fit=results['models'][key]['pooled_ols_coefficients']
    assert np.allclose([fit['deviation_ed'],fit['punishment_unequal'],fit['punishment_equal']],reference,atol=1e-9)

@pytest.mark.parametrize('key,reference',[('current_B_raw',(-.788891,-.122489,-.063395)),('current_A_raw',(-1.053546,-.264680,-.014932)),('current_A_verified',(-1.082767,-.279819,-.062598)),('previous_B_verified',(.972215,-.088691,-.006940))])
def test_re_ml_reference(key,reference,results):
    c=results['models'][key]['coefficients']
    assert np.allclose([c['deviation_ed'],c['punishment_unequal'],c['punishment_equal']],reference,atol=1e-5)


def test_optimized_objective_not_worse_than_zero(rows):
    m=a.collapsed_re_by_person(a.prepare(rows,'current','raw','A'))
    r=a.fit_ml_re(a.prepare(rows,'current','raw','A'))['variance_ratio_random_intercept']
    N=sum(q['n'] for q in m)
    objective=lambda t:N*np.log(a.gls_profile(m,t)['sse']/N)+a.gls_profile(m,t)['relative_logdet']
    assert objective(r)<=objective(0)+1e-8


def test_profiles_do_not_interpret_independent_decisions(rows):
    f=a.fit_ml_re(a.prepare(rows,'current','raw','B'))
    assert f['subjects']<=64 and f['groups']==16 and f['session_clusters']==4


def test_negative_variance_ratio(rows):
    m=a.collapsed_re_by_person(a.prepare(rows,'current','raw','B'))
    with pytest.raises(ValueError):a.gls_profile(m,-.1)


def test_profile_explicit_covariance():
    person=np.array([0,0,0,1,1,1,1]); y=np.array([1.,3.,5.,4.,2.,1.,0.]);X=np.array([[1,0,0,0],[1,1,0,0],[1,0,1,0],[1,0,0,0],[1,0,0,1],[1,2,0,0],[1,0,1,1]],float)
    data=[(int(person[i]), 'g'+str(int(person[i])), int(person[i]),float(y[i]),X[i]) for i in range(len(y))]
    m=a.collapsed_re_by_person(data);rho=.7
    z=a.gls_profile(m,rho)
    V=np.zeros((7,7));
    for i in range(7):
        for j in range(7): V[i,j]=(i==j)+rho*(person[i]==person[j])
    Vinv=np.linalg.inv(V)
    expected=np.linalg.solve(X.T@Vinv@X,X.T@Vinv@y)
    assert np.allclose(z['b'],expected,atol=1e-10)
    assert abs(z['sse']-(y-X@expected).T@Vinv@(y-X@expected))<1e-9


def test_statsmodels_independent_random_intercept(rows):
    import statsmodels.api as sm
    data=a.prepare(rows,'current','raw','A');z=a.fit_ml_re(data)
    X=np.asarray([q[4] for q in data]);y=np.asarray([q[3] for q in data]);groups=np.asarray([q[0] for q in data]);
    r=sm.MixedLM(y,X,groups=groups).fit(reml=False,method='powell',maxiter=250,disp=False)
    assert r.converged
    assert np.allclose(list(z['coefficients'].values()),r.fe_params,atol=1e-5)


def test_corrupt_derivative_rejected(tmp_path):
    p=tmp_path/'broken.txt';p.write_text('DATA=AA==\nCORR=AA==\n')
    with pytest.raises(ValueError):a.decode_panel(p)


def test_bad_correction_duplicate_rejected(tmp_path):
    dat=dict(s.split('=',1) for s in a.PACKED.read_text().splitlines())
    z=bytearray(base64.b64decode(dat['CORR']));z[3:6]=z[:3]
    p=tmp_path/'corrupt.b64.txt';p.write_text('DATA='+dat['DATA']+'\nCORR='+base64.b64encode(z).decode()+'\n')
    with pytest.raises(ValueError):a.decode_panel(p)


def test_wrong_dta_fingerprint_rejected(tmp_path):
    f=tmp_path/'claimed.dta';f.write_bytes(b'fake Stata')
    with pytest.raises(ValueError):
        ifhash=a.git_blob_sha(f.read_bytes())
        if ifhash!=a.DTA_SHA:raise ValueError('DTA source fingerprint mismatch')


def test_wrong_raw_csv_fingerprint_rejected(tmp_path):
    f=tmp_path/'data.csv';f.write_text('ProfileID,RoundID\n1,1\n')
    with pytest.raises(ValueError):a.build_derived_from_verified_csv(f)


def test_small_n_rejects():
    with pytest.raises(ValueError):a.fit_ml_re([])


def test_re_smoothly_reduce_to_ols(rows):
    m=a.collapsed_re_by_person(a.prepare(rows,'current','raw','B'))
    fit=a.gls_profile(m,0.)
    z=a.fit_ml_re(a.prepare(rows,'current','raw','B'))['pooled_ols_coefficients']
    assert np.allclose(fit['b'],list(z.values()))


def test_anon_derivative_has_no_source_ids():
    s=a.PACKED.read_text()
    assert 'ProfileID' not in s and 'Seq1' not in s and 'Received' not in s


def test_author_published_comparability_not_identity(results):
    l=results['models']['current_B_raw']['coefficients']
    assert abs(l['punishment_unequal']+0.123)<0.002
    assert abs(l['punishment_equal']+0.065)<0.003
    assert abs(l['deviation_ed']+.839)>0.03


def test_pre_timing_flips_deviation(rows):
    p=a.fit_ml_re(a.prepare(rows,'previous','verified','B'))['coefficients']['deviation_ed']
    q=a.fit_ml_re(a.prepare(rows,'current','verified','B'))['coefficients']['deviation_ed']
    assert p>0 and q<0


def test_corrected_high_equal_slope_shift(rows):
    p=a.fit_ml_re(a.prepare(rows,'current','verified','A'))['coefficients']['punishment_equal']
    q=a.fit_ml_re(a.prepare(rows,'current','raw','A'))['coefficients']['punishment_equal']
    assert p<q-0.035


def test_published_counts_in_data(results):
    assert results['models']['current_B_raw']['n']==a.PUBLISHED['current_B_source']['n']
    assert results['models']['current_A_raw']['n']==a.PUBLISHED['current_A_source']['n']
