import unittest
import json
import csv
import hashlib
import subprocess
import sys
from collections import Counter
from pathlib import Path
from tempfile import TemporaryDirectory

from r052_selection_audit import (
    CANONICAL, binary, build_transitions, deterministic_colliding_selection,
    evaluate_leave_one_session_out, p_smoothed, row_to_canonical, sha256_file,
    validate_panel, worst_case_missing_bounds,
)


def toy_row(*, session="A", subject="u", partner="v", game="1", rnd=1,
            coop=1, partner_coop=3, punished=0, given=0, out=0,
            partner_out=0, role="weak", game_type="asymmetric"):
    return dict(session=session, subject=subject, partner=partner,
                game=game, round=rnd, cooperation=coop,
                partner_cooperation=partner_coop, received_punishment=punished,
                gave_punishment=given, opted_out=out,
                partner_opted_out=partner_out, role=role, game_type=game_type)


class R052Tests(unittest.TestCase):
    def test_binary_zero(self): self.assertEqual(binary("0", "x"), 0)
    def test_binary_one(self): self.assertEqual(binary("1", "x"), 1)
    def test_binary_reject_two(self):
        with self.assertRaises(ValueError): binary("2", "x")
    def test_sha256(self):
        with TemporaryDirectory() as d:
            p = Path(d)/"a"; p.write_bytes(b"abc")
            self.assertEqual(sha256_file(p), "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad")
    def test_mapping_all(self):
        row = toy_row()
        row["round"] = "1"
        row["cooperation"] = "1"
        row["partner_cooperation"] = "3"
        for k in ("received_punishment", "gave_punishment", "opted_out", "partner_opted_out"):
            row[k] = "0"
        out = row_to_canonical(row, {k:k for k in CANONICAL})
        self.assertEqual(out["round"], 1)
    def test_mapping_reject_incomplete(self):
        with self.assertRaises(ValueError): row_to_canonical({}, {"session": "session"})
    def test_mapping_reject_values_out_of_range(self):
        row = {k: str(v) for k,v in toy_row(coop=7).items()}
        with self.assertRaises(ValueError): row_to_canonical(row, {k:k for k in CANONICAL})
    def test_validate_one(self): self.assertEqual(validate_panel([toy_row()])["rows"], 1)
    def test_duplicate_reject(self):
        a=toy_row()
        with self.assertRaises(ValueError): validate_panel([a,a])
    def test_bad_partner_reject(self):
        with self.assertRaises(ValueError): validate_panel([toy_row(partner="u")])
    def test_pair_reciprocal(self):
        a=toy_row();b=toy_row(subject="v",partner="u",coop=3,partner_coop=1)
        self.assertEqual(validate_panel([a,b])["rows"],2)
    def test_exit_allows_blank_cooperation_and_punishment(self):
        row={k: str(v) for k,v in toy_row(out=1).items()}
        for k in ("cooperation", "partner_cooperation", "received_punishment", "gave_punishment"):
            row[k] = ""
        o = row_to_canonical(row, {k:k for k in CANONICAL})
        self.assertIsNone(o["cooperation"])
        events, counters=build_transitions([o,toy_row(rnd=2)])
        self.assertEqual((len(events), counters["opt_out_n_or_n_plus_1"]),(0,1))
    def test_no_exit_rejects_blank_cooperation(self):
        row={k: str(v) for k,v in toy_row().items()}; row["cooperation"]=""
        with self.assertRaises(ValueError): row_to_canonical(row,{k:k for k in CANONICAL})
    def test_partner_coop_mismatch(self):
        a=toy_row();b=toy_row(subject="v",partner="u",coop=2,partner_coop=1)
        with self.assertRaises(ValueError): validate_panel([a,b])
    def test_transition_eligible(self):
        a=toy_row();b=toy_row(rnd=2,coop=2,punished=1)
        e,r=build_transitions([a,b])
        self.assertEqual(len(e),1)
        self.assertEqual(e[0]["increased_next_round"],1)
        self.assertEqual(e[0]["received_punishment_n"],0)
    def test_out_at_next_round_excludes(self):
        e,r=build_transitions([toy_row(),toy_row(rnd=2,out=1)])
        self.assertEqual((len(e),r["opt_out_n_or_n_plus_1"]),(0,1))
    def test_previous_not_lower_excludes(self):
        e,r=build_transitions([toy_row(coop=4),toy_row(rnd=2)])
        self.assertEqual((len(e),r["not_lower_cooperator_in_n"]),(0,1))
    def test_avoid_cross_game(self):
        e,r=build_transitions([toy_row(game="1",rnd=50),toy_row(game="2",rnd=1)])
        self.assertEqual(len(e),0)
    def test_round_gap_excludes(self):
        e,r=build_transitions([toy_row(),toy_row(rnd=3)])
        self.assertEqual((len(e),r["missing_consecutive_round"]),(0,1))
    def test_partner_switch_excludes(self):
        e,r=build_transitions([toy_row(),toy_row(partner="w",rnd=2)])
        self.assertEqual((len(e),r["partner_change_within_game"]),(0,1))
    def test_null_example_exact(self):
        x=deterministic_colliding_selection()
        self.assertAlmostEqual(x["missing_fraction"],.03)
        self.assertAlmostEqual(x["spurious_observed_difference"],.0309278350515464)
    def test_null_example_bounds_include_zero(self):
        b=deterministic_colliding_selection()["sharp_bounds"]
        self.assertAlmostEqual(b["contrast_min"],0)
        self.assertAlmostEqual(b["contrast_max"],.06)
    def test_bounds_invalid(self):
        with self.assertRaises(ValueError): worst_case_missing_bounds(10,9,10,10,9,4)
    def test_bounds_all_observed(self):
        b=worst_case_missing_bounds(10,10,3,10,10,5)
        self.assertAlmostEqual(b["contrast_min"],.2)
        self.assertAlmostEqual(b["contrast_max"],.2)
    def test_smoothing(self):
        t=Counter({("n", ("weak",)):2, ("y", ("weak",)):1})
        self.assertAlmostEqual(p_smoothed(t,("weak",),.5),.5)
    def test_evaluate_refuses_single_session(self):
        with self.assertRaises(ValueError):
            evaluate_leave_one_session_out([{"session":"A"}])
    def test_cli_real_source_gate_on_constructed_bytes(self):
        # This exercises the full pipeline on constructed rows only.
        with TemporaryDirectory() as d:
            root=Path(d); f=root/"constructed.csv"; schema=root/"schema.json"; out=root/"result.json"
            rs=[]
            for sess in ("A","B"):
                for rnd in (1,2):
                    low=toy_row(session=sess,rnd=rnd,coop=1 if rnd==1 else 2,partner_coop=3)
                    high=toy_row(session=sess,subject="v",partner="u",rnd=rnd,coop=3,
                                 partner_coop=1 if rnd==1 else 2,role="strong")
                    rs.extend((low,high))
            with f.open("w",newline="",encoding="utf-8") as stream:
                writer=csv.DictWriter(stream,fieldnames=CANONICAL);writer.writeheader();writer.writerows(rs)
            schema.write_text(json.dumps({k:k for k in CANONICAL}),encoding="utf-8")
            digest=sha256_file(f)
            command=[sys.executable,str(Path(__file__).parent/"r052_selection_audit.py"),
                     "--source-csv",str(f),"--schema-map",str(schema),
                     "--expected-sha256",digest,"--output",str(out)]
            good=subprocess.run(command,capture_output=True,text=True)
            self.assertEqual(good.returncode,0,good.stderr)
            result=json.loads(out.read_text())
            self.assertEqual(result["eligible_transition_count"],2)
            self.assertIn("requires_independent_audit",result["source_status"])
            out.unlink()
            command[command.index(digest)]="0"*64
            bad=subprocess.run(command,capture_output=True,text=True)
            self.assertNotEqual(bad.returncode,0)
            self.assertFalse(out.exists())

    def test_evaluate_two_sessions(self):
        events=[]
        for s in ["A","B"]:
            for i in range(20):
                events.append({"session":s,"role":"weak","game_type":"symmetric",
                               "received_punishment_n": i%2,"cooperation_n":i%6,
                               "increased_next_round":(i+s.count("B"))%2})
        x=evaluate_leave_one_session_out(events)
        self.assertEqual(len(x["by_session"]),2)
        self.assertTrue(all(0 <= v["M3_add_prior_cooperation"]["brier"] <= 1 for v in x["by_session"].values()))


if __name__ == "__main__": unittest.main(verbosity=2)
