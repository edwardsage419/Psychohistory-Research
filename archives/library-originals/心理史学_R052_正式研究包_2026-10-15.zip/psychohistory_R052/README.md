# 心理史学 R052 研究包

本包是R051的下一轮增量。内容分为真实公开论文来源核验、独立数学/合成反例、源门槛验证程序以及下一轮科研关口。

本地验证：

```bash
cd psychohistory_R052
python -m unittest -v test_r052.py
python r052_selection_audit.py --null-example
```

若以后合法取得Bone等2016 S5 CSV，并核实了真实字段定义，可另建**实际**列映射JSON，再执行：

```bash
python r052_selection_audit.py \
  --source-csv /your/path/official-s5.csv \
  --schema-map /your/path/reviewed-column-map.json \
  --expected-sha256 <independently-recorded-SHA256> \
  --output /your/path/heldout-results.json
```

这里的`<...>`为必须由合法取得的实际文件代入的占位符，禁止假设原始文件字段已经过核验。用户提供的自身SHA只能证明输入字节匹配其声明，不能独立证明官方来源真实。R052没有Bone新数据预测结果。

重要：公式缺失界限需要定义退出后的潜在二元结果；如果退出后目标没有定义，不能直接用于真实行为因果效应。PESEN v0.1维持冻结。
