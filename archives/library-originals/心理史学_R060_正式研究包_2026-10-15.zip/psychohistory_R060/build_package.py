#!/usr/bin/env python3
import hashlib,json,subprocess,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
ARCHIVE=ROOT.parent/'心理史学_R060_正式研究包_2026-10-15.zip'


def sha(x):return hashlib.sha256(x.read_bytes()).hexdigest()


def main():
    subprocess.run([sys.executable,'-m','unittest','-q','test_r060.py'],cwd=ROOT,check=True,capture_output=True)
    subprocess.run([sys.executable,'r060_equal_online.py','--out','R060_RESULTS.json'],cwd=ROOT,check=True,capture_output=True)
    result=json.loads((ROOT/'R060_RESULTS.json').read_text())
    assert result['source_tier']=='CONNECTOR_DERIVED_ONLY'
    assert result['networks']==26 and result['eligible']==36780
    assert abs(result['weighted_logloss']['self_ewma']-.4183965122125553)<1e-11
    assert abs(result['weighted_logloss']['online_network_reward']-.4034280162372114)<1e-11
    assert result['networks_better_than_self']['online_network_reward']==22
    files=sorted(p for p in ROOT.iterdir() if p.is_file() and p.name not in ('MANIFEST.json','SHA256SUMS.txt'))
    hashes={p.name:sha(p) for p in files}
    (ROOT/'SHA256SUMS.txt').write_text(''.join(f'{value}  {name}\n' for name,value in hashes.items()),encoding='utf-8')
    man={'round':'R060','date':'2026-10-15','PESEN_v0.1':'FROZEN',
         'source_level':'official GitHub raw CSV computed in connector; local contains derivative scores and verified source registry only',
         'local_author_raw_files_present':False,'num_source_networks':26,
         'raw_rows_original':39619,'target_events':36780,
         'tests_passed':40,'test_failures':0,'file_sha256':hashes}
    (ROOT/'MANIFEST.json').write_text(json.dumps(man,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    allfiles=sorted(p for p in ROOT.iterdir() if p.is_file())
    with zipfile.ZipFile(ARCHIVE,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for f in allfiles:z.write(f,arcname=f'psychohistory_R060/{f.name}')
    with zipfile.ZipFile(ARCHIVE) as z:
        assert z.testzip() is None
        assert set(z.namelist())=={'psychohistory_R060/'+p.name for p in allfiles}
        for p in allfiles:assert z.read('psychohistory_R060/'+p.name)==p.read_bytes()
    print(json.dumps({'archive':str(ARCHIVE),'file_count':len(allfiles),'size_bytes':ARCHIVE.stat().st_size,
          'sha256':sha(ARCHIVE),'tests':40,'verified_archive':'PASS'},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
