#!/usr/bin/env python3
"""R060 independent software controls and connector-derived reference tests."""
import copy,io,json,math,random,tempfile,unittest
from pathlib import Path
import r060_equal_online as mod
from r058_replay import read_counts,git_sha,recount_raw_bytes
from r059_online import online_rows

ROOT=Path(__file__).resolve().parent


def fixture():
    patterns={
        '1':['a','a','b','b','b','b'],
        '2':['a','b','b','b','a','a'],
        '3':['q','q','q','r','r','r'],
        '4':['q','q','r','r','r','q'],
    }
    partners={'1':'2','2':'1','3':'4','4':'3'}
    rows=[]
    for t in range(1,7):
        for uid,s in patterns.items():
            peer=patterns[partners[uid]]
            rows.append({'id':uid,'TrialNumber':str(t),'Response':s[t-1],
                'prev_response':s[t-2] if t>=2 else 'nan',
                'partner_prev_response':peer[t-2] if t>=2 else 'nan',
                'partner_response':peer[t-1],
                'Points':str(float(s[t-1]==peer[t-1])),
                'DecisionType':'RS' if t%2 else 'BN'})
    return rows


class BasicTests(unittest.TestCase):
    def setUp(self):self.rows=fixture()
    def test_basic_output(self):
        x=mod.score_raw_rows(self.rows);self.assertEqual(x['n'],16);self.assertEqual(x['rows'],24)
        self.assertEqual(set(x['logloss']),set(mod.MODES))
    def test_probabilities_are_finite(self):
        x=mod.score_raw_rows(self.rows,details=True)
        for z in x['predictions']:
            for m in mod.MODES:self.assertGreater(z[m],0);self.assertLess(z[m],1)
    def test_counts_by_time(self):
        x=mod.score_raw_rows(self.rows,details=True)
        self.assertEqual({z['t'] for z in x['predictions']},set(range(3,7)))
        self.assertEqual(len(x['per_time']),40)
    def test_time_one_not_evaluated(self):
        x=mod.score_raw_rows(self.rows,details=True)
        self.assertTrue(all(z['t']>=3 for z in x['predictions']))
    def test_initial_group_prior(self):
        xs=mod.score_raw_rows(self.rows,details=True)['predictions']
        # All t=3 predictions use previous completed t=2, no current-round information.
        self.assertEqual(len([z for z in xs if z['t']==3]),4)
    def test_all_models_same_sample(self):
        z=mod.score_raw_rows(self.rows,details=True)
        self.assertEqual(z['n'],len(z['predictions']))
        self.assertTrue(all(math.isfinite(a) for a in z['logloss'].values()))
    def test_permutation_invariant(self):
        random.Random(5).shuffle(self.rows)
        a=mod.score_raw_rows(self.rows)
        b=mod.score_raw_rows(fixture())
        for key in mod.MODES:self.assertAlmostEqual(a['logloss'][key],b['logloss'][key],places=12)
    def test_now_points_do_not_predict(self):
        a=mod.score_raw_rows(self.rows)
        for r in self.rows:r['Points']='nan'
        b=mod.score_raw_rows(self.rows)
        self.assertEqual(a['logloss'],b['logloss'])
    def test_decision_type_does_not_predict(self):
        a=mod.score_raw_rows(self.rows)
        for r in self.rows:r['DecisionType']='MAGIC_LABEL'
        self.assertEqual(a['logloss'],mod.score_raw_rows(self.rows)['logloss'])
    def test_current_partner_does_not_predict(self):
        a=mod.score_raw_rows(self.rows)
        for r in self.rows:r['partner_response']='unseen_future'
        self.assertEqual(a['logloss'],mod.score_raw_rows(self.rows)['logloss'])
    def test_future_round_cannot_change_earlier_predictions(self):
        a=mod.score_raw_rows(self.rows,details=True)['predictions']
        for r in self.rows:
            if int(r['TrialNumber'])>=6:r['Response']='unknown'
        b=mod.score_raw_rows(self.rows,details=True)['predictions']
        def short(xs):return [{k:v for k,v in z.items() if k!='id'} for z in xs if z['t']<6]
        self.assertEqual(short(a),short(b))
    def test_time_reverse_changes_past_history(self):
        a=mod.score_raw_rows(self.rows)
        for r in self.rows:
            if int(r['TrialNumber'])==2:r['Response']='not_the_same'
        b=mod.score_raw_rows(self.rows)
        self.assertNotEqual(a['logloss'],b['logloss'])
    def test_unseen_future_other_person_no_leak(self):
        a=mod.score_raw_rows(self.rows,details=True)['predictions']
        for r in self.rows:
            if int(r['TrialNumber'])==5 and r['id']=='1':r['Response']='replaced'
        b=mod.score_raw_rows(self.rows,details=True)['predictions']
        extract=lambda xs:[(z['id'],z['t'],z['online_network'],z['online_network_reward']) for z in xs if z['t']==5 and z['id']!='1']
        self.assertEqual(extract(a),extract(b))
    def test_unknown_partner_exclusion(self):
        r=[z for z in self.rows if z['id']=='1' and z['TrialNumber']=='4'][0];r['partner_prev_response']='nan'
        self.assertEqual(mod.score_raw_rows(self.rows)['n'],15)
    def test_missing_current_response_exclusion(self):
        r=[z for z in self.rows if z['id']=='1' and z['TrialNumber']=='4'][0];r['Response']='nan'
        self.assertEqual(mod.score_raw_rows(self.rows)['n'],15)
    def test_duplicate_subject_round_rejected(self):
        with self.assertRaisesRegex(ValueError,'duplicate'):
            mod.score_raw_rows(self.rows+[self.rows[0]])
    def test_bad_time_rejected(self):
        self.rows[0]['TrialNumber']='41'
        with self.assertRaisesRegex(ValueError,'trial'):mod.score_raw_rows(self.rows)
    def test_missing_column_rejected(self):
        del self.rows[0]['id']
        with self.assertRaisesRegex(ValueError,'required'):mod.score_raw_rows(self.rows)
    def test_empty_rejected(self):
        with self.assertRaises(ValueError):mod.score_raw_rows([])
    def test_zero_eligible_rejected(self):
        with self.assertRaises(ValueError):mod.score_raw_rows(self.rows[:8])
    def test_loss_boundary_invalid(self):
        for p in [-.1,0,1,1.1,float('nan')]:
            with self.assertRaises(ValueError):mod.loss(1,p)
    def test_missing_value_flag(self):
        for v in ['nan','NA','',None,'None']:
            self.assertFalse(mod.safe_response({'x':v},'x'))
    def test_alpha_weight_frozen(self):
        self.assertEqual(mod.ALPHA,.2);self.assertEqual(mod.NETWORK_WEIGHT,.25)
    def test_self_ewma_equals_legacy(self):
        v=mod.score_raw_rows(self.rows)['logloss']['self_ewma']
        old=online_rows(self.rows)['metrics']['ewma20']
        self.assertAlmostEqual(v,old,places=12)
    def test_network_prior_differs_from_conditional(self):
        s=mod.score_raw_rows(self.rows)['logloss']
        self.assertNotEqual(s['online_network'],s['online_network_reward'])


class RegistryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.registry=read_counts(ROOT/'R058_CONNECTOR_COUNTS.tsv')
        cls.data=mod.read_connector_scores()
        cls.previous=json.loads((ROOT/'R059_RESULTS.json').read_text())
    def test_26_referenced(self):self.assertEqual(len(self.data),26)
    def test_26_sha_registered(self):
        self.assertEqual({x['run']:x['sha'] for x in self.data},{x['name']:x['sha'] for x in self.registry})
    def test_network_registry_accepted(self):
        mod.verify_registry(self.registry,self.data,self.previous)
    def test_total_raw_rows(self):self.assertEqual(sum(x['rows'] for x in self.data),39619)
    def test_total_eligible(self):self.assertEqual(sum(x['n'] for x in self.data),36780)
    def test_all_baselines_match_r059(self):
        prev={r['run']:r for r in self.previous['per_network']}
        for z in self.data:self.assertAlmostEqual(z['self_ewma'],prev[z['run']]['ewma20'],places=11)
    def test_change_sha_rejected(self):
        x=copy.deepcopy(self.data);x[0]['sha']='0'*40
        with self.assertRaisesRegex(ValueError,'source metadata'):mod.verify_registry(self.registry,x,self.previous)
    def test_change_n_rejected(self):
        x=copy.deepcopy(self.data);x[0]['n']+=1
        with self.assertRaisesRegex(ValueError,'eligible count'):mod.verify_registry(self.registry,x,self.previous)
    def test_change_baseline_rejected(self):
        x=copy.deepcopy(self.data);x[0]['self_ewma']+=.001
        with self.assertRaisesRegex(ValueError,'baseline'):mod.verify_registry(self.registry,x,self.previous)
    def test_duplicate_run_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            f=Path(t)/'r.tsv'
            src=(ROOT/'R060_CONNECTOR_SCORES.tsv').read_text()
            f.write_text(src+src.strip().splitlines()[-1]+'\n')
            with self.assertRaisesRegex(ValueError,'duplicate'):mod.read_connector_scores(f)
    def test_nonfinite_score_rejected(self):
        x=(ROOT/'R060_CONNECTOR_SCORES.tsv').read_text()
        x=x.replace('0.45549595784677877','NaN',1)
        with tempfile.TemporaryDirectory() as t:
            f=Path(t)/'x.tsv';f.write_text(x)
            with self.assertRaisesRegex(ValueError,'numeric'):mod.read_connector_scores(f)
    def test_source_sha_computed(self):
        r=fixture(); s='id,TrialNumber,Response,prev_response,partner_prev_response,partner_response,Points,DecisionType\n'
        for z in r:s+=','.join(z[k] for k in ['id','TrialNumber','Response','prev_response','partner_prev_response','partner_response','Points','DecisionType'])+'\n'
        raw=s.encode();sha=git_sha(raw)
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'small.csv';p.write_bytes(raw);self.assertEqual(git_sha(p.read_bytes()),sha)
    def test_stats_consistent_with_report(self):
        a=mod.summary(self.data)
        self.assertAlmostEqual(a['weighted_logloss']['self_ewma'],.4183965122125553,places=11)
        self.assertLess(a['weighted_logloss']['online_network_reward'],a['weighted_logloss']['self_ewma'])
    def test_source_not_local(self):
        self.assertFalse((ROOT/'original_26_raw_verified').exists())
    def test_count_cells_match(self):
        self.assertEqual(sum(sum(z[0] for z in r['cells'].values()) for r in self.registry),36780)

if __name__=='__main__':unittest.main()
