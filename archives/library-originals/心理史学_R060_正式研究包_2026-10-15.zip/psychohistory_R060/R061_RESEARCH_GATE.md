# R061研究关口：寻找能够区分社会行为信号与私有奖励反馈的实验

1. **主要候选**：Najar, Bonnet, Bahrami & Palminteri (2020), “The actions of others act as a pseudo-reward to drive imitation in the context of social reinforcement learning,” *PLOS Biology* DOI `10.1371/journal.pbio.3001028`。官方代码库 `https://github.com/hrl-team/mfree_imitation`，GitHub仓库tree SHA `554ee8007ff6fd1c51cd68d7d254f22a34e6dab1`。公开 `data/task1.csv` Git blob `6f90784a49c26c92806b4876cb0ce4b446f810b1` (652,938 B) 与 `data/task2.csv` Git blob `5239155f233d42e4dbbe3f986865d5459a3e9cee` (905,163 B)，已确认文件表头包含实验/个体/场次/条件及私有奖励等字段。连接器的`start_line`只提供前几行，原始完整字节的本地真实性仍**待检验**。
2. 解析数据字典后严格分开：`id="dem"` 的示范者行为、真实主体可选择的轮次、`out`奖励、私有选择、示范者动作、`condition.obs`和`condition.demskill`。核对每个任务私有奖励和社会示范暴露的可观测时间。完整审查缺失、试次切换与有意安排的示范者“熟练/不熟练”条件。
3. **先冻结目标**：预测受试者观察后下一次私有选择，至少与“仅自己历史奖励”和“自己历史+示范者上次选择”比较；按受试者或原始实验独立分组，不以单行假独立。实验目标属于观察学习，不能直接当作R060协调奖励实验的系数复现。
4. 对潜在跨尺度：若发现独立社会信息增益，仍仅证明实验任务相关的个体决策信息价值；不直接推断组织制度更替或历史轨迹。
5. **持续缺口**：R060的26份原始CSV目前连接器侧审计和本地衍生文件验证完成，但本地原始26份尚未物化。持续保留SHA1完整重放门槛，不反复将网络不可达错误重包装为进展。
6. 新来源如果仍不可下载，在相同轮次将已存在来源的竞争解释作为结果保存，失败闭合并清楚标注。PESEN v0.1 FROZEN。
