# 心理史学 R060 归档 — 2026-10-15

包含原始实验网络**连接器侧**计算的26行匿名真实衍生得分以及本地完全可运行的Python标准库复算代码、测试、数学与实验限制报告、R061研究关口。

快速重算：
```
python -m unittest -v test_r060.py
python r060_equal_online.py --out R060_RESULTS.json
```

要验证26份实验原始CSV，按26个网络名称置于一个目录：
```
python r060_equal_online.py --raw-dir /path/to/author_raw_csvs --out raw_verified_result.json
```
必须全部通过冻结Git blob SHA1，才允许标记`LOCAL_ORIGINAL_VERIFIED`。目前正式档案 `source_tier=CONNECTOR_DERIVED_ONLY`。

研究论文：https://pmc.ncbi.nlm.nih.gov/articles/PMC12799169/ 。作者数据：https://github.com/jpriniski/NetCom 。下一轮候选：https://github.com/hrl-team/mfree_imitation 。
