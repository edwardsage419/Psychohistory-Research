import hashlib
import pathlib
import sys
import tempfile
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import r045_analysis as m


class DataLevelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data = m.parse_derived()
        cls.report = m.summarize()

    def test_source_fingerprint_length(self):
        self.assertEqual(len(m.SOURCE_GIT_BLOB), 40)

    def test_source_git_blob_sha(self):
        payload = b'hello\n'
        self.assertEqual(m.git_blob_sha(payload), hashlib.sha1(b'blob 6\0hello\n').hexdigest())

    def test_git_blob_mutation_changes_sha(self):
        self.assertNotEqual(m.git_blob_sha(b'a'), m.git_blob_sha(b'b'))

    def test_sixteen_distinct_groups(self):
        self.assertEqual(len(self.data), 16)
        self.assertEqual(len({x['gid'] for x in self.data}), 16)

    def test_four_sessions(self):
        self.assertEqual({x['session'] for x in self.data}, {'5', '6', '7', '8'})

    def test_two_group_arms(self):
        self.assertEqual({x['gid'][:2] for x in self.data}, {'01', '11'})

    def test_eight_groups_per_arm(self):
        for arm in ('01', '11'):
            self.assertEqual(sum(x['gid'].startswith(arm) for x in self.data), 8)

    def test_fifty_six_transitions_per_group(self):
        self.assertTrue(all(x['n'] == 56 for x in self.data))

    def test_n_transitions(self):
        self.assertEqual(sum(x['n'] for x in self.data), 896)

    def test_five_changed_groups(self):
        a = [x for x in self.data if x['raw'] != x['fix']]
        self.assertEqual(sorted(x['gid'] for x in a), ['11_7_4', '11_8_5', '11_8_6', '11_8_7', '11_8_8'])

    def test_unequal_untouched(self):
        self.assertTrue(all(x['raw'] == x['fix'] for x in self.data if x['equal'] == 0))

    def test_independent_result_requires_six_features(self):
        self.assertEqual(len(m.MODEL_VARS), 6)

    def test_upper_triangle_count(self):
        self.assertEqual(len(m.PAIR_ORDER), 10)

    def test_pair_order(self):
        self.assertEqual(m.PAIR_ORDER, [(0,0),(0,1),(0,2),(0,3),(1,1),(1,2),(1,3),(2,2),(2,3),(3,3)])

    def test_matrix_symmetry(self):
        import numpy as np
        a = m.unpack_upper(range(10))
        self.assertTrue(np.allclose(a, a.T))
        self.assertEqual(float(a[3,3]), 9.0)

    def test_pack_roundtrip(self):
        a = m.unpack_upper(range(10))
        self.assertEqual(m.pack_upper(a), list(range(10)))

    def test_upper_wrong_length_rejected(self):
        with self.assertRaises(ValueError): m.unpack_upper([1,2])

    def test_expanded_design_dimension(self):
        self.assertEqual(m.expand_group(self.data[0], 'raw')[0].shape, (6, 6))

    def test_binary_equal_design(self):
        import numpy as np
        for group in self.data:
            xx, xy = m.expand_group(group, 'raw')
            if group['equal'] == 0:
                self.assertTrue(np.array_equal(xx[4,:], np.zeros(6)))
                self.assertTrue(np.array_equal(xy[4:], np.zeros(2)))
            else:
                self.assertEqual(xx[4,4], group['n'])

    def test_five_suspicious_groups_in_equal_arm(self):
        self.assertTrue(all(x['equal'] == 1 for x in self.data if x['raw'] != x['fix']))

    def test_raw_slope_unequal_regression(self):
        self.assertAlmostEqual(self.report['models']['raw']['group_cluster']['implied_slope_unequal'], -0.0426659888468294, places=10)

    def test_corrected_slope_unequal_regression(self):
        self.assertAlmostEqual(self.report['models']['fix']['group_cluster']['implied_slope_unequal'], -0.04388925220631751, places=10)

    def test_raw_equal_slope(self):
        self.assertAlmostEqual(self.report['models']['raw']['group_cluster']['implied_slope_equal'], 0.001503868315922946, places=10)

    def test_corrected_equal_slope(self):
        self.assertAlmostEqual(self.report['models']['fix']['group_cluster']['implied_slope_equal'], -0.0178266513308896, places=10)

    def test_raw_equal_interaction(self):
        self.assertAlmostEqual(self.report['models']['raw']['group_cluster']['coef']['equal_x_lag_punishment'], .044169857162752346, places=10)

    def test_fixed_equal_interaction(self):
        self.assertAlmostEqual(self.report['models']['fix']['group_cluster']['coef']['equal_x_lag_punishment'], .026062600875427888, places=10)

    def test_raw_cluster_se(self):
        self.assertAlmostEqual(self.report['models']['raw']['group_cluster']['cluster_se']['equal_x_lag_punishment'], .014365378532897221, places=9)

    def test_corrected_cluster_se(self):
        self.assertAlmostEqual(self.report['models']['fix']['group_cluster']['cluster_se']['equal_x_lag_punishment'], .01749337795117454, places=9)

    def test_sixteen_group_clusters(self):
        self.assertEqual(self.report['models']['raw']['group_cluster']['clusters'], 16)

    def test_four_session_clusters(self):
        self.assertEqual(self.report['models']['raw']['session_cluster']['clusters'], 4)

    def test_cluster_point_estimate_invariance(self):
        for typ in ('raw','fix'):
            a=self.report['models'][typ]['group_cluster']['coef']
            b=self.report['models'][typ]['session_cluster']['coef']
            for k in a: self.assertAlmostEqual(a[k],b[k],places=11)

    def test_group_loo_has_sixteen(self):
        for name in ('raw', 'fix'):
            self.assertEqual(len(self.report['leave_one_group_out'][name]), 16)

    def test_corrected_loo_sign_can_change(self):
        x=[p['equal_slope'] for p in self.report['leave_one_group_out']['fix']]
        self.assertLess(min(x),0)
        self.assertGreater(max(x),0)

    def test_corrected_loo_expected_extremes(self):
        x=[p['equal_slope'] for p in self.report['leave_one_group_out']['fix']]
        self.assertAlmostEqual(min(x),-.02797622638598318, places=9)
        self.assertAlmostEqual(max(x), .009051812014034377, places=9)

    def test_equal_sign_change(self):
        self.assertTrue(self.report['sensitivity']['sign_change_equal_slope'])

    def test_change_in_equal_slope(self):
        self.assertAlmostEqual(self.report['sensitivity']['equal_slope_change'],-.01933051964681268,places=10)

    def test_wrong_group_crossproducts_rejected(self):
        original=m.parse_derived()
        invalid=original[:8]
        with self.assertRaises(ValueError): m.fit(invalid, 'raw')

    def test_empty_groups_rejected(self):
        with self.assertRaises(ValueError): m.fit([])

    def test_derived_malformed_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            p=pathlib.Path(td)/'x.csv'; p.write_text('invalid,23,1\n')
            with self.assertRaises(ValueError): m.parse_derived(p)

    def test_duplicate_groups_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            p=pathlib.Path(td)/'x.csv'; lines=m.DERIVED.read_text().splitlines()
            p.write_text('\n'.join(lines+[lines[0]]))
            with self.assertRaises(ValueError): m.parse_derived(p)

    def test_wrong_correction_marker_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            p=pathlib.Path(td)/'x.csv'; text=m.DERIVED.read_text().replace(',!,56,3585',',?,56,3585')
            p.write_text(text)
            with self.assertRaises(ValueError): m.parse_derived(p)

    def test_fake_raw_sha_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            p=pathlib.Path(td)/'source.csv'; p.write_text('bogus')
            with self.assertRaisesRegex(ValueError, 'fingerprint mismatch'):
                m.reconstruct_original(p)

    def test_fake_raw_columns_rejected_when_no_sha(self):
        with tempfile.TemporaryDirectory() as td:
            p=pathlib.Path(td)/'source.csv'; p.write_text('a,b\n1,2\n')
            with self.assertRaisesRegex(ValueError, 'Missing columns'):
                m.reconstruct_original(p,check_sha=False)


if __name__ == '__main__': unittest.main()
