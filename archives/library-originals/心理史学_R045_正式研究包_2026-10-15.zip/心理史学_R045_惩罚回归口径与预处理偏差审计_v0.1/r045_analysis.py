"""R045: author-data-derived, per-group exact linear crossproducts.

This is an exploratory pooled OLS sensitivity model, NOT the author's Stata RE model.
The raw-byte path is fail-closed and needs verified original CSV bytes.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
from collections import defaultdict
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent
DERIVED = ROOT / 'R045_GROUP_REGRESSION_SUFFICIENT_STATS.csv'
SOURCE_GIT_BLOB = '73c02176bc9e060af987149594a85f9f7b591230'
PAIR_ORDER = [(i, j) for i in range(4) for j in range(i, 4)]
MODEL_VARS = ['intercept', 'lag_punishment', 'lag_self_extraction',
              'lag_group_extraction_sum', 'equal', 'equal_x_lag_punishment']


def git_blob_sha(data: bytes) -> str:
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\x00' + data).hexdigest()


def unpack_upper(vals):
    if len(vals) != 10:
        raise ValueError('Expected exactly 10 upper-triangle elements')
    out = np.zeros((4, 4), dtype=float)
    for (i, j), v in zip(PAIR_ORDER, vals):
        out[i, j] = out[j, i] = float(v)
    return out


def pack_upper(M):
    return [int(round(M[i, j])) for i, j in PAIR_ORDER]


def parse_derived(path=DERIVED):
    ret = []
    for line in Path(path).read_text(encoding='utf-8').splitlines():
        if not line.strip():
            continue
        p = line.split(',')
        if len(p) not in (19, 34):
            raise ValueError('Malformed 19/34-field sufficient-stat row')
        gid, session = p[:2]
        h = int(gid.split('_')[0][0])
        v = list(map(int, p[2:19]))
        if v[0] <= 0 or v[0] != 56:
            raise ValueError('Expected exactly 56 target transitions/group')
        raw = {'xx': v[3:13], 'xy': v[13:17]}
        # Layout: n, sy, syy, 10 XTX and 4 XTY
        raw = {'xx': v[3:13], 'xy': v[13:17]}
        # v has 17 entries: n sy syy + 10 + 4
        fix = raw
        if len(p) == 34:
            if p[19] != '!':
                raise ValueError('Corrected block must begin with !')
            z = list(map(int, p[20:]))
            if len(z) != 14:
                raise ValueError('Wrong corrected block size')
            fix = {'xx': z[:10], 'xy': z[10:]}
            if h == 0:
                raise ValueError('Mismatch must be within equal treatment')
        if len(raw['xx']) != 10 or len(raw['xy']) != 4:
            raise ValueError('Invalid source crossproduct')
        ret.append({'gid': gid, 'session': session, 'equal': h, 'n': v[0],
                    'sy': v[1], 'syy': v[2], 'raw': raw, 'fix': fix})
    if len({x['gid'] for x in ret}) != len(ret):
        raise ValueError('Duplicate experiment group')
    return ret


def expand_group(g, version):
    # Base per-event [1, lag_received, lag_personal, lag_group_sum]
    # Expanded regression features [base, equal, equal*lag_received]
    h = g['equal']
    T = np.array([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0],
                  [0, 0, 0, 1], [h, 0, 0, 0], [0, h, 0, 0]], dtype=float)
    xx = unpack_upper(g[version]['xx'])
    xy = np.array(g[version]['xy'], dtype=float)
    return T @ xx @ T.T, T @ xy


def fit(groups, version='raw', cluster='gid'):
    if not groups:
        raise ValueError('No groups')
    k = len(MODEL_VARS)
    xx = np.zeros((k, k))
    xy = np.zeros(k)
    ssg = defaultdict(lambda: [np.zeros((k, k)), np.zeros(k)])
    n, y2 = 0, 0
    for g in groups:
        G, z = expand_group(g, version)
        xx += G
        xy += z
        cg = str(g[cluster])
        ssg[cg][0][:] += G
        ssg[cg][1][:] += z
        n += g['n']
        y2 += g['syy']
    if np.linalg.matrix_rank(xx) < k:
        raise ValueError('Design rank-deficient: check which arms present')
    inv = np.linalg.inv(xx)
    b = np.linalg.solve(xx, xy)
    rss = max(0.0, float(y2 - 2 * b @ xy + b @ xx @ b))
    meat = np.zeros((k, k))
    for mx, my in ssg.values():
        score = my - mx @ b
        meat += np.outer(score, score)
    G = len(ssg)
    if G < 2:
        raise ValueError('Need >=2 clusters')
    small = G / (G - 1) * (n - 1) / (n - k)
    V = small * inv @ meat @ inv
    se = np.sqrt(np.maximum(0, np.diag(V)))
    b = b.tolist()
    return {'n': n, 'clusters': G, 'coef': dict(zip(MODEL_VARS, b)),
            'cluster_se': dict(zip(MODEL_VARS, map(float, se))),
            'implied_slope_unequal': b[1],
            'implied_slope_equal': b[1] + b[5],
            'rss': rss, 'cluster_warning': 'Four sessions only; session SE not valid for precise hypothesis testing' if cluster == 'session' else '16 interacting groups in 4 treatment sessions; grouping does not resolve session-level confounding'}


def reconstruct_original(path: Path, check_sha=True):
    data = Path(path).read_bytes()
    if check_sha and git_blob_sha(data) != SOURCE_GIT_BLOB:
        raise ValueError('Author raw CSV Git blob fingerprint mismatch; reject results')
    import io
    source = list(csv.DictReader(io.StringIO(data.decode('utf-8-sig'))))
    needed = {'ProfileID', 'GameID', 'Session', 'Homo', 'FF', 'RoundID',
              'Invest', 'Received', 'Seq1', 'Seq2', 'Seq3', 'Seq4',
              'Total', 'Total2', 'Paid'}
    if not source or not needed <= set(source[0]):
        raise ValueError('Missing columns required for original-source audit')
    valid = [r for r in source if r['ProfileID'] and r['RoundID']]
    if len(valid) != 2048:
        raise ValueError(f'Original-source nonblank row count must be 2048, got {len(valid)}')
    rounds, people = defaultdict(list), defaultdict(list)
    for r in valid:
        arm = r['Homo'] + r['FF']
        g = f"{arm}_{r['Session']}_{r['GameID']}"
        t = int(r['RoundID'])
        ob = {'id': r['ProfileID'], 'gid': g, 'session': r['Session'], 'arm': arm,
              't': t, 'inv': int(r['Invest']),
              'rec': None if r['Received'] == '.' else int(r['Received']),
              'seq': [r[f'Seq{k}'] for k in range(1, 5)],
              'paid': None if r['Paid'] == '.' else int(r['Paid']),
              'total': None if r['Total'] == '.' else float(r['Total']),
              'total2': None if r['Total2'] == '.' else float(r['Total2'])}
        rounds[(g, t)].append(ob)
        people[ob['id']].append(ob)
    if len(people) != 128 or len(rounds) != 32 * 16:
        raise ValueError('Unexpected number of original subjects or group-rounds')
    previous_sum = {}
    n_recv_wrong = n_payoff_wrong = 0
    for key, row in rounds.items():
        if len(row) != 4:
            raise ValueError('Expected four unique members per group and round')
        previous_sum[key] = sum(x['inv'] for x in row)
        if row[0]['t'] == 1 or row[0]['arm'][1] == '0':
            continue
        slot = {}
        inbound = defaultdict(int)
        for x in row:
            slots = [j for j, amount in enumerate(x['seq']) if amount == '.']
            if len(slots) != 1 or slots[0] in slot:
                raise ValueError('Ambiguous per-round self-label position')
            slot[slots[0]] = x
        for x in row:
            sent = 0
            for j, amt in enumerate(x['seq']):
                if amt != '.':
                    inbound[slot[j]['id']] += int(amt)
                    sent += int(amt)
            if sent != 3 * x['paid']:
                raise ValueError('Inconsistent payment cost; reject')
        for x in row:
            x['fix'] = inbound[x['id']]
            n_recv_wrong += int(x['rec'] != x['fix'])
            n_payoff_wrong += int(abs(x['total'] - x['paid'] - x['fix'] - x['total2']) > 1e-6)
    if n_recv_wrong != 80 or n_payoff_wrong != 0:
        raise ValueError('Original document does not reproduce R044 ledger identities')
    counters = {}
    for person in people.values():
        person.sort(key=lambda x: x['t'])
        if len(person) != 16 or [x['t'] for x in person] != list(range(1, 17)):
            raise ValueError('Person-specific missing/duplicate periods')
        for t_idx in range(2, 16):
            current, prev = person[t_idx], person[t_idx - 1]
            if current['arm'][1] != '1':
                continue
            gid = current['gid']
            if gid not in counters:
                counters[gid] = {'gid': gid, 'session': current['session'],
                                 'equal': int(current['arm'][0] == '1'), 'n': 0,
                                 'sy': 0, 'syy': 0,
                                 'raw': {'xx': np.zeros((4, 4)), 'xy': np.zeros(4)},
                                 'fix': {'xx': np.zeros((4, 4)), 'xy': np.zeros(4)}}
            g = counters[gid]
            y = current['inv'] - prev['inv']
            g['n'] += 1
            g['sy'] += y
            g['syy'] += y ** 2
            for typ, v in (('raw', prev['rec']), ('fix', prev['fix'])):
                x = np.array([1, v, prev['inv'], previous_sum[(gid, prev['t'])]], float)
                g[typ]['xx'] += np.outer(x, x)
                g[typ]['xy'] += x * y
    result = []
    for gid in sorted(counters):
        g = counters[gid]
        for typ in ('raw', 'fix'):
            g[typ] = {'xx': pack_upper(g[typ]['xx']),
                      'xy': [int(round(x)) for x in g[typ]['xy']]}
        result.append(g)
    if result != parse_derived():
        raise ValueError('Original-source crossproducts differ from connected-source derivatives')
    return result


def summarize(path=DERIVED, raw=None):
    groups = parse_derived(path)
    if len(groups) != 16 or sum(g['n'] for g in groups) != 896:
        raise ValueError('Expected 16 actual punishment groups and 896 transitions')
    if raw is not None:
        reconstruct_original(Path(raw), check_sha=True)
    rows = {'stage': 'R045 real-source-derived exact OLS reanalysis, not a published Stata RE replication',
            'source_git_blob': SOURCE_GIT_BLOB,
            'features': MODEL_VARS,
            'group_count': 16, 'n_transitions': 896, 'session_count': 4,
            'source_level': 'author raw CSV parsed through connected GitHub; local independently recomputed per-group integer crossproducts; local raw mode provided but original bytes unavailable here',
            'models': {}, 'leave_one_group_out': {}}
    for version in ('raw', 'fix'):
        rows['models'][version] = {'group_cluster': fit(groups, version, 'gid'),
                                   'session_cluster': fit(groups, version, 'session')}
        loo = []
        for g in groups:
            v = fit([x for x in groups if x['gid'] != g['gid']], version, 'gid')
            loo.append({'omitted_group': g['gid'], 'equal_slope': v['implied_slope_equal'],
                        'unequal_slope': v['implied_slope_unequal']})
        rows['leave_one_group_out'][version] = loo
    a = rows['models']['raw']['group_cluster']
    b = rows['models']['fix']['group_cluster']
    rows['sensitivity'] = {'equal_slope_change': b['implied_slope_equal'] - a['implied_slope_equal'],
                           'interaction_change': b['coef']['equal_x_lag_punishment'] - a['coef']['equal_x_lag_punishment'],
                           'sign_change_equal_slope': a['implied_slope_equal'] > 0 and b['implied_slope_equal'] < 0,
                           'inferential_status': 'exploratory association; no proof of causal sanction effects; session-level assignment unverified'}
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--raw', type=Path, help='Original author data.csv; validate Git blob and all derived counts')
    ap.add_argument('--output', type=Path, help='Save JSON report')
    args = ap.parse_args()
    val = summarize(raw=args.raw)
    text = json.dumps(val, ensure_ascii=False, indent=2)
    if args.output:
        args.output.write_text(text + '\n', encoding='utf-8')
    print(json.dumps({'group_count': val['group_count'], 'n_transitions': val['n_transitions'],
                      'raw_slope_equal': val['models']['raw']['group_cluster']['implied_slope_equal'],
                      'fixed_slope_equal': val['models']['fix']['group_cluster']['implied_slope_equal'],
                      'measurement_sensitivity': val['sensitivity']}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
