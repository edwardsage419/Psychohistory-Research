# R045 — Punishment measurement error and temporal-control audit

R045使用作者`InequalityCPR`公开原始CSV经连接器全量读取产生的16四人组、896逐轮行为转移的**精确整数充分统计量**，在本地重建回归与稳健性结果。数据流及完整限制详见`R045_EVIDENCE_AUDIT.md`。

运行（只需Python与numpy）：

```bash
python r045_analysis.py --output R045_RESULTS_RECALCULATED.json
python -m unittest discover -s tests -v
```

若另行获取作者官方字节，则运行：

```bash
python r045_analysis.py --raw /path/to/data.csv --output R045_VERIFIED_FROM_RAW.json
```

使用标准Git blob SHA1核验源文件（原始CSV可含BOM、CRLF、空白行）；再验证2048条有效数据、32组、128人、4人各16轮、动态惩罚目标列、三重账单与全部16组交叉积。失败会拒绝结果。本会话**没有**实际执行该原始字节通路；本地软件测试不是作者Stata随机效应模型复现。

**科研结论不超出探索性数据测量敏感性**；PESEN v0.1冻结，不修改任何外部仓库。
