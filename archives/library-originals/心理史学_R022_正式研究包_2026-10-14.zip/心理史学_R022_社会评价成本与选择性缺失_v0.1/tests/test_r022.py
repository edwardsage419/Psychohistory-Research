import unittest
import csv
from pathlib import Path
from tempfile import TemporaryDirectory
from r022_analysis import (
    git_blob_sha, read_group_csv, validate_groups, cell_summary, effect, effect_and_bounds,
    stratified_group_bootstrap, full_sample_tipping_point, produce, derive_groups, METRICS
)
BASE = Path(__file__).resolve().parents[1]

class R022Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.gs = read_group_csv(BASE/'GROUP_COST_STATS.csv')

    def test_blob(self):
        self.assertEqual(git_blob_sha(b'test'),'30d74d258442c7c65512eafab474568dd706c430')

    def test_verified_design(self):
        self.assertTrue(validate_groups(self.gs))

    def test_exact_n(self):
        self.assertEqual(sum(x['n'] for x in self.gs),960)

    def test_exact_groups(self):
        self.assertEqual(len(self.gs),48)

    def test_zero_expression(self):
        self.assertEqual(sum(x['zeros'] for x in self.gs),205)

    def test_questionnaire_responses(self):
        for m in METRICS:
            self.assertEqual(sum(x[m+'_n'] for x in self.gs),705)

    def test_no_express_zero_and_response(self):
        self.assertEqual(sum(x['zeros_responded'] for x in self.gs),58)

    def test_silent_questionnaire_nonrespondent(self):
        self.assertEqual(sum(x['zeros']-x['zeros_responded'] for x in self.gs),147)

    def test_source_contrast_negative(self):
        self.assertAlmostEqual(effect_and_bounds(self.gs,'neg')['respondents_effect'],-0.3654656436541437,places=6)

    def test_source_contrast_time(self):
        self.assertAlmostEqual(effect_and_bounds(self.gs,'zeroeffect')['respondents_effect'],-0.0143856237563904,places=5)

    def test_source_bounds(self):
        b=effect_and_bounds(self.gs,'neg')['missingness_bound']
        self.assertAlmostEqual(b[0],-1.3026041666666668,places=5)
        self.assertAlmostEqual(b[1],.8223958333333332,places=5)

    def test_zero_in_bounds(self):
        low,up=effect_and_bounds(self.gs,'neg')['missingness_bound']
        self.assertLess(low,0);self.assertGreater(up,0)

    def test_direction_specificity(self):
        self.assertLess(effect_and_bounds(self.gs,'neg')['respondents_effect'],
                        effect_and_bounds(self.gs,'zeroeffect')['respondents_effect'])

    def test_tipping_point(self):
        self.assertAlmostEqual(full_sample_tipping_point(),2.949248120300752)

    def test_random_tipping(self):
        self.assertGreater(full_sample_tipping_point(low_missing_mean=2.5),
                           full_sample_tipping_point(low_missing_mean=2))

    def test_duplicate_rejection(self):
        with self.assertRaises(ValueError):validate_groups(self.gs+[self.gs[0]])

    def test_group_sample_corruption(self):
        gs=[dict(x) for x in self.gs]
        gs[0]['n']=0
        with self.assertRaises(ValueError):validate_groups(gs)

    def test_bounds_score_out_of_scale(self):
        gs=[dict(x) for x in self.gs]
        gs[0]['neg_sum']=10000
        with self.assertRaises(ValueError):validate_groups(gs)

    def test_mean_function(self):
        self.assertEqual(effect({'high|high':3,'low|high':1,'high|low':3,'low|low':1}),2)

    def test_bootstrap_reproducible(self):
        a=stratified_group_bootstrap(self.gs,B=50,seed=123)
        b=stratified_group_bootstrap(self.gs,B=50,seed=123)
        self.assertEqual(a,b)

    def test_bootstrap_direction_sample(self):
        a=stratified_group_bootstrap(self.gs,B=100,seed=123)['neg']
        self.assertLess(a[1],0)

    def test_source_sha_refusal(self):
        with self.assertRaises(ValueError):derive_groups(b'not author data')

    def test_clamp_logic(self):
        g=[dict(x) for x in self.gs];g[0]['zeros_responded']=99
        with self.assertRaises(ValueError):validate_groups(g)

    def test_produce(self):
        r=produce(self.gs,B=30,seed=77)
        self.assertEqual(r['selection_table_from_real_group_stats']['no_expression']['missing'],147)
        self.assertEqual(r['design']['missing'],255)

if __name__ == '__main__':unittest.main()
