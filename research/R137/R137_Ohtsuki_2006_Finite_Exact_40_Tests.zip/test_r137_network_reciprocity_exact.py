"""Tests for R137. Run python -m unittest -v test_r137_network_reciprocity_exact.py."""
import unittest
from fractions import Fraction as F
from itertools import product
from r137_network_reciprocity_exact import (
    cycle, complete, graph_automorphisms, orbit_data, payoff,
    transition_and_gradient, fixation_data, exact_threshold, exact_probability,
    solve, permute_mask, validate
)


class R137ExactFiniteNetworkTests(unittest.TestCase):
    def test_cycle_adjacency(self):
        self.assertEqual(cycle(5)[0], (1,4))

    def test_complete_adjacency(self):
        self.assertEqual(complete(4)[0], (1,2,3))

    def test_simple_graphs_reject_bad_cycle(self):
        for n in (0,1,2,3):
            with self.subTest(n=n), self.assertRaises(ValueError): cycle(n)

    def test_reject_graph_asymmetric(self):
        with self.assertRaises(ValueError): validate(((1,),(0,2),(0,)))

    def test_reject_graph_self_loop(self):
        with self.assertRaises(ValueError): validate(((0,1),(0,2),(1,)))

    def test_reject_graph_duplicate(self):
        with self.assertRaises(ValueError): validate(((1,1),(0,2),(1,)))

    def test_reject_graph_disconnected(self):
        graph=((1,2),(0,2),(0,1),(4,5),(3,5),(3,4))
        with self.assertRaises(ValueError): fixation_data(graph,'DB',F(3))

    def test_reject_irregular(self):
        graph=((1,2,3),(0,2),(0,1,3),(0,2))
        with self.assertRaises(ValueError): fixation_data(graph,'DB',F(3))

    def test_symmetric_graph_automorphisms(self):
        self.assertEqual(len(graph_automorphisms(cycle(5))),10)
        self.assertEqual(len(graph_automorphisms(cycle(6))),12)
        self.assertEqual(len(graph_automorphisms(cycle(8))),16)
        self.assertEqual(len(graph_automorphisms(complete(4))),24)

    def test_orbit_counts(self):
        self.assertEqual([len(orbit_data(cycle(n))[0]) for n in (5,6,8)],[8,13,30])
        self.assertEqual(len(orbit_data(complete(4))[0]),5)

    def test_orbit_cover_all_states(self):
        for g in (cycle(5),cycle(6),cycle(8),complete(4)):
            reps, lookup, aut=orbit_data(g)
            self.assertEqual(len(lookup),2**len(g))
            for s in range(1<<len(g)):
                self.assertEqual(lookup[s],lookup[permute_mask(s,aut[-1])])

    def test_donation_payoff(self):
        g=cycle(5)
        self.assertEqual(payoff(g,1,F(3),F(1)),(F(-2),F(3),F(0),F(0),F(3)))

    def test_donation_cost_paid_per_neighbor(self):
        self.assertEqual(payoff(complete(4),1,F(4),F(1))[0],F(-3))

    def test_reject_float_payoff(self):
        with self.assertRaises(ValueError): payoff(cycle(5),1,3.0,F(1))

    def test_reject_nonpositive_benefit_cost(self):
        with self.assertRaises(ValueError): payoff(cycle(5),1,F(0),F(1))
        with self.assertRaises(ValueError): payoff(cycle(5),1,F(1),F(0))

    def test_reject_invalid_update(self):
        with self.assertRaises(ValueError): transition_and_gradient(cycle(5),1,'WRONG',F(3),F(1))

    def test_neutral_markov_rows_and_zero_derivative(self):
        for g in (cycle(5),cycle(6),complete(4)):
            for s in range(1<<len(g)):
                for rule in ('DB','BD','IM'):
                    p,d=transition_and_gradient(g,s,rule,F(3),F(1))
                    self.assertEqual(sum(p.values()),1)
                    self.assertEqual(sum(d.values()),0)
                    self.assertTrue(all(x>=0 for x in p.values()))

    def test_absorbing_monotypes(self):
        for g in (cycle(5),complete(4)):
            for rule in ('DB','BD','IM'):
                for mask in (0,(1<<len(g))-1):
                    p,d=transition_and_gradient(g,mask,rule,F(3),F(1))
                    self.assertEqual(p,{mask:F(1)})
                    self.assertTrue(all(v==0 for v in d.values()))

    def test_neutral_single_cooperator_probability(self):
        for g in (cycle(5),cycle(6),cycle(8),complete(4)):
            for rule in ('DB','BD','IM'):
                self.assertEqual(fixation_data(g,rule,F(2))['neutral_fixation'],F(1,len(g)))

    def test_exact_cycle_db_thresholds(self):
        self.assertEqual([exact_threshold(cycle(n),'DB')['threshold'] for n in (5,6,8)], [F(6),F(4),F(3)])

    def test_2016_finite_formula_cycle_cases(self):
        for n in (5,6,8):
            expected=F(2*(n-2),n-4)
            self.assertEqual(exact_threshold(cycle(n),'DB')['threshold'],expected)

    def test_large_population_source_asymptotic_caution(self):
        self.assertNotEqual(exact_threshold(cycle(5),'DB')['threshold'],F(2))
        self.assertNotEqual(exact_threshold(cycle(6),'DB')['threshold'],F(2))

    def test_update_rule_changes_outcome(self):
        self.assertEqual(exact_threshold(cycle(8),'DB')['threshold'],F(3))
        self.assertEqual(exact_threshold(cycle(8),'IM')['threshold'],F(13))
        self.assertIsNone(exact_threshold(cycle(8),'BD')['threshold'])

    def test_bd_cycle_never_positive_selection_gradient(self):
        for n in (5,6,8):
            z=exact_threshold(cycle(n),'BD')
            self.assertLess(z['slope'],0)
            self.assertIsNone(z['threshold'])

    def test_complete4_no_threshold(self):
        for rule in ('DB','BD','IM'):
            self.assertIsNone(exact_threshold(complete(4),rule)['threshold'])

    def test_cycle6_gradient_at_boundary_zero(self):
        self.assertEqual(fixation_data(cycle(6),'DB',F(4))['gradient'],F(0))

    def test_cycle8_gradient_side_of_boundary(self):
        self.assertLess(fixation_data(cycle(8),'DB',F(2))['gradient'],0)
        self.assertGreater(fixation_data(cycle(8),'DB',F(4))['gradient'],0)

    def test_imitation_requires_higher_benefit_cycle8(self):
        self.assertLess(fixation_data(cycle(8),'IM',F(8))['gradient'],0)
        self.assertGreater(fixation_data(cycle(8),'IM',F(15))['gradient'],0)

    def test_neutral_exact_fixation_probability_independent(self):
        for g in (cycle(5),cycle(6),complete(4)):
            for rule in ('DB','BD','IM'):
                self.assertEqual(exact_probability(g,1,rule,F(3),F(1),F(0)),F(1,len(g)))

    def test_small_positive_strength_matches_exact_gradient_sign(self):
        for n,b,sign in ((5,5,-1),(5,7,1),(6,3,-1),(6,5,1),(8,2,-1),(8,4,1)):
            rho=exact_probability(cycle(n),1,'DB',F(b),F(1),F(1,10000))
            delta=rho-F(1,n)
            self.assertEqual((delta>0)-(delta<0),sign)

    def test_complete4_finite_strength_selection_against_cooperation(self):
        rho=exact_probability(complete(4),1,'DB',F(10),F(1),F(1,1000))
        self.assertLess(rho,F(1,4))

    def test_exact_solver_rejects_singular(self):
        with self.assertRaises(ArithmeticError): solve(((F(1),F(1)),(F(2),F(2))),(F(2),F(4)))

    def test_exact_solver_known_linear_system(self):
        self.assertEqual(solve(((F(2),F(1)),(F(1),F(1))),(F(5),F(3))),(F(2),F(1)))

    def test_reject_incorrect_strength_type(self):
        with self.assertRaises(ValueError): exact_probability(cycle(5),1,'DB',F(3),F(1),0.01)

    def test_reject_negative_strength(self):
        with self.assertRaises(ValueError): exact_probability(cycle(5),1,'DB',F(3),F(1),F(-1,100))

    def test_reject_nonpositive_fitness(self):
        with self.assertRaises(ValueError): exact_probability(cycle(5),1,'DB',F(3),F(1),F(1))

    def test_reject_unknown_direct_update(self):
        with self.assertRaises(ValueError): exact_probability(cycle(5),1,'INVALID',F(3),F(1),F(0))

    def test_pooled_mean_does_not_determine_fixation_probability(self):
        # Both configurations have 2C of 6 but a different number of C-C links.
        g=cycle(6)
        adjacent=(1<<0)|(1<<1)
        dispersed=(1<<0)|(1<<3)
        a=exact_probability(g,adjacent,'DB',F(5),F(1),F(1,100))
        b=exact_probability(g,dispersed,'DB',F(5),F(1),F(1,100))
        self.assertNotEqual(a,b)

    def test_cycle5_orbits_are_graph_symmetry_not_equilibrium_classes(self):
        reps,_,_=orbit_data(cycle(5))
        self.assertEqual(reps[0],0)
        self.assertEqual(reps[-1],(1<<5)-1)

    def test_fixation_gradient_exact_fraction(self):
        r=fixation_data(cycle(5),'DB',F(7))
        self.assertIsInstance(r['gradient'],F)
        self.assertEqual(r['gradient'],F(1,10))


if __name__=='__main__':
    unittest.main()
