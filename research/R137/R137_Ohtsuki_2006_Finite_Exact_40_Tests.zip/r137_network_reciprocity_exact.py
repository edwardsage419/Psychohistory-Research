"""R137: exact weak-selection fixation gradients for finite graph donation games.

Independent finite-N calculations. Read README for source and scope boundaries.
Requires only Python 3 standard library.
"""
from fractions import Fraction as F
from itertools import permutations
from collections import defaultdict


def cycle(n):
    if n < 4:
        raise ValueError('simple cycles require n >= 4')
    return tuple(tuple(sorted({(i-1) % n, (i+1) % n})) for i in range(n))


def complete(n):
    if n < 3:
        raise ValueError('n >= 3 required')
    return tuple(tuple(j for j in range(n) if j != i) for i in range(n))


def validate(g):
    n = len(g)
    if not 3 <= n <= 10:
        raise ValueError('size 3..10')
    for i, ns in enumerate(g):
        if not ns or len(set(ns)) != len(ns) or i in ns or any(type(j) is not int or j < 0 or j >= n for j in ns):
            raise ValueError('invalid neighbors')
        if any(i not in g[j] for j in ns):
            raise ValueError('asymmetric adjacency')
    return n


def graph_automorphisms(g):
    n = validate(g)
    result = []
    for p in permutations(range(n)):
        if all({p[j] for j in g[i]} == set(g[p[i]]) for i in range(n)):
            result.append(p)
    return tuple(result)


def permute_mask(s, p):
    return sum(1 << p[i] for i in range(len(p)) if (s >> i) & 1)


def orbit_data(g):
    n = validate(g)
    aut = graph_automorphisms(g)
    index = {}
    reps = []
    for s in range(1 << n):
        if s in index:
            continue
        orbit = {permute_mask(s, p) for p in aut}
        idx = len(reps)
        for z in orbit:
            index[z] = idx
        reps.append(min(orbit))
    assert len(index) == 1 << n
    return tuple(reps), index, aut


def payoff(g, state, benefit, cost):
    if not isinstance(benefit, F) or not isinstance(cost, F) or benefit <= 0 or cost <= 0:
        raise ValueError('benefit and cost positive Fraction')
    return tuple(benefit * sum((state >> j) & 1 for j in ns) - (cost * len(ns) if (state >> i) & 1 else 0) for i, ns in enumerate(g))


def replace_bit(state, site, donor):
    return (state | (1 << site)) if (state >> donor) & 1 else (state & ~(1 << site))


def derivative_probability(pay, site, pool):
    m = len(pool)
    return F(pay[site] * m - sum(pay[i] for i in pool), m * m)


def transition_and_gradient(g, state, update, benefit, cost):
    """Return exact neutral transition P(0) and derivative P'(0)."""
    n = validate(g)
    if not 0 <= state < (1 << n) or update not in ('DB', 'BD', 'IM'):
        raise ValueError('invalid state or update')
    pay = payoff(g, state, benefit, cost)
    p0, p1 = defaultdict(F), defaultdict(F)
    if update == 'DB':
        for dead, pool in enumerate(g):
            for donor in pool:
                nxt = replace_bit(state, dead, donor)
                p0[nxt] += F(1, n * len(pool))
                p1[nxt] += derivative_probability(pay, donor, pool) / n
    elif update == 'BD':
        pool = tuple(range(n))
        for donor in pool:
            for dead in g[donor]:
                nxt = replace_bit(state, dead, donor)
                p0[nxt] += F(1, n * len(g[donor]))
                p1[nxt] += derivative_probability(pay, donor, pool) / len(g[donor])
    else:  # IM: focal may copy own type
        for focal, ns in enumerate(g):
            pool = (focal,) + tuple(ns)
            for donor in pool:
                nxt = replace_bit(state, focal, donor)
                p0[nxt] += F(1, n * len(pool))
                p1[nxt] += derivative_probability(pay, donor, pool) / n
    assert sum(p0.values()) == 1
    assert sum(p1.values()) == 0
    return dict(p0), dict(p1)


def solve(A, b):
    """Exact Fraction Gauss-Jordan linear solve, reject nonuniqueness."""
    n = len(b)
    aug = [list(A[i]) + [b[i]] for i in range(n)]
    for col in range(n):
        pivot = next((i for i in range(col, n) if aug[i][col]), None)
        if pivot is None:
            raise ArithmeticError('noninvertible transient generator')
        aug[col], aug[pivot] = aug[pivot], aug[col]
        v = aug[col][col]
        aug[col] = [x / v for x in aug[col]]
        for row in range(n):
            if row == col or not aug[row][col]:
                continue
            mult = aug[row][col]
            aug[row] = [a - mult * q for a, q in zip(aug[row], aug[col])]
    return tuple(row[-1] for row in aug)


def fixation_data(g, update, benefit, cost=F(1)):
    n = validate(g)
    if len({len(ns) for ns in g}) != 1:
        raise ValueError('fixation_data restricted to regular graphs')
    seen = {0}
    for i in list(range(n)):
        for j in list(seen):
            seen.update(g[j])
    if len(seen) != n:
        raise ValueError('fixation_data requires connected graph')
    reps, idx, aut = orbit_data(g)
    trans = [s for s in reps if s and s != (1 << n) - 1]
    rows = []
    derivative_reward = []
    neutral_reward = []
    full = (1 << n) - 1
    for s in trans:
        p0, p1 = transition_and_gradient(g, s, update, benefit, cost)
        neutral_reward.append(p0.get(full, F(0)))
        derivative_reward.append(sum(v * F(t.bit_count(), n) for t, v in p1.items()))
        rows.append(tuple(F(int(s == t)) - sum(p for v, p in p0.items() if idx[v] == idx[t]) for t in trans))
    neutral = solve(rows, neutral_reward)
    gradient = solve(rows, derivative_reward)
    # Uniformly random placement of one cooperative mutant.
    g_map = {s: gradient[i] for i, s in enumerate(trans)}
    n_map = {s: neutral[i] for i, s in enumerate(trans)}
    mean_gradient = sum(g_map[reps[idx[1 << i]]] for i in range(n)) / n
    mean_neutral = sum(n_map[reps[idx[1 << i]]] for i in range(n)) / n
    assert mean_neutral == F(1, n)
    assert all(neutral[i] == F(s.bit_count(), n) for i, s in enumerate(trans))
    return {'gradient': mean_gradient, 'neutral_fixation': mean_neutral, 'orbits': len(reps),
            'transient_orbits': len(trans), 'automorphisms': len(aut)}


def exact_threshold(g, update):
    """Root of derivative in b given fixed c=1, if one exists."""
    f0 = fixation_data(g, update, F(1), F(1))['gradient']
    f1 = fixation_data(g, update, F(2), F(1))['gradient']
    slope = f1 - f0
    if slope <= 0:
        return {'threshold': None, 'slope': slope, 'gradient_b1': f0,
                'reason': 'increasing benefit cannot produce positive first-order gradient'}
    return {'threshold': F(1) - f0 / slope, 'slope': slope, 'gradient_b1': f0}


def exact_probability(g, state, update, benefit, cost, strength):
    """Independent positive-fitness event enumeration at finite strength w.

    Deliberately avoids transition_and_gradient and derivative_probability.
    """
    n = validate(g)
    if len({len(ns) for ns in g}) != 1:
        raise ValueError('regular graph required')
    if not isinstance(strength, F) or strength < 0:
        raise ValueError('invalid strength')
    if not isinstance(benefit, F) or not isinstance(cost, F):
        raise ValueError('invalid payoff types')
    reps, orbit, _ = orbit_data(g)
    indices = [z for z in reps if z not in (0, (1 << n)-1)]
    rows, rewards = [], []
    for s in indices:
        rewards_by_vertex = []
        for i, ns in enumerate(g):
            num_coop = sum(bool(s & (1 << j)) for j in ns)
            rewards_by_vertex.append(1 + strength*(benefit*num_coop-cost*len(ns)*bool(s & (1 << i))))
        if min(rewards_by_vertex) <= 0:
            raise ValueError('fitness must remain positive')
        probability = defaultdict(F)
        if update == 'DB':
            for dead, ns in enumerate(g):
                mass = sum(rewards_by_vertex[j] for j in ns)
                for source in ns:
                    t = (s | (1 << dead)) if s & (1 << source) else (s & ~(1 << dead))
                    probability[t] += rewards_by_vertex[source] / mass / n
        elif update == 'BD':
            mass = sum(rewards_by_vertex)
            for source, neighbors in enumerate(g):
                for dead in neighbors:
                    t = (s | (1 << dead)) if s & (1 << source) else (s & ~(1 << dead))
                    probability[t] += rewards_by_vertex[source] / mass / len(neighbors)
        elif update == 'IM':
            for focal, ns in enumerate(g):
                donors = (focal,) + tuple(ns)
                mass = sum(rewards_by_vertex[j] for j in donors)
                for source in donors:
                    t = (s | (1 << focal)) if s & (1 << source) else (s & ~(1 << focal))
                    probability[t] += rewards_by_vertex[source] / mass / n
        else:
            raise ValueError('invalid update rule')
        assert sum(probability.values()) == 1
        rewards.append(probability.get((1 << n)-1, F(0)))
        rows.append(tuple(F(int(s==t)) - sum(prob for outcome,prob in probability.items()
                            if orbit[outcome] == orbit[t]) for t in indices))
    answer = solve(rows, rewards)
    values = {s:v for s,v in zip(indices, answer)}
    if state in (0, (1 << n)-1):
        return F(int(state != 0))
    return values[reps[orbit[state]]]


def main():
    import json
    studies = [(f'cycle{n}', cycle(n)) for n in (5,6,7,8,9)] + [('complete4', complete(4))]
    rows = []
    for name, graph in studies:
        for rule in ('DB', 'BD', 'IM'):
            z = exact_threshold(graph, rule)
            rows.append({'graph': name, 'n': len(graph), 'k': len(graph[0]), 'update': rule,
                         'threshold': None if z['threshold'] is None else str(z['threshold']),
                         'slope': str(z['slope']), 'gradient_at_b1': str(z['gradient_b1']),
                         'neutral': str(F(1, len(graph))),
                         'orbit_count': len(orbit_data(graph)[0])})
    print(json.dumps({'source':'Ohtsuki et al 2006 Nature 441:502-505; finite exact constructed graphs',
                      'model':'fixed graph donation, F=1+w payoff, exact derivative w=0',
                      'results':rows, 'E2_real_human':0, 'E3_historical_event':0},indent=2))


if __name__ == '__main__':
    main()
