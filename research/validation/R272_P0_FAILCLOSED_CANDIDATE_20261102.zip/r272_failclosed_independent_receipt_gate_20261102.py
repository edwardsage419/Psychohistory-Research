#!/usr/bin/env python3
"""R272 independent fail-closed archived E1 receipt gate, standard library only.

This candidate is not connected to production workflows. It never imports the
archived R272 generator. Use --self-test for isolated mutation controls.
"""
import argparse
import csv
import hashlib
import io
import itertools
import json
from fractions import Fraction as Q
from math import comb
from pathlib import Path

FREEZE = '52f84dbfbe8563cf5c9a491e67d5e320223e0a56'
SOURCE_BLOB = '13843eecf2f9f05c19ee5545bdb224f58313f367'
FREEZE_BLOB = '9fbdb0078a58c4a9c0a548643227e30da5731119'
CSV_SHA = 'dc40ed773491817caf242ba6416e1bdf98ef2f1a2cd05e1956bdf5aec5801663'
JSON_SHA = 'f891df1c4640c2f49a457c436bc043f6bc08b768ac92594050e7e08061495a40'
PS = (Q(1, 4), Q(1, 2), Q(3, 4))
MODELS = ('CONSTANT_HALF', 'TRAIN_MLE', 'LAPLACE_BETA11')
COLS = ('world', 'true_p', 'predictor', 'original_full_sixbit_source',
        'original_training_four_bits', 'original_future_test_two_bits',
        'train_successes', 'test_successes', 'exact_original_source_probability',
        'forecast_trained_on_four_bits_only', 'original_train_brier_per_row',
        'original_test_brier_per_row', 'exact_train_mean_brier',
        'exact_independent_test_mean_brier', 'unfloored_future_log_loss_is_infinite')
LOCKED = {
    (Q(1, 4), 'CONSTANT_HALF'): ('1/4', '1/4'),
    (Q(1, 4), 'TRAIN_MLE'): ('9/64', '15/64'),
    (Q(1, 4), 'LAPLACE_BETA11'): ('11/72', '31/144'),
    (Q(1, 2), 'CONSTANT_HALF'): ('1/4', '1/4'),
    (Q(1, 2), 'TRAIN_MLE'): ('3/16', '5/16'),
    (Q(1, 2), 'LAPLACE_BETA11'): ('7/36', '5/18'),
    (Q(3, 4), 'CONSTANT_HALF'): ('1/4', '1/4'),
    (Q(3, 4), 'TRAIN_MLE'): ('9/64', '15/64'),
    (Q(3, 4), 'LAPLACE_BETA11'): ('11/72', '31/144'),
}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def git_blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def forecast(model, k):
    return Q(1, 2) if model == 'CONSTANT_HALF' else (Q(k, 4) if model == 'TRAIN_MLE' else Q(k + 1, 6))


def name(p, model):
    return 'TRUE_P' + str(p).replace('/', 'OF') + '_' + model


def expected_row(p, model, bits):
    train, test = bits[:4], bits[4:]
    k, j = train.count('1'), test.count('1')
    q = forecast(model, k)
    mass = p ** (k + j) * (1 - p) ** (6 - k - j)
    tr = [((int(y) - q) ** 2) for y in train]
    te = [((int(y) - q) ** 2) for y in test]
    inf = int((q == 0 and j >= 1) or (q == 1 and j <= 1))
    return dict(zip(COLS, map(str, (
        name(p, model), p, model, bits, train, test, k, j, mass, q,
        ';'.join(map(str, tr)), ';'.join(map(str, te)),
        sum(tr, Q(0)) / 4, sum(te, Q(0)) / 2, inf))))


def expected_world(p, model):
    train = future = Q(0)
    for k in range(5):
        q = forecast(model, k)
        weight = comb(4, k) * p ** k * (1 - p) ** (4 - k)
        train += weight * (k * (1 - q) ** 2 + (4 - k) * q ** 2) / 4
        future += weight * (p * (1 - q) ** 2 + (1 - p) * q ** 2)
    inf = (1 - p) ** 4 * (1 - (1 - p) ** 2) + p ** 4 * (1 - p ** 2) if model == 'TRAIN_MLE' else Q(0)
    require((str(train), str(future)) == LOCKED[p, model], 'frozen expected loss differs')
    return {'world': name(p, model), 'true_p': str(p), 'predictor': model,
            'full_ordered_source_types': 64,
            'exact_design_expected_train_mean_Brier': str(train),
            'exact_design_expected_independent_future_mean_Brier': str(future),
            'exact_unfloored_infinite_test_log_loss_event_probability': str(inf),
            'source_enumeration_equals_independent_binomial_theory': True}


def strict_json(data):
    def unique_pairs(pairs):
        out = {}
        for key, value in pairs:
            require(key not in out, 'duplicate JSON key: ' + key)
            out[key] = value
        return out
    return json.loads(data, object_pairs_hook=unique_pairs)


def same_json_types(actual, expected):
    return json.dumps(actual, sort_keys=True, ensure_ascii=False) == json.dumps(expected, sort_keys=True, ensure_ascii=False)


def verify(csv_bytes, result_bytes, receipt_bytes, pins=True):
    try:
        rows = list(csv.DictReader(io.StringIO(csv_bytes.decode('utf-8'), newline='')))
        result = strict_json(result_bytes)
        receipt = strict_json(receipt_bytes)
    except (UnicodeError, ValueError, csv.Error) as exc:
        raise ValueError('invalid serialized receipt') from exc
    require(len(rows) == 576, 'source row count')
    require(tuple(rows[0]) == COLS, 'CSV column identity')
    require(all(tuple(row) == COLS and None not in row for row in rows), 'CSV row schema')
    expected = []
    expected_worlds = []
    for p, model in itertools.product(PS, MODELS):
        world = expected_world(p, model)
        expected_worlds.append(world)
        mass = Q(0)
        weighted_train = weighted_test = weighted_inf = Q(0)
        for bits_tuple in itertools.product('01', repeat=6):
            bits = ''.join(bits_tuple)
            row = expected_row(p, model, bits)
            expected.append(row)
            m = Q(row['exact_original_source_probability'])
            mass += m
            weighted_train += m * Q(row['exact_train_mean_brier'])
            weighted_test += m * Q(row['exact_independent_test_mean_brier'])
            weighted_inf += m * int(row['unfloored_future_log_loss_is_infinite'])
        require(mass == 1, 'world probability mass')
        require((str(weighted_train), str(weighted_test), str(weighted_inf)) ==
                (world['exact_design_expected_train_mean_Brier'],
                 world['exact_design_expected_independent_future_mean_Brier'],
                 world['exact_unfloored_infinite_test_log_loss_event_probability']), 'independent world moments')
    require(rows == expected, 'source identity or field-level mathematics differs')
    expected_result = dict(research_id='R272', original_catalogue_id='12-002',
        prescore_freeze_commit=FREEZE,
        scope='FINITE_ARTIFICIAL_E1_INDEPENDENT_TRAIN4_TEST2_BERNOULLI_PREDICTION',
        artificial_worlds=9, complete_source_types=576,
        independent_source_sequences_per_true_p=64, training_bit_count=4,
        strictly_heldout_test_bit_count=2,
        all_nine_analytical_binomial_scores_verified=True,
        zero_probability_log_loss_failure_separately_recorded=True,
        no_real_human_E2=0, no_real_historical_E3=0,
        R073='FROZEN', PESEN_v0_1='FROZEN', world_results=expected_worlds)
    require(type(result) is dict and same_json_types(result, expected_result), 'result claims or moments differ')
    expected_receipt = dict(research_id='R272', prescore_freeze_commit=FREEZE,
        all_complete_original_sources=576, independent_analytic_comparisons=9,
        source_sha256=sha(csv_bytes), results_sha256=sha(result_bytes),
        new_real_human_E2=0, new_real_historical_E3=0)
    require(type(receipt) is dict and same_json_types(receipt, expected_receipt), 'receipt hashes or identity differ')
    if pins:
        require(sha(csv_bytes) == CSV_SHA and sha(result_bytes) == JSON_SHA, 'historical archived byte identity differs')
    return dict(status='PASS', rows=len(rows), worlds=len(expected_worlds),
                field_values=len(rows) * len(COLS), receipt_hashes=2, pinned_archive=pins,
                evidence='INTERNAL_NONBLIND_FINITE_ARTIFICIAL_E1')


def synthetic_fixture():
    rows = [expected_row(p, model, ''.join(bits))
            for p, model in itertools.product(PS, MODELS)
            for bits in itertools.product('01', repeat=6)]
    out = io.StringIO(newline='')
    writer = csv.DictWriter(out, fieldnames=COLS, lineterminator='\n')
    writer.writeheader()
    writer.writerows(rows)
    cb = out.getvalue().encode()
    rb = (json.dumps(dict(research_id='R272', original_catalogue_id='12-002',
        prescore_freeze_commit=FREEZE,
        scope='FINITE_ARTIFICIAL_E1_INDEPENDENT_TRAIN4_TEST2_BERNOULLI_PREDICTION',
        artificial_worlds=9, complete_source_types=576,
        independent_source_sequences_per_true_p=64, training_bit_count=4,
        strictly_heldout_test_bit_count=2,
        all_nine_analytical_binomial_scores_verified=True,
        zero_probability_log_loss_failure_separately_recorded=True,
        no_real_human_E2=0, no_real_historical_E3=0,
        R073='FROZEN', PESEN_v0_1='FROZEN',
        world_results=[expected_world(p, m) for p, m in itertools.product(PS, MODELS)]))).encode()
    rec = dict(research_id='R272', prescore_freeze_commit=FREEZE,
        all_complete_original_sources=576, independent_analytic_comparisons=9,
        source_sha256=sha(cb), results_sha256=sha(rb),
        new_real_human_E2=0, new_real_historical_E3=0)
    return cb, rb, json.dumps(rec).encode()


def self_test():
    cb, rb, mb = synthetic_fixture()
    require(verify(cb, rb, mb, pins=False)['status'] == 'PASS', 'positive control')
    mutations = []
    def mutated(c=cb, r=rb, m=mb):
        try:
            verify(c, r, m, pins=False)
        except ValueError:
            return True
        return False
    # All mutation controls update the hash receipt when appropriate.
    rows = list(csv.DictReader(io.StringIO(cb.decode())))
    def csv_mutation(field, value):
        items = [dict(x) for x in rows]
        items[0][field] = value
        out = io.StringIO(newline='')
        w = csv.DictWriter(out, fieldnames=COLS, lineterminator='\n')
        w.writeheader(); w.writerows(items)
        data = out.getvalue().encode()
        meta = json.loads(mb); meta['source_sha256'] = sha(data)
        return mutated(c=data, m=json.dumps(meta).encode())
    mutations.append(('probability_mass', csv_mutation('exact_original_source_probability', '0')))
    mutations.append(('duplicate_source', csv_mutation('original_full_sixbit_source', '000001')))
    mutations.append(('train_test_leak', csv_mutation('original_future_test_two_bits', '11')))
    mutations.append(('score_corruption', csv_mutation('exact_independent_test_mean_brier', '0')))
    for label, val in [('fake_e2', 1), ('fake_e2_boolean', True), ('fake_oracle_flag', False), ('missing_worlds', [])]:
        obj = json.loads(rb)
        if label in ('fake_e2', 'fake_e2_boolean'): obj['no_real_human_E2'] = val
        elif label == 'fake_oracle_flag': obj['all_nine_analytical_binomial_scores_verified'] = val
        else: obj['world_results'] = val
        new_r = json.dumps(obj).encode(); meta = json.loads(mb); meta['results_sha256'] = sha(new_r)
        mutations.append((label, mutated(r=new_r, m=json.dumps(meta).encode())))
    mutations.append(('receipt_hash', mutated(m=mb.replace(b'R272', b'R273'))))
    mutations.append(('duplicate_json_key', mutated(r=rb[:-1] + b',\"research_id\":\"R272\"}')))
    meta = json.loads(mb); meta['all_complete_original_sources'] = 576.0
    mutations.append(('receipt_number_type', mutated(m=json.dumps(meta).encode())))
    require(all(ok for _, ok in mutations), 'mutation accepted: ' + str(mutations))
    return dict(positive_controls=1, rejected_mutations=len(mutations), cases=[x for x, _ in mutations])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        print(json.dumps(self_test(), sort_keys=True))
        return
    root = args.root
    def pinned(path, expected):
        data = (root / path).read_bytes()
        require(git_blob(data) == expected, 'source or freeze Git blob mismatch: ' + str(path))
        return data
    pinned('research/R272/r272_exact_train_test_prediction.py', SOURCE_BLOB)
    pinned('protocols/R272_OUT_OF_SAMPLE_9_BERNOULLI_WORLDS_576_FULL_SOURCE_PRESCORE_FREEZE_2026-10-23.md', FREEZE_BLOB)
    folder = root / 'research/R272'
    result = verify((folder / 'R272_ALL_576_ORIGINAL_TRAIN_AND_TEST_SOURCES.csv').read_bytes(),
                    (folder / 'R272_EXACT_RESULTS.json').read_bytes(),
                    (folder / 'R272_MACHINE_RECEIPT.json').read_bytes())
    print(json.dumps(result, sort_keys=True))


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, KeyError, TypeError) as error:
        raise SystemExit('FAIL: ' + str(error)) from error
