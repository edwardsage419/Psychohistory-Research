"""R147: source-inspired, researcher-constructed finite diffusion identification examples.

No actual US city observations, no causal identification in historical data.
"""
from __future__ import annotations

from collections import defaultdict
from fractions import Fraction as F
from itertools import product
import json

PARENT_PROB = (F(1, 4), F(3, 4))
N = 4
GRAPHS = {
    "path": ((0, 1), (1, 2), (2, 3)),
    "star": ((0, 1), (0, 2), (0, 3)),
    "ring": ((0, 1), (1, 2), (2, 3), (3, 0)),
}


def probability(x):
    """Exact numerical input must be Fraction or int, but not bool/float."""
    if type(x) not in (int, F):
        raise TypeError("A probability must be int or Fraction, not bool/float")
    z = F(x)
    if not (0 <= z <= 1):
        raise ValueError("Probability outside [0,1]")
    return z


def validate_graph(edges):
    if not isinstance(edges, (list, tuple)):
        raise TypeError("Edges must be list/tuple")
    out = set()
    for edge in edges:
        if not isinstance(edge, (list, tuple)) or len(edge) != 2:
            raise ValueError("Each edge must be a 2-tuple")
        a, b = edge
        if type(a) is not int or type(b) is not int:
            raise TypeError("Vertices must be integer and not bool")
        if not (0 <= a < N and 0 <= b < N) or a == b:
            raise ValueError("Out of range or loop")
        pair = tuple(sorted((a, b)))
        if pair in out:
            raise ValueError("Duplicate undirected edge")
        out.add(pair)
    return tuple(sorted(out))


def direct_adoption_worlds(mechanism, intervention=None):
    """Enumerate 32 equiprobable elementary worlds; do(A) changes only A equation."""
    if mechanism not in ("diffusion", "shared_shock"):
        raise ValueError("Unknown structural mechanism")
    if intervention is not None and type(intervention) is not int:
        raise TypeError("Intervention should be 0/1 int or None")
    if intervention not in (None, 0, 1):
        raise ValueError("Intervention should be 0/1 or None")
    mass = defaultdict(F)
    for u, rb, rc in product((0, 1), range(4), range(4)):
        a = u if intervention is None else intervention
        parent = a if mechanism == "diffusion" else u
        b = int(rb < (3 if parent else 1))
        c = int(rc < (3 if parent else 1))
        mass[(a, b, c)] += F(1, 32)
    return {k: v for k, v in sorted(mass.items())}


def closed_form_observational():
    mass = {}
    for a, b, c in product((0, 1), repeat=3):
        p = PARENT_PROB[a]
        mass[(a, b, c)] = F(1, 2) * (p if b else 1 - p) * (p if c else 1 - p)
    return mass


def under_do_probability(mechanism, a):
    mass = direct_adoption_worlds(mechanism, a)
    return sum((p for (x, b, c), p in mass.items() if b), F(0))


def observational_difference():
    obs = direct_adoption_worlds("diffusion")
    out = []
    for a in (0, 1):
        sub = sum((v for (x, b, c), v in obs.items() if x == a), F(0))
        p = sum((v for (x, b, c), v in obs.items() if x == a and b), F(0)) / sub
        out.append(p)
    return out[1] - out[0]


def exposure(mask, node, edges):
    nodes = [y if x == node else x for x, y in edges if x == node or y == node]
    return F(sum(bool(mask & (1 << k)) for k in nodes), len(nodes)) if nodes else F(0)


def _validate_case(mask, edges, beta, shock):
    if type(mask) is not int or mask < 0 or mask >= (1 << N):
        raise ValueError("Invalid state mask")
    edges = validate_graph(edges)
    return edges, probability(beta), probability(shock)


def step_a(mask, edges, beta, shock):
    """Method A: condition on global shock, enumerate each nonadopter's 0/1 decisions."""
    edges, beta, shock = _validate_case(mask, edges, beta, shock)
    waiting = [i for i in range(N) if not mask & (1 << i)]
    out = defaultdict(F)
    for z, probz in [(0, 1 - shock), (1, shock)]:
        if not probz:
            continue
        pi = {i: F(1, 8) + beta * exposure(mask, i, edges) + F(z, 4) for i in waiting}
        assert all(0 <= p <= 1 for p in pi.values())
        for choices in product((0, 1), repeat=len(waiting)):
            q = F(probz)
            nxt = mask
            for i, val in zip(waiting, choices):
                q *= pi[i] if val else 1 - pi[i]
                if val:
                    nxt |= 1 << i
            out[nxt] += q
    return dict(out)


def step_b(mask, edges, beta, shock):
    """Method B: independently build full 16-target-state transition coefficients."""
    edges, beta, shock = _validate_case(mask, edges, beta, shock)
    out = {}
    for nxt in range(1 << N):
        if (nxt & mask) != mask:
            continue
        likelihood = F(0)
        for z in (0, 1):
            pz = shock if z else 1 - shock
            if not pz:
                continue
            prod = F(pz)
            for i in range(N):
                if mask & (1 << i):
                    continue
                degree = sum(1 for a, b in edges if i in (a, b))
                adopted = sum(bool(mask & (1 << (b if a == i else a))) for a, b in edges if i in (a, b))
                transition = F(1, 8) + beta * (F(adopted, degree) if degree else 0) + F(z, 4)
                prod *= transition if nxt & (1 << i) else 1 - transition
            likelihood += prod
        out[nxt] = likelihood
    return out


def distribution(graph, beta, shock, steps=4, method="a"):
    if graph not in GRAPHS:
        raise ValueError("Unknown graph")
    beta = probability(beta)
    shock = probability(shock)
    if type(steps) is not int or not 0 <= steps <= 8:
        raise ValueError("Steps must be int in [0,8]")
    if method not in ("a", "b"):
        raise ValueError("Unknown independent method")
    ed = GRAPHS[graph]
    dist = {1: F(1)}
    for _ in range(steps):
        nxt = defaultdict(F)
        for mask, weight in dist.items():
            transitions = step_a(mask, ed, beta, shock) if method == "a" else step_b(mask, ed, beta, shock)
            for new_mask, p in transitions.items():
                nxt[new_mask] += weight * p
        dist = dict(nxt)
        if sum(dist.values(), F(0)) != 1:
            raise AssertionError("Probabilities not conserved")
    return {i: dist.get(i, F(0)) for i in range(1 << N)}


def as_str_dict(m):
    return {str(k): str(v) for k, v in sorted(m.items())}


def complete_report():
    obs_d = direct_adoption_worlds("diffusion")
    obs_s = direct_adoption_worlds("shared_shock")
    obs_c = closed_form_observational()
    assert obs_d == obs_s == obs_c
    scenarios = []
    for graph in GRAPHS:
        for beta in (F(0), F(1, 2)):
            for shock in (F(0), F(1, 2)):
                d1 = distribution(graph, beta, shock, method="a")
                d2 = distribution(graph, beta, shock, method="b")
                assert d1 == d2
                expected = sum((v * i.bit_count() for i, v in d1.items()), F(0))
                scenarios.append({
                    "graph": graph, "beta": str(beta), "yearly_shared_shock_prob": str(shock),
                    "steps": 4, "expected_final_adopters": str(expected),
                    "expected_new_adopters": str(expected - 1),
                    "prob_all_4": str(d1[15]),
                    "final_mask_probabilities": as_str_dict(d1),
                    "two_independent_dynamics_agree": True,
                })
    return {
        "research_id": "R147", "source": "Shipan Volden 2008, Berry Berry 1990 original theory", 
        "scope": "PROJECT-CONSTRUCTED SYNTHETIC E1, NOT AUTHOR REPLICATION", 
        "worlds": 32, "observable_histories": 8,
        "observational_joint_diffusion": {"".join(map(str, key)): str(val) for key, val in obs_d.items()},
        "observational_joint_shared_shock": {"".join(map(str, key)): str(val) for key, val in obs_s.items()},
        "observational_likelihood_exact_equal": True,
        "observational_conditional_peer_risk_difference": str(observational_difference()),
        "causal_effect_under_do": {
            name: str(under_do_probability(name, 1) - under_do_probability(name, 0))
            for name in ("diffusion", "shared_shock")},
        "follower_pair_both_adopt": str(sum((v for (a,b,c),v in obs_d.items() if b and c), F(0))),
        "synthetic_graph_scenarios": len(scenarios),
        "graph_results": scenarios,
        "no_peer_graph_invariance_when_beta_zero": all(
            distribution("path", F(0), s) == distribution(g, F(0), s)
            for s in (F(0), F(1,2)) for g in GRAPHS),
        "source_historical_675_cities_dataset_rerun": False,
        "four_original_political_diffusion_mechanisms_distinguished_empirically": False,
        "new_E2_real_human_predictions": 0,
        "new_E3_historical_event_predictions": 0,
        "R073": "FROZEN", "PESEN_v0_1": "FROZEN",
    }


def canonical_bytes():
    return (json.dumps(complete_report(), sort_keys=True, indent=2, ensure_ascii=False) + "\n").encode("utf-8")


if __name__ == "__main__":
    import sys
    sys.stdout.buffer.write(canonical_bytes())
