"""Independent R147 math validation; no actual regional adoption data."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import hashlib
import json
import unittest

import r147_shipan_volden_policy_diffusion_exact as m


class TestTheoryAndCausalContrast(unittest.TestCase):
    def test_01_probability_none_wrong(self):
        with self.assertRaises(TypeError): m.probability(None)

    def test_02_probability_bool_wrong(self):
        with self.assertRaises(TypeError): m.probability(True)

    def test_03_probability_float_wrong(self):
        with self.assertRaises(TypeError): m.probability(0.5)

    def test_04_probability_bounds(self):
        for p in (-1, F(-1, 99), 2):
            with self.subTest(p=p), self.assertRaises(ValueError): m.probability(p)

    def test_05_probability_endpoints(self):
        self.assertEqual(m.probability(0), 0)
        self.assertEqual(m.probability(F(1, 2)), F(1,2))
        self.assertEqual(m.probability(1), 1)

    def test_06_a_joint_original_worlds_32(self):
        for g in ('diffusion','shared_shock'):
            obs=m.direct_adoption_worlds(g)
            self.assertEqual(sum(obs.values(), F(0)), 1)
            self.assertEqual(len(obs), 8)
            self.assertTrue(all(v>0 for v in obs.values()))

    def test_07_model_observational_equivalence(self):
        self.assertEqual(m.direct_adoption_worlds('diffusion'),m.direct_adoption_worlds('shared_shock'))

    def test_08_independent_factorization(self):
        self.assertEqual(m.direct_adoption_worlds('diffusion'),m.closed_form_observational())

    def test_09_explicit_profile_111(self):
        self.assertEqual(m.closed_form_observational()[(1,1,1)],F(9,32))

    def test_10_explicit_profile_100(self):
        self.assertEqual(m.closed_form_observational()[(1,0,0)],F(1,32))

    def test_11_conditional_difference(self):
        self.assertEqual(m.observational_difference(),F(1,2))

    def test_12_primitive_diffusion_do_1(self):
        self.assertEqual(m.under_do_probability('diffusion',1),F(3,4))

    def test_13_primitive_diffusion_do_0(self):
        self.assertEqual(m.under_do_probability('diffusion',0),F(1,4))

    def test_14_primitive_common_do_1(self):
        self.assertEqual(m.under_do_probability('shared_shock',1),F(1,2))

    def test_15_primitive_common_do_0(self):
        self.assertEqual(m.under_do_probability('shared_shock',0),F(1,2))

    def test_16_stated_nonidentification(self):
        self.assertNotEqual(m.under_do_probability('diffusion',1)-m.under_do_probability('diffusion',0),m.under_do_probability('shared_shock',1)-m.under_do_probability('shared_shock',0))

    def test_17_correlated_followers(self):
        obs=m.direct_adoption_worlds('shared_shock')
        pb=sum(v for (a,b,c),v in obs.items() if b)
        pc=sum(v for (a,b,c),v in obs.items() if c)
        joint=sum(v for (a,b,c),v in obs.items() if b and c)
        self.assertEqual(pb, F(1,2))
        self.assertEqual(pc, F(1,2))
        self.assertEqual(joint,F(5,16))
        self.assertGreater(joint,pb*pc)

    def test_18_conditional_independence(self):
        obs=m.direct_adoption_worlds('shared_shock')
        for a in (0,1):
            cond=sum(v for (x,b,c),v in obs.items() if x==a and b and c)/F(1,2)
            self.assertEqual(cond,F(1,16) if a==0 else F(9,16))

    def test_19_invalid_mechanism(self):
        with self.assertRaises(ValueError): m.direct_adoption_worlds('magic')

    def test_20_invalid_intervention_bool(self):
        with self.assertRaises(TypeError): m.direct_adoption_worlds('diffusion',True)

    def test_21_invalid_intervention_value(self):
        with self.assertRaises(ValueError): m.direct_adoption_worlds('diffusion',2)

    def test_22_graph_three_distinct_structures(self):
        edges=[m.validate_graph(e) for e in m.GRAPHS.values()]
        self.assertEqual(len(set(edges)),3)

    def test_23_graph_reflection_undirected(self):
        self.assertEqual(m.validate_graph(((0,1),(1,2))),m.validate_graph(((1,0),(2,1))))

    def test_24_graph_self_loop_fail(self):
        with self.assertRaises(ValueError): m.validate_graph(((0,0),))

    def test_25_graph_duplicate_fail(self):
        with self.assertRaises(ValueError): m.validate_graph(((0,1),(1,0)))

    def test_26_graph_bad_node_fail(self):
        with self.assertRaises(ValueError): m.validate_graph(((0,4),))

    def test_27_graph_bool_node_fail(self):
        with self.assertRaises(TypeError): m.validate_graph(((True,1),))

    def test_28_graph_bad_edge_fail(self):
        with self.assertRaises(ValueError): m.validate_graph(((0,),))

    def test_29_graph_string_fail(self):
        with self.assertRaises(TypeError): m.validate_graph('01')

    def test_30_exposure_path(self):
        self.assertEqual(m.exposure(1,1,m.GRAPHS['path']),F(1,2))
        self.assertEqual(m.exposure(1,3,m.GRAPHS['path']),F(0))

    def test_31_exposure_star(self):
        self.assertEqual(m.exposure(1,1,m.GRAPHS['star']),F(1))
        self.assertEqual(m.exposure(1,2,m.GRAPHS['star']),F(1))

    def test_32_exposure_ring(self):
        self.assertEqual(m.exposure(1,1,m.GRAPHS['ring']),F(1,2))
        self.assertEqual(m.exposure(1,3,m.GRAPHS['ring']),F(1,2))

    def test_33_invalid_state_negative(self):
        with self.assertRaises(ValueError): m.step_a(-1,m.GRAPHS['path'],0,0)

    def test_34_invalid_state_bool(self):
        with self.assertRaises(ValueError): m.step_a(True,m.GRAPHS['path'],0,0)

    def test_35_invalid_state_beyond_4_nodes(self):
        with self.assertRaises(ValueError): m.step_a(16,m.GRAPHS['path'],0,0)

    def test_36_shock_given_p_is_correlated(self):
        uninf=m.distribution('path',F(0),F(1,2))
        p1=sum(v for mask,v in uninf.items() if mask&2)
        p2=sum(v for mask,v in uninf.items() if mask&4)
        p12=sum(v for mask,v in uninf.items() if mask&6==6)
        self.assertGreater(p12,p1*p2)

    def test_37_no_peer_graph_invariance(self):
        for s in (F(0),F(1,2)):
            base=m.distribution('path',F(0),s)
            for g in m.GRAPHS:
                self.assertEqual(base,m.distribution(g,F(0),s))

    def test_38_beta_increases_expected_adoption(self):
        for g in m.GRAPHS:
            for s in (F(0),F(1,2)):
                def average(beta):
                    return sum(p*mask.bit_count() for mask,p in m.distribution(g,beta,s).items())
                self.assertGreater(average(F(1,2)),average(F(0)))

    def test_39_no_repeal(self):
        for g in m.GRAPHS:
            for mask in range(16):
                for nxt,p in m.step_a(mask,m.GRAPHS[g],F(1,2),F(1,2)).items():
                    if p: self.assertEqual(nxt&mask,mask)

    def test_40_full_adoption_absorbing(self):
        for g in m.GRAPHS:
            self.assertEqual(m.step_a(15,m.GRAPHS[g],F(1,2),F(1,2)),{15:F(1)})

    def test_41_no_same_period_cascade_for_far_node(self):
        p=m.step_a(1,m.GRAPHS['path'],F(1,2),0)
        # At first step, node 3 not exposed; it adopts only with baseline p=1/8.
        self.assertEqual(sum(v for mask,v in p.items() if mask&8),F(1,8))

    def test_42_start_seed_fixed(self):
        for s in (0,F(1,2)):
            x=m.distribution('path',F(1,2),s)
            self.assertTrue(all(not p or mask&1 for mask,p in x.items()))

    def test_43_zero_step_identity(self):
        x=m.distribution('path',0,0,steps=0)
        self.assertEqual(x[1],1)
        self.assertEqual(sum(x.values()),1)

    def test_44_bad_step_bool(self):
        with self.assertRaises(ValueError): m.distribution('path',0,0,steps=True)

    def test_45_bad_graph_id(self):
        with self.assertRaises(ValueError): m.distribution('hexagon',0,0)

    def test_46_bad_method(self):
        with self.assertRaises(ValueError): m.distribution('path',0,0,method='unseen')

    def test_47_exact_4_step_zero_peer_without_shock(self):
        x=m.distribution('path',0,0)
        p=1-F(7,8)**4
        self.assertEqual(sum(v for mask,v in x.items() if mask&2),p)

    def test_48_result_meta_science(self):
        x=m.complete_report()
        self.assertFalse(x['source_historical_675_cities_dataset_rerun'])
        self.assertFalse(x['four_original_political_diffusion_mechanisms_distinguished_empirically'])
        self.assertEqual((x['new_E2_real_human_predictions'],x['new_E3_historical_event_predictions']),(0,0))

    def test_49_result_all_12_scenarios(self):
        x=m.complete_report()
        self.assertEqual(len(x['graph_results']),12)
        self.assertEqual(x['synthetic_graph_scenarios'],12)

    def test_50_archive_byte_determinism(self):
        self.assertEqual(m.canonical_bytes(),m.canonical_bytes())


# Per-case tests intentionally independently exercise each configuration and each transition algorithm.
def _case_test(graph, beta, shock, property_name):
    def test(self):
        a=m.distribution(graph,beta,shock,method='a')
        b=m.distribution(graph,beta,shock,method='b')
        if property_name=='agreement':
            self.assertEqual(a,b)
        elif property_name=='mass':
            self.assertEqual(sum(a.values(),F(0)),1)
            self.assertEqual(sum(b.values(),F(0)),1)
            self.assertTrue(all(p>=0 for p in a.values()))
        elif property_name=='first_step':
            a1=m.distribution(graph,beta,shock,steps=1,method='a')
            b1=m.distribution(graph,beta,shock,steps=1,method='b')
            self.assertEqual(a1,b1)
            self.assertEqual(sum(a1.values(),F(0)),1)
        return None
    return test

for graph in m.GRAPHS:
    for beta in (F(0),F(1,2)):
        for shock in (F(0),F(1,2)):
            for which in ('agreement','mass','first_step'):
                name=f'test_exact_{graph}_beta{str(beta).replace("/","_")}_shock{str(shock).replace("/","_")}_{which}'
                setattr(TestTheoryAndCausalContrast,name,_case_test(graph,beta,shock,which))


if __name__ == '__main__':
    unittest.main()
