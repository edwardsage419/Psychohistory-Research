"""R140 tests: authored scientific assertions plus 128 distinct exhaustive scenario tests."""
import json
import unittest
from dataclasses import replace
from itertools import product
from pathlib import Path

from r140_ostrom2011_iad_exact import (
    RULE_TYPES, Rules, analyse, all_institutions, authorized, equilibria_by_best_responses,
    equilibria_by_deviations, feasible, fine_effective, main_result, payoffs, profiles,
    resource_welfare, signature, transfer_revenue,
)


class Contracts(unittest.TestCase):
    def test_01_rule_names_exact_seven(self):
        self.assertEqual(RULE_TYPES, ('boundary', 'position', 'choice', 'aggregation', 'information', 'payoff', 'scope'))

    def test_02_all_128_configs(self):
        self.assertEqual(len(all_institutions()), 128)

    def test_03_128_unique_rule_tuples(self):
        self.assertEqual(len(set(all_institutions())), 128)

    def test_04_reject_boundary_bool(self):
        with self.assertRaises(ValueError): Rules(boundary=True)

    def test_05_reject_boundary_float(self):
        with self.assertRaises(ValueError): Rules(boundary=2.0)

    def test_06_reject_boundary_four(self):
        with self.assertRaises(ValueError): Rules(boundary=4)

    def test_07_reject_position_wrong(self):
        with self.assertRaises(ValueError): Rules(position='caretaker')

    def test_08_reject_choice_bool(self):
        with self.assertRaises(ValueError): Rules(choice=True)

    def test_09_reject_choice_three(self):
        with self.assertRaises(ValueError): Rules(choice=3)

    def test_10_reject_aggregation_invalid(self):
        with self.assertRaises(ValueError): Rules(aggregation='vote')

    def test_11_reject_information_invalid(self):
        with self.assertRaises(ValueError): Rules(information='probabilistic')

    def test_12_reject_payoff_float(self):
        with self.assertRaises(ValueError): Rules(payoff=2.0)

    def test_13_reject_payoff_other(self):
        with self.assertRaises(ValueError): Rules(payoff=3)

    def test_14_reject_scope_bool(self):
        with self.assertRaises(ValueError): Rules(scope=True)

    def test_15_reject_scope_other(self):
        with self.assertRaises(ValueError): Rules(scope=0)

    def test_16_reject_illtyped_profile(self):
        self.assertFalse(feasible(Rules(), (1, 1, 1.0)))

    def test_17_reject_illtyped_length(self):
        self.assertFalse(feasible(Rules(), (1, 1)))

    def test_18_reject_negative_action(self):
        self.assertFalse(feasible(Rules(), (-1, 1, 2)))

    def test_19_reject_unauthorized_action(self):
        self.assertFalse(feasible(Rules(boundary=2), (1, 1, 1)))

    def test_20_reject_steward_extraction(self):
        self.assertFalse(feasible(Rules(position='steward_last'), (1, 1, 1)))

    def test_21_steward_unauthorized_no_monitoring(self):
        self.assertEqual(fine_effective(Rules(boundary=2, position='steward_last', information='public', payoff=2)), 0)

    def test_22_steward_authorized_enables_fine(self):
        self.assertEqual(fine_effective(Rules(boundary=3, position='steward_last', information='public', payoff=2)), 2)

    def test_23_no_information_no_sanction(self):
        self.assertEqual(fine_effective(Rules(boundary=3, position='steward_last', information='private', payoff=2)), 0)

    def test_24_payoff_components(self):
        self.assertEqual(payoffs(Rules(), (2, 2, 2)), (4, 4, 4))

    def test_25_profit_plus_transfers_equals_resource(self):
        r = Rules(position='steward_last', information='public', payoff=2)
        p = (2, 2, 0)
        self.assertEqual(payoffs(r, p), (6, 6, 0))
        self.assertEqual(sum(payoffs(r, p)) + transfer_revenue(r, p), resource_welfare(p))

    def test_26_unrestricted_baseline_unique_NE(self):
        self.assertEqual(equilibria_by_deviations(Rules())[0], ((2, 2, 2),))

    def test_27_unrestricted_inefficient(self):
        a = analyse(Rules())
        self.assertEqual((a['NE_resource_welfare_min'], a['max_feasible_resource_welfare']), (12, 16))

    def test_28_quota_six_equilibria(self):
        a = analyse(Rules(aggregation='collective_quota4'))
        self.assertEqual(a['NE_count'], 6)
        self.assertEqual(a['NE_resource_welfare_min'], 16)

    def test_29_scope_equivalence(self):
        self.assertEqual(signature(Rules(scope=4)), signature(Rules(aggregation='collective_quota4')))

    def test_30_fake_fine_no_monitor_is_inert(self):
        self.assertEqual(signature(Rules()), signature(Rules(information='public', payoff=2)))

    def test_31_steward_private_inert(self):
        r = Rules(position='steward_last', information='private', payoff=2)
        self.assertEqual(signature(r), signature(replace(r, payoff=0)))

    def test_32_steward_private_public_payoff_difference(self):
        private = Rules(position='steward_last', information='private', payoff=2)
        public = replace(private, information='public')
        self.assertNotEqual(signature(private), signature(public))
        self.assertEqual(equilibria_by_deviations(private)[0], equilibria_by_deviations(public)[0])

    def test_33_net_utility_not_resource_only(self):
        with self.assertRaises(ValueError): payoffs(Rules(scope=4), (2, 2, 2))

    def test_34_boolean_action_rejected(self):
        self.assertFalse(feasible(Rules(), (True, 1, 2)))

    def test_35_no_feasible_report_missing(self):
        self.assertTrue(all(profiles(r) for r in all_institutions()))

    def test_36_every_game_has_pure_equilibrium(self):
        self.assertTrue(all(equilibria_by_deviations(r)[0] for r in all_institutions()))

    def test_37_rule_fields_json_preserved(self):
        self.assertEqual(tuple(Rules().as_dict()), RULE_TYPES)

    def test_38_all_profile_types_integer(self):
        self.assertTrue(all(all(type(v) is int for v in p) for r in all_institutions() for p in profiles(r)))

    def test_39_no_negative_resource_welfare(self):
        self.assertTrue(all(resource_welfare(p) >= 0 for r in all_institutions() for p in profiles(r)))

    def test_40_total_counts(self):
        result = main_result()
        self.assertEqual((result['total_configs'], result['total_feasible_profiles_across_configs'], result['total_unilateral_feasible_comparisons']), (128, 1136, 4584))

    def test_41_unique_game_signatures(self):
        self.assertEqual(main_result()['unique_full_game_signatures'], 6)

    def test_42_observational_equivalence_pairs(self):
        self.assertEqual(main_result()['observational_equivalent_unordered_pairs'], 2272)

    def test_43_zero_no_equilibrium(self):
        self.assertEqual(main_result()['configs_with_no_pure_NE'], 0)

    def test_44_124_configurations_have_optimal_NE(self):
        self.assertEqual(main_result()['configs_with_resource_optimal_pure_NE'], 124)

    def test_45_all_source_truth_flags(self):
        m = main_result()
        self.assertFalse(m['source_model_ostrom_simulated'])
        self.assertEqual((m['new_real_subject_rows'], m['new_E2_predictive_scores'], m['new_E3_historical_forecasts']), (0, 0, 0))

    def test_46_score_reconstruction_independent(self):
        for r in all_institutions():
            for p in profiles(r):
                E = sum(p)
                eff = (2 if r.position == 'steward_last' and r.boundary == 3 and r.information == 'public' and r.payoff == 2 else 0)
                reference = tuple(x * (8 - E) - (eff if x == 2 else 0) for x in p)
                self.assertEqual(payoffs(r, p), reference)

    def test_47_all_profiles_match_cartesian_filter(self):
        for r in all_institutions():
            candidate = tuple(x for x in product(range(3), repeat=3) if feasible(r, x))
            self.assertEqual(profiles(r), candidate)

    def test_48_conservation_of_revenue(self):
        for r in all_institutions():
            for p in profiles(r):
                self.assertEqual(sum(payoffs(r,p)) + transfer_revenue(r,p), resource_welfare(p))

    def test_49_expected_NE_optimum(self):
        for r in all_institutions():
            ne, _ = equilibria_by_deviations(r)
            self.assertLessEqual(max(map(resource_welfare, ne)), max(map(resource_welfare, profiles(r))))

    def test_50_two_Nash_methods_all_universe(self):
        for r in all_institutions():
            self.assertEqual(equilibria_by_deviations(r)[0], equilibria_by_best_responses(r))

    def test_51_archive_json_matches_replay(self):
        archived = json.loads((Path(__file__).parent/'R140_EXACT_RESULTS.json').read_text())
        self.assertEqual(archived, main_result())


def make_case(rules, index):
    def test_case(self):
        actions = profiles(rules)
        self.assertEqual(actions, tuple(x for x in product(range(3), repeat=3) if feasible(rules, x)))
        eq1, checked = equilibria_by_deviations(rules)
        eq2 = equilibria_by_best_responses(rules)
        self.assertEqual(eq1, eq2)
        self.assertGreaterEqual(checked, 0)
        self.assertTrue(eq1)
        self.assertEqual(analyse(rules)['rules'], rules.as_dict())
    test_case.__name__ = f'test_rule_configuration_{index:03d}'
    return test_case


class EachFrozenConfiguration(unittest.TestCase):
    """Each of the 128 parameter tuples is an independently reported unittest case."""


for i, config in enumerate(all_institutions()):
    setattr(EachFrozenConfiguration, f'test_rule_configuration_{i:03d}', make_case(config, i))


if __name__ == '__main__':
    unittest.main()
