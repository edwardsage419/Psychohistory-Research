"""R140 project-built, finite exact example of Ostrom's seven IAD rule classes.
NOT an implementation of a unique behavior model specified by Ostrom.
"""
from dataclasses import dataclass, replace
from itertools import product
from collections import Counter
import json

RULE_TYPES = ('boundary', 'position', 'choice', 'aggregation', 'information', 'payoff', 'scope')

@dataclass(frozen=True)
class Rules:
    boundary: int = 3
    position: str = 'all_extractors'
    choice: int = 2
    aggregation: str = 'independent'
    information: str = 'private'
    payoff: int = 0
    scope: int = 6

    def __post_init__(self):
        if type(self.boundary) is not int or self.boundary not in (2, 3):
            raise ValueError('boundary must be exactly int 2 or 3')
        if type(self.position) is not str or self.position not in ('all_extractors', 'steward_last'):
            raise ValueError('invalid position')
        if type(self.choice) is not int or self.choice not in (1, 2):
            raise ValueError('choice must be exactly int 1 or 2')
        if type(self.aggregation) is not str or self.aggregation not in ('independent', 'collective_quota4'):
            raise ValueError('invalid aggregation')
        if type(self.information) is not str or self.information not in ('private', 'public'):
            raise ValueError('invalid information')
        if type(self.payoff) is not int or self.payoff not in (0, 2):
            raise ValueError('payoff must be exactly int 0 or 2')
        if type(self.scope) is not int or self.scope not in (4, 6):
            raise ValueError('scope must be exactly int 4 or 6')

    def as_dict(self):
        return {k: getattr(self, k) for k in RULE_TYPES}


def authorized(r):
    return tuple(i for i in range(3) if i < r.boundary and not (r.position == 'steward_last' and i == 2))


def fine_effective(r):
    return (r.payoff if r.position == 'steward_last' and r.boundary == 3
            and r.information == 'public' else 0)


def feasible(r, profile):
    if not isinstance(r, Rules):
        raise TypeError('Rules required')
    if type(profile) not in (tuple, list) or len(profile) != 3:
        return False
    active = authorized(r)
    for i, e in enumerate(profile):
        if type(e) is not int or e < 0:
            return False
        if i in active:
            if e > r.choice:
                return False
        elif e != 0:
            return False
    total = sum(profile)
    return total <= r.scope and (r.aggregation == 'independent' or total <= 4)


def profiles(r):
    active = authorized(r)
    opts = [range(r.choice + 1) if i in active else (0,) for i in range(3)]
    return tuple(p for p in product(*opts) if feasible(r, p))


def payoffs(r, p):
    if not feasible(r, p):
        raise ValueError('infeasible profile')
    e = sum(p)
    f = fine_effective(r)
    return tuple(a * (8 - e) - f * max(0, a - 1) for a in p)


def resource_welfare(p):
    if len(p) != 3 or any(type(x) is not int or x < 0 for x in p):
        raise ValueError('invalid extraction')
    e = sum(p)
    return e * (8 - e)


def transfer_revenue(r, p):
    if not feasible(r, p):
        raise ValueError('infeasible profile')
    return fine_effective(r) * sum(max(0, x - 1) for x in p)


def equilibria_by_deviations(r):
    result = []
    checks = 0
    for p in profiles(r):
        u = payoffs(r, p)
        stable = True
        for i in range(3):
            for a in range(r.choice + 1):
                if a == p[i]:
                    continue
                d = list(p)
                d[i] = a
                if feasible(r, d):
                    checks += 1
                    if payoffs(r, d)[i] > u[i]:
                        stable = False
        if stable:
            result.append(p)
    return tuple(result), checks


def equilibria_by_best_responses(r):
    good = []
    for p in profiles(r):
        is_best = True
        for i in range(3):
            alternatives = []
            for a in range(r.choice + 1):
                trial = list(p)
                trial[i] = a
                if feasible(r, trial):
                    alternatives.append(payoffs(r, trial)[i])
            if payoffs(r, p)[i] != max(alternatives):
                is_best = False
        if is_best:
            good.append(p)
    return tuple(good)


def analyse(r):
    all_p = profiles(r)
    ne, checks = equilibria_by_deviations(r)
    alternate = equilibria_by_best_responses(r)
    assert ne == alternate
    if not ne:
        raise ArithmeticError('this declared finite game has no pure NE')
    max_welfare = max(resource_welfare(p) for p in all_p)
    optimal = tuple(p for p in all_p if resource_welfare(p) == max_welfare)
    return {
        'rules': r.as_dict(), 'authorized': list(authorized(r)),
        'effective_fee': fine_effective(r),
        'feasible_profiles': len(all_p), 'pure_NE': [list(p) for p in ne],
        'NE_count': len(ne), 'unilateral_feasible_checks': checks,
        'NE_resource_welfare_min': min(resource_welfare(p) for p in ne),
        'NE_resource_welfare_max': max(resource_welfare(p) for p in ne),
        'max_feasible_resource_welfare': max_welfare,
        'optimal_profile_count': len(optimal),
        'NE_transfer_revenues': [transfer_revenue(r, p) for p in ne],
        'NE_private_utility_vectors': [list(payoffs(r, p)) for p in ne],
    }


def all_institutions():
    return tuple(Rules(*settings) for settings in product(
        (2, 3), ('all_extractors', 'steward_last'), (1, 2),
        ('independent', 'collective_quota4'), ('private', 'public'), (0, 2), (4, 6)))


def signature(r):
    return (profiles(r), tuple(payoffs(r, p) for p in profiles(r)), equilibria_by_deviations(r)[0])


def main_result():
    universe = all_institutions()
    results = [analyse(r) for r in universe]
    base = Rules()
    q = replace(base, aggregation='collective_quota4')
    s = replace(base, scope=4)
    fine_no_monitor = replace(base, payoff=2, information='public')
    steward_private = Rules(position='steward_last', boundary=3, information='private', payoff=2)
    steward_public = replace(steward_private, information='public')
    unique = {signature(r) for r in universe}
    equal_pairs = sum(signature(universe[i]) == signature(universe[j])
                      for i in range(len(universe)) for j in range(i + 1, len(universe)))
    return {
        'study_id': 'R140', 'source_DOI': '10.1111/j.1541-0072.2010.00394.x',
        'all_seven_rule_slots': list(RULE_TYPES), 'total_configs': len(universe),
        'total_feasible_profiles_across_configs': sum(r['feasible_profiles'] for r in results),
        'total_unilateral_feasible_comparisons': sum(r['unilateral_feasible_checks'] for r in results),
        'unique_full_game_signatures': len(unique),
        'observational_equivalent_unordered_pairs': equal_pairs,
        'configs_with_no_pure_NE': sum(r['NE_count'] == 0 for r in results),
        'configs_with_resource_optimal_pure_NE': sum(r['NE_resource_welfare_max'] == r['max_feasible_resource_welfare'] for r in results),
        'source_model_ostrom_simulated': False,
        'contexts': {
            'baseline': analyse(base), 'collective_quota4': analyse(q), 'scope4': analyse(s),
            'fine_without_monitor': analyse(fine_no_monitor),
            'steward_private': analyse(steward_private),
            'steward_public': analyse(steward_public),
        },
        'equivalences': {
            'quota4_vs_scope4_exact': signature(q) == signature(s),
            'fine_without_monitor_vs_baseline_exact': signature(fine_no_monitor) == signature(base),
            'private_steward_fine_vs_no_fine': signature(steward_private) == signature(replace(steward_private, payoff=0)),
        },
        'rule_type_control_is_not_evidence_of_causal_identification': True,
        'new_real_subject_rows': 0, 'new_E2_predictive_scores': 0, 'new_E3_historical_forecasts': 0,
        'R073': 'FROZEN', 'PESEN_v0_1': 'FROZEN'
    }

if __name__ == '__main__':
    print(json.dumps(main_result(), ensure_ascii=False, sort_keys=True, indent=2))
