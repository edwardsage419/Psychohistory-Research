"""First-party synthetic exact global-game R142 tests, not empirical inference."""
import json
import unittest
from fractions import Fraction as F
from itertools import product
import r142_finite_private_signals as gg

ROWS = gg.full_results()
LOOKUP = {(r['h'], r['k_quarters']): r for r in ROWS['cases']}


def independent_reference_equilibria(mod):
    """Independent full direct-world type payoff approach, no score_fast call."""
    n = 1 << len(mod['signals'])
    br = []
    for other in range(n):
        must_attack = must_safe = 0
        for i, signal in enumerate(mod['signals']):
            world_payoff = sum(w * (4 * theta - mod['k'] + 8 * ((other >> mod['signals'].index(y)) & 1))
                               for theta, x, y, w in mod['worlds'] if x == signal)
            if world_payoff > 0:
                must_attack |= 1 << i
            elif world_payoff < 0:
                must_safe |= 1 << i
        br.append((must_attack, must_safe))
    pairs = []
    for p in range(n):
        for q in range(n):
            p_required, p_forbidden = br[q]
            q_required, q_forbidden = br[p]
            if ((p & p_required) == p_required and (p & p_forbidden) == 0
                    and (q & q_required) == q_required and (q & q_forbidden) == 0):
                pairs.append((p, q))
    return tuple(pairs)


class ProvenanceTests(unittest.TestCase):
    def test_001_all_sources(self):
        self.assertEqual(ROWS['sources'][0]['doi'], '10.2307/2951491')
        self.assertEqual(ROWS['sources'][1]['doi'], '10.2307/116850')

    def test_002_no_claim_original_proof(self):
        self.assertFalse(ROWS['full_game_author_theorem_reproduced'])

    def test_003_no_human(self):
        self.assertEqual(ROWS['new_E2_real_human_predictive_scores'], 0)

    def test_004_no_history(self):
        self.assertEqual(ROWS['new_E3_historical_predictive_scores'], 0)

    def test_005_frozen(self):
        self.assertEqual((ROWS['R073'], ROWS['PESEN_v0.1']), ('FROZEN', 'FROZEN'))

    def test_006_only_these_parameters(self):
        self.assertEqual((ROWS['noise_width_grid'], ROWS['cost_quarters_grid']), ([0, 1, 2], [3, 4, 5]))

    def test_007_nine_cells(self):
        self.assertEqual(len(ROWS['cases']), 9)

    def test_008_no_duplicate_cases(self):
        self.assertEqual(len(LOOKUP), 9)

    def test_009_all_pairs(self):
        self.assertEqual(ROWS['sum_strategy_pairs_examined'], 838656)

    def test_010_theta0_complete_information(self):
        self.assertEqual(ROWS['common_information_theta0_k3_pure_NEs'], [[0,0], [1,1]])

    def test_011_risk_dominance_exact(self):
        self.assertGreater(F(5,4), F(3,4))
        self.assertEqual(F(0)-F(3,4)+2, F(5,4))

    def test_012_h0_theta_minus1_has_coordination(self):
        self.assertEqual(gg.complete_info_pure_NEs(-1, 3), ((0,0), (1,1)))

    def test_013_h0_theta_minus2_only_safe(self):
        self.assertEqual(gg.complete_info_pure_NEs(-2, 3), ((0,0),))

    def test_014_h0_theta2_only_attack(self):
        self.assertEqual(gg.complete_info_pure_NEs(2, 3), ((1,1),))

    def test_015_model_not_currency_game(self):
        self.assertIn('NOT_ORIGINAL_CONTINUOUS_THEOREM', ROWS['study'])


class InputTests(unittest.TestCase):
    def test_016_bad_negative_h(self):
        with self.assertRaises(ValueError): gg.make_model(-1, 3)

    def test_017_bad_large_h(self):
        with self.assertRaises(ValueError): gg.make_model(3, 3)

    def test_018_float_h(self):
        with self.assertRaises(ValueError): gg.make_model(1.0, 3)

    def test_019_bool_h(self):
        with self.assertRaises(ValueError): gg.make_model(True, 3)

    def test_020_bool_k(self):
        with self.assertRaises(ValueError): gg.make_model(1, True)

    def test_021_float_k(self):
        with self.assertRaises(ValueError): gg.make_model(1, 3.0)

    def test_022_k_out_of_range(self):
        with self.assertRaises(ValueError): gg.make_model(1, 6)

    def test_023_noise_weights_h0(self):
        self.assertEqual(gg.noise_weights(0), ((0, 4),))

    def test_024_noise_weights_h1(self):
        self.assertEqual(gg.noise_weights(1), ((-1, 1), (0, 2), (1, 1)))

    def test_025_noise_weights_h2(self):
        self.assertEqual(gg.noise_weights(2), ((-2, 1), (0, 2), (2, 1)))

    def test_026_invalid_theta(self):
        with self.assertRaises(ValueError): gg.complete_info_pure_NEs(999, 3)


class ProbabilityTests(unittest.TestCase):
    def test_027_total_world_weight(self):
        for h,k in product(gg.H_VALUES,gg.K_QUARTERS):
            with self.subTest(h=h,k=k):
                mod=gg.make_model(h,k)
                self.assertEqual(sum(w for *_,w in mod['worlds']),80)

    def test_028_expected_type_count(self):
        for h,m in [(0,5),(1,7),(2,9)]:
            self.assertEqual(len(gg.make_model(h,3)['signals']),m)

    def test_029_symmetric_joint(self):
        for h in gg.H_VALUES:
            m=gg.make_model(h,4)
            self.assertEqual(m['joint'],tuple(tuple(m['joint'][j][i] for j in range(len(m['signals']))) for i in range(len(m['signals']))))

    def test_030_world_positive_weight(self):
        for h in gg.H_VALUES:
            self.assertTrue(all(w>0 for *_,w in gg.make_model(h,3)['worlds']))

    def test_031_theta_prior_exact(self):
        for h in gg.H_VALUES:
            model=gg.make_model(h,3)
            for theta in gg.THETAS:
                self.assertEqual(sum(w for t,*rest,w in model['worlds'] if t==theta),16)

    def test_032_marginal_mass(self):
        for h in gg.H_VALUES:
            model=gg.make_model(h,3)
            self.assertEqual(sum(model['masses']),80)
            self.assertTrue(all(n>0 for n in model['masses']))

    def test_033_posterior_normalized(self):
        for h in gg.H_VALUES:
            mod=gg.make_model(h,3)
            for signal in mod['signals']:
                self.assertEqual(sum(gg.posterior(mod,signal)),F(1))

    def test_034_posterior_extreme(self):
        m=gg.make_model(1,3)
        self.assertEqual(gg.posterior(m,-3), (F(1),F(0),F(0),F(0),F(0)))
        self.assertEqual(gg.posterior(m,3), (F(0),F(0),F(0),F(0),F(1)))

    def test_035_middle_posterior_symmetric(self):
        for h in (1,2):
            mod=gg.make_model(h,3)
            ps=gg.posterior(mod,0)
            self.assertEqual(ps,tuple(reversed(ps)))

    def test_036_posterior_nontrivial(self):
        m=gg.make_model(1,3)
        self.assertEqual(gg.posterior(m,0),(F(0),F(1,4),F(1,2),F(1,4),F(0)))


class EquilibriumTests(unittest.TestCase):
    def test_037_all_nash_direct_recheck(self):
        for h,k in product(gg.H_VALUES,gg.K_QUARTERS):
            with self.subTest(h=h,k=k):
                mod=gg.make_model(h,k)
                self.assertEqual(gg.equilibrium_pairs(mod),independent_reference_equilibria(mod))

    def test_038_each_attacking_conditional_sign_exact(self):
        for h,k in product(gg.H_VALUES,gg.K_QUARTERS):
            mod=gg.make_model(h,k)
            for other in range(1<<len(mod['signals'])):
                for i,x in enumerate(mod['signals']):
                    self.assertEqual(gg.score_fast(mod,i,other),gg.score_from_worlds(mod,x,other))

    def test_039_payoff_difference_fraction(self):
        for h,k in product(gg.H_VALUES,gg.K_QUARTERS):
            mod=gg.make_model(h,k)
            for i,x in enumerate(mod['signals']):
                self.assertEqual(gg.payoff_difference(mod,i,0),F(gg.score_from_worlds(mod,x,0),4*mod['masses'][i]))

    def test_040_nash_strategy_pairs_symmetric(self):
        for h,k in product(gg.H_VALUES,gg.K_QUARTERS):
            model=gg.make_model(h,k)
            eqs=set(gg.equilibrium_pairs(model))
            self.assertTrue(all((q,p) in eqs for p,q in eqs))

    def test_041_original_four_complete_h0_k3(self):
        self.assertEqual(LOOKUP[0,3]['pure_bayesian_NE_count'],4)

    def test_042_original_eight_complete_h0_k4(self):
        self.assertEqual(LOOKUP[0,4]['pure_bayesian_NE_count'],8)

    def test_043_h1_two_equilibria_each(self):
        for k in (3,4,5):self.assertEqual(LOOKUP[1,k]['pure_bayesian_NE_count'],2)

    def test_044_h2_multiple_not_original_uniqueness_theorem(self):
        self.assertEqual([LOOKUP[2,k]['pure_bayesian_NE_count'] for k in (3,4,5)],[8,10,8])

    def test_045_all_reported_pure_NE_symmetric(self):
        self.assertTrue(all(row['asymmetric_BNE_count']==0 for row in ROWS['cases']))

    def test_046_h1_monotone_threshold_strategies(self):
        for k in (3,4,5):
            mod=gg.make_model(1,k)
            self.assertTrue(all(gg.is_monotone(mod,p) and gg.is_monotone(mod,q)
                                for p,q in gg.equilibrium_pairs(mod)))

    def test_047_h2_nonmonotone_discrete_signals(self):
        m=gg.make_model(2,3)
        self.assertIn((490,490),gg.equilibrium_pairs(m))
        self.assertFalse(gg.is_monotone(m,490))

    def test_048_all_reported_count_consistent(self):
        for row in ROWS['cases']:
            n=row['pure_bayesian_NE_count']
            self.assertEqual(len(row['equilibrium_policy_masks']),n)
            self.assertEqual(row['symmetric_BNE_count']+row['asymmetric_BNE_count'],n)

    def test_049_marginal_strategy_pair_count(self):
        for row in ROWS['cases']:
            self.assertEqual(row['policy_pairs_examined'],row['number_pure_strategies_per_player']**2)

    def test_050_both_BNE_strategies_are_brs(self):
        for h,k in product(gg.H_VALUES,gg.K_QUARTERS):
            m=gg.make_model(h,k)
            for p,q in gg.equilibrium_pairs(m):
                self.assertTrue(gg.is_best_response_direct(m,p,q))
                self.assertTrue(gg.is_best_response_direct(m,q,p))

    def test_051_negative_safe_not_brs(self):
        m=gg.make_model(1,3)
        self.assertFalse(gg.is_best_response_direct(m,0,(1<<7)-1))

    def test_052_policy_decode(self):
        m=gg.make_model(1,3)
        self.assertEqual(gg.decode_policy(m,112),(1,2,3))

    def test_053_risk_selection_not_assumed(self):
        self.assertGreater(LOOKUP[1,3]['pure_bayesian_NE_count'],1)

    def test_054_monotonicity_not_forced(self):
        self.assertLess(LOOKUP[2,4]['both_players_monotone_BNE_count'],LOOKUP[2,4]['pure_bayesian_NE_count'])

    def test_055_result_json_round_trip(self):
        d=json.loads(json.dumps(ROWS,sort_keys=True))
        self.assertEqual(d,ROWS)


if __name__=='__main__':unittest.main()
