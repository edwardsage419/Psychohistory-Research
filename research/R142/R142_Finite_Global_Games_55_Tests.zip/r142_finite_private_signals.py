"""R142: exact finite Bayesian global-game *illustration*, not original paper replication.

Inputs: theta ~ Uniform{-2,-1,0,1,2}, two conditionally independent private
signals x_i=theta+eta_i with eta={-h,0,h}, weights 1:2:1, h>0.
When h=0, eta=0 with weight 4. Attack vs safe payoff difference:
theta - k_quarters/4 + 2*1{opponent attacks}. All calculations exact.
"""
from fractions import Fraction
from itertools import product
from functools import lru_cache
import json

THETAS = (-2, -1, 0, 1, 2)
H_VALUES = (0, 1, 2)
K_QUARTERS = (3, 4, 5)


def check_input(h, k):
    if type(h) is not int or h not in H_VALUES:
        raise ValueError('noise width h must be an integer in {0,1,2}')
    if type(k) is not int or k not in K_QUARTERS:
        raise ValueError('cost must be integer quarters in {3,4,5}')


def noise_weights(h):
    if type(h) is not int or h not in H_VALUES:
        raise ValueError('invalid noise width')
    return ((0, 4),) if h == 0 else ((-h, 1), (0, 2), (h, 1))


def make_model(h, k):
    # Validate BEFORE the cache: Python considers 1 == True == 1.0 as keys.
    check_input(h, k)
    return _make_model_cached(h, k)


@lru_cache(maxsize=9)
def _make_model_cached(h, k):
    worlds = []
    for theta in THETAS:
        for (eta1, w1), (eta2, w2) in product(noise_weights(h), repeat=2):
            # Scale joint probabilities by 80; duplicates are summed below.
            worlds.append((theta, theta + eta1, theta + eta2, w1 * w2))
    assert sum(w for _, _, _, w in worlds) == 80
    sig = tuple(sorted({x for _, x, _, _ in worlds}))
    idx = {x: i for i, x in enumerate(sig)}
    m = len(sig)
    # Each row r corresponds to own signal r; columns are opponent signals.
    joint = [[0 for _ in range(m)] for _ in range(m)]
    base = [0] * m
    masses = [0] * m
    theta_x = [[0 for _ in THETAS] for _ in range(m)]
    for theta, x, y, w in worlds:
        i, j = idx[x], idx[y]
        joint[i][j] += w
        base[i] += w * (4 * theta - k)
        masses[i] += w
        theta_x[i][theta - THETAS[0]] += w
    assert sum(masses) == 80
    assert all(joint[i][j] == joint[j][i] for i in range(m) for j in range(m))
    assert all(masses[i] == sum(joint[i]) for i in range(m))
    return {'h': h, 'k': k, 'signals': sig, 'worlds': tuple(worlds),
            'joint': tuple(tuple(row) for row in joint),
            'base': tuple(base), 'masses': tuple(masses),
            'theta_x': tuple(tuple(row) for row in theta_x)}


def score_from_worlds(model, own_signal, opponent_mask):
    """Separate direct enumeration of original joint outcomes; integer scaled."""
    sig = model['signals']
    own_index = sig.index(own_signal)
    idx = {x: i for i, x in enumerate(sig)}
    return sum(w * (4 * theta - model['k'] + 8 * ((opponent_mask >> idx[y]) & 1))
               for theta, x, y, w in model['worlds'] if x == sig[own_index])


def posterior(model, signal):
    """P(theta | own signal) as exact rational probabilities."""
    i = model['signals'].index(signal)
    den = model['masses'][i]
    return tuple(Fraction(v, den) for v in model['theta_x'][i])


def score_fast(model, signal_index, opponent_mask):
    row = model['joint'][signal_index]
    total = model['base'][signal_index]
    for j, w in enumerate(row):
        if (opponent_mask >> j) & 1:
            total += 8 * w
    return total


def payoff_difference(model, signal_index, opponent_mask):
    return Fraction(score_fast(model, signal_index, opponent_mask),
                    4 * model['masses'][signal_index])


def best_response_masks(model, opponent_mask):
    """(must_attack, must_safe); score=0 types allow both."""
    pos = neg = 0
    for i in range(len(model['signals'])):
        s = score_fast(model, i, opponent_mask)
        if s > 0:
            pos |= 1 << i
        if s < 0:
            neg |= 1 << i
    return pos, neg


def is_best_response(policy, own_best_masks):
    pos, neg = own_best_masks
    return (policy & pos) == pos and (policy & neg) == 0


def is_best_response_direct(model, own_policy, other_policy):
    """Independent direct outcome payoff calculation for each own type."""
    for i, x in enumerate(model['signals']):
        actual_attack = bool((own_policy >> i) & 1)
        s = score_from_worlds(model, x, other_policy)
        if (actual_attack and s < 0) or (not actual_attack and s > 0):
            return False
    return True


def is_monotone(model, policy):
    m = len(model['signals'])
    return all(((policy >> i) & 1) <= ((policy >> (i + 1)) & 1)
               for i in range(m - 1))


def decode_policy(model, policy):
    return tuple(model['signals'][i] for i in range(len(model['signals']))
                 if (policy >> i) & 1)


def equilibrium_pairs(model):
    m = len(model['signals'])
    n_strategies = 1 << m
    br = tuple(best_response_masks(model, p) for p in range(n_strategies))
    pairs = []
    for p in range(n_strategies):
        pos, neg = br[p]
        # q is best-response to p; check reverse condition p best-response to q.
        for q in range(n_strategies):
            if ((q & pos) == pos and (q & neg) == 0
                    and is_best_response(p, br[q])):
                pairs.append((p, q))
    return tuple(pairs)


def complete_info_pure_NEs(theta, k):
    if type(theta) is not int or theta not in THETAS:
        raise ValueError('unknown fundamental')
    if type(k) is not int or k not in K_QUARTERS:
        raise ValueError('invalid k')
    # Player1 / Player2 0=S,1=A, direct deviation payoffs.
    def own_payoff(own, other):
        return Fraction(own * (4 * theta - k + 8 * other), 4)
    ans = []
    for a, b in product((0, 1), repeat=2):
        if (own_payoff(a, b) >= own_payoff(1 - a, b)
                and own_payoff(b, a) >= own_payoff(1 - b, a)):
            ans.append((a, b))
    return tuple(ans)


def result(h, k):
    mod = make_model(h, k)
    eqs = equilibrium_pairs(mod)
    sym = tuple(p for p, q in eqs if p == q)
    nonsym = tuple((p, q) for p, q in eqs if p != q)
    monotone = tuple((p, q) for p, q in eqs
                     if is_monotone(mod, p) and is_monotone(mod, q))
    # Report exact posterior for each observed signal, no probabilistic samples.
    out = {
        'h': h, 'k_quarters': k, 'attack_cost': str(Fraction(k, 4)),
        'theta_prior': [str(Fraction(1, 5)) for _ in THETAS],
        'signals': list(mod['signals']), 'number_signals': len(mod['signals']),
        'number_pure_strategies_per_player': 1 << len(mod['signals']),
        'policy_pairs_examined': 1 << (2 * len(mod['signals'])),
        'pure_bayesian_NE_count': len(eqs),
        'symmetric_BNE_count': len(sym), 'asymmetric_BNE_count': len(nonsym),
        'both_players_monotone_BNE_count': len(monotone),
        'equilibrium_policy_masks': [list(z) for z in eqs],
        'posterior_theta_given_signal': {
            str(signal): [str(v) for v in posterior(mod, signal)]
            for signal in mod['signals']},
    }
    return out


def full_results():
    rows = [result(h, k) for h, k in product(H_VALUES, K_QUARTERS)]
    return {
        'research': 'R142', 'catalogue': 'P2 05-018 Global Games',
        'sources': [{'authors': 'Carlsson and van Damme', 'year': 1993,
                     'doi': '10.2307/2951491', 'read_print_pages': [989, 993]},
                    {'authors': 'Morris and Shin', 'year': 1998,
                     'doi': '10.2307/116850', 'read_print_pages': [588, 590]}],
        'study': 'PROJECT_CONSTRUCTED_FINITE_DISCRETE_BAYESIAN_COORDINATION_GAME_NOT_ORIGINAL_CONTINUOUS_THEOREM',
        'cost_quarters_grid': list(K_QUARTERS), 'noise_width_grid': list(H_VALUES),
        'cases': rows,
        'sum_strategy_pairs_examined': sum(r['policy_pairs_examined'] for r in rows),
        'common_information_theta0_k3_pure_NEs': [list(x) for x in complete_info_pure_NEs(0, 3)],
        'risk_dominance_theta0_k3': 'attack_A_by_strict_product_of_deviation_losses_5/4>3/4',
        'full_game_author_theorem_reproduced': False,
        'new_E2_real_human_predictive_scores': 0,
        'new_E3_historical_predictive_scores': 0,
        'R073': 'FROZEN', 'PESEN_v0.1': 'FROZEN'
    }


if __name__ == '__main__':
    print(json.dumps(full_results(), ensure_ascii=False, indent=2, sort_keys=True))
