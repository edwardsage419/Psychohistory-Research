"""R148 genuine independent tests: fixed SES rules, exact exogenous weather/governance mixing."""
import unittest
from fractions import Fraction as F
from itertools import product
import r148_ostrom_ses_exact as m


class PhysicalTests(unittest.TestCase):
    def test_zero_absorbing_all_policies(self):
        for p, shock, broken in product(m.POLICIES,(False,True),(False,True)):
            self.assertEqual(m.step(0,p,shock,broken),(0,0))
    def test_open_six_no_shock(self):
        self.assertEqual(m.step(6,'OPEN',False,False),(5,2))
    def test_open_six_shock(self):
        self.assertEqual(m.step(6,'OPEN',True,False),(3,2))
    def test_quota_six_no_shock(self):
        self.assertEqual(m.step(6,'QUOTA',False,False),(6,1))
    def test_adapt_six_no_shock(self):
        self.assertEqual(m.step(6,'ADAPT',False,False),(6,1))
    def test_adapt_stock_two_protects(self):
        self.assertEqual(m.step(2,'ADAPT',False,False),(3,0))
    def test_adapt_stock_two_shock(self):
        self.assertEqual(m.step(2,'ADAPT',True,False),(0,0))
    def test_quota_stock_two_shock(self):
        self.assertEqual(m.step(2,'QUOTA',True,False),(0,1))
    def test_adapt_stock_seven_harvest_two(self):
        self.assertEqual(m.step(7,'ADAPT',False,False),(6,2))
    def test_adapt_stock_eight_harvest_two(self):
        self.assertEqual(m.step(8,'ADAPT',False,False),(7,2))
    def test_adapt_failure_replaces_current_rule(self):
        self.assertEqual(m.step(6,'ADAPT',False,True),m.step(6,'OPEN',False,False))
    def test_quota_failure_replaces_current_rule(self):
        self.assertEqual(m.step(6,'QUOTA',False,True),m.step(6,'OPEN',False,False))
    def test_open_infrastructure_breakdown_irrelevant(self):
        for s in range(9):
            for climate in (True,False):
                self.assertEqual(m.step(s,'OPEN',climate,False),m.step(s,'OPEN',climate,True))
    def test_resource_stays_bounded(self):
        for s in range(9):
            for p in m.POLICIES:
                for a,b in product((False,True),repeat=2):
                    later,h=m.step(s,p,a,b)
                    self.assertTrue(0<=later<=8)
                    self.assertTrue(0<=h<=s)
    def test_regrowth_only_after_extraction_and_shock(self):
        self.assertEqual(m.step(1,'ADAPT',False,False),(2,0))
    def test_weather_damages_after_harvest(self):
        self.assertEqual(m.step(4,'OPEN',True,False),(0,2))
    def test_no_within_year_adaptive_replanning(self):
        self.assertEqual(m.step(3,'ADAPT',True,False),(0,1))
    def test_carrying_cap_no_overflow(self):
        self.assertLessEqual(m.step(8,'ADAPT',False,False)[0],8)
    def test_governance_fees(self):
        self.assertEqual(m.COST,{'OPEN':F(0),'QUOTA':F(1,8),'ADAPT':F(1,4)})

class InputTests(unittest.TestCase):
    def test_bad_probability_float(self):
        for arg in ((.25,F(0)),(F(0),.25)):
            with self.assertRaises(ValueError):m.forward('OPEN',*arg)
    def test_bad_probability_bool(self):
        for arg in ((True,F(0)),(F(0),True)):
            with self.assertRaises(ValueError):m.backward('OPEN',*arg)
    def test_bad_probability_integer(self):
        with self.assertRaises(ValueError):m.forward('OPEN',0,F(0))
    def test_bad_probability_outside_grid(self):
        with self.assertRaises(ValueError):m.forward('OPEN',F(1,3),F(0))
    def test_invalid_policy(self):
        with self.assertRaises(ValueError):m.forward('FISH',F(0),F(0))
    def test_invalid_policy_nonstring(self):
        with self.assertRaises(ValueError):m.step(4,0,True,False)
    def test_invalid_stock_bool(self):
        with self.assertRaises(ValueError):m.step(True,'OPEN',False,False)
    def test_invalid_stock_negative(self):
        with self.assertRaises(ValueError):m.step(-1,'OPEN',False,False)
    def test_invalid_stock_over_cap(self):
        with self.assertRaises(ValueError):m.step(9,'OPEN',False,False)
    def test_invalid_shock_numeric(self):
        with self.assertRaises(ValueError):m.step(6,'OPEN',1,False)
    def test_invalid_failure_numeric(self):
        with self.assertRaises(ValueError):m.step(6,'OPEN',False,0)
    def test_invalid_initial_bool(self):
        with self.assertRaises(ValueError):m.forward('OPEN',F(0),F(0),initial=False)
    def test_invalid_horizon_too_long(self):
        with self.assertRaises(ValueError):m.forward('OPEN',F(0),F(0),horizon=9)
    def test_invalid_horizon_bool(self):
        with self.assertRaises(ValueError):m.backward('OPEN',F(0),F(0),horizon=True)
    def test_invalid_horizon_negative(self):
        with self.assertRaises(ValueError):m.forward('OPEN',F(0),F(0),horizon=-1)
    def test_independent_probability_mass(self):
        for q in m.WEATHER:
            for f in m.FAILURES:
                self.assertEqual(sum((w for _,_,w in m.elementary_events(q,f)),F(0)),1)

class SourceBoundaries(unittest.TestCase):
    def test_deterministic_open_collapse_by_year_five(self):
        self.assertEqual(m.deterministic_stock_path('OPEN'),[6,5,4,3,2,0,0,0,0])
    def test_deterministic_quota_stable(self):
        self.assertEqual(m.deterministic_stock_path('QUOTA'),[6]*9)
    def test_deterministic_adaptive_stable(self):
        self.assertEqual(m.deterministic_stock_path('ADAPT'),[6]*9)
    def test_open_expected_harvest_ten(self):
        self.assertEqual(m.forward('OPEN',F(0),F(0))['expected_total_harvest'],'10')
    def test_quota_eight_units(self):
        self.assertEqual(m.forward('QUOTA',F(0),F(0))['expected_total_harvest'],'8')
    def test_adaptive_eight_units(self):
        self.assertEqual(m.forward('ADAPT',F(0),F(0))['expected_total_harvest'],'8')
    def test_open_collapse_without_shock(self):
        self.assertEqual(m.forward('OPEN',F(0),F(0))['collapse_probability'],'1')
    def test_stable_policy_survival_no_shock(self):
        for p in ('ADAPT','QUOTA'):
            self.assertEqual(m.forward(p,F(0),F(0))['survival_probability'],'1')
    def test_open_gross_greater_but_survival_worse(self):
        a=m.forward('OPEN',F(0),F(0));b=m.forward('ADAPT',F(0),F(0))
        self.assertGreater(F(a['expected_total_harvest']),F(b['expected_total_harvest']))
        self.assertLess(F(a['survival_probability']),F(b['survival_probability']))
    def test_governance_annual_cost_paid_even_if_collapse(self):
        for p in m.POLICIES:
            a=m.forward(p,F(1,2),F(1,4))
            self.assertEqual(F(a['expected_governance_expense']),m.T*m.COST[p])
    def test_terminal_mass_sum_one(self):
        for p in m.POLICIES:
            for q in m.WEATHER:
                for f in m.FAILURES:
                    a=m.forward(p,q,f)
                    for yearly in a['yearly_stock_pmf']:
                        self.assertEqual(sum(map(F,yearly.values()),F(0)),1)
    def test_expected_net_budget_identity(self):
        for p in m.POLICIES:
            for q in m.WEATHER:
                a=m.forward(p,q,F(1,4))
                self.assertEqual(F(a['expected_net_harvest_less_expense']),F(a['expected_total_harvest'])-F(a['expected_governance_expense']))
    def test_collapse_is_absorbing_distribution(self):
        for p in m.POLICIES:
            a=m.forward(p,F(1,2),F(1,4))
            pmfs=a['yearly_stock_pmf']
            for x,y in zip(pmfs,pmfs[1:]):
                self.assertGreaterEqual(F(y['0']),F(x['0']))
    def test_open_failure_prob_irrelevant_all_q(self):
        for q in m.WEATHER:
            self.assertEqual(m.forward('OPEN',q,F(0))['terminal_stock_pmf'],m.forward('OPEN',q,F(1,4))['terminal_stock_pmf'])
    def test_weather_shock_effect_quota_survival(self):
        out=[F(m.forward('QUOTA',q,F(0))['survival_probability']) for q in m.WEATHER]
        self.assertGreater(out[0],out[1]);self.assertGreater(out[1],out[2])
    def test_adapt_failure_risk_positive_at_q_zero(self):
        a=m.forward('ADAPT',F(0),F(0));b=m.forward('ADAPT',F(0),F(1,4))
        self.assertEqual(a['collapse_probability'],'0')
        self.assertGreater(F(b['collapse_probability']),0)
    def test_shared_weather_repeated_path_exact(self):
        for p in m.POLICIES:
            x=m.forward(p,F(1,4),F(0));y=m.weather_path_exact(p)
            self.assertEqual(x['terminal_stock_pmf'],y['terminal_stock_pmf'])
            self.assertEqual(x['expected_total_harvest'],y['expected_total_harvest'])
    def test_zero_stock_no_harvest_future(self):
        for p in m.POLICIES:
            x=m.backward(p,F(1,2),F(1,4),initial=0)
            self.assertEqual(x['expected_total_harvest'],'0')
            self.assertEqual(x['terminal_stock_pmf']['0'],'1')
    def test_terminal_horizon_zero(self):
        for p in m.POLICIES:
            a=m.forward(p,F(0),F(0),horizon=0)
            self.assertEqual(a['expected_total_harvest'],'0')
            self.assertEqual(a['terminal_stock_pmf']['6'],'1')
    def test_terminal_pmf_all_nine_states(self):
        for p in m.POLICIES:
            a=m.forward(p,F(1,4),F(0))
            self.assertEqual(set(a['terminal_stock_pmf']),{str(i) for i in range(9)})
    def test_two_users_symmetric_division_is_exact(self):
        self.assertEqual(F(m.step(6,'OPEN',False,False)[1],2),1)
        self.assertEqual(F(m.step(6,'QUOTA',False,False)[1],2),F(1,2))
    def test_exact_quota_survival_no_failure(self):
        self.assertEqual(m.forward('QUOTA',F(1,4),F(0))['survival_probability'],'44469/65536')
    def test_exact_adapt_survival_with_failures(self):
        self.assertEqual(m.forward('ADAPT',F(1,2),F(1,4))['survival_probability'],'737973/16777216')
    def test_adapt_not_universally_dominant_in_net(self):
        a=m.forward('ADAPT',F(0),F(0));b=m.forward('QUOTA',F(0),F(0))
        self.assertLess(F(a['expected_net_harvest_less_expense']),F(b['expected_net_harvest_less_expense']))
    def test_replay_has_no_empirical_scores(self):
        s=m.full_replay()
        self.assertEqual((s['new_E2_real_human_predictive_scores'],s['new_E3_real_history_forecasts']),(0,0))
        self.assertTrue(s['sources_are_conceptual_not_numerical_reproductions'])
    def test_18_scenarios_exact(self):
        s=m.full_replay()
        self.assertEqual(s['cases_count'],18)
        self.assertTrue(s['open_failure_invariance'])
        self.assertTrue(s['all_18_forward_backward_exact'])
    def test_full_replay_two_path_agreement(self):
        s=m.full_replay()
        self.assertTrue(all(r['independent_backward_equals_forward'] for r in s['full_cases']))


class ScenarioSuite(unittest.TestCase):
    pass

# Each parameter set is a distinct real test in unittest output, not a counted subTest.
for policy in m.POLICIES:
    for q in m.WEATHER:
        for f in m.FAILURES:
            tag=f'{policy.lower()}_q{q.numerator}over{q.denominator}_f{f.numerator}over{f.denominator}'
            def mk_cross(p=policy,qq=q,ff=f):
                def check(self):
                    a=m.forward(p,qq,ff);b=m.backward(p,qq,ff)
                    for key,val in b.items():self.assertEqual(a[key],val)
                return check
            def mk_mass(p=policy,qq=q,ff=f):
                def check(self):
                    a=m.forward(p,qq,ff)
                    self.assertEqual(len(a['yearly_stock_pmf']),m.T+1)
                    self.assertEqual(sum((F(z) for z in a['terminal_stock_pmf'].values()),F(0)),1)
                return check
            setattr(ScenarioSuite,'test_cross_'+tag,mk_cross())
            setattr(ScenarioSuite,'test_mass_'+tag,mk_mass())


if __name__=='__main__':
    unittest.main()
