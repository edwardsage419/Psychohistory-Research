"""R148: original finite SES stock/governance stochastic diagnostic, not Ostrom numeric code.
Sources: Ostrom Science 2009 DOI 10.1126/science.1172133;
Anderies Janssen Ostrom Ecology & Society 2004 DOI 10.5751/ES-00610-090118.
All physical and behavioral parameters are original, frozen in R148 prescore protocol.
"""
from fractions import Fraction as F
from itertools import product
from functools import lru_cache
import json

POLICIES = ("OPEN", "QUOTA", "ADAPT")
WEATHER = (F(0), F(1, 4), F(1, 2))
FAILURES = (F(0), F(1, 4))
T = 8
INITIAL = 6
COST = {"OPEN": F(0), "QUOTA": F(1, 8), "ADAPT": F(1, 4)}


def validate(policy, q, failure, initial=INITIAL, horizon=T):
    if type(policy) is not str or policy not in POLICIES:
        raise ValueError("unknown policy")
    for n, v, allowed in (("climate probability", q, WEATHER),
                          ("infrastructure probability", failure, FAILURES)):
        if type(v) is not F or v not in allowed:
            raise ValueError(n)
    if type(initial) is not int or not 0 <= initial <= 8:
        raise ValueError("invalid resource stock")
    if type(horizon) is not int or not 0 <= horizon <= T:
        raise ValueError("invalid horizon")


def step(stock, policy, climate_shock, infrastructure_failure):
    if type(stock) is not int or not 0 <= stock <= 8:
        raise ValueError("bad stock")
    if type(policy) is not str or policy not in POLICIES:
        raise ValueError("bad governance")
    if type(climate_shock) is not bool or type(infrastructure_failure) is not bool:
        raise ValueError("event flags must be bool")
    if policy == "OPEN" or infrastructure_failure:
        request = 2
    elif policy == "QUOTA":
        request = 1
    else:
        request = 0 if stock <= 2 else (1 if stock <= 6 else 2)
    harvest = min(stock, request)
    after_damage = max(0, stock - harvest - (2 if climate_shock else 0))
    regrowth = 1 if 1 <= after_damage <= 6 else 0
    new_stock = min(8, after_damage + regrowth)
    return new_stock, harvest


def elementary_events(q, failure):
    # Inputs intentionally validated prior to this helper, never cached.
    for weather, fw in ((False, 1-q), (True, q)):
        for broken, fb in ((False, 1-failure), (True, failure)):
            weight = fw * fb
            if weight:
                yield weather, broken, weight


def forward(policy, q, failure, initial=INITIAL, horizon=T):
    validate(policy, q, failure, initial, horizon)
    masses = {initial: F(1)}
    yearly = [{str(s): str(masses.get(s, F(0))) for s in range(9)}]
    expected_harvest = F(0)
    each_harvest = []
    for _ in range(horizon):
        later = {}
        this_h = F(0)
        for stock, prob in masses.items():
            for shock, broken, w in elementary_events(q, failure):
                next_stock, harvested = step(stock, policy, shock, broken)
                later[next_stock] = later.get(next_stock, F(0)) + prob*w
                this_h += prob*w*harvested
        if sum(later.values(), F(0)) != 1:
            raise AssertionError("probability mass escaped")
        masses = later
        yearly.append({str(s): str(masses.get(s, F(0))) for s in range(9)})
        each_harvest.append(str(this_h))
        expected_harvest += this_h
    p_survive = 1 - masses.get(0, F(0))
    expected_stock = sum((s*w for s,w in masses.items()), F(0))
    return {
        "policy": policy, "climate_probability": str(q), "failure_probability": str(failure),
        "horizon": horizon, "initial_stock": initial,
        "yearly_stock_pmf": yearly, "terminal_stock_pmf": yearly[-1],
        "survival_probability": str(p_survive),
        "collapse_probability": str(1-p_survive),
        "expected_terminal_stock": str(expected_stock),
        "expected_harvest_each_year": each_harvest,
        "expected_total_harvest": str(expected_harvest),
        "expected_governance_expense": str(horizon*COST[policy]),
        "expected_net_harvest_less_expense": str(expected_harvest-horizon*COST[policy]),
    }


def backward(policy, q, failure, initial=INITIAL, horizon=T):
    """Independent recursive Bellman computation, duplicates neither step nor forward."""
    validate(policy, q, failure, initial, horizon)
    @lru_cache(None)
    def solve(stock, left):
        if left == 0:
            return (tuple(F(1 if stock == i else 0) for i in range(9)), F(0))
        pmf = [F(0)]*9
        harvest_sum = F(0)
        for damaged in (False, True):
            for broken in (False, True):
                weight = (q if damaged else 1-q)*(failure if broken else 1-failure)
                if not weight:
                    continue
                if policy == "OPEN" or broken:
                    planned = 2
                elif policy == "QUOTA":
                    planned = 1
                elif stock <= 2:
                    planned = 0
                elif stock <= 6:
                    planned = 1
                else:
                    planned = 2
                taken = min(planned, stock)
                remain = max(stock-taken-(2 if damaged else 0), 0)
                s1 = min(8, remain+(1 if remain in (1,2,3,4,5,6) else 0))
                later_pmf, later_h = solve(s1, left-1)
                for j in range(9):
                    pmf[j] += weight*later_pmf[j]
                harvest_sum += weight*(taken+later_h)
        return tuple(pmf), harvest_sum
    pmf, expected_harvest = solve(initial,horizon)
    return {
        "terminal_stock_pmf": {str(i):str(pmf[i]) for i in range(9)},
        "survival_probability": str(1-pmf[0]),
        "expected_terminal_stock": str(sum((i*pmf[i] for i in range(9)), F(0))),
        "expected_total_harvest": str(expected_harvest),
        "expected_net_harvest_less_expense": str(expected_harvest-horizon*COST[policy]),
    }


def weather_path_exact(policy, q=F(1, 4)):
    """All 256 deterministic weather paths, NO governance failure; third implementation."""
    validate(policy, q, F(0))
    dist = {i:F(0) for i in range(9)}
    total = F(0)
    for path in product((0,1), repeat=T):
        freq = sum(path)
        w = q**freq*(1-q)**(T-freq)
        s = INITIAL
        got = 0
        for flag in path:
            if policy == "OPEN":
                planned = 2
            elif policy == "QUOTA":
                planned = 1
            else:
                planned = (0 if s < 3 else (1 if s < 7 else 2))
            h = min(s,planned)
            x = max(s-h-2*flag,0)
            s = min(8,x+(int(0 < x < 7)))
            got += h
        dist[s] += w
        total += w*got
    return {"terminal_stock_pmf":{str(i):str(dist[i]) for i in range(9)},
            "expected_total_harvest":str(total)}


def full_replay():
    cases = []
    for policy in POLICIES:
        for q in WEATHER:
            for failure in FAILURES:
                a = forward(policy,q,failure)
                b = backward(policy,q,failure)
                for key, val in b.items():
                    if a[key] != val:
                        raise AssertionError((policy,q,failure,key,a[key],val))
                a["independent_backward_equals_forward"] = True
                cases.append(a)
    paths = {p:weather_path_exact(p) for p in POLICIES}
    for p in POLICIES:
        x = forward(p,F(1,4),F(0))
        assert paths[p]["terminal_stock_pmf"] == x["terminal_stock_pmf"]
        assert paths[p]["expected_total_harvest"] == x["expected_total_harvest"]
    def find(p,q,f):
        return next(c for c in cases if c["policy"] == p and c["climate_probability"]==str(q) and c["failure_probability"]==str(f))
    all_open_graph_invariance = all(find("OPEN",q,F(0))["terminal_stock_pmf"]==find("OPEN",q,F(1,4))["terminal_stock_pmf"] for q in WEATHER)
    no_weather_paths={p:[step_stock for step_stock in deterministic_stock_path(p)] for p in POLICIES}
    return {"research":"R148", "catalogue":"P1/06-006 Social Ecological Systems",
            "sources_are_conceptual_not_numerical_reproductions":True,
            "project_synthetic_stock_process":True,"cases_count":len(cases),
            "governance_fees_paid_through_horizon_even_after_collapse":True,
            "exogenous_weather_sequences_each_policy":2**T,
            "all_18_forward_backward_exact":all(c["independent_backward_equals_forward"] for c in cases),
            "weather_path_crosscheck":paths,
            "open_failure_invariance":all_open_graph_invariance,
            "no_climate_deterministic_paths":no_weather_paths,
            "full_cases":cases,
            "new_E2_real_human_predictive_scores":0,
            "new_E3_real_history_forecasts":0,
            "R073":"FROZEN", "PESEN_v0_1":"FROZEN"}


def deterministic_stock_path(policy):
    s = INITIAL
    path = [s]
    for _ in range(T):
        s,_=step(s,policy,False,False)
        path.append(s)
    return path


if __name__ == "__main__":
    print(json.dumps(full_replay(),ensure_ascii=False,sort_keys=True,separators=(",",":")))
