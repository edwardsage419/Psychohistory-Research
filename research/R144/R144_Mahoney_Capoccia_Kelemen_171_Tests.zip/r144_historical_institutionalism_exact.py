"""R144: wholly PROJECT-CONSTRUCTED deterministic sequence automaton.

Mahoney (2000), Capoccia & Kelemen (2007) motivate concepts only.
This program does not reproduce an original author's numerical model or
identify counterfactual effects in any real historical case.
"""
from __future__ import annotations

from itertools import permutations, product
import json
import sys

EVENTS = ('O', 'M', 'A', 'E', 'B', 'W')
INIT = (0, 0, 0, 0)  # (reformed, coalition, window, entrenched)


def validate_state(state):
    if not isinstance(state, tuple) or len(state) != 4:
        raise ValueError('state must be a four-tuple')
    r, c, w, e = state
    for v in state:
        if type(v) is not int:
            raise ValueError('state values must be exact ints (not bool or float)')
    if r not in (0, 1) or c not in (0, 1) or w not in (0, 1, 2) or e not in (0, 1):
        raise ValueError('invalid state domain')
    if e and not r:
        raise ValueError('entrenched reform cannot be unreformed')
    return state


def step(state, event):
    r, c, w, e = validate_state(state)
    if type(event) is not str or event not in EVENTS:
        raise ValueError('event must be one of O, M, A, E, B, W')
    if event == 'O':
        return (r, c, w if e else 2, e)
    new_w = max(0, w - 1)
    if event == 'M' and w > 0:
        c = 1
    elif event == 'A' and w > 0 and c == 1:
        r = 1
    elif event == 'E' and r:
        e = 1
    elif event == 'B' and not e:
        r = 0
        c = 0
    out = (r, c, new_w, e)
    return validate_state(out)


def independent_step(state, event):
    """Separate spec interpreter using a table of update functions, not step()."""
    validate_state(state)
    if type(event) is not str or event not in EVENTS:
        raise ValueError('unsupported event')
    s = dict(zip(('regime', 'coalition', 'window', 'entrenched'), state))
    before = dict(s)
    if event == 'O':
        if before['entrenched'] == 0:
            s['window'] = 2
    else:
        s['window'] = 0 if before['window'] == 0 else before['window'] - 1
        if event == 'M':
            if before['window'] != 0:
                s['coalition'] = 1
        if event == 'A':
            if before['coalition'] == 1 and before['window'] != 0:
                s['regime'] = 1
        if event == 'E':
            if before['regime'] == 1:
                s['entrenched'] = 1
        if event == 'B':
            if before['entrenched'] == 0:
                s['regime'] = 0
                s['coalition'] = 0
    return validate_state((s['regime'], s['coalition'], s['window'], s['entrenched']))


def validate_events(seq):
    if not isinstance(seq, (tuple, list)):
        raise ValueError('sequence must be a list or tuple')
    if any(type(e) is not str or e not in EVENTS for e in seq):
        raise ValueError('invalid event')
    return tuple(seq)


def trace(seq, transition=step):
    seq = validate_events(seq)
    path = [INIT]
    for event in seq:
        path.append(transition(path[-1], event))
    return tuple(path)


def terminal(seq):
    return trace(seq)[-1]


def regime_and_lock(state):
    return (state[0], state[3])


def paired_do(seq, index, replacement='W'):
    seq = validate_events(seq)
    if type(index) is not int or index < 0 or index >= len(seq):
        raise ValueError('index must identify one existing event')
    if type(replacement) is not str or replacement not in EVENTS:
        raise ValueError('replacement must be event')
    alt = seq[:index] + (replacement,) + seq[index+1:]
    return {'original': terminal(seq), 'alternative': terminal(alt), 'alternative_sequence': alt}


def count_signature(seq):
    seq = validate_events(seq)
    return tuple(seq.count(e) for e in EVENTS)


def full_study():
    terminal_histogram = {f'{r}{e}': 0 for r in (0, 1) for e in (0, 1)}
    final_full_state_counts = {}
    total_profiles = 0
    checked_transition_steps = 0
    pairs = 0
    changed_regime = 0
    changed_lock = 0
    changed_either = 0
    by_position = {str(i): {'total': 0, 'regime_changed': 0, 'lock_changed': 0, 'either_changed': 0} for i in range(5)}
    by_event = {e: {'total': 0, 'regime_changed': 0, 'lock_changed': 0, 'either_changed': 0} for e in EVENTS}
    for seq in product(EVENTS, repeat=5):
        path = trace(seq)
        independently_computed = trace(seq, independent_step)
        if path != independently_computed:
            raise AssertionError(('two interpreters disagree', seq, path, independently_computed))
        checked_transition_steps += 5
        finish = path[-1]
        if finish[3] and not finish[0]:
            raise AssertionError('lock invariant violated')
        key = f'{finish[0]}{finish[3]}'
        terminal_histogram[key] += 1
        st = ','.join(map(str, finish))
        final_full_state_counts[st] = final_full_state_counts.get(st, 0) + 1
        total_profiles += 1
        for i, event in enumerate(seq):
            alt = terminal(seq[:i] + ('W',) + seq[i+1:])
            regime_diff = alt[0] != finish[0]
            lock_diff = alt[3] != finish[3]
            either = regime_diff or lock_diff
            pairs += 1
            changed_regime += int(regime_diff)
            changed_lock += int(lock_diff)
            changed_either += int(either)
            for stats in (by_position[str(i)], by_event[event]):
                stats['total'] += 1
                stats['regime_changed'] += int(regime_diff)
                stats['lock_changed'] += int(lock_diff)
                stats['either_changed'] += int(either)
    sequences = {}
    for seq in permutations('OMAEB'):
        word = ''.join(seq)
        traj = trace(seq)
        sequences[word] = {'terminal': list(traj[-1]), 'trajectory': [list(x) for x in traj]}
    distinct_hist_states = sorted(set(tuple(x['terminal']) for x in sequences.values()))
    ordered_outcomes = {'0': 0, '1': 0}
    for x in sequences.values():
        ordered_outcomes[str(x['terminal'][0])] += 1
    witness_forward = trace(tuple('OMAEB'))
    witness_reverse = trace(tuple('BEAMO'))
    unfortified = trace(tuple('OMAWW'))
    fortified = trace(tuple('OMAEW'))
    return {
        'scope': 'E1 entirely constructed finite deterministic automaton, no original-author numerical simulation or historical identification',
        'events': list(EVENTS), 'initial_state': list(INIT), 'length': 5,
        'total_sequences': total_profiles, 'total_validated_state_transitions_per_interpreter': checked_transition_steps,
        'exact_full_terminal_state_histogram': dict(sorted(final_full_state_counts.items())),
        'regime_entrenchment_histogram': terminal_histogram,
        'total_paired_do_wait_comparisons': pairs,
        'paired_counterfactual_regime_changed': changed_regime,
        'paired_counterfactual_lock_changed': changed_lock,
        'paired_counterfactual_either_changed': changed_either,
        'paired_counterfactuals_by_position': by_position,
        'paired_counterfactuals_by_factual_event': by_event,
        'distinct_event_permutations_count': len(sequences),
        'all_five_distinct_event_orderings': sequences,
        'number_distinct_five_event_final_full_states': len(distinct_hist_states),
        'number_distinct_five_event_final_regime_types': len(set(x[0] for x in distinct_hist_states)),
        'five_distinct_orderings_regime_histogram': ordered_outcomes,
        'all_five_distinct_orderings_same_count_signature': len({count_signature(seq) for seq in permutations('OMAEB')}) == 1,
        'forward_witness_OMAEB': [list(x) for x in witness_forward],
        'reverse_witness_BEAMO': [list(x) for x in witness_reverse],
        'same_final_regime_unfortified_OMAWW': [list(x) for x in unfortified],
        'same_final_regime_fortified_OMAEW': [list(x) for x in fortified],
        'backlash_after_unfortified': list(step(unfortified[-1], 'B')),
        'backlash_after_fortified': list(step(fortified[-1], 'B')),
        'two_independent_transition_implementations_exact_agreement': True,
        'source_author_numerical_model_rerun': False, 'external_historical_counterfactual_identified': False,
        'new_real_person_E2': 0, 'new_historical_event_E3': 0,
    }


def render_results():
    return json.dumps(full_study(), indent=2, ensure_ascii=False, sort_keys=True) + '\n'


if __name__ == '__main__':
    sys.stdout.write(render_results())
