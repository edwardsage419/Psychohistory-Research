"""R144 source- and assumption-bounded regression tests. Synthetic only."""
import itertools
import json
import unittest

import r144_historical_institutionalism_exact as r


class R144CoreTests(unittest.TestCase):
    def test_event_vocab(self): self.assertEqual(r.EVENTS, ('O', 'M', 'A', 'E', 'B', 'W'))
    def test_init(self): self.assertEqual(r.INIT, (0, 0, 0, 0))
    def test_open_window(self): self.assertEqual(r.step(r.INIT, 'O'), (0, 0, 2, 0))
    def test_mobilize_closed_noop(self): self.assertEqual(r.step(r.INIT, 'M'), r.INIT)
    def test_mobilize_open(self): self.assertEqual(r.trace(('O','M'))[-1], (0, 1, 1, 0))
    def test_adopt_requires_coalition(self): self.assertEqual(r.trace(('O','A'))[-1][0], 0)
    def test_adopt_requires_window(self): self.assertEqual(r.trace(('O','M','W','A'))[-1][0], 0)
    def test_adopt_success(self): self.assertEqual(r.trace(('O','M','A'))[-1], (1,1,0,0))
    def test_entrench_after_reform(self): self.assertEqual(r.trace(('O','M','A','E'))[-1], (1,1,0,1))
    def test_entrench_without_reform(self): self.assertEqual(r.trace(('E',))[-1], r.INIT)
    def test_backlash_unprotected(self): self.assertEqual(r.trace(('O','M','A','B'))[-1], (0,0,0,0))
    def test_backlash_protected(self): self.assertEqual(r.trace(('O','M','A','E','B'))[-1], (1,1,0,1))
    def test_open_after_entrench_no_reopening(self): self.assertEqual(r.trace(('O','M','A','E','O'))[-1], (1,1,0,1))
    def test_wait_window_decay(self): self.assertEqual(r.trace(('O','W','W'))[-1], r.INIT)
    def test_open_refresh(self): self.assertEqual(r.trace(('O','W','O'))[-1][2], 2)
    def test_forward_order(self): self.assertEqual(r.terminal(tuple('OMAEB'))[0:4:3], (1,1))
    def test_reverse_order(self): self.assertEqual(r.terminal(tuple('BEAMO'))[0], 0)
    def test_same_events_different_order(self): self.assertEqual(r.count_signature(tuple('OMAEB')), r.count_signature(tuple('BEAMO')))
    def test_same_visible_regime(self): self.assertEqual(r.terminal(tuple('OMAWW'))[0], r.terminal(tuple('OMAEW'))[0])
    def test_different_hidden_entrenchment(self): self.assertNotEqual(r.terminal(tuple('OMAWW'))[3], r.terminal(tuple('OMAEW'))[3])
    def test_identical_future_backlash(self): self.assertNotEqual(r.terminal(tuple('OMAWWB'))[0], r.terminal(tuple('OMAEWB'))[0])
    def test_event_input_float(self):
        with self.assertRaises(ValueError): r.step(r.INIT, 1.0)
    def test_event_input_bool(self):
        with self.assertRaises(ValueError): r.step(r.INIT, True)
    def test_event_input_other(self):
        with self.assertRaises(ValueError): r.step(r.INIT, 'R')
    def test_state_float(self):
        with self.assertRaises(ValueError): r.step((1., 0, 0, 0), 'W')
    def test_state_bool(self):
        with self.assertRaises(ValueError): r.step((True, 0, 0, 0), 'W')
    def test_state_negative(self):
        with self.assertRaises(ValueError): r.step((0, 0, -1, 0), 'W')
    def test_state_inconsistent_lock(self):
        with self.assertRaises(ValueError): r.step((0, 0, 0, 1), 'W')
    def test_state_non_tuple(self):
        with self.assertRaises(ValueError): r.step([0, 0, 0, 0], 'W')
    def test_bad_sequence_scalar(self):
        with self.assertRaises(ValueError): r.trace('OMA')
    def test_bad_sequence_item(self):
        with self.assertRaises(ValueError): r.trace(('O', None))
    def test_bad_index_float(self):
        with self.assertRaises(ValueError): r.paired_do(('O',), 0.0)
    def test_bad_index_bool(self):
        with self.assertRaises(ValueError): r.paired_do(('O',), False)
    def test_bad_index_overflow(self):
        with self.assertRaises(ValueError): r.paired_do(('O',), 1)
    def test_bad_replacement(self):
        with self.assertRaises(ValueError): r.paired_do(('O',), 0, 'X')
    def test_counterfactual_not_interfere_original(self):
        p=('O','M','A','E','B')
        x=r.paired_do(p,0)
        self.assertEqual(p, ('O','M','A','E','B'))
        self.assertEqual(x['alternative_sequence'], ('W','M','A','E','B'))
    def test_main_full_histogram(self):
        a=r.full_study()['regime_entrenchment_histogram']
        self.assertEqual(a, {'00':7663,'01':0,'10':96,'11':17})
    def test_main_sample_count(self): self.assertEqual(r.full_study()['total_sequences'], 7776)
    def test_counterfactual_full_count(self): self.assertEqual(r.full_study()['total_paired_do_wait_comparisons'], 38880)
    def test_main_counterfactual_effect_regime(self): self.assertEqual(r.full_study()['paired_counterfactual_regime_changed'],373)
    def test_main_counterfactual_effect_lock(self): self.assertEqual(r.full_study()['paired_counterfactual_lock_changed'],69)
    def test_main_counterfactual_effect_either(self): self.assertEqual(r.full_study()['paired_counterfactual_either_changed'],388)
    def test_five_event_multiset_permutations(self): self.assertEqual(r.full_study()['distinct_event_permutations_count'],120)
    def test_five_event_results(self): self.assertEqual(r.full_study()['five_distinct_orderings_regime_histogram'],{'0':116,'1':4})
    def test_five_event_distinct_full_states(self): self.assertEqual(r.full_study()['number_distinct_five_event_final_full_states'],7)
    def test_negative_control_signature(self): self.assertTrue(r.full_study()['all_five_distinct_orderings_same_count_signature'])
    def test_two_interpreter_complete_agreement_flag(self): self.assertTrue(r.full_study()['two_independent_transition_implementations_exact_agreement'])
    def test_scope_no_E2_E3(self):
        v=r.full_study()
        self.assertFalse(v['source_author_numerical_model_rerun'])
        self.assertFalse(v['external_historical_counterfactual_identified'])
        self.assertEqual((v['new_real_person_E2'],v['new_historical_event_E3']),(0,0))
    def test_counterfactual_grouping_totals(self):
        v=r.full_study()
        self.assertEqual(sum(x['total'] for x in v['paired_counterfactuals_by_position'].values()), 38880)
        self.assertEqual(sum(x['total'] for x in v['paired_counterfactuals_by_factual_event'].values()), 38880)
    def test_counterfactual_wait_is_negative_control(self):
        self.assertEqual(r.full_study()['paired_counterfactuals_by_factual_event']['W']['either_changed'],0)
    def test_both_interpreters_all_sequences_upto_four(self):
        for t in range(5):
            for seq in itertools.product(r.EVENTS, repeat=t):
                self.assertEqual(r.trace(seq), r.trace(seq,r.independent_step),seq)


def _add_permutation_test(seq):
    name='test_unique_order_'+''.join(seq)
    def test(self):
        a=r.trace(seq)
        b=r.trace(seq, r.independent_step)
        self.assertEqual(a,b)
        self.assertEqual(len(a),6)
        self.assertTrue(all(0 <= x[2] <= 2 and (not x[3] or x[0]) for x in a))
        self.assertEqual(r.count_signature(seq),(1,1,1,1,1,0))
    setattr(R144CoreTests,name,test)

for seq in itertools.permutations('OMAEB'):
    _add_permutation_test(seq)

if __name__=='__main__':
    unittest.main()
