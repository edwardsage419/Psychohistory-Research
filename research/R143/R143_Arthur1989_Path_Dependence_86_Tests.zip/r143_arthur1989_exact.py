"""R143: exact, bounded audit of Arthur (1989) Table 1 and equations (1)-(3).

This is ORIGINAL STUDY software. Its main model follows a specified discrete
special case of the author's adoption model, NOT the author's executable code.
All counts refer to artificial arrivals; no empirical human or historical data.
"""
from __future__ import annotations

from collections import defaultdict
from fractions import Fraction as F
from itertools import combinations
from math import comb
import json


def _fraction(v):
    if isinstance(v, bool) or not isinstance(v, (int, F)):
        raise TypeError('only exact int/Fraction values permitted')
    return F(v)


def _count(v):
    if type(v) is not int or v < 0:
        raise ValueError('adoption count must be a nonnegative int')
    return v


def original_choose_A(n_a, n_b, kind, r=1, s=1):
    """Probability of A, using Arthur (1989) Table I, constructed intercepts.

    Intercepts R: A=2 B=0; S: A=0 B=2. A tie is 1/2.
    'r' and 's' index agent-type returns, shared across technologies.
    """
    n_a, n_b = _count(n_a), _count(n_b)
    if kind not in ('R','S') or type(kind) is not str:
        raise ValueError('kind must be R or S')
    r, s = _fraction(r), _fraction(s)
    slope = r if kind == 'R' else s
    a, b = (F(2), F(0)) if kind == 'R' else (F(0), F(2))
    difference = (a + slope*n_a) - (b + slope*n_b)
    return F(1) if difference > 0 else (F(0) if difference < 0 else F(1,2))


def iid_choose_A(n_a, n_b, r=1, s=1):
    return (original_choose_A(n_a,n_b,'R',r,s) + original_choose_A(n_a,n_b,'S',r,s))/2


def _transient_up(d):
    if type(d) is not int or d not in (-2,-1,0,1,2):
        raise ValueError('transient adoption difference must lie [-2,2]')
    return iid_choose_A(max(d,0), max(-d,0))


def solve_linear_exact(matrix, rhs):
    """Independent exact Gauss-Jordan linear system; reject singular systems."""
    n=len(rhs)
    if len(matrix)!=n or any(len(row)!=n for row in matrix):
        raise ValueError('matrix dimensions mismatch')
    a=[[F(x) for x in row]+[F(rhs[i])] for i,row in enumerate(matrix)]
    for j in range(n):
        pivot=next((i for i in range(j,n) if a[i][j]!=0),None)
        if pivot is None:
            raise ArithmeticError('singular coefficient matrix')
        a[j],a[pivot]=a[pivot],a[j]
        factor=a[j][j]
        a[j]=[x/factor for x in a[j]]
        for i in range(n):
            if i!=j:
                factor=a[i][j]
                if factor:
                    a[i]=[u-factor*v for u,v in zip(a[i],a[j])]
    return tuple(row[-1] for row in a)


def absorbing_exact():
    """Prob eventual A lock and expected time to FIRST lock from d=-2..2."""
    states=list(range(-2,3))
    matrix=[]
    to_a=[]
    steps=[]
    for d in states:
        p=_transient_up(d)
        row=[F(int(d==j)) for j in states]
        if d+1 in states: row[d+1+2]-=p
        if d-1 in states: row[d-1+2]-=(1-p)
        matrix.append(row)
        to_a.append(p if d==2 else F(0))
        steps.append(F(1))
    hitting=solve_linear_exact(matrix,to_a)
    time=solve_linear_exact(matrix,steps)
    return {d:{'probability_A':hitting[i], 'mean_time_to_first_lock':time[i]} for i,d in enumerate(states)}


def absorbing_independent_gambler():
    """Nonmatrix product-of-odds formula, one-step ratios on six edges."""
    increments=[F(1)]
    for d in range(-2,3):
        p=_transient_up(d)
        assert 0<p<1
        increments.append(increments[-1]*(1-p)/p)
    total=sum(increments)
    return {d:sum(increments[:d+3])/total for d in range(-2,3)}


def distribution_after_order(order, *, r=1,s=1):
    if type(order) is not str or not all(x in 'RS' for x in order):
        raise ValueError('order must only contain R and S')
    r=_fraction(r);s=_fraction(s)
    states={(0,0):F(1)}
    for kind in order:
        next_states=defaultdict(F)
        for (na,nb),w in states.items():
            p=original_choose_A(na,nb,kind,r,s)
            if p: next_states[(na+1,nb)]+=w*p
            if p<1: next_states[(na,nb+1)]+=w*(1-p)
        states=dict(next_states)
    assert sum(states.values())==1
    return states


def brute_order_tie_paths(order, *, r=1,s=1):
    """Independent explicit path-tree recursion: no merging at intermediate times."""
    if type(order) is not str or not all(x in 'RS' for x in order):
        raise ValueError('invalid order')
    r=_fraction(r); s=_fraction(s)
    leaves=defaultdict(F)
    def visit(i,na,nb,w):
        if i==len(order):
            leaves[(na,nb)]+=w
            return
        p=original_choose_A(na,nb,order[i],r,s)
        if p: visit(i+1,na+1,nb,w*p)
        if p<1: visit(i+1,na,nb+1,w*(1-p))
    visit(0,0,0,F(1))
    return dict(leaves)


def six_type_orders():
    seq=[]
    for indices in combinations(range(6),3):
        s=['S']*6
        for j in indices:s[j]='R'
        seq.append(''.join(s))
    assert len(seq)==20
    return seq


def horizon_counts(t, r=1, s=1):
    if type(t) is not int or t<0:
        raise ValueError('horizon must be nonnegative int')
    if t>40:
        raise ValueError('horizon capped for verified exact enumeration')
    r=_fraction(r);s=_fraction(s)
    states={(0,0):F(1)}
    for _ in range(t):
        next_states=defaultdict(F)
        for (na,nb),w in states.items():
            p=iid_choose_A(na,nb,r,s)
            if p: next_states[(na+1,nb)]+=w*p
            if p<1: next_states[(na,nb+1)]+=w*(1-p)
        states=dict(next_states)
    assert sum(states.values())==1
    return states


def horizon_d_independent(t):
    """Ind. d-only DP, with persistent absorbing orientation beyond boundaries."""
    if type(t) is not int or t<0 or t>40:
        raise ValueError('invalid horizon')
    states={0:F(1)}
    for _ in range(t):
        nxt=defaultdict(F)
        for d,w in states.items():
            p=F(1) if d>=3 else (F(0) if d<=-3 else _transient_up(d))
            if p: nxt[d+1]+=w*p
            if p<1: nxt[d-1]+=w*(1-p)
        states=dict(nxt)
    return states


def classify_locks(states):
    pa=sum(w for (na,nb),w in states.items() if na-nb>=3)
    pb=sum(w for (na,nb),w in states.items() if nb-na>=3)
    return (pa,pb,1-pa-pb)


def closed_form_unlocked_at(t):
    """Independent symmetry/renewal formula for the SPECIFIED r=s=1 baseline.

    First lock must happen at odd time 3+2j; each two-step block survives
    with probability 5/8 after initial two periods (both parities share mass).
    """
    if type(t) is not int or t<0:
        raise ValueError('nonnegative integer time required')
    if t<3:
        return F(1)
    return F(5,8)**(1+(t-3)//2)


def closed_form_first_lock_at(t):
    """Distribution P(tau=3+2j) = (3/8)(5/8)^j."""
    if type(t) is not int or t<0:
        raise ValueError('nonnegative integer time required')
    if t<3 or (t-3)%2:
        return F(0)
    return F(3,8)*F(5,8)**((t-3)//2)


def constructed_tech_asym_payoffs(n_a,n_b,kind,subsidy_b=0):
    """NON-ORIGINAL extension: return slope differs by technology A:1 B:2."""
    n_a,n_b=_count(n_a),_count(n_b)
    if type(kind) is not str or kind not in ('R','S'):raise ValueError('kind R/S')
    g=_fraction(subsidy_b)
    if kind=='R':return (F(2+n_a),F(2*n_b)+g)
    return (F(n_a),F(2+2*n_b)+g)


def constructed_tech_asym_probability(n_a,n_b,kind,subsidy_b=0):
    a,b=constructed_tech_asym_payoffs(n_a,n_b,kind,subsidy_b)
    return F(1) if a>b else F(0) if a<b else F(1,2)


def ff(x):return str(x)

def packet():
    src=absorbing_exact()
    odds=absorbing_independent_gambler()
    assert all(src[d]['probability_A']==odds[d] for d in odds)
    orders={}
    for word in six_type_orders():
        dp=distribution_after_order(word)
        brute=brute_order_tie_paths(word)
        assert dp==brute
        locks=classify_locks(dp)
        orders[word]={'A_adopter_count_pmf':{str(a):ff(sum(w for (aa,_),w in dp.items() if aa==a)) for a in sorted({aa for aa,_ in dp})},'locked_A':ff(locks[0]),'locked_B':ff(locks[1]),'not_locked':ff(locks[2])}
    horizon=[]
    for t in [1,2,3,4,5,6,8,10,12]:
        states=horizon_counts(t)
        ds=horizon_d_independent(t)
        assert {d:sum(w for (a,b),w in states.items() if a-b==d) for d in sorted(set(a-b for a,b in states))}==ds
        pa,pb,pending=classify_locks(states)
        assert pending==closed_form_unlocked_at(t)
        const=horizon_counts(t,0,0)
        assert all(const.get((k,t-k),0)==F(comb(t,k),2**t) for k in range(t+1))
        diminish=horizon_counts(t,-1,-1)
        horizon.append({'t':t,'positive_feedback_lock_A':ff(pa),'positive_feedback_lock_B':ff(pb),'unlocked':ff(pending),'constant_returns_binomial_all_A':ff(const.get((t,0),0)),'diminishing_returns_max_abs_difference':max(abs(a-b) for a,b in diminish),'zero_feedback_expected_A':ff(sum(F(a)*v for (a,b),v in const.items()))})
    assert distribution_after_order('RRRSSS')=={(6,0):F(1)}
    assert distribution_after_order('SSSRRR')=={(0,6):F(1)}
    assert distribution_after_order('RRRSSS',r=0,s=0)=={(3,3):F(1)}
    assert distribution_after_order('SSSRRR',r=0,s=0)=={(3,3):F(1)}
    return {
      'R143':'Arthur 1989 direct Table 1, equation 1-3 and project separate asymmetry extension',
      'evidence_boundary':'E1 exact theoretical synthetic, no humans, no external historical forecast',
      'original_main_payoffs':{'R_A':'2 + r*nA','R_B':'r*nB','S_A':'s*nA','S_B':'2 + s*nB','main_r':'1','main_s':'1'},
      'absorbing_markov':{str(d):{'prob_A_lock':ff(src[d]['probability_A']),'expected_steps_to_first_lock':ff(src[d]['mean_time_to_first_lock']),'independent_gambler_hit_prob':ff(odds[d])} for d in sorted(src)},
      'exact_first_lock_time_closed_form':{'mass_at_odd_t_3_plus_2j':'(3/8)*(5/8)^j, j>=0','survival_mass_at_t_ge_3':'(5/8)^(1+floor((t-3)/2))','mean_time':'19/3'},
      'six_arrival_fixed_three_R_three_S_orders':orders,
      'six_arrival_order_count':len(orders),
      'iid_horizon_exact':horizon,
      'constant_return_order_independent':True,
      'constructed_separate_tech_slopes_not_arthur_table1':{
          'A_slope':'1','B_slope':'2','first_three_R_lock_A_without_subsidy':all(constructed_tech_asym_probability(3,0,k)==1 for k in ('R','S')),
          'equal_development_three_adoptions_per_tech_strictly_better_B_for_both_types':all(constructed_tech_asym_probability(3,3,k)==0 for k in ('R','S')),
          'subsidy_B_2_at_3_A_adopters_S_chooses_B':constructed_tech_asym_probability(3,0,'S',2)==0,
          'subsidy_B_2_at_6_A_adopters_both_choose_A':all(constructed_tech_asym_probability(6,0,k,2)==1 for k in ('R','S')),
          'stock3_R_equal_exposure_utility':list(map(ff,constructed_tech_asym_payoffs(3,3,'R'))),
          'stock3_S_equal_exposure_utility':list(map(ff,constructed_tech_asym_payoffs(3,3,'S'))),
      },
      'original_authors_empirical_or_simulation_code_rerun':False,
      'new_E2_person_level_scoring':0,'new_E3_historical_event_forecasts':0,'R073':'FROZEN','PESEN_v0_1':'FROZEN'
    }

if __name__=='__main__':
    print(json.dumps(packet(),indent=2,sort_keys=True,ensure_ascii=False))
