"""R143 61 independently registered unittest checks (synthetic exact mathematics)."""
import unittest
from fractions import Fraction as F
from math import comb
from itertools import combinations
import r143_arthur1989_exact as m


class TestOriginalArthurPayoff(unittest.TestCase):
    def test_original_R_preference_zero_stock(self):
        self.assertEqual(m.original_choose_A(0,0,'R'),1)
    def test_original_S_preference_zero_stock(self):
        self.assertEqual(m.original_choose_A(0,0,'S'),0)
    def test_S_tie_at_two(self):
        self.assertEqual(m.original_choose_A(2,0,'S'),F(1,2))
    def test_R_tie_at_minus_two(self):
        self.assertEqual(m.original_choose_A(0,2,'R'),F(1,2))
    def test_R_at_minus_three_switches(self):
        self.assertEqual(m.original_choose_A(0,3,'R'),0)
    def test_S_at_plus_three_switches(self):
        self.assertEqual(m.original_choose_A(3,0,'S'),1)
    def test_A_locked_once_three_ahead(self):
        for d in range(3,13):
            with self.subTest(d=d):
                self.assertEqual(m.iid_choose_A(d,0),1)
    def test_B_locked_once_three_ahead(self):
        for d in range(3,13):
            with self.subTest(d=d):
                self.assertEqual(m.iid_choose_A(0,d),0)
    def test_R_slope_not_technology_specific(self):
        self.assertEqual(m.original_choose_A(5,0,'R',r=-1,s=99),0)
    def test_S_slope_not_technology_specific(self):
        self.assertEqual(m.original_choose_A(0,5,'S',r=99,s=-1),1)
    def test_constant_returns_preferences_independent_stock(self):
        for a in range(8):
            for b in range(8):
                self.assertEqual(m.original_choose_A(a,b,'R',0,0),1)
                self.assertEqual(m.original_choose_A(a,b,'S',0,0),0)
    def test_original_adoption_share_equation_1(self):
        for a in range(1,10):
            for b in range(1,10):
                self.assertEqual(F(a,a+b),F(1,2)+F(a-b,2*(a+b)))
    def test_no_absorption_at_tie_boundaries(self):
        self.assertEqual(m._transient_up(-2),F(1,4))
        self.assertEqual(m._transient_up(2),F(3,4))
    def test_exact_5_transient_rows(self):
        self.assertEqual([m._transient_up(d) for d in range(-2,3)],
                         [F(1,4), F(1,2),F(1,2),F(1,2),F(3,4)])


class TestAbsorbingHitting(unittest.TestCase):
    def test_prob_symmetric_ex_ante(self):
        self.assertEqual(m.absorbing_exact()[0]['probability_A'],F(1,2))
    def test_first_hitting_time(self):
        self.assertEqual(m.absorbing_exact()[0]['mean_time_to_first_lock'],F(19,3))
    def test_linear_vs_gamblers_exact(self):
        a=m.absorbing_exact(); b=m.absorbing_independent_gambler()
        self.assertEqual({i:v['probability_A'] for i,v in a.items()},b)
    def test_hit_boundaries_monotone(self):
        a=m.absorbing_exact()
        self.assertEqual(sorted(a, key=lambda d:a[d]['probability_A']),list(range(-2,3)))
    def test_reflection_hitting_probability(self):
        a=m.absorbing_exact()
        for d in range(-2,3):
            self.assertEqual(a[d]['probability_A']+a[-d]['probability_A'],1)
    def test_reflection_expected_times(self):
        a=m.absorbing_exact()
        for d in range(-2,3):
            self.assertEqual(a[d]['mean_time_to_first_lock'],a[-d]['mean_time_to_first_lock'])
    def test_first_step_hitting_recurrence(self):
        a=m.absorbing_exact()
        for d in range(-2,3):
            p=m._transient_up(d)
            hi=a[d+1]['probability_A'] if d<2 else F(1)
            lo=a[d-1]['probability_A'] if d>-2 else F(0)
            self.assertEqual(a[d]['probability_A'],p*hi+(1-p)*lo)
    def test_first_step_time_recurrence(self):
        a=m.absorbing_exact()
        for d in range(-2,3):
            p=m._transient_up(d)
            hi=a[d+1]['mean_time_to_first_lock'] if d<2 else F(0)
            lo=a[d-1]['mean_time_to_first_lock'] if d>-2 else F(0)
            self.assertEqual(a[d]['mean_time_to_first_lock'],1+p*hi+(1-p)*lo)
    def test_exact_first_lock_geometric_odd_distribution(self):
        for t in range(20):
            if t<3 or t%2==0:
                self.assertEqual(m.closed_form_first_lock_at(t),0)
            else:
                self.assertEqual(m.closed_form_first_lock_at(t),
                                 m.closed_form_unlocked_at(t-1)-m.closed_form_unlocked_at(t))
    def test_closed_form_first_lock_expected_time(self):
        # Independent geometric series: 3+2*E[j], E[j]=(5/8)/(3/8)=5/3.
        self.assertEqual(F(3)+2*F(5,3),F(19,3))
        self.assertEqual(m.absorbing_exact()[0]['mean_time_to_first_lock'],F(19,3))
    def test_closed_form_finite_horizon_matches_direct(self):
        for t in range(13):
            self.assertEqual(m.closed_form_unlocked_at(t),m.classify_locks(m.horizon_counts(t))[2])

    def test_linear_solver_rejects_singular(self):
        with self.assertRaises(ArithmeticError):m.solve_linear_exact([[1,1],[2,2]],[1,2])
    def test_linear_solver_rejects_dimension(self):
        with self.assertRaises(ValueError):m.solve_linear_exact([[1,2]], [1])


class TestFiniteComparisons(unittest.TestCase):
    def test_all_twenty_balanced_orders(self):
        self.assertEqual(len(m.six_type_orders()),20)
        self.assertEqual(set(m.six_type_orders()),{
          ''.join('R' if i in inds else 'S' for i in range(6)) for inds in combinations(range(6),3)})
    def test_first_three_R_lock_A(self):
        self.assertEqual(m.distribution_after_order('RRRSSS'),{(6,0):F(1)})
    def test_first_three_S_lock_B(self):
        self.assertEqual(m.distribution_after_order('SSSRRR'),{(0,6):F(1)})
    def test_alternating_order_no_lock(self):
        self.assertEqual(m.distribution_after_order('RSRSRS'),{(3,3):F(1)})
    def test_mixed_history_has_two_possible_outcomes(self):
        self.assertEqual(m.distribution_after_order('RRSSRS'),{(6,0):F(1,2),(3,3):F(1,2)})
    def test_same_agent_counts_order_matter(self):
        self.assertNotEqual(m.distribution_after_order('RRRSSS'),m.distribution_after_order('SSSRRR'))
    def test_constant_returns_history_order_irrelevant(self):
        self.assertEqual({tuple(m.distribution_after_order(s,r=0,s=0).items())[0][0] for s in m.six_type_orders()}, {(3,3)})
    def test_fixed_order_probabilities_normalized(self):
        for s in m.six_type_orders():
            self.assertEqual(sum(m.distribution_after_order(s).values()),1)
    def test_reflection_of_fixed_orders(self):
        for s in m.six_type_orders():
            a=m.distribution_after_order(s)
            flipped=m.distribution_after_order(''.join('S' if x=='R' else 'R' for x in s))
            self.assertEqual({(b,a):p for (a,b),p in a.items()},flipped)
    def test_distribution_inputs_not_mutated(self):
        p=m.distribution_after_order('RSRSRS')
        p[(999,0)]=F(1)
        self.assertNotIn((999,0),m.distribution_after_order('RSRSRS'))
    def test_independent_tree_branches_short_example(self):
        self.assertEqual(m.brute_order_tie_paths('RRS'),m.distribution_after_order('RRS'))
    def test_constant_binomial_distributions_twelve(self):
        for t in range(13):
            a=m.horizon_counts(t,0,0)
            self.assertEqual(a,{(k,t-k):F(comb(t,k),2**t) for k in range(t+1)})
    def test_complete_horizon_dp_zero(self):
        self.assertEqual(m.horizon_counts(0),{(0,0):F(1)})
    def test_three_step_locked_mass(self):
        a,b,p=m.classify_locks(m.horizon_counts(3))
        self.assertEqual((a,b,p),(F(3,16),F(3,16),F(5,8)))
    def test_four_step_locked_mass_not_diminish(self):
        self.assertEqual(m.classify_locks(m.horizon_counts(4)),(F(3,16),F(3,16),F(5,8)))
    def test_mass_conservation_for_all_horizons(self):
        for t in range(13):self.assertEqual(sum(m.horizon_counts(t).values()),1)
    def test_diminishing_returns_d_bound(self):
        for t in range(13):
            self.assertLessEqual(max(abs(a-b) for a,b in m.horizon_counts(t,-1,-1)),3)
    def test_long_run_lock_prob_monotone_on_grid(self):
        old=F(0)
        for t in range(13):
            a,b,p=m.classify_locks(m.horizon_counts(t))
            self.assertGreaterEqual(a+b,old)
            old=a+b


class TestExplicitCrossModelBoundary(unittest.TestCase):
    def test_separate_technology_slopes_explicitly_not_original(self):
        self.assertEqual(m.constructed_tech_asym_payoffs(3,0,'R'),(5,0))
        self.assertEqual(m.constructed_tech_asym_payoffs(3,0,'S'),(3,2))
    def test_asymmetric_B_potential_superior_for_R(self):
        self.assertEqual(m.constructed_tech_asym_payoffs(3,3,'R'),(5,6))
    def test_asymmetric_B_potential_superior_for_S(self):
        self.assertEqual(m.constructed_tech_asym_payoffs(3,3,'S'),(3,8))
    def test_A_locked_after_three_R_in_extension(self):
        for kind in ('R','S'):
            self.assertEqual(m.constructed_tech_asym_probability(3,0,kind),1)
    def test_subsidy_two_breaks_initial_S_preference(self):
        self.assertEqual(m.constructed_tech_asym_probability(3,0,'S',F(2)),0)
    def test_subsidy_two_fails_after_six_A_adoptions(self):
        for kind in ('R','S'):
            self.assertEqual(m.constructed_tech_asym_probability(6,0,kind,F(2)),1)
    def test_different_feedback_slopes_not_allowed_in_original_payoff_function(self):
        self.assertNotEqual(m.constructed_tech_asym_payoffs(3,3,'R'),(5,3))
    def test_main_full_packet_stable(self):
        p=m.packet()
        self.assertEqual(p['six_arrival_order_count'],20)
        self.assertEqual(p['absorbing_markov']['0']['prob_A_lock'],'1/2')
        self.assertEqual(p['absorbing_markov']['0']['expected_steps_to_first_lock'],'19/3')
        self.assertEqual(p['new_E2_person_level_scoring'],0)
        self.assertEqual(p['new_E3_historical_event_forecasts'],0)
        self.assertFalse(p['original_authors_empirical_or_simulation_code_rerun'])


class TestInvalidInputs(unittest.TestCase):
    def test_negative_count(self):
        with self.assertRaises(ValueError):m.original_choose_A(-1,0,'R')
    def test_float_count(self):
        with self.assertRaises(ValueError):m.original_choose_A(1.0,0,'R')
    def test_boolean_count(self):
        with self.assertRaises(ValueError):m.original_choose_A(True,0,'R')
    def test_float_slope_even_unused_type(self):
        with self.assertRaises(TypeError):m.original_choose_A(0,0,'R',r=1,s=1.0)
    def test_boolean_slope(self):
        with self.assertRaises(TypeError):m.original_choose_A(0,0,'S',r=True,s=1)
    def test_bad_kind(self):
        with self.assertRaises(ValueError):m.original_choose_A(0,0,'X')
    def test_bad_order(self):
        with self.assertRaises(ValueError):m.distribution_after_order('RX')
    def test_bad_order_tree(self):
        with self.assertRaises(ValueError):m.brute_order_tie_paths('RSA')
    def test_bad_horizon_float(self):
        with self.assertRaises(ValueError):m.horizon_counts(3.0)
    def test_bad_horizon_boolean(self):
        with self.assertRaises(ValueError):m.horizon_counts(True)
    def test_bad_horizon_large(self):
        with self.assertRaises(ValueError):m.horizon_counts(41)
    def test_bad_asym_subsidy(self):
        with self.assertRaises(TypeError):m.constructed_tech_asym_payoffs(0,0,'R',1.0)
    def test_bad_asym_kind(self):
        with self.assertRaises(ValueError):m.constructed_tech_asym_payoffs(0,0,'X')


# Distinct, named case tests for each conditional R/S arrival order. No random sampling.
for _seq in m.six_type_orders():
    def _make_test(seq):
        def check(self):
            a=m.distribution_after_order(seq)
            b=m.brute_order_tie_paths(seq)
            self.assertEqual(a,b)
            self.assertEqual(sum(a.values()),F(1))
            self.assertTrue(all(i+j==6 for i,j in a))
        return check
    setattr(TestFiniteComparisons,'test_path_tree_'+_seq,_make_test(_seq))

if __name__=='__main__':
    unittest.main()
