"""45 true unit tests of published 2004 binary reputation norm model."""
import unittest
from decimal import Decimal, localcontext
from fractions import Fraction
from itertools import product
from r135_ohtsuki_iwasa_2004_exact_norms import (
    NORM_NAMES, STRATEGY_NAMES, norm_bit, action_bit, next_good,
    next_state_prob, stationary_mutant, stationary_resident, cooperation,
    candidate_margin, flip_norm, flip_strategy, mirror_orbit, ess_scan,
    structural_audit,
)


class TestSource2004(unittest.TestCase):
    def test_source_4096_full_state_space(self):
        self.assertEqual(256*16, 4096)
        self.assertEqual(structural_audit()['all_pairs'], 4096)

    def test_mirror_2080(self):
        self.assertEqual(structural_audit()['mirror_orbits'], 2080)

    def test_fixed_mirror_64(self):
        self.assertEqual(structural_audit()['mirror_fixed_points'], 64)

    def test_norm_names_from_source_table_1(self):
        self.assertEqual(NORM_NAMES,{170:'IMAGE',186:'STAND',184:'S-STAND',152:'JUDGE'})

    def test_strategy_names_from_source_table_2(self):
        self.assertEqual(STRATEGY_NAMES,{0:'AllD',15:'AllC',10:'CO',3:'SELF',2:'AND',11:'OR'})

    def test_image_scoring_ignores_recipients_and_self(self):
        for i,j in product((0,1), repeat=2):
            self.assertEqual(norm_bit(170,i,j,1),1)
            self.assertEqual(norm_bit(170,i,j,0),0)

    def test_standing_sanction_is_good_only_with_good_self(self):
        self.assertEqual(norm_bit(186,1,0,0),1)
        self.assertEqual(norm_bit(186,0,0,0),0)

    def test_256_different_eight_bit_norms(self):
        self.assertEqual(len({tuple(norm_bit(n,i,j,a) for i,j,a in product((0,1),repeat=3)) for n in range(256)}),256)

    def test_16_different_four_bit_strategies(self):
        self.assertEqual(len({tuple(action_bit(s,i,j) for i,j in product((0,1),repeat=2)) for s in range(16)}),16)

    def test_image_discriminator_action_co(self):
        for i,j in product((0,1),repeat=2):
            self.assertEqual(action_bit(10,i,j),j)

    def test_alld_never_help(self):
        for i,j in product((0,1),repeat=2):
            self.assertEqual(action_bit(0,i,j),0)

    def test_allc_always_help(self):
        for i,j in product((0,1),repeat=2):
            self.assertEqual(action_bit(15,i,j),1)

    def test_cooperation_bilinear_direct_independent(self):
        for s in (0,2,3,10,11,15):
            for a,b in product((.1,.3,.5,.9),repeat=2):
                actual=0.0
                for i,j in product((0,1),repeat=2):
                    # Independent string interpretation of bit masks.
                    rule=f'{s:04b}'[(1-i)*2+(1-j)]=='1'
                    if rule:
                        actual += (a if i else 1-a)*(b if j else 1-b)
                self.assertAlmostEqual(actual,cooperation(s,a,b),places=14)

    def test_error_zero_one_sided_only(self):
        # CO always defects against bad recipients.
        self.assertAlmostEqual(next_good(170,10,1,0,.02,.02),.02)
        self.assertAlmostEqual(next_good(170,10,1,1,.02,.02),.02+.96*.98)

    def test_exact_fraction_source_eq3_all_16_by_4_states(self):
        me=Fraction(1,50); ma=Fraction(1,50)
        for norm in (0,42,170,186,184,152,255):
            for strat in range(16):
                for i,j in product((0,1),repeat=2):
                    act=action_bit(strat,i,j)
                    d1=norm_bit(norm,i,j,act)
                    d0=norm_bit(norm,i,j,0)
                    exact=ma+(1-2*ma)*((1-me)*d1+me*d0)
                    observed=next_good(norm,strat,i,j)
                    self.assertAlmostEqual(float(exact),observed,places=13)

    def test_reject_invalid_norm(self):
        with self.assertRaises(ValueError): norm_bit(256,1,1,1)

    def test_reject_invalid_state(self):
        with self.assertRaises(ValueError): action_bit(1,0,2)

    def test_reject_invalid_error(self):
        with self.assertRaises(ValueError): next_good(170,10,1,1,0,.02)

    def test_reject_invalid_environment(self):
        with self.assertRaises(ValueError): next_state_prob(170,10,0,1.01)

    def test_reject_comparing_identical_strategies(self):
        with self.assertRaises(ValueError): candidate_margin(170,10,10)

    def test_reject_invalid_benefit(self):
        with self.assertRaises(ValueError): candidate_margin(170,10,0,b=1,c=1)

    def test_stationary_resident_fixes_source_eq4(self):
        for norm in (0,33,81,170,186,184,152,255):
            for strategy in range(16):
                x=stationary_resident(norm,strategy)
                t0=next_state_prob(norm,strategy,0,x)
                t1=next_state_prob(norm,strategy,1,x)
                self.assertLess(abs(x-(x*t1+(1-x)*t0)),1e-13)

    def test_mutant_stationary_source_eq4(self):
        for norm in (17,89,152,170,186):
            for rule in range(16):
                for h in (.2,.5,.8):
                    x=stationary_mutant(norm,rule,h)
                    self.assertAlmostEqual(x,x*next_state_prob(norm,rule,1,h)+(1-x)*next_state_prob(norm,rule,0,h),places=13)

    def test_resident_and_mutant_same_when_rules_equal(self):
        for norm in (81,170,186,255):
            for s in range(16):
                self.assertAlmostEqual(stationary_mutant(norm,s,stationary_resident(norm,s)),stationary_resident(norm,s),places=13)

    def test_all_norm_mirror_is_involution(self):
        for n in range(256): self.assertEqual(flip_norm(flip_norm(n)),n)

    def test_all_strategy_mirror_is_involution(self):
        for s in range(16): self.assertEqual(flip_strategy(flip_strategy(s)),s)

    def test_mirror_preserves_source_eq3(self):
        for n in (0,11,25,81,89,170,184,186,255):
            for s in (0,2,3,10,11,15):
                for own,other in product((0,1),repeat=2):
                    self.assertAlmostEqual(next_good(flip_norm(n),flip_strategy(s),1-own,1-other),1-next_good(n,s,own,other),places=13)

    def test_mirror_preserves_mutant_fitness_order(self):
        for n in (17,81,89,170,184,186,255):
            for p,q in ((10,0),(11,2),(15,0),(10,15)):
                self.assertAlmostEqual(candidate_margin(n,p,q),candidate_margin(flip_norm(n),flip_strategy(p),flip_strategy(q)),places=12)

    def test_mirror_orbit_two_or_one(self):
        for n in range(256):
            for s in range(16):
                orbit=mirror_orbit(n,s)
                self.assertIn(len(orbit),(1,2))
                self.assertIn((n,s),orbit)

    def test_original_2004_161_total_equivalence_ess(self):
        r=ess_scan()
        self.assertEqual(r['ess_mirror_orbits'],161)
        self.assertEqual(r['reduced_ess_repr_count'],161)

    def test_original_2004_136_allD_equivalence(self):
        self.assertEqual(ess_scan()['allD_ess_mirror_orbits'],136)

    def test_original_2004_25_nontrivial_equivalence(self):
        self.assertEqual(ess_scan()['nontrivial_ess_mirror_orbits'],25)

    def test_all_15_mutants_of_4096_checked(self):
        self.assertEqual(ess_scan()['mutant_challenges'],61440)

    def test_leading_eight_top_all_above_94_percent_actual(self):
        top=ess_scan()['top_eight']
        self.assertEqual(len(top),8)
        self.assertTrue(all(e['executed_help_relative_payoff']>.94 for e in top))

    def test_published_large_payoff_orbit_stability(self):
        self.assertGreaterEqual(ess_scan()['smallest_strict_winner_margin'],.0003999999)

    def test_no_ambiguous_whole_ESS_candidate(self):
        # Many individual mutant comparisons are nearly neutral, but a candidate
        # lacking robust strict margins was never forced through a tolerance tie.
        self.assertEqual(ess_scan()['ambiguous_near_ties'],0)

    def test_b2_intended_vs_executed_payoff(self):
        r=ess_scan()
        self.assertAlmostEqual(r['max_executed_relative_payoff'],.98*r['max_intended_relative_cooperation'])

    def test_reproduce_source_four_benefits_nontrivial_counts(self):
        expected={4:73,3:59,1.2:15,1.1:13}
        for b,count in expected.items():
            with self.subTest(benefit=b):
                self.assertEqual(ess_scan(b)['nontrivial_ess_mirror_orbits'],count)

    def test_source_complete_reputation_only_conditional(self):
        self.assertEqual(next_state_prob(170,10,1,.5),next_state_prob(170,10,0,.5))

    def test_source_2004_benefit_threshold_distinct_candidates(self):
        # Higher b opens cooperative ESS options without changing norm space.
        self.assertGreater(ess_scan(4)['nontrivial_ess_mirror_orbits'],ess_scan(1.1)['nontrivial_ess_mirror_orbits'])

    def test_exact_allD_cost_neutral_payoff(self):
        for n in (0,33,81,170,186,255):
            h=stationary_resident(n,0)
            self.assertEqual(cooperation(0,h,h),0)

    def test_stationary_resident_decimal_independent_root(self):
        with localcontext() as ctx:
            ctx.prec=45
            e=Decimal('0.02'); ma=Decimal('0.02')
            def bit_norm(n,i,j,a):
                return int(f'{n:08b}'[(1-i)*4+(1-j)*2+(1-a)])
            def bit_action(s,i,j):
                return int(f'{s:04b}'[(1-i)*2+(1-j)])
            for norm,strat in ((81,13),(17,5),(152,10),(184,10),(170,10),(186,11)):
                def source_next(own,rec):
                    action=bit_action(strat,own,rec)
                    return ma+(1-2*ma)*((1-e)*bit_norm(norm,own,rec,action)+e*bit_norm(norm,own,rec,0))
                t00,t01=source_next(0,0),source_next(0,1)
                t10,t11=source_next(1,0),source_next(1,1)
                def fn(x):
                    return x*(x*t11+(1-x)*t10)+(1-x)*(x*t01+(1-x)*t00)-x
                lo,hi=Decimal(0),Decimal(1)
                for _ in range(168):
                    m=(lo+hi)/2
                    if fn(m)>0:lo=m
                    else:hi=m
                exact=(lo+hi)/2
                self.assertLess(abs(float(exact)-stationary_resident(norm,strat)),5e-14)


# Additional independent tests of all four published named assessment rules.
for n,name in NORM_NAMES.items():
    def make_table_test(rule_name,number):
        def f(self):
            bits=''.join(str(norm_bit(number,i,j,a)) for i,j,a in
                         ((1,1,1),(1,1,0),(1,0,1),(1,0,0),
                          (0,1,1),(0,1,0),(0,0,1),(0,0,0)))
            self.assertEqual(bits,f'{number:08b}',rule_name)
        return f
    setattr(TestSource2004,f'test_original_table1_named_{name.lower().replace("-","_")}',make_table_test(name,n))

# Four separated cost-benefit scenarios each perform the full 4096-state scan.
for b,label,count in ((4,'4',73),(3,'3',59),(1.2,'1p2',15),(1.1,'1p1',13)):
    def make_b_test(benefit,expected):
        def f(self):
            r=ess_scan(benefit)
            self.assertEqual(r['pairs_checked'],4096)
            self.assertEqual(r['nontrivial_ess_mirror_orbits'],expected)
            self.assertEqual(r['allD_ess_mirror_orbits'],136)
        return f
    setattr(TestSource2004,f'test_original_fig2_b_{label}',make_b_test(b,count))

if __name__=='__main__':
    unittest.main()
