"""R135. Firsthand 2004 binary reputation normative strategy space.

Origin: Ohtsuki and Iwasa (2004), JTB 231:107-120, Eqs 2-10.
Reanalysis is of published *mathematical model*, not original author code/data.
"""
from __future__ import annotations
import json
from functools import lru_cache

ERROR_E = .02
ERROR_A = .02
STRATEGY_NAMES = {0: 'AllD', 15: 'AllC', 10: 'CO', 3: 'SELF', 2: 'AND', 11: 'OR'}
NORM_NAMES = {170: 'IMAGE', 186: 'STAND', 184: 'S-STAND', 152: 'JUDGE'}


def norm_bit(norm: int, own: int, recipient: int, action: int) -> int:
    if not (0 <= norm < 256 and own in (0, 1) and recipient in (0, 1) and action in (0, 1)):
        raise ValueError('Invalid norm/state/action')
    return (norm >> (7 - (4*(1-own) + 2*(1-recipient) + (1-action)))) & 1


def action_bit(strategy: int, own: int, recipient: int) -> int:
    if not (0 <= strategy < 16 and own in (0, 1) and recipient in (0, 1)):
        raise ValueError('Invalid strategy/state')
    return (strategy >> (3 - (2*(1-own) + (1-recipient)))) & 1


def next_good(norm: int, strategy: int, own: int, recipient: int,
              me: float = ERROR_E, ma: float = ERROR_A) -> float:
    if not (0 < me < .5 and 0 < ma < .5):
        raise ValueError('Positive execution and assignment errors <1/2 required')
    intended = action_bit(strategy, own, recipient)
    d_intend = norm_bit(norm, own, recipient, intended)
    d_defect = norm_bit(norm, own, recipient, 0)
    return ma + (1-2*ma)*((1-me)*d_intend + me*d_defect)


def next_state_prob(norm: int, strategy: int, own: int, environment_good: float,
                    me: float = ERROR_E, ma: float = ERROR_A) -> float:
    if not 0 <= environment_good <= 1:
        raise ValueError('Probability outside simplex')
    return (environment_good * next_good(norm, strategy, own, 1, me, ma) +
            (1-environment_good) * next_good(norm, strategy, own, 0, me, ma))


def stationary_mutant(norm: int, strategy: int, resident_good: float,
                      me: float = ERROR_E, ma: float = ERROR_A) -> float:
    """Explicit source Eq4 stationary two-state Markov balance."""
    lower = next_state_prob(norm, strategy, 0, resident_good, me, ma)
    upper = next_state_prob(norm, strategy, 1, resident_good, me, ma)
    out = lower / (1-upper+lower)
    assert 0 < out < 1
    return out


@lru_cache(maxsize=20000)
def stationary_resident(norm: int, strategy: int,
                        me: float = ERROR_E, ma: float = ERROR_A) -> float:
    """Independent monotone sign-bracketing fixed point for Eq4 resident."""
    lo, hi = 0.0, 1.0
    for _ in range(55):
        mid = (lo+hi)*.5
        val = stationary_mutant(norm, strategy, mid, me, ma)
        if val > mid:
            lo = mid
        else:
            hi = mid
    out = .5 * (lo+hi)
    assert abs(stationary_mutant(norm, strategy, out, me, ma)-out)<1e-13
    return out


def cooperation(strategy: int, own_good: float, other_good: float) -> float:
    """Source Eq5/6/7 intended conditional giving, prior to execution error."""
    return sum(action_bit(strategy, own, opp)*
               (own_good if own else (1-own_good))*
               (other_good if opp else (1-other_good))
               for own in (0,1) for opp in (0,1))


def candidate_margin(norm: int, resident: int, invader: int, b: float=2, c: float=1,
                     me: float=ERROR_E, ma: float=ERROR_A) -> float:
    if resident == invader:
        raise ValueError('ESS comparisons require distinct strategies')
    if b <= c or c <= 0:
        raise ValueError('Benefit must exceed positive cost')
    hr = stationary_resident(norm, resident, me, ma)
    hm = stationary_mutant(norm, invader, hr, me, ma)
    resident_pay = (b-c)*cooperation(resident,hr,hr)
    mutant_pay = b*cooperation(resident,hr,hm)-c*cooperation(invader,hm,hr)
    return resident_pay-mutant_pay


def flip_norm(norm: int) -> int:
    """Global relabel 0 <-> 1 on both reputations and on assigned label."""
    return sum((1-norm_bit(norm,1-own,1-recipient,action)) <<
               (7-(4*(1-own)+2*(1-recipient)+(1-action)))
               for own in (0,1) for recipient in (0,1) for action in (0,1))


def flip_strategy(strategy: int) -> int:
    return sum(action_bit(strategy,1-own,1-recipient) <<
               (3-(2*(1-own)+(1-recipient)))
               for own in (0,1) for recipient in (0,1))


def mirror_orbit(norm:int, strategy:int) -> tuple[tuple[int,int], ...]:
    return tuple(sorted(set(((norm,strategy),(flip_norm(norm),flip_strategy(strategy))))))


@lru_cache(maxsize=16)
def ess_scan(b: float=2, c: float=1, me: float=ERROR_E, ma: float=ERROR_A,
             tol: float=1e-12) -> dict:
    """Original 256 norms x 16 resident strategies x all 15 alternatives.

    Ignores exact possible near-tie cases inside ±tol and reports them separately.
    Distinct ESS pairs reduced by the true binary reputation mirror automorphism.
    """
    found=[]
    weak=[]
    min_abs_margin=1e6
    smallest_passing_margin=1e6
    near_equal_challenges=0
    maximal_pay=-1e6
    for norm in range(256):
        for resident in range(16):
            hr=stationary_resident(norm,resident,me,ma)
            resident_coop=cooperation(resident,hr,hr)
            pay=(b-c)*resident_coop
            margins=[]
            for mut in range(16):
                if mut==resident: continue
                hm=stationary_mutant(norm,mut,hr,me,ma)
                margin=pay-(b*cooperation(resident,hr,hm)-c*cooperation(mut,hm,hr))
                margins.append(margin)
                min_abs_margin=min(min_abs_margin,abs(margin))
                near_equal_challenges += (abs(margin)<tol)
            if min(margins)>tol:
                found.append((norm,resident,pay,min(margins)))
                maximal_pay=max(pay,maximal_pay)
                smallest_passing_margin=min(smallest_passing_margin,min(margins))
            elif min(margins)>=-tol:
                weak.append((norm,resident,min(margins)))
    mirrors={mirror_orbit(n,s) for n,s,_,_ in found}
    reduced=[p for p in found if (p[0],p[1])==mirror_orbit(p[0],p[1])[0]]
    nontrivial=[p for p in reduced if p[1]!=0]
    top=sorted(nontrivial,key=lambda x:-x[2])[:8]
    return {
        'norms':256,'strategies':16,'pairs_checked':4096,'mutant_challenges':4096*15,
        'ess_raw':len(found),'ess_mirror_orbits':len(mirrors),
        'reduced_ess_repr_count':len(reduced),
        'allD_ess_mirror_orbits':len([o for o in mirrors if o[0][1]==0]),
        'nontrivial_ess_mirror_orbits':len([o for o in mirrors if o[0][1]!=0]),
        'ambiguous_near_ties':len(weak),
        'minimum_abs_pair_margin':min_abs_margin,
        'near_equal_individual_challenges':near_equal_challenges,
        'smallest_strict_winner_margin':smallest_passing_margin,
        'top_eight':[
            {'norm':n,'rule':f'{n:08b}','behavior':f'{s:04b}','intended_relative_cooperation':round(v/(b-c),10),
             'executed_help_relative_payoff':round((1-me)*v/(b-c),10),
             'worst_margin':round(m,10)}
            for n,s,v,m in top],
        'nontrivial_mirror_orbits_unique':len({mirror_orbit(n,s) for n,s,_,_ in found if s!=0}),
        'max_intended_relative_cooperation':maximal_pay/(b-c),
        'max_executed_relative_payoff':(1-me)*maximal_pay/(b-c)
    }


def structural_audit()->dict:
    all_pairs={(n,s) for n in range(256) for s in range(16)}
    orbits={mirror_orbit(n,s) for n,s in all_pairs}
    assert all(mirror_orbit(*v[0])==v for v in orbits)
    return {'all_pairs':len(all_pairs),'mirror_orbits':len(orbits),
            'mirror_fixed_points':sum(len(o)==1 for o in orbits),
            'norm_example_bits':{name:f'{num:08b}' for num,name in NORM_NAMES.items()},
            'behavior_example_bits':{name:f'{num:04b}' for num,name in STRATEGY_NAMES.items()}}


def main()->dict:
    output={'scope':'R135 original 2004 equations numerical model reproduction',
            'source':'https://doi.org/10.1016/j.jtbi.2004.06.005',
            'parameters':{'me':.02,'ma':.02,'c':1,'b':2},
            'structure':structural_audit(),
            'b2':ess_scan(),
            'sensitivity':{str(b):ess_scan(b) for b in (4,3,1.2,1.1)},
            'human_rows':0,'external_history_E3':0}
    print(json.dumps(output,indent=2))
    return output

if __name__=='__main__':
    main()
