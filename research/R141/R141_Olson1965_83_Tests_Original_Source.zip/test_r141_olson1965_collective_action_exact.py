"""Independent properties and exhaustive domain checks for R141 synthetic models."""
import unittest
from fractions import Fraction as F
from itertools import product
from math import comb
import r141_olson1965_collective_action_exact as m

class OlsonChecks(unittest.TestCase):
    def test_original_public_good_zero_free_ride_N16(self):
        self.assertEqual(sum(m.symmetric_nash(16)), 0)
        self.assertGreater(sum(m.social_optimum(16)), 0)
    def test_social_n1_matches_private(self):
        self.assertEqual(m.social_optimum(1), m.symmetric_nash(1))
    def test_base_N3_exact(self):
        self.assertEqual(sum(m.symmetric_nash(3)), F(3))
        self.assertEqual(sum(m.social_optimum(3)), F(33,5))
    def test_n8_and_n16_exact(self):
        self.assertEqual(sum(m.symmetric_nash(8)),F(4,3))
        self.assertEqual(sum(m.symmetric_nash(16,F(1,2))),F(4,3))
    def test_continuous_half_reward_n24_boundary(self):
        self.assertEqual(sum(m.symmetric_nash(24,F(1,2))),F(0))
    def test_continuous_effort_monotonic_with_n(self):
        totals=[sum(m.symmetric_nash(n)) for n in m.GROUP_SIZES]
        self.assertEqual(totals,sorted(totals,reverse=True))
    def test_social_optimum_positively_varies_n(self):
        totals=[sum(m.social_optimum(n)) for n in m.GROUP_SIZES]
        self.assertEqual(totals,sorted(totals))
    def test_incentive_does_not_change_resource_cost_function(self):
        n=8
        x=m.symmetric_nash(n,F(1,2))
        self.assertEqual(m.social_welfare(x),m.benefit(sum(x))-sum(x)-sum(y*y for y in x))
        self.assertEqual(m.payoffs(x,[F(1,n)]*n,F(1,2)),m.payoffs(x,[F(1,n)]*n,F(0))[:0]+tuple(z+F(1,2)*y for z,y in zip(m.payoffs(x,[F(1,n)]*n),x)))
    def test_privileged_alone(self):
        shares=(F(1,2),)+(F(1,30),)*15
        x=m.heterogeneous_nash(shares)
        self.assertEqual(x,(F(2),)+(F(0),)*15)
        for i in range(16):
            self.assertEqual(x[i],m.best_response(sum(x)-x[i],shares[i]))
    def test_privileged_resource_welfare(self):
        shares=(F(1,2),)+(F(1,30),)*15
        self.assertEqual(m.social_welfare(m.heterogeneous_nash(shares)),F(16))
    def test_heterogeneous_equal_shares_agree(self):
        for n in (1,2,3,6,12,16):
            self.assertEqual(m.heterogeneous_nash([F(1,n)]*n),m.symmetric_nash(n))
    def test_zero_share_never_contributes(self):
        self.assertEqual(m.heterogeneous_nash((F(1),F(0),F(0))), (F(11,3),F(0),F(0)))
    def test_resource_welfare_not_tax_revenue(self):
        x=m.symmetric_nash(8,F(1,2))
        self.assertEqual(sum(m.payoffs(x,[F(1,8)]*8,F(1,2))) - F(1,2)*sum(x),m.social_welfare(x))
    def test_linear_br_without_continuous_grid_search(self):
        n=5; r=F(1,2); xs=m.symmetric_nash(n,r)
        for i in range(n):
            oth=sum(xs)-xs[i]
            b=m.best_response(oth,F(1,n),r)
            for z in [F(0),b/F(2),b,b+F(1,17),b+F(1)]:
                v=list(xs);v[i]=z
                self.assertLessEqual(m.payoffs(v,[F(1,n)]*n,r)[i],m.payoffs(tuple(xs),[F(1,n)]*n,r)[i])
    def test_binary_n8_no_reward_coordination(self):
        x=m.binary_scan(8)
        self.assertEqual(x['equilibria'],57)
        self.assertEqual(x['equilibrium_by_contributors'],{'0':1,'3':56})
    def test_binary_n8_bonus2_overprovide(self):
        x=m.binary_scan(8,F(2))
        self.assertEqual(x['equilibrium_by_contributors'],{'8':1})
        self.assertEqual(x['fiscal_cost_all_contribute'],'16')
    def test_binary_n16_zero_reward_only_empty(self):
        x=m.binary_scan(16)
        self.assertEqual(x['equilibrium_by_contributors'],{'0':1})
    def test_binary_n16_half_reward_complementarity(self):
        x=m.binary_scan(16,F(1,2))
        self.assertEqual(x['equilibrium_by_contributors'],{'0':1,'3':560})
    def test_nonselective_public_benefit_for_unpaid(self):
        n=8;mask=7
        self.assertEqual(m.binary_individual_payoff(mask,6,n),F(3,2))
    def test_switch_equals_direct_utility(self):
        n=6
        for r in m.THRESHOLD_REWARDS:
            for mask in range(1<<n):
                for i in range(n):
                    low=mask&~(1<<i)
                    net=m.binary_individual_payoff(low|(1<<i),i,n,r)-m.binary_individual_payoff(low,i,n,r)
                    self.assertEqual(net,m.gain_if_switch_to_contributing(n,low.bit_count(),r))
    def test_bin_reward_half_does_not_break_empty_coordination(self):
        for n in m.THRESHOLD_SIZES:
            self.assertTrue(m.is_ne_direct(0,n,F(1,2)))
    def test_bin_bonus2_strict_contributor(self):
        for n in m.THRESHOLD_SIZES:
            self.assertTrue(m.is_ne_direct((1<<n)-1,n,F(2)))
            self.assertFalse(m.is_ne_direct(0,n,F(2)))
    def test_reject_float_parameter(self):
        with self.assertRaises(TypeError):m.symmetric_nash(2,0.5)
    def test_reject_boolean_n(self):
        with self.assertRaises(TypeError):m.symmetric_nash(True)
    def test_reject_bad_share_sum(self):
        with self.assertRaises(ValueError):m.heterogeneous_nash([F(1,4),F(1,4)])
    def test_reject_negative_share(self):
        with self.assertRaises(ValueError):m.heterogeneous_nash([F(-1),F(2)])
    def test_reject_float_cache_alias_1_0(self):
        with self.assertRaises(TypeError):m.frac(1.0)
    def test_reject_negative_reward(self):
        with self.assertRaises(ValueError):m.binary_scan(5,F(-1))
    def test_reject_negative_effort(self):
        with self.assertRaises(ValueError):m.social_welfare((-1,1))
    def test_reject_impossible_threshold(self):
        with self.assertRaises(ValueError):m.binary_scan(2)
    def test_uniform_individual_payoff_at_q(self):
        self.assertEqual(m.binary_individual_payoff(7,0,8),F(1,2))
    def test_fiscal_burden_distinct_from_resource_cost(self):
        x=m.binary_scan(8,F(2))
        self.assertEqual(F(x['fiscal_cost_all_contribute']),F(16))
        self.assertEqual(x['best_possible_min_contributors'],3)
    def test_symmetric_strict_best_response_quadratic(self):
        for n in (2,5,8,16):
            xs=m.symmetric_nash(n)
            s=F(1,n)
            for i in range(n):
                oth=sum(xs)-xs[i]
                br=m.best_response(oth,s)
                self.assertEqual(br,xs[i])
                # FOC if active, boundary KKT otherwise
                deriv=s*(m.A-sum(xs))-m.C-m.D*xs[i]
                self.assertTrue(deriv==0 if xs[i]>0 else deriv<=0)
    def test_science_scope_no_real_data(self):
        o=m.report()
        self.assertTrue(o['all_payoff_functions_project_constructed'])
        self.assertEqual((o['new_E2_real_human_scores'],o['new_E3_real_historical_scores']),(0,0))
    def test_analytic_nonreward_ne_counts(self):
        for n in m.THRESHOLD_SIZES:
            obs=m.binary_scan(n)
            expected=1+(comb(n,3) if F(12,n)>=1 else 0)
            self.assertEqual(obs['equilibria'],expected)


def make_continuous_test(n,r):
    def check(self):
        xs=m.symmetric_nash(n,r)
        eq=max(F(0),(F(12)-n*(1-r))/3)
        self.assertEqual(sum(xs),eq)
        self.assertEqual(m.heterogeneous_nash([F(1,n)]*n,r),xs)
        for i in range(n):
            self.assertEqual(m.best_response(eq-xs[i],F(1,n),r),xs[i])
        self.assertGreaterEqual(m.social_welfare(m.social_optimum(n)),m.social_welfare(xs))
    return check


def make_binary_test(n,r):
    def check(self):
        result=m.binary_scan(n,r)
        self.assertEqual(result['profiles'],1<<n)
        self.assertEqual(result['possible_single_flip_comparisons'],(1<<n)*n)
        self.assertEqual(result['equilibria'],sum(result['equilibrium_by_contributors'].values()))
        expected_all_contribute = 1 if (r>1 or (n==3 and F(12,n)>=1-r)) else 0
        self.assertEqual(result['equilibrium_by_contributors'].get(str(n),0), expected_all_contribute)
        if r<1:
            self.assertTrue(result['all_zero_NE'])
    return check

for n in m.GROUP_SIZES:
    for r in m.GROUP_REWARDS:
        setattr(OlsonChecks, f'test_continuous_group_{n:02d}_reward_{str(r).replace("/","_")}',make_continuous_test(n,r))
for n in m.THRESHOLD_SIZES:
    for r in m.THRESHOLD_REWARDS:
        setattr(OlsonChecks, f'test_binary_group_{n:02d}_reward_{str(r).replace("/","_")}',make_binary_test(n,r))

if __name__=='__main__':
    unittest.main()
