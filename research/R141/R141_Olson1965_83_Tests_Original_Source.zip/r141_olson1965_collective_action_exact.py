"""R141: independently constructed finite models motivated by Olson (1965).
Original theory: group size, differential benefit shares, selective incentives;
all numerical payoffs and parameters here are NEW project assumptions, E1 only.
All expected payoff/equilibrium comparisons use Fraction, no floats.
"""
from __future__ import annotations

from fractions import Fraction as F
from itertools import product
from math import comb
import json

A = F(12)
C = F(1)
D = F(2)
V = F(12)
Q = 3
GROUP_SIZES = (1, 2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 24)
GROUP_REWARDS = (F(0), F(1, 2))
THRESHOLD_SIZES = (3, 4, 5, 6, 8, 10, 12, 16)
THRESHOLD_REWARDS = (F(0), F(1, 2), F(2))


def frac(v):
    if type(v) not in (int, F):
        raise TypeError('only exact integer/Fraction inputs')
    return F(v)


def ensure_params(a=A, c=C, d=D, r=F(0)):
    a,c,d,r=map(frac,(a,c,d,r))
    if a<=0 or c<=0 or d<=0 or r<0 or r>c:
        raise ValueError('a,c,d positive, 0<=r<=c')
    return a,c,d,r


def positive_n(n):
    if type(n) is not int:
        raise TypeError('n must be int')
    if n<1:
        raise ValueError('n must be positive')
    return n


def benefit(total, a=A):
    total,a=frac(total),frac(a)
    if total<0 or total>a:
        raise ValueError('project domain 0<=T<=a')
    return a*total-total*total/2


def symmetric_nash(n, r=F(0), a=A, c=C, d=D):
    n=positive_n(n)
    a,c,d,r=ensure_params(a,c,d,r)
    total=max(F(0),(a-n*(c-r))/(1+d))
    return tuple(total/n for _ in range(n))


def social_optimum(n, a=A, c=C, d=D):
    n=positive_n(n)
    a,c,d,_=ensure_params(a,c,d)
    total=max(F(0),(a-c)/(1+d/F(n)))
    return tuple(total/n for _ in range(n))


def heterogeneous_nash(shares, r=F(0), a=A, c=C, d=D):
    a,c,d,r=ensure_params(a,c,d,r)
    if not isinstance(shares,(list,tuple)) or not shares:
        raise ValueError('nonempty tuple/list of exact shares')
    shares=tuple(frac(s) for s in shares)
    if any(s<0 for s in shares) or sum(shares)!=1:
        raise ValueError('nonnegative shares summing to one')
    # Each possible active support size, sorted by valuation, gives ONE
    # candidate algebraic total. Admit it only if complementarity holds.
    indexes=sorted(range(len(shares)),key=lambda i:(-shares[i],i))
    for k in range(len(shares)+1):
        active=indexes[:k]
        s=sum((shares[i] for i in active),F(0))
        total=(a*s-k*(c-r))/(d+s)
        if total<0 or total>a:
            continue
        x=tuple(max(F(0),(si*(a-total)-(c-r))/d) for si in shares)
        if sum(x)==total and all((shares[i]*(a-total)-(c-r)>0)==(i in active) for i in range(len(shares))):
            return x
    raise ArithmeticError('no Nash equilibrium active set')


def best_response(others_sum, share, r=F(0), a=A, c=C, d=D):
    a,c,d,r=ensure_params(a,c,d,r)
    others_sum,share=frac(others_sum),frac(share)
    if others_sum<0 or others_sum>a or share<0 or share>1:
        raise ValueError('bad others or share')
    return max(F(0),(share*(a-others_sum)-(c-r))/(d+share))


def payoffs(xs, shares, r=F(0), a=A,c=C,d=D):
    a,c,d,r=ensure_params(a,c,d,r)
    xs=tuple(frac(x) for x in xs)
    shares=tuple(frac(s) for s in shares)
    if len(xs)!=len(shares) or not xs or any(x<0 for x in xs) or any(s<0 for s in shares) or sum(shares)!=1:
        raise ValueError('invalid efforts/shares')
    total=sum(xs)
    b=benefit(total,a)
    return tuple(shares[i]*b-c*x-d*x*x/2+r*x for i,x in enumerate(xs))


def social_welfare(xs, a=A,c=C,d=D):
    a,c,d,_=ensure_params(a,c,d)
    xs=tuple(frac(x) for x in xs)
    if any(x<0 for x in xs):
        raise ValueError('negative effort')
    return benefit(sum(xs),a)-c*sum(xs)-d*sum(x*x for x in xs)/2


def threshold_reward(reward):
    r=frac(reward)
    if r<0:
        raise ValueError('reward nonnegative')
    return r


def binary_individual_payoff(mask, i, n, reward=F(0), value=V, cost=C, threshold=Q):
    n=positive_n(n)
    if type(mask) is not int or mask<0 or mask>=(1<<n) or type(i) is not int or not 0<=i<n:
        raise ValueError('invalid mask/index')
    r=threshold_reward(reward)
    value,cost=frac(value),frac(cost)
    if value<=0 or cost<=0 or type(threshold) is not int or threshold<2 or threshold>n:
        raise ValueError('invalid threshold economics')
    b=(mask>>i)&1
    return value/F(n)*(mask.bit_count()>=threshold) -b*(cost-r)


def gain_if_switch_to_contributing(n, other_contributors, reward=F(0), value=V,cost=C,threshold=Q):
    n=positive_n(n)
    r=threshold_reward(reward)
    value,cost=frac(value),frac(cost)
    if type(other_contributors) is not int or not (0<=other_contributors<n):
        raise ValueError('invalid other contributors')
    if type(threshold) is not int or not 2<=threshold<=n or value<=0 or cost<=0:
        raise ValueError('invalid threshold')
    return value/F(n)*((other_contributors+1>=threshold)-(other_contributors>=threshold))-cost+r


def is_ne_direct(mask, n, reward=F(0), value=V, cost=C, threshold=Q):
    for i in range(n):
        before=binary_individual_payoff(mask,i,n,reward,value,cost,threshold)
        after=binary_individual_payoff(mask^(1<<i),i,n,reward,value,cost,threshold)
        if after>before:
            return False
    return True


def is_ne_independent_count(mask,n,reward=F(0),value=V,cost=C,threshold=Q):
    k=mask.bit_count()
    if k>0 and gain_if_switch_to_contributing(n,k-1,reward,value,cost,threshold)<0:
        return False
    if k<n and gain_if_switch_to_contributing(n,k,reward,value,cost,threshold)>0:
        return False
    return True


def binary_scan(n,reward=F(0),value=V,cost=C,threshold=Q):
    n=positive_n(n)
    if n>20:
        raise ValueError('limit exhaustively audited binary cases to 20')
    r=threshold_reward(reward)
    if threshold>n or threshold<2:
        raise ValueError('threshold out of range')
    eq=[]; by_k={}; checks=0
    for mask in range(1<<n):
        direct=is_ne_direct(mask,n,r,value,cost,threshold)
        analytic=is_ne_independent_count(mask,n,r,value,cost,threshold)
        if direct!=analytic:
            raise AssertionError('direct vs independent count criterion')
        checks+=n
        if direct:
            eq.append(mask)
            k=mask.bit_count()
            by_k[k]=by_k.get(k,0)+1
    for k,num in by_k.items():
        assert num==comb(n,k)
    return {'n':n,'reward':str(r),'profiles':1<<n,'possible_single_flip_comparisons':checks,
            'equilibria':len(eq),'equilibrium_by_contributors':{str(k):v for k,v in sorted(by_k.items())},
            'all_zero_NE':0 in eq,'all_contribute_NE':(1<<n)-1 in eq,
            'fiscal_cost_all_contribute':str(r*n),
            'best_possible_min_contributors':threshold}


def fmt(x):
    return str(x)


def report():
    continuous=[]
    for n in GROUP_SIZES:
        opt=social_optimum(n)
        for r in GROUP_REWARDS:
            xs=symmetric_nash(n,r)
            welfare=social_welfare(xs)
            for i in range(n):
                assert best_response(sum(xs)-xs[i],F(1,n),r)==xs[i]
            continuous.append({'n':n,'reward':str(r),'individual_effort':str(xs[0]),
              'total_effort':str(sum(xs)),'resource_welfare':str(welfare),
              'external_incentive_budget':str(r*sum(xs)),
              'social_optimum_total_effort':str(sum(opt)),
              'social_optimum_welfare':str(social_welfare(opt)),
              'free_rider_loss':str(social_welfare(opt)-welfare)})
    n=16
    shares=(F(1,2),)+(F(1,30),)*15
    privileged=heterogeneous_nash(shares)
    assert privileged==(F(2),)+(F(0),)*15
    binary=[binary_scan(n,r) for n in THRESHOLD_SIZES for r in THRESHOLD_REWARDS]
    index={(v['n'],v['reward']):v for v in binary}
    assert index[8,'0']['equilibria']==57
    assert index[16,'0']['equilibria']==1
    assert index[8,'2']['equilibria']==1 and index[8,'2']['all_contribute_NE']
    return {
      'research_id':'R141','primary':'Mancur Olson 1965, original chapter pp6–52 (not author numerical simulation)',
      'all_payoff_functions_project_constructed':True,
      'continuous':continuous,'continuous_cases':len(continuous),
      'heterogeneous_16':{'shares':['1/2']+['1/30']*15,'Nash_efforts':[str(x) for x in privileged],
          'total_effort':str(sum(privileged)),'equal_shares_Nash_total':str(sum(symmetric_nash(16)))},
      'binary':binary,'binary_scenarios':len(binary),
      'binary_all_profiles':sum(x['profiles'] for x in binary),
      'binary_all_possible_single_flip_comparisons':sum(x['possible_single_flip_comparisons'] for x in binary),
      'new_E2_real_human_scores':0,'new_E3_real_historical_scores':0,
      'R073':'FROZEN','PESEN_v0_1':'FROZEN'
    }

if __name__=='__main__':
    print(json.dumps(report(),ensure_ascii=False,indent=2,sort_keys=True))
