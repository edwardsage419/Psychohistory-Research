"""R133: exact strict ESS calculations; all new examples are mathematics, not observations."""
from fractions import Fraction as F
from itertools import product

# Nature 246 (1973), page 16, Table 1: 25 rounded simulated mean payoffs.
# Ordered as Mouse, Hawk, Bully, Retaliator, Prober-Retaliator.
ORIGINAL_1973_NAMES = (
    'Mouse', 'Hawk', 'Bully', 'Retaliator', 'Prober-Retaliator'
)
ORIGINAL_1973_ROUNDED_TABLE = (
    ('29.0', '19.5', '19.5', '29.0', '17.2'),
    ('80.0', '-19.5', '74.6', '-18.1', '-18.9'),
    ('80.0', '4.9', '41.5', '11.9', '11.2'),
    ('29.0', '-22.3', '57.1', '29.0', '23.1'),
    ('56.7', '-20.1', '59.4', '26.9', '21.9'),
)
PROJECT_THREE_STRATEGY_MATRIX = (
    (-1, -3, 4),
    (-3, -1, 4),
    (4, 4, -8),
)


def _exact(value):
    """Reject floats and bools so binary approximations cannot masquerade as exact."""
    if isinstance(value, (float, bool)):
        raise TypeError('use int, Fraction, or decimal/rational text')
    if not isinstance(value, (int, F, str)):
        raise TypeError('unsupported exact numeric type')
    return F(value)


def matrix_exact(matrix):
    rows = tuple(tuple(_exact(x) for x in row) for row in matrix)
    if not rows or any(len(row) != len(rows) for row in rows):
        raise ValueError('nonempty square payoff matrix required')
    return rows


def strategy_exact(strategy, n):
    v = tuple(_exact(x) for x in strategy)
    if len(v) != n or any(x < 0 for x in v) or sum(v) != 1:
        raise ValueError('strategy must be a probability vector of correct length')
    return v


def pure(n, index):
    if n < 2 or not 0 <= index < n:
        raise ValueError('invalid pure strategy')
    return tuple(F(int(i == index)) for i in range(n))


def expected_payoff(matrix, row_strategy, column_strategy):
    a = matrix_exact(matrix)
    p = strategy_exact(row_strategy, len(a))
    q = strategy_exact(column_strategy, len(a))
    return sum((p[i] * a[i][j] * q[j] for i in range(len(a))
                for j in range(len(a))), F(0))


def invasion_coefficients(matrix, resident, mutant):
    """D(epsilon)=(p-q)^T A [(1-epsilon)p+epsilon q]."""
    a = matrix_exact(matrix)
    p = strategy_exact(resident, len(a))
    q = strategy_exact(mutant, len(a))
    if p == q:
        raise ValueError('mutant must differ from resident')
    difference = [p[i] - q[i] for i in range(len(a))]
    d0 = sum((difference[i] * a[i][j] * p[j]
              for i in range(len(a)) for j in range(len(a))), F(0))
    d1 = sum((difference[i] * a[i][j] * (q[j]-p[j])
              for i in range(len(a)) for j in range(len(a))), F(0))
    return d0, d1


def resistant_to_mutant(matrix, resident, mutant):
    """Exact necessary/sufficient ESS criterion against this specific mutant."""
    d0, d1 = invasion_coefficients(matrix, resident, mutant)
    return d0 > 0 or (d0 == 0 and d1 > 0)


def exact_2x2_ess(matrix):
    """Global strict ESS classification for every mutant mixture in a 2x2 game.

    Internal candidate records a Nash equilibrium even when it fails ESS.
    """
    a = matrix_exact(matrix)
    if len(a) != 2:
        raise ValueError('2x2 matrix required')
    x, y, z, w = a[0][0], a[0][1], a[1][0], a[1][1]
    alpha = x - y - z + w
    beta = y - w
    out = {
        'pure_A': x > z or (x == z and y > w),
        'pure_B': w > y or (w == y and z > x),
        'interior_candidate': None,
        'interior_is_ess': False,
        'alpha': alpha,
        'beta': beta,
    }
    if alpha:
        share = -beta / alpha
        if 0 < share < 1:
            out['interior_candidate'] = share
            out['interior_is_ess'] = alpha < 0
    return out


def table_pure_witnesses():
    """For each original rounded-table pure resident, find a failing pure mutant.

    These witnesses disprove strict ESS for the *rounded table*, not underlying
    stochastic contest payoffs beyond the printed 1-decimal resolution.
    """
    a = matrix_exact(ORIGINAL_1973_ROUNDED_TABLE)
    witnesses = {}
    for i, name in enumerate(ORIGINAL_1973_NAMES):
        p = pure(len(a), i)
        candidates = [(j, invasion_coefficients(a, p, pure(len(a), j)))
                      for j in range(len(a)) if j != i
                      if not resistant_to_mutant(a, p, pure(len(a), j))]
        witnesses[name] = candidates[0] if candidates else None
    return witnesses


def toy_three_strategy_witness():
    a = matrix_exact(PROJECT_THREE_STRATEGY_MATRIX)
    p = (F(1, 3), F(1, 3), F(1, 3))
    vertices = [invasion_coefficients(a, p, pure(3, i)) for i in range(3)]
    mixed_q = (F(1, 2), F(1, 6), F(1, 3))
    return vertices, invasion_coefficients(a, p, mixed_q)


def grid_2x2(low=-2, high=2):
    for data in product(range(low, high+1), repeat=4):
        yield ((data[0], data[1]), (data[2], data[3]))


def summarize_exhaustive_grid():
    summary = {'games': 0, 'pure_A_ess': 0, 'pure_B_ess': 0,
               'two_pure_ess': 0, 'interior_nash': 0,
               'interior_ess': 0, 'no_ess': 0}
    for matrix in grid_2x2():
        r = exact_2x2_ess(matrix)
        summary['games'] += 1
        summary['pure_A_ess'] += r['pure_A']
        summary['pure_B_ess'] += r['pure_B']
        summary['two_pure_ess'] += r['pure_A'] and r['pure_B']
        summary['interior_nash'] += r['interior_candidate'] is not None
        summary['interior_ess'] += r['interior_is_ess']
        summary['no_ess'] += not (r['pure_A'] or r['pure_B'] or r['interior_is_ess'])
    return summary


if __name__ == '__main__':
    print('625 exact integer games:', summarize_exhaustive_grid())
    print('1973 rounded pure-strategy counterexamples:', table_pure_witnesses())
    print('three-strategy pure vs mixed mutant:', toy_three_strategy_witness())
