"""Independent rational checks of R133 strict invasion and source Table 1."""
import sys
import unittest
from fractions import Fraction as F
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from r133_ess_1973_exact import (
    ORIGINAL_1973_NAMES, ORIGINAL_1973_ROUNDED_TABLE,
    PROJECT_THREE_STRATEGY_MATRIX, expected_payoff,
    exact_2x2_ess, grid_2x2, invasion_coefficients, matrix_exact,
    pure, resistant_to_mutant, strategy_exact, summarize_exhaustive_grid,
    table_pure_witnesses, toy_three_strategy_witness,
)


def independent_payoff(matrix, p, q):
    """Simple alternative row-by-row implementation; no production payoff call."""
    return sum((F(pi) * F(x) * F(qj) for pi, row in zip(p, matrix)
                for x, qj in zip(row, q)), F(0))


def independent_difference(matrix, p, q, eps):
    env = [(F(1)-eps)*pi + eps*qi for pi, qi in zip(p, q)]
    return independent_payoff(matrix, p, env) - independent_payoff(matrix, q, env)


class R133StrictESSTests(unittest.TestCase):
    def test_source_1973_has_five_named_strategies(self):
        self.assertEqual(len(ORIGINAL_1973_NAMES), 5)
        self.assertEqual(ORIGINAL_1973_NAMES[3], 'Retaliator')

    def test_original_1973_table_shape(self):
        a = matrix_exact(ORIGINAL_1973_ROUNDED_TABLE)
        self.assertEqual((len(a), sum(map(len, a))), (5, 25))

    def test_original_1973_table_25_published_printed_cells(self):
        expected = (
            (290, 195, 195, 290, 172),
            (800, -195, 746, -181, -189),
            (800, 49, 415, 119, 112),
            (290, -223, 571, 290, 231),
            (567, -201, 594, 269, 219),
        )
        self.assertEqual(matrix_exact(ORIGINAL_1973_ROUNDED_TABLE),
                         tuple(tuple(F(i, 10) for i in row) for row in expected))

    def test_original_retaliator_mouse_four_ties(self):
        a = matrix_exact(ORIGINAL_1973_ROUNDED_TABLE)
        for i in (0, 3):
            for j in (0, 3):
                self.assertEqual(a[i][j], 29)

    def test_rounded_table_every_pure_has_disqualifying_witness(self):
        a = matrix_exact(ORIGINAL_1973_ROUNDED_TABLE)
        for name, witness in table_pure_witnesses().items():
            self.assertIsNotNone(witness, name)
            j, (d0, d1) = witness
            i = ORIGINAL_1973_NAMES.index(name)
            self.assertNotEqual(i, j)
            self.assertEqual((d0, d1), invasion_coefficients(a, pure(5, i), pure(5, j)))
            self.assertFalse(resistant_to_mutant(a, pure(5, i), pure(5, j)))

    def test_retaliator_rounded_table_fails_strict_second_condition(self):
        self.assertEqual(table_pure_witnesses()['Retaliator'], (0, (F(0), F(0))))

    def test_strict_ess_invasion_coefficients_exact(self):
        a = ((F(5), F(2)), (F(1), F(3)))
        p, q = (F(1), F(0)), (F(1, 4), F(3, 4))
        d0, d1 = invasion_coefficients(a, p, q)
        for eps in (F(0), F(1, 99), F(1, 2), F(1)):
            self.assertEqual(d0+eps*d1, independent_difference(a, p, q, eps))

    def test_first_order_strict_suffices(self):
        self.assertTrue(resistant_to_mutant(((3, 0), (1, 2)), (1, 0), (0, 1)))

    def test_strict_second_order_in_neutral_first_order(self):
        self.assertEqual(invasion_coefficients(((0, 2), (0, 1)), (1, 0), (0, 1)), (F(0), F(1)))
        self.assertTrue(resistant_to_mutant(((0, 2), (0, 1)), (1, 0), (0, 1)))

    def test_second_order_zero_is_not_strict(self):
        self.assertEqual(invasion_coefficients(((0, 2), (0, 2)), (1, 0), (0, 1)), (F(0), F(0)))
        self.assertFalse(resistant_to_mutant(((0, 2), (0, 2)), (1, 0), (0, 1)))

    def test_negative_first_order_disqualifies(self):
        self.assertFalse(resistant_to_mutant(((0, 0), (1, 0)), (1, 0), (0, 1)))

    def test_five_hundred_twenty_five_no_grid_is_actually_625(self):
        self.assertEqual(len(list(grid_2x2())), 625)
        self.assertEqual(len(set(tuple(x for row in g for x in row) for g in grid_2x2())), 625)

    def test_all_625_boundary_classifications_against_independent_invasion(self):
        qs = [(F(i, 12), F(12-i, 12)) for i in range(13)]
        for a in grid_2x2():
            summary = exact_2x2_ess(a)
            for name, p in [('pure_A', (F(1), F(0))), ('pure_B', (F(0), F(1)))]:
                outcomes = [independent_difference(a, p, q, F(0)) for q in qs if q != p]
                # Pure resident ESS if for any other q either linear intercept
                # positive, or zero intercept and positive positive-eps slope.
                independent = True
                for q in qs:
                    if q == p:
                        continue
                    d0 = independent_difference(a, p, q, F(0))
                    d1 = independent_difference(a, p, q, F(1)) - d0
                    independent &= d0 > 0 or (d0 == 0 and d1 > 0)
                self.assertEqual(summary[name], independent, (a, name, outcomes))

    def test_all_625_interior_nash_candidates_vs_direct_payoff(self):
        for a in grid_2x2():
            r = exact_2x2_ess(a)
            p1 = r['interior_candidate']
            if p1 is None:
                continue
            p = (p1, F(1)-p1)
            self.assertEqual(independent_payoff(a, (1, 0), p),
                             independent_payoff(a, (0, 1), p))
            for i in range(13):
                q = (F(i, 12), F(12-i, 12))
                if q == p:
                    continue
                d0 = independent_difference(a, p, q, F(0))
                d1 = independent_difference(a, p, q, F(1)) - d0
                self.assertEqual(d0, 0)
                self.assertEqual(r['interior_is_ess'], d1 > 0, (a, p, q))

    def test_exhaustive_integer_summary_frozen(self):
        self.assertEqual(summarize_exhaustive_grid(), {
            'games': 625, 'pure_A_ess': 300, 'pure_B_ess': 300,
            'two_pure_ess': 100, 'interior_nash': 200,
            'interior_ess': 100, 'no_ess': 25})

    def test_matrices_with_no_ess_are_flat_fitness_games(self):
        for a in grid_2x2():
            r = exact_2x2_ess(a)
            if not (r['pure_A'] or r['pure_B'] or r['interior_is_ess']):
                self.assertEqual(a[0][0], a[1][0])
                self.assertEqual(a[0][1], a[1][1])

    def test_stag_hunt_two_pure_and_internal_non_ess(self):
        r = exact_2x2_ess(((4, 0), (3, 3)))
        self.assertEqual((r['pure_A'], r['pure_B'], r['interior_candidate'],
                          r['interior_is_ess']), (True, True, F(3, 4), False))

    def test_chicken_one_mixed_ess(self):
        r = exact_2x2_ess(((-2, 2), (0, 1)))
        self.assertEqual((r['pure_A'], r['pure_B'], r['interior_candidate'],
                          r['interior_is_ess']), (False, False, F(1, 3), True))

    def test_logistic_dominant_pure_ess(self):
        r = exact_2x2_ess(((2, 2), (1, 1)))
        self.assertTrue(r['pure_A'])
        self.assertFalse(r['pure_B'])
        self.assertIsNone(r['interior_candidate'])

    def test_neutral_game_has_no_strict_ess(self):
        r = exact_2x2_ess(((0, 0), (0, 0)))
        self.assertFalse(r['pure_A'] or r['pure_B'] or r['interior_is_ess'])

    def test_all_625_positive_scale_invariance(self):
        for a in grid_2x2():
            r = exact_2x2_ess(a)
            scaled = tuple(tuple(3*x for x in row) for row in a)
            s = exact_2x2_ess(scaled)
            for key in ('pure_A', 'pure_B', 'interior_candidate', 'interior_is_ess'):
                self.assertEqual(r[key], s[key])

    def test_all_625_global_additive_payoff_invariance(self):
        for a in grid_2x2():
            r = exact_2x2_ess(a)
            shifted = tuple(tuple(x+13 for x in row) for row in a)
            s = exact_2x2_ess(shifted)
            for key in ('pure_A', 'pure_B', 'interior_candidate', 'interior_is_ess'):
                self.assertEqual(r[key], s[key])

    def test_toy_matrix_row_sums_zero(self):
        self.assertEqual([sum(row) for row in PROJECT_THREE_STRATEGY_MATRIX], [0]*3)

    def test_toy_three_pure_mutants_all_resisted(self):
        vertices, mixed = toy_three_strategy_witness()
        self.assertEqual(vertices, [(F(0), F(1)), (F(0), F(1)), (F(0), F(8))])
        self.assertTrue(all(d0 == 0 and d1 > 0 for d0, d1 in vertices))

    def test_toy_three_mixed_mutant_can_invade(self):
        vertices, mixed = toy_three_strategy_witness()
        self.assertEqual(mixed, (F(0), F(-1, 9)))
        self.assertFalse(resistant_to_mutant(PROJECT_THREE_STRATEGY_MATRIX,
                         (F(1, 3),)*3, (F(1, 2), F(1, 6), F(1, 3))))

    def test_toy_three_verifies_direct_for_several_epsilon(self):
        a = PROJECT_THREE_STRATEGY_MATRIX
        p = (F(1, 3),)*3
        q = (F(1, 2), F(1, 6), F(1, 3))
        for eps in (F(1, 1000), F(1, 10), F(1, 2), F(1)):
            self.assertEqual(independent_difference(a, p, q, eps), -eps/F(9))

    def test_toy_3_payoff_shift_unchanged(self):
        a = PROJECT_THREE_STRATEGY_MATRIX
        b = tuple(tuple(x+9 for x in row) for row in a)
        p = (F(1, 3),)*3
        q = (F(1, 2), F(1, 6), F(1, 3))
        self.assertEqual(invasion_coefficients(a, p, q), invasion_coefficients(b, p, q))

    def test_payoff_function_against_independent_direct(self):
        a = ORIGINAL_1973_ROUNDED_TABLE
        for i in range(5):
            for j in range(5):
                p, q = pure(5, i), pure(5, j)
                self.assertEqual(expected_payoff(a, p, q), independent_payoff(a, p, q))

    def test_reject_float_payoff(self):
        with self.assertRaises(TypeError):
            matrix_exact(((1.0, 2), (3, 4)))

    def test_reject_boolean_payoff(self):
        with self.assertRaises(TypeError):
            matrix_exact(((True, 2), (3, 4)))

    def test_reject_ragged_matrix(self):
        with self.assertRaises(ValueError):
            matrix_exact(((1, 2), (3,)))

    def test_reject_strategy_outside_simplex(self):
        with self.assertRaises(ValueError):
            strategy_exact((F(5, 4), F(-1, 4)), 2)

    def test_reject_strategy_wrong_sum(self):
        with self.assertRaises(ValueError):
            strategy_exact((F(1, 3), F(1, 3)), 2)

    def test_reject_identical_mutant(self):
        with self.assertRaises(ValueError):
            invasion_coefficients(((1, 2), (3, 4)), (1, 0), (1, 0))

    def test_reject_non_2x2_classifier(self):
        with self.assertRaises(ValueError):
            exact_2x2_ess(((1,),))

    def test_reject_invalid_pure_index(self):
        with self.assertRaises(ValueError):
            pure(3, 3)


if __name__ == '__main__':
    unittest.main(verbosity=2)
