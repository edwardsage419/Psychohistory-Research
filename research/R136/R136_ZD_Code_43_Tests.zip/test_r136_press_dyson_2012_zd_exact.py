"""Unittest independent crosschecks for R136 source Fig2B and Eq8-15."""
import unittest
from fractions import Fraction as F
from itertools import product
from r136_press_dyson_2012_zd_exact import (
    R,S,T,P,SX,SY,ONE,ensure_strategy,markov_matrix,gaussian_exact,
    stationary,payoff_dot,payoff_pair_gaussian,payoff_pair_determinants,
    determinant4,paper_determinant,extortion,equalizer,equalizer_target,
    tremble,opponents_grid,feasible_extortion_grid,scan_extortion,
    scan_equalizer,scan_boundary,scan_execution_error
)

class SourceFormula(unittest.TestCase):
    def test_original_source_payoffs(self):
        self.assertEqual((T,R,P,S),(F(5),F(3),F(1),F(0)))
    def test_source_X_Y_payoff_order(self):
        self.assertEqual((SX,SY),((F(3),F(0),F(5),F(1)),(F(3),F(5),F(0),F(1))))
    def test_transition_row_sum(self):
        m=markov_matrix((F(1,4),)*4,(F(1,3),)*4)
        self.assertEqual(tuple(map(sum,m)),ONE)
    def test_source_q_CD_DC_swap(self):
        p=(F(1),)*4;q=(F(1),F(0),F(1),F(0))
        m=markov_matrix(p,q)
        self.assertEqual(m[1],(F(1),F(0),F(0),F(0)))
        self.assertEqual(m[2],(F(0),F(1),F(0),F(0)))
    def test_p_allD(self):
        m=markov_matrix((F(0),)*4,(F(1,2),)*4)
        self.assertTrue(all(row[:2]==(F(0),F(0)) for row in m))
    def test_p_allC(self):
        m=markov_matrix((F(1),)*4,(F(1,2),)*4)
        self.assertTrue(all(row[2:]==(F(0),F(0)) for row in m))
    def test_stationarity_row_independent(self):
        p=(F(1,3),F(2,3),F(1,4),F(3,4));q=(F(3,5),F(2,5),F(1,5),F(4,5))
        v=stationary(p,q);m=markov_matrix(p,q)
        for j in range(4):
            self.assertEqual(sum(v[i]*m[i][j] for i in range(4)),v[j])
    def test_independent_solver_equalizer(self):
        p=equalizer(F(9,10),F(1,20));q=(F(1,3),F(2,3),F(3,5),F(4,5))
        self.assertEqual(payoff_pair_gaussian(p,q),payoff_pair_determinants(p,q))
    def test_determinant_identity(self):
        identity=tuple(tuple(F(i==j) for j in range(4)) for i in range(4))
        self.assertEqual(determinant4(identity),1)
    def test_determinant_zero_duplicate_rows(self):
        mat=((F(1),F(2),F(3),F(4)),)*4
        self.assertEqual(determinant4(mat),0)
    def test_fig2B_determinant_all_one_f(self):
        p=(F(1,3),F(1,2),F(2,3),F(3,4));q=(F(1,4),F(3,4),F(1,2),F(1,3))
        self.assertNotEqual(paper_determinant(p,q,ONE),0)
    def test_exact_payoff_baseline_alld_randomY(self):
        p=(F(0),)*4;q=(F(1,2),)*4
        sx,sy=payoff_pair_gaussian(p,q)
        self.assertEqual((sx,sy),(F(3),F(1,2)))
    def test_independently_computed_uniform_chain(self):
        p=q=(F(1,2),)*4
        self.assertEqual(stationary(p,q),(F(1,4),)*4)
        self.assertEqual(payoff_pair_gaussian(p,q),(F(9,4),F(9,4)))
    def test_exact_permutation_sign(self):
        from r136_press_dyson_2012_zd_exact import permutation_sign
        self.assertEqual(permutation_sign((1,0,2,3)),-1)
        self.assertEqual(permutation_sign((3,2,1,0)),1)

class BoundedZD(unittest.TestCase):
    def test_grid_size(self):
        self.assertEqual(len(feasible_extortion_grid()),14)
    def test_opponent_grid_size(self):
        self.assertEqual(len(opponents_grid()),81)
    def test_p_source_Eq15(self):
        self.assertEqual(extortion(F(3),F(1,20)),(F(4,5),F(7,20),F(7,20),F(0)))
    def test_source_Eq11_vector_identity(self):
        for chi,phi,p in feasible_extortion_grid():
            pt=(p[0]-1,p[1]-1,p[2],p[3])
            target=tuple(phi*((sx-P)-chi*(sy-P)) for sx,sy in zip(SX,SY))
            self.assertEqual(pt,target)
    def test_probability_constraints(self):
        for _,_,p in feasible_extortion_grid():
            self.assertTrue(all(F(0)<=x<=F(1) for x in p))
    def test_full_1134_source_payoff_scan(self):
        self.assertEqual(scan_extortion()['ZD_payoff_pairs'],1134)
    def test_equalizer_Eq8(self):
        self.assertEqual(equalizer(F(9,10),F(1,20)),(F(9,10),F(3,4),F(1,8),F(1,20)))
    def test_equalizer_Eq9(self):
        self.assertEqual(equalizer_target(equalizer(F(9,10),F(1,20))),F(5,3))
    def test_equalizer_81_opponents(self):
        self.assertEqual(scan_equalizer()['opponents'],81)
    def test_equalizer_sameY_for_distinctq(self):
        p=equalizer(F(9,10),F(1,20))
        q1=(F(1,4),)*4;q2=(F(3,4),)*4
        self.assertEqual(payoff_pair_gaussian(p,q1)[1],payoff_pair_gaussian(p,q2)[1])
    def test_two_routes_on_selected_distincts(self):
        for chi,phi,p in feasible_extortion_grid():
            for q in ((F(1,4),)*4,(F(3,4),)*4):
                self.assertEqual(payoff_pair_gaussian(p,q),payoff_pair_determinants(p,q))
    def test_deterministic_boundaries_accounted(self):
        s=scan_boundary()
        self.assertEqual(s['unique_stationary']+s['singular_or_multi_stationary'],16)
    def test_no_invented_stationary_for_alld_pair(self):
        with self.assertRaises(ValueError):
            stationary((F(1),F(0),F(1),F(0)),(F(1),F(0),F(1),F(0)))
    def test_tremble_changes_probabilities(self):
        p=extortion(F(3),F(1,20))
        self.assertEqual(tremble(p,F(1,20))[3],F(1,20))
    def test_tremble_exact_nonzero_relation_gap(self):
        d=scan_execution_error()
        self.assertEqual(d['original_linear_residual'],'0')
        self.assertNotEqual(d['trembled_residual'],'0')
    def test_tremble_zero_exact_identity(self):
        p=extortion(F(3),F(1,20))
        self.assertEqual(tremble(p,F(0)),p)

class Validation(unittest.TestCase):
    def test_invalid_length(self):
        with self.assertRaises(ValueError): ensure_strategy((F(0),F(1)))
    def test_invalid_float(self):
        with self.assertRaises(ValueError): ensure_strategy((0.5,F(1,2),F(0),F(1)))
    def test_invalid_integer(self):
        with self.assertRaises(ValueError): ensure_strategy((0,F(1,2),F(0),F(1)))
    def test_invalid_probability(self):
        with self.assertRaises(ValueError): ensure_strategy((F(2),F(0),F(0),F(0)))
    def test_invalid_chi(self):
        with self.assertRaises(ValueError): extortion(F(1),F(1,10))
    def test_phi_zero(self):
        with self.assertRaises(ValueError): extortion(F(3),F(0))
    def test_phi_above_feasibility(self):
        with self.assertRaises(ValueError): extortion(F(3),F(1,10))
    def test_gaussian_nonunique(self):
        with self.assertRaises(ValueError): gaussian_exact([[F(0)]*4 for _ in range(4)],[F(0)]*4)
    def test_equalizer_bad_boundary(self):
        with self.assertRaises(ValueError): equalizer(F(0),F(1))
    def test_equalizer_singular(self):
        with self.assertRaises(ValueError): equalizer_target((F(1),F(1),F(0),F(0)))
    def test_tremble_bad_error(self):
        with self.assertRaises(ValueError): tremble((F(1,2),)*4,F(2))
    def test_wrong_determinant_shape(self):
        with self.assertRaises(ValueError): determinant4(((F(1),),))
    def test_wrong_determinant_f_length(self):
        with self.assertRaises(ValueError): paper_determinant((F(1,2),)*4,(F(1,2),)*4,(F(1),))

if __name__=='__main__':
    unittest.main()
