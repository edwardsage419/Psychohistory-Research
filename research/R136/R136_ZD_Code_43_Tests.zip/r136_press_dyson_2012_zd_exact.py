"""R136: exact reconstruction of Press-Dyson (2012) memory-one IPD.

Scope: stationary Markov payoffs for the canonical (T,R,P,S)=(5,3,1,0),
Eq. 3/5/6/8/9/11/15. All probabilities are exact Fraction objects.
No real people, no original author evolutionary simulation.
"""
from fractions import Fraction as F
from itertools import product, permutations
from math import prod
import json

R, S, T, P = map(F, (3, 0, 5, 1))
SX = (R, S, T, P)
SY = (R, T, S, P)
ONE = (F(1),) * 4


def ensure_strategy(seq):
    if not isinstance(seq, (tuple, list)) or len(seq) != 4:
        raise ValueError('strategy requires four probabilities')
    if any(type(x) is not F or x < 0 or x > 1 for x in seq):
        raise ValueError('strategy must use exact Fraction probabilities [0,1]')
    return tuple(seq)


def payoff_dot(v, payoff):
    return sum((x * y for x, y in zip(v, payoff)), F(0))


def markov_matrix(p, q):
    """Rows/columns indexed CC CD DC DD from the X player's perspective.

    q=(q_CC,q_CD,q_DC,q_DD) in Y's own perspective; swap q_CD,q_DC.
    """
    p, q = ensure_strategy(p), ensure_strategy(q)
    qr = (q[0], q[2], q[1], q[3])
    return tuple((a*b, a*(1-b), (1-a)*b, (1-a)*(1-b))
                 for a, b in zip(p, qr))


def gaussian_exact(a, b):
    """Independent exact Gaussian elimination for A x=b, unique solutions only."""
    n = len(b)
    m = [[F(x) for x in a[i]] + [F(b[i])] for i in range(n)]
    for col in range(n):
        pivot = next((row for row in range(col, n) if m[row][col]), None)
        if pivot is None:
            raise ValueError('stationary distribution not unique')
        m[col], m[pivot] = m[pivot], m[col]
        piv = m[col][col]
        m[col] = [x/piv for x in m[col]]
        for r in range(n):
            if r != col:
                factor = m[r][col]
                m[r] = [x-factor*y for x, y in zip(m[r],m[col])]
    return tuple(row[-1] for row in m)


def stationary(p, q):
    m=markov_matrix(p, q)
    # Three stationarity equations, then total probability equals one.
    a=tuple(tuple(m[row][col] - F(row==col) for row in range(4))
            for col in range(3)) + (ONE,)
    v=gaussian_exact(a, (F(0),F(0),F(0),F(1)))
    if any(x < 0 for x in v) or sum(v) != 1:
        raise AssertionError('invalid stationary distribution')
    if any(sum((v[i]*m[i][j] for i in range(4)), F(0)) != v[j]
           for j in range(4)):
        raise AssertionError('stationarity failed')
    return v


def permutation_sign(perm):
    return -1 if sum(perm[i]>perm[j] for i in range(len(perm)) for j in range(i+1,len(perm)))%2 else 1


def determinant4(matrix):
    """Independent Leibniz determinant, no Gaussian linear solver calls."""
    if len(matrix)!=4 or any(len(row)!=4 for row in matrix):
        raise ValueError('expected 4x4 determinant')
    return sum((permutation_sign(perm)*prod(matrix[i][perm[i]] for i in range(4))
                for perm in permutations(range(4))), F(0))


def paper_determinant(p, q, f):
    """Original Press & Dyson Fig2B determinant with q2/q3 exchanged."""
    p, q = ensure_strategy(p), ensure_strategy(q)
    if len(f)!=4:
        raise ValueError('f requires four entries')
    mat=(
       (-1+p[0]*q[0], -1+p[0], -1+q[0],f[0]),
       (p[1]*q[2], -1+p[1],q[2],f[1]),
       (p[2]*q[1],p[2],-1+q[1],f[2]),
       (p[3]*q[3],p[3],q[3],f[3])
    )
    return determinant4(mat)


def payoff_pair_gaussian(p,q):
    v=stationary(p,q)
    return payoff_dot(v,SX),payoff_dot(v,SY)


def payoff_pair_determinants(p,q):
    d=paper_determinant(p,q,ONE)
    if d==0:
        raise ValueError('determinant undefined for non-unique stationarity')
    return paper_determinant(p,q,SX)/d, paper_determinant(p,q,SY)/d


def extortion(chi,phi):
    if type(chi) is not F or type(phi) is not F or chi <= 1 or not (0<phi<=1/(4*chi+1)):
        raise ValueError('requires chi>1 and 0<phi<=1/(4chi+1)')
    p=(1-2*phi*(chi-1),1-phi*(4*chi+1),phi*(chi+4),F(0))
    return ensure_strategy(p)


def equalizer(p1,p4):
    if type(p1) is not F or type(p4) is not F:
        raise ValueError('p1 and p4 must be Fraction')
    p2=(p1*(T-P)-(1+p4)*(T-R))/(R-P)
    p3=((1-p1)*(P-S)+p4*(R-S))/(R-P)
    return ensure_strategy((p1,p2,p3,p4))


def equalizer_target(p):
    p=ensure_strategy(p)
    den=(1-p[0])+p[3]
    if den==0:
        raise ValueError('singular equalizer')
    return ((1-p[0])*P+p[3]*R)/den


def tremble(p, error):
    if type(error) is not F or error<0 or error>1:
        raise ValueError('error must be exact probability')
    p=ensure_strategy(p)
    return tuple(error+(1-2*error)*x for x in p)


def opponents_grid():
    g=(F(1,4),F(1,2),F(3,4))
    return tuple(product(g,repeat=4))


def feasible_extortion_grid():
    chis=(F(2),F(3),F(5),F(7))
    phis=(F(1,100),F(1,50),F(1,25),F(1,20),F(1,10))
    return tuple((chi,phi,extortion(chi,phi))
                 for chi in chis for phi in phis if phi<=1/(4*chi+1))


def scan_extortion():
    count=0
    witnesses={}
    for chi,phi,p in feasible_extortion_grid():
        for q in opponents_grid():
            sx,sy=payoff_pair_gaussian(p,q)
            if (sx,sy)!=payoff_pair_determinants(p,q):
                raise AssertionError('Fig2B and independent Markov solver disagree')
            if sx-P!=chi*(sy-P):
                raise AssertionError('Press Dyson extortion identity failed')
            count+=1
        witnesses[f'{chi}:{phi}']=[str(x) for x in p]
    return {'ZD_payoff_pairs':count,'ZD_strategies':len(witnesses),'opponents_per_strategy':81,'strategies':witnesses}


def scan_equalizer():
    p=equalizer(F(9,10),F(1,20))
    target=equalizer_target(p)
    for q in opponents_grid():
        sx,sy=payoff_pair_gaussian(p,q)
        if sy!=target or (sx,sy)!=payoff_pair_determinants(p,q):
            raise AssertionError('Press Dyson score equalizer failed')
    return {'p':[str(x) for x in p], 'opponents':81,'equalized_Y_score':str(target)}


def scan_boundary():
    # Singularity is explicitly reported; no arbitrary stationary selection.
    p=extortion(F(3),F(1,20))
    valid=0
    singular=0
    for q in product((F(0),F(1)),repeat=4):
        try:
            sx,sy=payoff_pair_gaussian(p,q)
        except ValueError:
            singular+=1
            continue
        if (sx,sy)!=payoff_pair_determinants(p,q) or sx-P!=3*(sy-P):
            raise AssertionError('boundary ZD failure for unique stationary chain')
        valid+=1
    return {'deterministic_opponents':16,'unique_stationary':valid,'singular_or_multi_stationary':singular}


def scan_execution_error():
    chi=F(3);phi=F(1,20)
    p=extortion(chi,phi)
    q=(F(1,2),)*4
    sx,sy=payoff_pair_gaussian(p,q)
    px=tremble(p,F(1,20))
    sx1,sy1=payoff_pair_gaussian(px,q)
    return {'chi':str(chi),'phi':str(phi),'tremble':str(F(1,20)),
            'original_payoffs':[str(sx),str(sy)],
            'original_linear_residual':str(sx-P-chi*(sy-P)),
            'actual_action_probabilities':[str(v) for v in px],
            'trembled_payoffs':[str(sx1),str(sy1)],
            'trembled_residual':str(sx1-P-chi*(sy1-P))}


def full_report():
    return {'R136': 'Press Dyson 2012 exact bounded zero determinant stationary math',
            'payoffs_X':list(map(str,SX)),'payoffs_Y':list(map(str,SY)),
            'extortion':scan_extortion(),'equalizer':scan_equalizer(),
            'deterministic_boundary':scan_boundary(),
            'execution_error':scan_execution_error(),
            'real_human_E2':0,'external_historical_E3':0}


if __name__=='__main__':
    print(json.dumps(full_report(),sort_keys=True,ensure_ascii=False,indent=2))
