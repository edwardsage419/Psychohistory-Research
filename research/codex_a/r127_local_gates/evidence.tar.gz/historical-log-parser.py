import pathlib,re
log=pathlib.Path('/tmp/r127_real_unittests.log').read_text()
assert re.findall(r'Ran (\d+) tests? in',log)==['60'],('R127_REQUIRE_ALL_60_TRUE_TESTS',log[-2400:])
assert re.search(r'\nOK\s*$',log),'R127_TRUE_TESTS_NOT_ALL_PASS'
print('R127_60_REAL_TESTS_SUCCESS')