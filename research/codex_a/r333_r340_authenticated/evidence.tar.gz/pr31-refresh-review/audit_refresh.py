import hashlib,json,subprocess
from pathlib import Path
repo='/workspace/Psychohistory-Research';old='03cf49d8970f273bb58ef0bfd125252166482dce';new='b928dc8d97202005560e2e73129c13adfd374097';a30='8005fcb75e9e20545adb245edd45d72dbc374632'
prefix='research/codex_b/2026-11-11-r077-scientific-readiness/'
adapter='research/codex_a/r077_integration/preflight.py'
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
def raw(path,ref=new):return git('show',ref+':'+path)
def sha(b):return hashlib.sha256(b).hexdigest()
def identity(b):return {'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'bytes':len(b),'sha256':sha(b)}
files=git('ls-tree','-r','--name-only',old,prefix).decode().splitlines()
changed=[p for p in files if raw(p,old)!=raw(p)]
assert changed==[prefix+'pins.json'] and len(files)==34
before=json.loads(raw(prefix+'pins.json',old));after=json.loads(raw(prefix+'pins.json'))
assert [p for p in before if before[p]!=after[p]]==[adapter]
assert before[adapter]==identity(raw(adapter,'d4740c2cd999b8da06a25b0ef407aeaf8a56ab6c'))
assert after[adapter]==identity(raw(adapter,a30))
assert raw(prefix+'evidence/pin-refresh-20261112/pins-before.json')==raw(prefix+'pins.json',old)
patch=raw(prefix+'evidence/pin-refresh-20261112/approved-A35.patch')
assert patch==raw('research/codex_a/r127_acceptance_20261112/pr31-pr30-pin-refresh.patch','9ae4eb923b7d1cbc78fdc0c81cddee591efc68ef')
counts={}
old_sources=json.loads(raw(prefix+'evidence/normal/summary.json',old))['sources']
for run in ['run','run-final']:
    location=prefix+'evidence/pin-refresh-20261112/'+run+'/'
    commands=json.loads(raw(location+'commands.json'));assert len(commands)==9
    n=0
    for c in commands:
        assert c['exit_code']==c['expected_exit']
        for pin in c['streams'].values():
            b=raw(location+pin['file']) if pin['file'] else b''
            assert len(b)==pin['bytes'] and sha(b)==pin['sha256'];n+=1
        if c['tag'].startswith('new-pins-green'):
            captured=json.loads(raw(location+c['streams']['stdout']['file']));assert len(captured)==22
            assert {p for p in captured if captured[p]!=old_sources[p]}=={adapter,prefix+'pins.json'}
            for p,pin in captured.items():
                b=raw(p,a30) if p==adapter else raw(p)
                got=identity(b)
                assert all(got[k]==v for k,v in pin.items())
        if c['tag'].startswith('retained-validator'):
            result=json.loads(raw(location+c['streams']['stdout']['file']))
            assert result=={'production_ready':False,'original_failures_retained':11,'retained_corrected_cases':35,'corrupt_retained_shadow_rejected':True,'mathematical_programs_rerun':False}
    counts[run]={'commands':len(commands),'stream_hashes':n}
result=json.loads(raw(prefix+'evidence/pin-refresh-20261112/run-final/result.json'))
assert result['helper_sha256']==sha(raw(prefix+'maintenance/verify_pin_refresh.py'))
fresh=json.loads(Path(__file__).with_name('fresh-helper').joinpath('result.json').read_text());assert fresh==result
report={'verdict':'APPROVE_CANDIDATE','runtime_dependency':'REQUIRES_PR30','head':new,'previous_head':old,'unchanged_original_files':33,'only_modified_existing_file':prefix+'pins.json','changed_pin_entries':1,'changed_pin_values':3,'saved_runs':counts,'fresh_helper_exit':0,'new_adapter':after[adapter],'new_manifest':identity(raw(prefix+'pins.json')),'approved_patch_sha256':sha(patch),'helper_sha256':result['helper_sha256'],'math_campaigns_rerun':False,'actionable_issues':[]}
Path(__file__).with_name('audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
