import subprocess,sys,types,unittest
repo='/workspace/Psychohistory-Research'
head='211f90b2509a9e958b560780bc30d7a488a518b9'
prefix='research/codex_b/2026-11-12-r077-qualification-r273-native/'
def read(name):return subprocess.check_output(['git','show',head+':'+prefix+name],cwd=repo)
source=types.ModuleType('source_join');source.__file__=repo+'/'+prefix+'source_join.py'
exec(compile(read('source_join.py'),source.__file__,'exec'),source.__dict__);sys.modules['source_join']=source
tests=types.ModuleType('saved_pr36_tests');tests.__file__=repo+'/'+prefix+'test_source_join.py'
exec(compile(read('test_source_join.py'),tests.__file__,'exec'),tests.__dict__)
result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(tests))
sys.exit(0 if result.wasSuccessful() and result.testsRun==5 else 1)
