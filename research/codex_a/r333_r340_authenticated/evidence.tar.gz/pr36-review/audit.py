import hashlib,json,subprocess,types,sys
from pathlib import Path
repo='/workspace/Psychohistory-Research'
head='211f90b2509a9e958b560780bc30d7a488a518b9'
base='d4740c2cd999b8da06a25b0ef407aeaf8a56ab6c'
prefix='research/codex_b/2026-11-12-r077-qualification-r273-native/'
def git(*args): return subprocess.check_output(['git',*args],cwd=repo)
def raw(path,ref=head): return git('show',ref+':'+path)
def doc(path): return json.loads(raw(prefix+path))
def sha(data): return hashlib.sha256(data).hexdigest()
def identity(data,pin):
    assert len(data)==pin['bytes'] and sha(data)==pin['sha256']
    if 'git_blob' in pin: assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==pin['git_blob']
pins=doc('pins.json')
for path,pin in pins.items():
    identity(raw(path),pin)
    assert raw(path)==raw(path,base)
streams=0
for mode in ['normal','optimized']:
    summary=doc('evidence/'+mode+'/summary.json')
    for path,pin in summary['sources'].items(): identity(raw(path),pin)
    assert len(summary['sources'])==22
    for path,pin in summary['source_identities'].items(): identity(raw(path),pin)
    commands=doc('evidence/'+mode+'/commands.json');assert len(commands)==16
    assert len({c['tag'] for c in commands})==16
    for command in commands:
        expected=1 if command['tag'].startswith('reject_') else 0
        assert command['exit_code']==expected
        for name,pin in command['streams'].items():
            data=raw(prefix+'evidence/'+mode+'/'+pin['file']) if pin['file'] else b''
            identity(data,pin);streams+=1
        if expected:
            case=next(c for c in summary['native_bad_receipts_rejected'] if command['tag']=='reject_'+c['case'])
            data=raw(prefix+'evidence/'+mode+'/'+command['streams']['stderr']['file'])
            assert b'Error:' in data and case['expected_domain_marker'].encode() in data
            assert b'SyntaxError:' not in data and b'ReferenceError:' not in data
    emit=next(c for c in commands if c['tag']=='original_R273_emit')
    assert '-I' in emit['argv'] and '-B' in emit['argv'] and '-O' not in emit['argv']
    tests=next(c for c in commands if c['tag']=='new5tests')
    assert ('-O' in tests['argv'])==(mode=='optimized')
    assert raw(prefix+'evidence/'+mode+'/original_R273_emit.stdout')==raw('research/R273/R273_MACHINE_RECEIPT.json')
    for tag,path in [('S69_csv','research/validation/R273_S69_ALL_576_PAIRED_SOURCE_ROWS_2026-10-30.csv'),('S69_json','research/validation/R273_S69_PAIRED_TARGET_RANK_EXACT_RESULTS_2026-10-30.json')]:
        assert raw(prefix+'evidence/'+mode+'/'+tag+'.stdout')==raw(path)
mod=types.ModuleType('source_join');exec(compile(raw(prefix+'source_join.py'),prefix+'source_join.py','exec'),mod.__dict__)
sys.modules['source_join']=mod
replay=types.ModuleType('review_replay');replay.__file__=str(Path(repo)/prefix/'replay.py')
exec(compile(raw(prefix+'replay.py'),prefix+'replay.py','exec'),replay.__dict__)
for case,(mutation,marker) in replay.bad_receipts(json.loads(raw(replay.JSON))).items():
    for mode in ['normal','optimized']:
        entry=next(x for x in doc('evidence/'+mode+'/summary.json')['native_bad_receipts_rejected'] if x['case']==case)
        assert sha(json.dumps(mutation).encode())==entry['artifact_sha256']
        assert marker==entry['expected_domain_marker']
join=mod.compare_sources(raw(replay.CSV),raw(replay.BASE_CSV))
risks=mod.compare_risks(json.loads(raw(replay.JSON)),json.loads(raw(replay.BASE_JSON)))
receipt=json.loads(raw(replay.BASE_RECEIPT));assert receipt['source_sha256']==sha(raw(replay.BASE_CSV));assert receipt['results_sha256']==sha(raw(replay.BASE_JSON))
changed=set(git('diff','--name-only',base,head).decode().splitlines())
refs={str(pr):'origin/review-pr'+str(pr) for pr in [30,31,32,33]};refs['35']='9ae4eb923b7d1cbc78fdc0c81cddee591efc68ef'
cross={}
for pr,ref in refs.items():
    other=set(git('diff','--name-only',base,ref).decode().splitlines())
    cross[pr]={'file_overlap':sorted(changed&other),'changed_pinned_paths':sorted(set(pins)&other)}
result={'verdict':'APPROVE_CANDIDATE','head':head,'base':base,'pinned_sources':len(pins),'fingerprints_per_mode':22,'commands':32,'stream_hashes':streams,'five_identities':doc('evidence/normal/summary.json')['source_identities'],'source_join':join,'risk_fields':risks,'negative_cases_per_mode':8,'cross_pr':cross,'new_code_sha256':{p:sha(raw(prefix+p)) for p in ['replay.py','source_join.py','test_source_join.py','pins.json']},'limits':['No original math campaigns rerun','No network, human data, CI, or remote mutation','Saved subprocess execution provenance checked internally; no independent historical execution attestation','R077 external access/licensing assertions not independently requalified']}
Path(__file__).with_name('audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
