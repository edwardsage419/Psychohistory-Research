"""Actual B-adopted PR30/31+32/33/35/36 source-only integration, no candidate pin edits."""
import hashlib,json,os,subprocess,sys,tempfile
from pathlib import Path
REPO=Path('/workspace/Psychohistory-Research');OUT=Path(__file__).parent/'actual-combination';OUT.mkdir(exist_ok=False)
MAIN='d4740c2cd999b8da06a25b0ef407aeaf8a56ab6c'
HEADS={r['number']:r['headRefOid']for r in json.loads(OUT.parent.joinpath('open-prs.json').read_bytes())}
B='research/codex_b/2026-11-11-r077-scientific-readiness';A='research/codex_a/r127_workflow_candidate';P='research/codex_a/r077_integration'
CAPTURE='import importlib.util,json,sys;s=importlib.util.spec_from_file_location("source_capture_only",sys.argv[1]);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);print(json.dumps(m.capture(),sort_keys=True))'
def git(root,*a):return subprocess.check_output(['git','--no-replace-objects','-C',str(root),*a],stderr=subprocess.PIPE)
def raw(head,p):return git(REPO,'show',head+':'+p)
def fp(b):return {'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
pins=json.loads(raw(HEADS[31],B+'/pins.json'));adapter=raw(HEADS[30],P+'/preflight.py')
if pins[P+'/preflight.py']!=fp(adapter):raise ValueError('BLOCKED_WAITING_B_OWNED_ADOPTION')
records=[]
with tempfile.TemporaryDirectory(prefix='actual-adopted-prs-')as td:
 root=Path(td)/'repo'
 subprocess.run(['git','clone','--shared','--no-checkout',str(REPO),str(root)],check=True,capture_output=True)
 git(root,'checkout','--detach',MAIN);git(root,'config','user.name','Source integration fixture');git(root,'config','user.email','fixture@example.invalid')
 for n,sha in sorted(HEADS.items()):
  patch=git(REPO,'diff','--binary',MAIN+'...'+sha)
  subprocess.run(['git','apply','--check','-'],input=patch,cwd=root,check=True,capture_output=True)
  subprocess.run(['git','apply','-'],input=patch,cwd=root,check=True,capture_output=True)
 git(root,'add','-A');git(root,'commit','-qm','Actual six-PR source fixture [skip ci]')
 combined=git(root,'rev-parse','HEAD').decode().strip()
 def run(tag,args,expected=0):
  child=subprocess.run(list(map(str,args)),cwd=root,capture_output=True,timeout=30)
  for kind,value in [('stdout',child.stdout),('stderr',child.stderr)]:(OUT/(tag+'.'+kind)).write_bytes(value)
  records.append({'tag':tag,'argv':list(map(str,args)),'cwd':str(root),'exit':child.returncode,'expected_exit':expected,'streams':{kind:{'bytes':len(value),'sha256':hashlib.sha256(value).hexdigest()}for kind,value in [('stdout',child.stdout),('stderr',child.stderr)]}})
  if child.returncode!=expected:raise ValueError(tag+':'+child.stderr.decode(errors='replace')[-400:])
  return child
 for optimized,label in [(False,'normal'),(True,'optimized')]:
  prefix=[sys.executable,'-B']+(['-O']if optimized else[])
  captured=json.loads(run('B31-capture-'+label,prefix+['-c',CAPTURE,str(root/B/'run_audit.py')]).stdout)
  if len(captured)!=22 or captured[P+'/preflight.py']!=fp(adapter):raise ValueError('CAPTURE_IDENTITY')
  result=json.loads(run('A33-checklist-'+label,prefix+[P+'/mainline_checklist.py','.'],2).stdout)
  if result['production_ready']is not False or result['original_failure_cases']!=11 or result['candidate_correct_orders']!=35 or result['mathematical_programs_rerun']is not False:raise ValueError('PRODUCTION_VETO')
 generated=run('R127-prepare',[sys.executable,'-B',A+'/prepare.py','.']).stdout
 originalpatch=raw(HEADS[32],A+'/candidate.patch')
 if generated!=originalpatch:raise ValueError('R127_PATCH_DRIFT')
 manifest=json.loads(raw(HEADS[32],A+'/candidate_manifest.json'))
 before={p:(root/p).read_bytes()for p in manifest['targets']}
 subprocess.run(['git','apply','--check','-'],input=generated,cwd=root,check=True,capture_output=True)
 subprocess.run(['git','apply','-'],input=generated,cwd=root,check=True,capture_output=True)
 git(root,'add','-A');git(root,'commit','-qm','Temporary R127 owner candidate wiring [skip ci]')
 candidate=git(root,'rev-parse','HEAD').decode().strip()
 capture='import importlib.util,json,sys;s=importlib.util.spec_from_file_location("gate_source_capture",sys.argv[1]);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);a,b,c=m.capture(sys.argv[2]);print(json.dumps({"sources":b,"head":c},sort_keys=True))'
 captured=json.loads(run('R127-source-capture',[sys.executable,'-B','-c',capture,str(root/'research/codex_a/r127_local_gates/gate.py'),str(root)]).stdout)
 if len(captured['sources'])!=5:raise ValueError('R127_SOURCES')
 subprocess.run(['git','bundle','create',str(OUT/'combined.bundle'),'HEAD','^'+MAIN],cwd=root,check=True,capture_output=True)
 for args in (['--reverse','--check'],['--reverse']):
  subprocess.run(['git','apply',*args,'-'],input=generated,cwd=root,check=True,capture_output=True)
 if any((root/p).read_bytes()!=b for p,b in before.items()):raise ValueError('R127_ROLLBACK')
 result={'status':'COMPLETE_ACTUAL_B_ADOPTED_COMBINATION','main':MAIN,'heads':HEADS,'B31_adopted_pin':pins[P+'/preflight.py'],'B_pin_candidate_applied_by_A':False,'source_capture_records':22,'A33_exit':2,'original_failures_retained':11,'candidate_orders_retained':35,'production_ready':False,'R127_patch_sha256':hashlib.sha256(generated).hexdigest(),'R127_five_source_capture':'COMPLETE','R127_three_targets_reversed_byte_for_byte':True,'local_combined_fixture':combined,'local_candidate_fixture':candidate,'fixture_not_GitHub_delivery':True,'bundle_sha256':hashlib.sha256((OUT/'combined.bundle').read_bytes()).hexdigest(),'commands':records,'mathematical_programs_rerun':False,'CI':'NOT_RUN','production_deployed':False}
 (OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k]for k in ('status','source_capture_records','original_failures_retained','candidate_orders_retained','production_ready')}))
