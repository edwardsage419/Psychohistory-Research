import hashlib,json,os,subprocess,sys
from pathlib import Path
ROOT=Path('/workspace/codex-a/pr30-36-integration-20261112');OUT=Path(__file__).parent
FIX=OUT/'r333-fixture';TOOL=ROOT/'research/codex_a/r333_r340_authenticated/replay.py'
COMPOSITE='research/evidence_audit/r333_r340_composite_acceptance_20261101.py'
rows=[]
def run(tag,args,expected,cwd=ROOT):
 p=subprocess.run(list(map(str,args)),cwd=cwd,capture_output=True,timeout=180)
 for name,raw in [('stdout',p.stdout),('stderr',p.stderr)]:(OUT/(tag+'.'+name)).write_bytes(raw)
 rows.append({'tag':tag,'argv':list(map(str,args)),'cwd':str(cwd),'exit':p.returncode,'expected_exit':expected,'streams':{name:{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}for name,raw in [('stdout',p.stdout),('stderr',p.stderr)]}})
 (OUT/'commands.json').write_text(json.dumps(rows,indent=2)+'\n')
 if p.returncode!=expected:raise ValueError(tag+':'+p.stderr.decode(errors='replace')[-500:])
 return p
for optimized,label in [(False,'normal'),(True,'optimized')]:
 prefix=[sys.executable,'-I','-B']+(['-O']if optimized else[])
 child=run('authenticated-'+label,prefix+[str(TOOL),str(ROOT)],0)
 data=json.loads(child.stdout)
 if data['production_ready']is not False or data['scientific_acceptance']!='NOT_RUN' or len(data['sources'])!=56:raise ValueError('BOUNDARY')
 # Trust-root counterexample: unauthenticated changed caller lies; new entry blocks it.
 p=FIX/COMPOSITE;original=p.read_bytes()
 try:
  p.write_text('import json\nprint(json.dumps('+repr(data['composite_receipt'])+'))\n')
  direct=run('unauthenticated-forged-'+label,prefix+[str(p),'--repo-root',str(FIX)],0)
  if json.loads(direct.stdout)!=data['composite_receipt']:raise ValueError('FORGED_CONTROL')
  blocked=run('authenticated-forged-'+label,prefix+[str(TOOL),str(FIX)],1)
  if 'identity mismatch' not in json.loads(blocked.stdout)['reason']:raise ValueError('WRONG_SOURCE_REJECTION')
 finally:p.write_bytes(original)
 for kind,path in [('math-csv',next((FIX/'research/R333').glob('*.csv'))),('historical-claim',FIX/'research/R333/R333_MACHINE_RECEIPT.json')]:
  original=path.read_bytes()
  try:
   path.write_bytes(original+b'\n')
   child=run('existing-'+kind+'-reject-'+label,prefix+[str(FIX/COMPOSITE),'--repo-root',str(FIX)],1)
   if b'COMPOSITE_ACCEPTANCE_FAIL:' not in child.stderr:raise ValueError('UNEXPECTED_REJECTION')
  finally:path.write_bytes(original)
run('node-version',['node','--version'],0)
run('python-version',[sys.executable,'-I','-B','-c','import sys,json;print(json.dumps({"version":sys.version,"executable":sys.executable}))'],0)
print(json.dumps({'status':'COMPLETE_ALL_EXPECTED_EXITS_MATCH','commands':len(rows),'real_R_or_B_files_changed':False,'CI':'NOT_RUN'}))
