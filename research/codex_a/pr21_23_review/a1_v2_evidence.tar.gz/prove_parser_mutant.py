import importlib.util,sys,unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location("review_contracts",sys.argv[1]);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
original=m.export
def weakened(repo,root):
 identities=original(repo,root)
 for number in m.HEADS:
  p=root/m.MODULES[number]/"audit.py";source=p.read_text()
  lines=source.splitlines(keepends=True);matches=[i for i,line in enumerate(lines) if "return json.loads(raw," in line]
  assert len(matches)==1
  lines[matches[0]]="    return json.loads(raw)\n";p.write_text("".join(lines))
 return identities
m.export=weakened
r=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite([m.CLIContracts("test_duplicate_json_keys_at_root_and_nested_depth")]))
assert r.testsRun==1 and len(r.failures)==8 and not r.errors
sys.exit(1)
