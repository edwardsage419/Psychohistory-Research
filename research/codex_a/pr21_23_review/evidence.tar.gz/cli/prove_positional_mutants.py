import importlib.util,sys,unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location("review_contracts",sys.argv[1]);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
original=m.export
def positional(repo,root):
 identities=original(repo,root)
 p=root/m.MODULES[22]/"audit.py";lines=p.read_text().splitlines(keepends=True)
 matches=[i for i,line in enumerate(lines) if line.strip().startswith("counted = {s:")];assert len(matches)==1
 lines[matches[0]]='    counted = {s: [sum(x[t] != y[t] for x,y in zip([v for (k,_),v in trajectories.items() if k==s], [v for (k,_),v in trajectories.items() if k=="SYNC"])) for t in (1,2)] for s in SCHEDULES[1:]}\n'
 p.write_text("".join(lines))
 p=root/m.MODULES[23]/"audit.py";source=p.read_text();needle='    copied=dict(document)';assert source.count(needle)==1
 added='    require([(r["distribution"],r["training_episodes"]) for r in document["worlds"]] == [(r["distribution"],r["m"]) for r in document["independent_polynomial"]],"POSITIONAL_JOIN")\n'
 p.write_text(source.replace(needle,added+needle))
 return identities
m.export=positional
if "--synchronized-only" in sys.argv[2:]:
 def sync_csv(self):
  for number in m.HEADS:
   rows=self.table(number);self.call(number,data=self.encoded([rows[0],*reversed(rows[1:])]))
 def sync_collections(self):
  doc=self.document(23)
  for field in ("worlds","independent_polynomial","mutation_tests"):doc[field].reverse()
  self.call(23,document=doc)
 m.CLIContracts.test_csv_reordering_preserves_identity=sync_csv
 m.CLIContracts.test_s85_identity_collections_can_be_reordered=sync_collections
suite=unittest.TestSuite([m.CLIContracts("test_csv_reordering_preserves_identity"),m.CLIContracts("test_s85_identity_collections_can_be_reordered")])
r=unittest.TextTestRunner(verbosity=2).run(suite)
assert not r.errors
sys.exit(0 if r.wasSuccessful() else 1)
