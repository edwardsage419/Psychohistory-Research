import hashlib,json,os,subprocess,sys
from pathlib import Path
ROOT=Path('/workspace/Psychohistory-Research');OUT=Path(__file__).parent
PY=Path('/workspace/codex-a/r127-acceptance-runtime/cpython-3.11.17-linux-x86_64-gnu/bin/python3.11')
FIX=OUT/'pr32-fixture'
subprocess.run(['git','clone','--shared','--no-checkout',str(ROOT),str(FIX)],check=True,capture_output=True)
subprocess.run(['git','checkout','--detach','16778c53b2e7a2c590ff65c854b1f7034169050d'],cwd=FIX,check=True,capture_output=True)
env=os.environ.copy();env['PATH']=str(PY.parent)+os.pathsep+env['PATH']
commands=[]
def run(label,args,cwd=FIX):
 child=subprocess.run(list(map(str,args)),cwd=cwd,env=env,capture_output=True,timeout=240)
 for name,raw in [('stdout',child.stdout),('stderr',child.stderr)]:(OUT/(label+'.'+name)).write_bytes(raw)
 commands.append({'tag':label,'argv':list(map(str,args)),'cwd':str(cwd),'PATH_prefix':str(PY.parent),'exit':child.returncode,'streams':{k:{'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()} for k,v in [('stdout',child.stdout),('stderr',child.stderr)]}})
 (OUT/'py311-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 if child.returncode:raise ValueError(label+':'+child.stderr.decode(errors='replace')[-500:])
 return child.stdout
info=json.loads(run('py311-runtime',[PY,'-I','-B','-c','import sys,json,ssl;print(json.dumps({"version":sys.version,"executable":sys.executable,"openssl":ssl.OPENSSL_VERSION}))']))
raw=PY.read_bytes();info['executable_sha256']=hashlib.sha256(raw).hexdigest();info['distribution']='astral-sh/python-build-standalone via uv, local workspace install';info['github_actions_runtime_equivalence']='NOT_ESTABLISHED';info['new_fees']=False
(OUT/'runtime.json').write_text(json.dumps(info,indent=2)+'\n')
for optimized,label in [(False,'normal'),(True,'optimized')]:
 run('py311-'+label+'-units',[PY,'-B']+(['-O']if optimized else[])+['-m','unittest','discover','-s','research/codex_a/r127_workflow_candidate','-p','test_candidate.py','-v'])
run('py311-exercise',[PY,'-B','research/codex_a/r127_workflow_candidate/exercise.py','.', '--output',OUT/'py311-integration'])
result=json.loads((OUT/'py311-integration/result.json').read_bytes())
for mode,label in zip(result['modes'],('normal','optimized')):
 data=json.loads((OUT/('py311-integration/'+label+'-sidecar.json')).read_bytes())
 assert data['execution']['python'].startswith('3.11.17')
 assert data['execution']['optimized'] is mode['optimized']
 assert mode['native_original_methods']==60 and mode['stage2_fields']==138 and mode['adversarial_rejections']==9
print(json.dumps({'runtime':info['version'],'normal_and_optimized':'PASS_60_METHODS_138_FIELDS_9_REJECTIONS_EACH','actions':'NOT_RUN'}))
