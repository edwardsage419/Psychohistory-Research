"""Independent mathematical assertions for the R146 preregistered synthetic model."""
import itertools
import unittest
from fractions import Fraction as F
import r146_meltzer_richard_exact as m


class FrozenR146Tests(unittest.TestCase):
    def setUp(self):
        self.base=(F(1,4),F(1,4),F(1,2),F(1,2),F(1,2),F(3,4),F(3,4),F(1),F(1))

    def test_source_project_not_author_utility(self):
        self.assertEqual(m.PRODUCTIVITIES,(F(0),F(1,4),F(1,2),F(3,4),F(1)))
    def test_exact_policy_grid(self): self.assertEqual((len(m.GRID),m.GRID[0],m.GRID[-1]),(21,F(0),F(1)))
    def test_tax_zero_labor(self): self.assertEqual(m.labor(F(3,4),F(0)),F(3,4))
    def test_tax_half_labor(self): self.assertEqual(m.labor(F(3,4),F(1,2)),F(3,8))
    def test_tax_one_zero_labor(self): self.assertEqual(m.labor(F(3,4),F(1)),F(0))
    def test_mean_squared_productivity(self): self.assertEqual(m.mean_q(self.base),F(4,9))
    def test_balanced_transfer_half(self): self.assertEqual(m.transfer(self.base,F(1,2)),F(1,9))
    def test_equal_fiscal_debit_credit(self):
        t=F(1,4)
        self.assertEqual(len(self.base)*m.transfer(self.base,t),sum((t*x*m.labor(x,t) for x in self.base),F(0)))
    def test_direct_utility_formula(self):
        t=F(7,23)
        for i,x in enumerate(self.base):self.assertEqual(m.direct_payoff(self.base,i,t),m.payoff(x*x,m.mean_q(self.base),t))
    def test_welfare_tax_loss(self):
        self.assertEqual(m.welfare(self.base,F(0))-m.welfare(self.base,F(1,2)),F(1,8)*sum(x*x for x in self.base))
    def test_median_continuous(self): self.assertEqual(m.election(self.base)['median_ideal'],F(7,23))
    def test_median_grid(self): self.assertEqual(m.election(self.base)['median_grid_winners'],(F(3,10),))
    def test_grid_majority_winner(self): self.assertEqual(m.election(self.base)['undefeated'],(F(3,10),))
    def test_richest_franchise(self):self.assertEqual(m.election(self.base,(4,5,6,7,8))['median_ideal'],F(0))
    def test_poorest_franchise(self):self.assertEqual(m.election(self.base,(0,1,2,3,4))['median_ideal'],F(7,23))
    def test_unchanged_median_growing_mean(self):
        changed=list(self.base);changed[5]=F(1)
        self.assertEqual(self.base[4],changed[4])
        self.assertGreater(m.mean_q(changed),m.mean_q(self.base))
        self.assertGreater(m.election(changed)['median_ideal'],m.election(self.base)['median_ideal'])
        self.assertEqual(m.election(changed)['median_ideal'],F(35,106))
    def test_median_change_reverses_simple_mean_comparison(self):
        a=(F(0),F(0),F(1,4),F(1,4),F(1,4),F(1,4),F(1))
        b=(F(0),F(0),F(1,2),F(1,2),F(1,2),F(1,2),F(1))
        self.assertLess(m.mean_q(a),m.mean_q(b))
        self.assertGreater(m.election(a)['median_ideal'],m.election(b)['median_ideal'])
        self.assertEqual((m.election(a)['median_ideal'],m.election(b)['median_ideal']),(F(13,33),F(1,9)))
    def test_fixed_labor_nontax_distortion(self):
        self.assertEqual(m.frozen_labor_voter_ideal(self.base,4),F(1))
        self.assertLess(m.election(self.base)['median_ideal'],F(1,2))
    def test_zero_productivity_all_taxes_indifferent(self):
        zeros=(F(0),)*5
        self.assertEqual(m.mean_q(zeros),F(0))
        self.assertEqual(m.election(zeros)['undefeated'],m.GRID)
        self.assertEqual(m.election(zeros)['median_ideal'],F(0))
    def test_equal_productivity_no_tax(self):
        self.assertEqual(m.election((F(3,4),)*5)['median_ideal'],F(0))
    def test_zero_productivity_voter_median_max_half(self):
        self.assertEqual(m.ideal(F(0),F(1,4)),F(1,2))
    def test_median_above_mean_no_tax(self):
        self.assertEqual(m.ideal(F(1),F(1,4)),F(0))
    def test_utility_quadratic_derivative_sign(self):
        q,m2=F(1,4),F(4,9)
        t=(m2-q)/(2*m2-q)
        for delta in (F(1,1000),F(1,20),F(1,4)):
            if t+delta<=1:self.assertLess(m.payoff(q,m2,t+delta),m.payoff(q,m2,t))
            if t-delta>=0:self.assertLess(m.payoff(q,m2,t-delta),m.payoff(q,m2,t))
    def test_ledger_transfer_cancels(self):
        for t in (F(0),F(1,7),F(1,2),F(1)):
            self.assertEqual(sum((m.direct_payoff(self.base,i,t) for i in range(9)),F(0)),m.welfare(self.base,t))
    def test_odd_population_restriction(self):
        with self.assertRaises(ValueError):m.check_xs((F(1),F(1)))
    def test_reject_float_productivity(self):
        with self.assertRaises(ValueError):m.check_xs((0.5,))
    def test_reject_boolean_productivity(self):
        with self.assertRaises(ValueError):m.check_xs((True,))
    def test_reject_negative_productivity(self):
        with self.assertRaises(ValueError):m.check_xs((-1,))
    def test_reject_above_one_productivity(self):
        with self.assertRaises(ValueError):m.check_xs((F(11,10),))
    def test_reject_float_tax(self):
        with self.assertRaises(ValueError):m.check_t(0.5)
    def test_reject_boolean_tax(self):
        with self.assertRaises(ValueError):m.check_t(True)
    def test_reject_negative_tax(self):
        with self.assertRaises(ValueError):m.check_t(F(-1,2))
    def test_reject_above_one_tax(self):
        with self.assertRaises(ValueError):m.check_t(F(3,2))
    def test_reject_duplicate_voter(self):
        with self.assertRaises(ValueError):m.election(self.base,(0,0,1))
    def test_reject_even_electorate(self):
        with self.assertRaises(ValueError):m.election(self.base,(0,1))
    def test_reject_outside_electorate(self):
        with self.assertRaises(ValueError):m.election(self.base,(0,1,20))
    def test_reject_boolean_voter_index(self):
        with self.assertRaises(ValueError):m.election(self.base,(True,1,2))
    def test_reject_repeated_grid_taxes(self):
        with self.assertRaises(ValueError):m.election(self.base,grid=(F(0),F(0)))
    def test_reject_float_mean(self):
        with self.assertRaises(ValueError):m.ideal(F(0),0.5)
    def test_reject_bool_squared_productivity(self):
        with self.assertRaises(ValueError):m.payoff(True,F(1,4),F(1,2))
    def test_grid_finite_pairwise_uncontested(self):
        xs=(F(0),F(1,4),F(1,2),F(3,4),F(1))
        e=m.election(xs)
        self.assertTrue(set(e['median_grid_winners']).issubset(e['undefeated']))


# 72 immutable, individually named deterministic economy cases; no random tests or cases selected post-scoring.
SAMPLED=(5,7,9)
for n in SAMPLED:
    xs_cases=list(itertools.combinations_with_replacement(m.PRODUCTIVITIES,n))
    # Distinct rank-based cases spanning corners, median-comparisons and unequal economies.
    positions=sorted(set(round(k*(len(xs_cases)-1)/23) for k in range(24)))
    for case_i,pos in enumerate(positions):
        xs=xs_cases[pos]
        def test_case(self,xs=xs):
            es=m.election(xs)
            mean=m.mean_q(xs)
            voter_q=sorted(x*x for x in xs)[len(xs)//2]
            self.assertEqual(es['median_ideal'],m.ideal(voter_q,mean))
            self.assertTrue(set(es['median_grid_winners']).issubset(es['undefeated']))
            self.assertEqual(len(xs)*m.transfer(xs,F(1,4)),sum((F(1,4)*x*m.labor(x,F(1,4)) for x in xs),F(0)))
            self.assertEqual(sum((m.direct_payoff(xs,i,F(1,3)) for i in range(len(xs))),F(0)),m.welfare(xs,F(1,3)))
        setattr(FrozenR146Tests,f'test_distribution_n{n}_rank_{case_i:02d}',test_case)

if __name__=='__main__':unittest.main()
