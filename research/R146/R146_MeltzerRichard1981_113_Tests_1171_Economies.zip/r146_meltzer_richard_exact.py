"""R146: finite project-constructed Meltzer-Richard-inspired tax vote (E1 only).

Copyright (c) 2026 Psychohistory-Research. Standard library, Fraction exact.
NOT the original 1981 paper's general u(c,leisure) or an empirical replay.
"""
from fractions import Fraction as F
from itertools import combinations_with_replacement
import hashlib
import json

PRODUCTIVITIES = tuple(F(k,4) for k in range(5))
GRID = tuple(F(k,20) for k in range(21))
STUDY_N = (5, 7, 9)


def check_xs(xs):
    if not isinstance(xs,(tuple,list)) or not xs or len(xs)%2==0:
        raise ValueError('odd, positive number of citizens required')
    if any(type(x) not in (int,F) or x<0 or x>1 for x in xs):
        raise ValueError('citizen productivity must be exact in [0,1]')
    return tuple(F(x) for x in xs)


def check_t(t):
    if type(t) not in (int,F) or t < 0 or t > 1:
        raise ValueError('tax must be exact in [0,1]')
    return F(t)


def mean_q(xs):
    xs=check_xs(xs)
    return sum((x*x for x in xs),F(0))/len(xs)


def labor(x,t):
    if type(x) not in (int,F) or x<0 or x>1:
        raise ValueError('productivity must be exact in [0,1]')
    t=check_t(t)
    return (1-t)*F(x)


def transfer(xs,t):
    xs=check_xs(xs)
    t=check_t(t)
    return t*sum((x*labor(x,t) for x in xs),F(0))/len(xs)


def direct_payoff(xs,index,t):
    xs=check_xs(xs)
    if type(index)!=int or index<0 or index>=len(xs):
        raise ValueError('index out of range')
    t=check_t(t)
    x=xs[index]
    n=labor(x,t)
    return (1-t)*x*n+transfer(xs,t)-n*n/2


def payoff(q,m,t):
    if type(q) not in (int,F) or type(m) not in (int,F) or q<0 or m<0:
        raise ValueError('invalid squared productivity or mean')
    t=check_t(t)
    return (1-t)*(1-t)*F(q)/2+t*(1-t)*F(m)


def ideal(q,m):
    if type(q) not in (int,F) or type(m) not in (int,F) or q<0 or m<0:
        raise ValueError('invalid squared productivity or mean')
    q,m=F(q),F(m)
    if not m or q>=m: return F(0)
    return (m-q)/(2*m-q)


def election(xs,voters=None,grid=GRID):
    xs=check_xs(xs)
    if voters is None:
        voters=tuple(range(len(xs)))
    if not isinstance(voters,(tuple,list)) or not voters or len(voters)%2==0:
        raise ValueError('electorate must be nonempty and odd')
    if any(type(i)!=int or i<0 or i>=len(xs) for i in voters) or len(set(voters))!=len(voters):
        raise ValueError('invalid voters or duplicate voting rights')
    if not isinstance(grid,(tuple,list)) or not grid or len(set(grid))!=len(grid):
        raise ValueError('policy grid must have unique entries')
    grid=tuple(check_t(t) for t in grid)
    m=mean_q(xs)
    ideals=sorted(ideal(xs[i]*xs[i],m) for i in voters)
    decisive=ideals[len(ideals)//2]
    # Independent direct-payoff implementation for pairwise policy comparisons.
    # Independently evaluate the primitive labor/transfer ledger once per policy.
    utility_by_policy={}
    all_policy_payoffs={}
    for t in grid:
        ns=tuple((1-t)*x for x in xs)
        budget=t*sum((x*n for x,n in zip(xs,ns)),F(0))/len(xs)
        all_policy_payoffs[t]=tuple((1-t)*x*n+budget-n*n/2 for x,n in zip(xs,ns))
        utility_by_policy[t]=tuple(all_policy_payoffs[t][i] for i in voters)
    med_id=sorted(voters,key=lambda i:xs[i])[len(voters)//2]
    mv_utility={t:all_policy_payoffs[t][med_id] for t in grid}
    mv_max=max(mv_utility.values())
    mv_best=tuple(t for t in grid if mv_utility[t]==mv_max)
    und=[]
    pairchecks=0
    for candidate in grid:
        c=utility_by_policy[candidate]
        lost=False
        for rival in grid:
            other=utility_by_policy[rival]
            votes=sum(a>b for a,b in zip(other,c))
            pairchecks+=1
            if votes>len(voters)//2:
                lost=True
                break
        if not lost: und.append(candidate)
    if not set(mv_best).issubset(und):
        raise AssertionError('median-voter grid optimum majority defeated')
    return {'median_ideal':decisive,'median_grid_winners':mv_best,
            'undefeated':tuple(und),'pairwise_compared':pairchecks,
            'all_policies_weak_majority_nondefeated':tuple(und)==tuple(grid)}


def welfare(xs,t):
    xs=check_xs(xs)
    t=check_t(t)
    return (1-t*t)*sum((x*x for x in xs),F(0))/2


def frozen_labor_voter_ideal(xs,index):
    xs=check_xs(xs)
    if type(index)!=int or index<0 or index>=len(xs):
        raise ValueError('bad index')
    q=xs[index]**2
    m=mean_q(xs)
    return F(1) if q<m else F(0) # flat preference when q=m fixed tie->0


def format_case(xs):
    # Sorted sets are distinct synthetic resident populations, not observations.
    e=election(xs)
    m=mean_q(xs)
    k=len(xs)//2
    return {'x': [str(x) for x in xs], 'mean_sq_x':str(m),
            'median_sq_x':str(xs[k]**2),
            'median_ideal_t':str(e['median_ideal']),
            'grid_winners':[str(t) for t in e['median_grid_winners']],
            'undefeated':[str(t) for t in e['undefeated']],
            'welfare_at_continuous_median_t':str(welfare(xs,e['median_ideal'])),
            'resource_cost_vs_zero_tax':str(welfare(xs,0)-welfare(xs,e['median_ideal']))}


def run():
    records={};num=0;all_zero=0;no_tax=0;positive_tax=0;two_grid=0;max_pair=0
    for n in STUDY_N:
        rows=[]
        for xs in combinations_with_replacement(PRODUCTIVITIES,n):
            row=format_case(xs)
            num+=1
            all_zero+=int(not any(xs))
            no_tax+=int(row['median_ideal_t']=='0')
            positive_tax+=int(row['median_ideal_t']!='0')
            two_grid+=int(len(row['grid_winners'])>1)
            # Check tax budget and individual labor supply for all 21 policies.
            m=mean_q(xs)
            for t in GRID:
                ns=tuple((1-t)*x for x in xs)
                r=t*sum((x*n_i for x,n_i in zip(xs,ns)),F(0))/n
                assert n*r==sum((t*x*n_i for x,n_i in zip(xs,ns)),F(0))
                ledgers=tuple((1-t)*x*n_i+r-n_i*n_i/2 for x,n_i in zip(xs,ns))
                assert sum(ledgers,F(0))==welfare(xs,t)
                assert all(u==payoff(x*x,m,t) for x,u in zip(xs,ledgers))
            # Lossless positional schema; x productivities encoded as base-4 quarter-unit digits.
            rows.append([''.join(str(int(4*x)) for x in xs),
                         row['mean_sq_x'],row['median_sq_x'],row['median_ideal_t'],
                         row['grid_winners'],row['undefeated'],
                         row['welfare_at_continuous_median_t'],row['resource_cost_vs_zero_tax']])
        records[str(n)]=rows
    baseline=(F(1,4),F(1,4),F(1,2),F(1,2),F(1,2),F(3,4),F(3,4),F(1),F(1))
    raised=list(baseline);raised[5]=F(1)
    same_median_raised=tuple(raised)
    low_med=(F(0),F(0),F(1,4),F(1,4),F(1,4),F(1,4),F(1))
    high_med=(F(0),F(0),F(1,2),F(1,2),F(1,2),F(1,2),F(1))
    franchises={'all_nine':tuple(range(9)),'richest_five':tuple(range(4,9)),
                'poorest_five':tuple(range(5)),'middle_five':tuple(range(2,7))}
    fb=election(baseline)
    pay_pairs={}
    for name,eligibility in franchises.items():
        e=election(baseline,eligibility)
        pay_pairs[name]={'voter_indices':list(eligibility),'continuous_decisive_tax':str(e['median_ideal']),
                         'grid_winners':[str(t) for t in e['median_grid_winners']]}
    return {
      'research_id':'R146','source':'Meltzer-Richard 1981 JPE 89 914-927 DOI 10.1086/261013',
      'full_original_utility_assumptions_reproduced':False,'project_special_case_quasilinear':True,
      'exact_math':'Fraction', 'all_synthetic_economies':num,'family_counts':{str(n):len(records[str(n)]) for n in STUDY_N},
      'number_all_zero':all_zero,'number_no_tax_continuous':no_tax,
      'number_positive_tax_continuous':positive_tax,'number_multiple_grid_median_winners':two_grid,
      'policy_grid':[str(t) for t in GRID],
      'mean_only_comparison':{'original_mean_sq':str(mean_q(baseline)),'changed_mean_sq':str(mean_q(same_median_raised)),
                   'original_median_sq':str(baseline[4]**2),'changed_median_sq':str(same_median_raised[4]**2),
                   'original_tax':str(fb['median_ideal']),'changed_tax':str(election(same_median_raised)['median_ideal'])},
      'cochanging_median_comparison':{'low_mean_sq':str(mean_q(low_med)), 'higher_mean_sq':str(mean_q(high_med)),
                   'low_median_sq':str(low_med[3]**2),'higher_median_sq':str(high_med[3]**2),
                   'low_tax':str(election(low_med)['median_ideal']),
                   'higher_tax':str(election(high_med)['median_ideal'])},
      'franchise_same_resident_population':pay_pairs,
      'baseline_endogenous_labor_median_tax':str(fb['median_ideal']),
      'baseline_frozen_labor_median_tax':str(frozen_labor_voter_ideal(baseline,4)),
      'all_economy_details_schema':['quarter_productivity_digit_string','mean_sq_x','median_sq_x','median_ideal_t',
                                    'grid_winners','undefeated','welfare_at_continuous_median_t','resource_cost_vs_zero_tax'],
      'all_economy_details':records,
      'new_E2_real_person_predictions':0,'new_E3_historical_event_forecasts':0,'R073':'FROZEN','PESEN_v0_1':'FROZEN'}


if __name__=='__main__':
    print(json.dumps(run(),ensure_ascii=False,indent=2,sort_keys=True,separators=(',',': ')))
