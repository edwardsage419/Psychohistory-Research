"""Independent deterministic acceptance tests for R138; 1961/1971/1973 sources."""
import itertools
import unittest
from fractions import Fraction
import r138_vickrey_clarke_groves_exact as m


class TestVickreyAuction(unittest.TestCase):
    def test_01_single_three_agents(self):
        self.assertEqual(len(m.BID_PROFILES), 125)
    def test_02_lowest_index_breaks_tie(self):
        self.assertEqual(m.single_auction((2,2,1)), (0,2))
    def test_03_second_bid_not_maximum(self):
        self.assertEqual(m.single_auction((4,2,1)), (0,2))
    def test_04_loser_pays_nothing(self):
        self.assertEqual(m.single_utility((4,2,1),(4,2,1),2),0)
    def test_05_winner_true_surplus(self):
        self.assertEqual(m.single_utility((4,2,1),(4,2,1),0),2)
    def test_06_truthful_all_profiles_and_all_bids(self):
        self.assertEqual(m.audit_single()['deviation_comparisons'], 1875)
    def test_07_truthful_zero_violations(self):
        self.assertEqual(m.audit_single()['DSIC_violations'],0)
    def test_08_strict_dominance_not_claimed(self):
        self.assertGreater(m.audit_single()['weak_ties_nontruth'],0)
    def test_09_first_price_shading_profitable(self):
        r=m.audit_single()['first_price_counterexample']; self.assertEqual((r['truthful_utility'],r['shaded_utility']),(0,2))
    def test_10_second_price_does_not_reward_shading(self):
        self.assertEqual(m.single_utility((4,1,0),(4,1,0),0),3)
        self.assertEqual(m.single_utility((4,1,0),(2,1,0),0),3)
    def test_11_reject_bool_value(self):
        with self.assertRaises(ValueError): m.single_auction((True,2,0))
    def test_12_reject_float_value(self):
        with self.assertRaises(ValueError): m.single_auction((2.,2,0))
    def test_13_reject_bid_over_range(self):
        with self.assertRaises(ValueError): m.single_auction((5,2,0))
    def test_14_reject_wrong_length(self):
        with self.assertRaises(ValueError): m.single_auction((2,0))
    def test_15_reject_invalid_bidder_index(self):
        with self.assertRaises(ValueError): m.single_utility((0,1,2),(0,1,2),3)
    def test_16_all_zero_bids(self):
        self.assertEqual(m.single_auction((0,0,0)),(0,0))
    def test_17_equivalent_high_tie(self):
        self.assertEqual(m.single_auction((4,4,4)),(0,4))


class TestCombinatorialVCG(unittest.TestCase):
    def test_18_type_space_nine(self):
        self.assertEqual(len(m.UNIT_TYPES),9)
    def test_19_truth_profiles_729(self):
        self.assertEqual(len(m.UNIT_PROFILES),729)
    def test_20_feasible_allocations_13(self):
        self.assertEqual(len(m.ASSIGNMENTS),13)
    def test_21_no_duplicate_assignee(self):
        self.assertTrue(all(a<0 or b<0 or a!=b for a,b in m.ASSIGNMENTS))
    def test_22_all_none_feasible(self):
        self.assertIn((-1,-1),m.ASSIGNMENTS)
    def test_23_true_welfare_maximum(self):
        self.assertEqual(m.audit_unit()['inefficient_allocations'],0)
    def test_24_all_19683_deviations(self):
        self.assertEqual(m.audit_unit()['deviation_comparisons'],19683)
    def test_25_no_profitable_unilateral_deviation(self):
        self.assertEqual(m.audit_unit()['DSIC_violations'],0)
    def test_26_truthful_individual_rationality(self):
        self.assertEqual(m.audit_unit()['true_profile_IR_violations'],0)
    def test_27_nonnegative_payments(self):
        self.assertEqual(m.audit_unit()['negative_payment_cases'],0)
    def test_28_per_item_second_price_differs(self):
        c=m.audit_unit()['unit_demand_counterexample_to_separate_item_second_price']; self.assertNotEqual(c['VCG_payment'],c['per_item_second_highest_other'])
    def test_29_utilities_are_integers(self):
        self.assertIsInstance(m.unit_utility(((2,1),(0,2),(1,1)),((2,1),(0,2),(1,1)),0),int)
    def test_30_deterministic_ties(self):
        p=((1,1),(1,1),(1,1)); self.assertEqual(m.unit_outcome(p),m.unit_outcome(p))
    def test_31_highest_welfare_simple(self):
        p=((2,0),(0,2),(0,0)); self.assertEqual(m.unit_outcome(p)[2],4)
    def test_32_externality_vs_separate_others_enumeration(self):
        for reports in m.UNIT_PROFILES:
            a, prices, _ = m.unit_outcome(reports)
            for i in range(3):
                candidates=[]
                for targetA in (-1,0,1,2):
                    for targetB in (-1,0,1,2):
                        if targetA==i or targetB==i: continue
                        if targetA!=-1 and targetB!=-1 and targetA==targetB: continue
                        w=0
                        if targetA!=-1: w+=reports[targetA][0]
                        if targetB!=-1: w+=reports[targetB][1]
                        candidates.append(w)
                observed=sum(reports[j][item] for item,j in enumerate(a) if j!=-1 and j!=i)
                self.assertEqual(prices[i],max(candidates)-observed)
    def test_33_reject_float_valuation(self):
        with self.assertRaises(ValueError): m.unit_outcome(((1.,2),(2,1),(0,1)))
    def test_34_reject_more_than_unit_value_bound(self):
        with self.assertRaises(ValueError): m.unit_outcome(((3,0),(0,0),(0,0)))
    def test_35_reject_bad_player_index(self):
        with self.assertRaises(ValueError): m.unit_utility(((0,0),(0,0),(0,0)),((0,0),(0,0),(0,0)),-1)
    def test_36_no_positive_payment_to_nonwinning_player(self):
        for reports in m.UNIT_PROFILES:
            a, pay, _=m.unit_outcome(reports)
            for i in range(3):
                if i not in a: self.assertEqual(pay[i],0)


class TestPublicProject(unittest.TestCase):
    def test_37_all_profiles_216(self):
        self.assertEqual(len(m.PUBLIC_PROFILES),216)
    def test_38_project_cost_five(self):
        self.assertEqual(m.PROJECT_COST,5)
    def test_39_build_on_tie(self):
        self.assertTrue(m.public_project((5,0,0))[0])
    def test_40_no_build_below_cost(self):
        self.assertFalse(m.public_project((4,0,0))[0])
    def test_41_v555_no_pivotal_taxes(self):
        self.assertEqual(m.public_project((5,5,5)),(True,(0,0,0)))
    def test_42_v222_three_one_taxes(self):
        self.assertEqual(m.public_project((2,2,2)),(True,(1,1,1)))
    def test_43_pivot_vs_independent_welfare_formula(self):
        for v in m.PUBLIC_PROFILES:
            _,t=m.public_project(v)
            for i in range(3): self.assertEqual(t[i],m.public_pivot_independent(v,i))
    def test_44_all_3888_deviations(self):
        self.assertEqual(m.audit_public()['deviation_comparisons'],3888)
    def test_45_no_DSIC_violations(self):
        self.assertEqual(m.audit_public()['DSIC_violations'],0)
    def test_46_true_welfare_maximized(self):
        self.assertEqual(m.audit_public()['inefficient_allocations'],0)
    def test_47_true_individual_rationality(self):
        self.assertEqual(m.audit_public()['truthful_IR_violations'],0)
    def test_48_some_budget_deficits(self):
        self.assertGreater(m.audit_public()['budget_deficit_profiles'],0)
    def test_49_zero_tax_built_profiles_exist(self):
        self.assertGreater(m.audit_public()['zero_tax_built_profiles'],0)
    def test_50_v555_budget_deficit_five(self):
        self.assertEqual(m.audit_public()['constructed_budget_cases']['555']['budget_balance'],-5)
    def test_51_v222_budget_deficit_two(self):
        self.assertEqual(m.audit_public()['constructed_budget_cases']['222']['budget_balance'],-2)
    def test_52_bad_nonpivot_charge(self):
        d=m.audit_public()['nonpivot_pay_as_report_counterexample']; self.assertEqual((d['truthful_utility'],d['deviation_utility']),(0,5))
    def test_53_reports_above_five_rejected(self):
        with self.assertRaises(ValueError): m.public_project((6,0,0))
    def test_54_invalid_cost_rejected(self):
        with self.assertRaises(ValueError): m.public_project((2,2,2),cost=0)
    def test_55_reject_bool_public_value(self):
        with self.assertRaises(ValueError): m.public_project((True,0,0))
    def test_56_pivot_never_exceeds_truth_valuation(self):
        for v in m.PUBLIC_PROFILES:
            built,tax=m.public_project(v)
            if built:
                self.assertTrue(all(0<=tax[i]<=v[i] for i in range(3)))
    def test_57_nonconstruction_zero_tax(self):
        for v in m.PUBLIC_PROFILES:
            build,tax=m.public_project(v)
            if not build: self.assertEqual(tax,(0,0,0))


class TestJointAcceptance(unittest.TestCase):
    def test_58_full_exhaustive_comparison_count(self):
        self.assertEqual(m.calculate()['total_unilateral_report_comparisons'],25446)
    def test_59_all_exhaustions_no_DSIC_violations(self):
        a=m.calculate(); self.assertEqual(sum(a[k]['DSIC_violations'] for k in ('auction','unit_demand_vcg','public_project_pivot')),0)
    def test_60_e2_e3_zero(self):
        a=m.calculate(); self.assertEqual((a['new_real_human_E2'],a['new_real_history_E3']),(0,0))
    def test_61_frozen_baselines(self):
        a=m.calculate(); self.assertEqual((a['R073'],a['PESEN_v0_1']),('FROZEN','FROZEN'))


if __name__ == '__main__':
    unittest.main()
