"""R138: finite constructed Vickrey/VCG mechanism audit; no behavioral data.

Primary sources: Vickrey (1961), Clarke (1971), Groves (1973).
The allocation domains and numerical examples are project-constructed.
"""
from __future__ import annotations

from functools import lru_cache
from itertools import product
import json

BIDS = tuple(range(5))
BID_PROFILES = tuple(product(BIDS, repeat=3))
UNIT_TYPES = tuple(product(range(3), repeat=2))
UNIT_PROFILES = tuple(product(UNIT_TYPES, repeat=3))
PUBLIC_TYPES = tuple(range(6))
PUBLIC_PROFILES = tuple(product(PUBLIC_TYPES, repeat=3))
PROJECT_COST = 5
# assignment for items A,B: -1 unassigned, or the index of its winning agent.
ASSIGNMENTS = tuple((a, b) for a in (-1, 0, 1, 2)
                    for b in (-1, 0, 1, 2) if a == -1 or b == -1 or a != b)
assert len(ASSIGNMENTS) == 13


def _check_3_ints(x, maximum):
    if type(x) not in (tuple, list) or len(x) != 3 or any(type(a) is not int or not 0 <= a <= maximum for a in x):
        raise ValueError('expected three bounded integer reports')
    return tuple(x)


def single_auction(bids, *, first_price=False):
    """Return (winner, payment), with smallest-index tie break."""
    b = _check_3_ints(bids, 4)
    best = max(b)
    winner = next(i for i, val in enumerate(b) if val == best)
    price = best if first_price else sorted(b, reverse=True)[1]
    return winner, price


def single_utility(truth, bids, player, *, first_price=False):
    t = _check_3_ints(truth, 4)
    if type(player) is not int or not 0 <= player < 3:
        raise ValueError('invalid player')
    winner, price = single_auction(bids, first_price=first_price)
    return t[player] - price if winner == player else 0


def _check_unit_profiles(profiles):
    if type(profiles) not in (tuple, list) or len(profiles) != 3:
        raise ValueError('need exactly 3 bidders')
    values = []
    for val in profiles:
        if type(val) not in (tuple, list) or len(val) != 2 or any(type(z) is not int or not 0 <= z <= 2 for z in val):
            raise ValueError('two item values must be integers 0, 1, 2')
        values.append(tuple(val))
    return tuple(values)


def assignment_welfare(allocation, profile, *, ignored_player=None):
    return sum(profile[agent][item] for item, agent in enumerate(allocation)
               if agent != -1 and agent != ignored_player)


def unit_outcome(reports):
    """Validate *before* memoization: Python treats 1 and 1.0 as equal cache keys."""
    return _unit_outcome_validated(_check_unit_profiles(reports))


@lru_cache(maxsize=None)
def _unit_outcome_validated(reports):
    # Fixed tie breaking via the first allocation in a permanent lexicographic list.
    assignment = max(ASSIGNMENTS, key=lambda a: assignment_welfare(a, reports))
    selected_total = assignment_welfare(assignment, reports)
    payments = []
    for i in range(3):
        without_i = max(assignment_welfare(a, reports, ignored_player=i)
                        for a in ASSIGNMENTS if i not in a)
        actual_other = assignment_welfare(assignment, reports, ignored_player=i)
        payments.append(without_i - actual_other)
    return assignment, tuple(payments), selected_total


def unit_utility(true_values, reports, player):
    truth = _check_unit_profiles(true_values)
    if type(player) is not int or not 0 <= player < 3:
        raise ValueError('invalid player')
    allocation, prices, _ = unit_outcome(_check_unit_profiles(reports))
    return sum(truth[player][item] for item, a in enumerate(allocation)
               if a == player) - prices[player]


def public_project(reports, *, cost=PROJECT_COST):
    reports = _check_3_ints(reports, 5)
    if type(cost) is not int or cost <= 0:
        raise ValueError('cost must be a positive integer')
    build = sum(reports) >= cost
    taxes = tuple(max(0, cost - (sum(reports) - reports[i])) if build else 0
                  for i in range(3))
    return build, taxes


def public_pivot_independent(reports, player, *, cost=PROJECT_COST):
    """Independent externality maximization including cost as planner welfare."""
    reports = _check_3_ints(reports, 5)
    if type(player) is not int or not 0 <= player < 3:
        raise ValueError('invalid player')
    other_total = sum(reports) - reports[player]
    w0 = max(0, other_total - cost)
    actual_w0 = (other_total - cost) if sum(reports) >= cost else 0
    return w0 - actual_w0


def public_utility(truth, reports, player, *, report_based_charge=False):
    truth = _check_3_ints(truth, 5)
    if type(player) is not int or not 0 <= player < 3:
        raise ValueError('invalid player')
    reports = _check_3_ints(reports, 5)
    built, tax = public_project(reports)
    fee = reports[player] if built and report_based_charge else tax[player]
    return (truth[player] if built else 0) - fee


def audit_single():
    checked = violations = ties = 0
    for truth in BID_PROFILES:
        for player in range(3):
            base = single_utility(truth, truth, player)
            for report in BIDS:
                new = list(truth); new[player] = report
                changed = single_utility(truth, new, player)
                checked += 1
                if changed > base:
                    violations += 1
                if changed == base and report != truth[player]:
                    ties += 1
    assert checked == 1875 and violations == 0
    return {'true_profiles': 125, 'deviation_comparisons': checked,
            'DSIC_violations': violations, 'weak_ties_nontruth': ties,
            'first_price_counterexample': {
                'values': [4, 1, 0], 'truthful_bid': 4,
                'truthful_utility': single_utility((4, 1, 0), (4, 1, 0), 0, first_price=True),
                'shaded_bid': 2, 'shaded_utility': single_utility((4, 1, 0), (2, 1, 0), 0, first_price=True)}}


def audit_unit():
    checked = violations = total_ir_violations = negative_payment = inefficient = 0
    price_not_second_highest_witness = None
    for truth in UNIT_PROFILES:
        alloc, payment, total = unit_outcome(truth)
        if total != max(assignment_welfare(a, truth) for a in ASSIGNMENTS):
            inefficient += 1
        for player in range(3):
            truthful_u = unit_utility(truth, truth, player)
            if truthful_u < 0:
                total_ir_violations += 1
            if payment[player] < 0:
                negative_payment += 1
            for r in UNIT_TYPES:
                bids = list(truth); bids[player] = r
                checked += 1
                if unit_utility(truth, bids, player) > truthful_u:
                    violations += 1
        if price_not_second_highest_witness is None:
            for item, winner in enumerate(alloc):
                if winner == -1:
                    continue
                # Scalar second-price across bidders for THIS item ignores unit-demand opportunity costs.
                simple_2nd = max(truth[j][item] for j in range(3) if j != winner)
                if payment[winner] != simple_2nd:
                    price_not_second_highest_witness = {
                        'true_type_profile': [list(x) for x in truth],
                        'assignment_A_B': list(alloc), 'winning_item': item,
                        'winner': winner, 'VCG_payment': payment[winner],
                        'per_item_second_highest_other': simple_2nd}
                if price_not_second_highest_witness:
                    break
    assert checked == 19683 and violations == 0
    return {'true_profiles': 729, 'feasible_allocations': len(ASSIGNMENTS),
            'deviation_comparisons': checked, 'DSIC_violations': violations,
            'true_profile_IR_violations': total_ir_violations,
            'negative_payment_cases': negative_payment,
            'inefficient_allocations': inefficient,
            'unit_demand_counterexample_to_separate_item_second_price': price_not_second_highest_witness}


def audit_public():
    checked = violations = inefficient = ir_violations = tax_disagreements = 0
    built = deficits = zero_taxes_built = 0
    worst_gap = 0
    for truth in PUBLIC_PROFILES:
        yes, tax = public_project(truth)
        if yes:
            built += 1
            balance = sum(tax) - PROJECT_COST
            if balance < 0:
                deficits += 1
            if sum(tax) == 0:
                zero_taxes_built += 1
            worst_gap = min(worst_gap, balance)
        if yes != (sum(truth) >= PROJECT_COST):
            inefficient += 1
        for i in range(3):
            if tax[i] != public_pivot_independent(truth, i):
                tax_disagreements += 1
            base = public_utility(truth, truth, i)
            if base < 0:
                ir_violations += 1
            for bid in PUBLIC_TYPES:
                alt = list(truth); alt[i] = bid
                checked += 1
                if public_utility(truth, alt, i) > base:
                    violations += 1
    assert checked == 3888 and violations == 0
    cases = {}
    for profile in ((5, 5, 5), (2, 2, 2), (4, 0, 0)):
        yes, tax = public_project(profile)
        cases[''.join(map(str, profile))] = {
            'build': yes, 'taxes': list(tax),
            'budget_balance': sum(tax) - (PROJECT_COST if yes else 0)}
    truth = (5, 5, 5)
    alternative = (0, 5, 5)
    return {'true_profiles': 216, 'deviation_comparisons': checked,
            'DSIC_violations': violations, 'inefficient_allocations': inefficient,
            'truthful_IR_violations': ir_violations,
            'independent_pivot_tax_mismatches': tax_disagreements,
            'project_built_profiles': built, 'budget_deficit_profiles': deficits,
            'zero_tax_built_profiles': zero_taxes_built,
            'minimum_budget_balance': worst_gap, 'constructed_budget_cases': cases,
            'nonpivot_pay_as_report_counterexample': {
                'values': list(truth), 'truthful_report': list(truth),
                'truthful_utility': public_utility(truth, truth, 0, report_based_charge=True),
                'deviation_report': list(alternative),
                'deviation_utility': public_utility(truth, alternative, 0, report_based_charge=True)}}


def calculate():
    return {'study': 'R138', 'sources': [
        'Vickrey 1961 DOI 10.1111/j.1540-6261.1961.tb02789.x',
        'Clarke 1971 DOI 10.1007/BF01726210',
        'Groves 1973 DOI 10.2307/1914085'],
        'auction': audit_single(), 'unit_demand_vcg': audit_unit(),
        'public_project_pivot': audit_public(),
        'total_unilateral_report_comparisons': 1875+19683+3888,
        'new_real_human_E2': 0, 'new_real_history_E3': 0,
        'R073': 'FROZEN', 'PESEN_v0_1': 'FROZEN'}


if __name__ == '__main__':
    print(json.dumps(calculate(), ensure_ascii=False, sort_keys=True, indent=2))
