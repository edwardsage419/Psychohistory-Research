"""Independent, exact tests: source eq1–4, original example, and NEW individual games."""
import unittest
from fractions import Fraction as F
from itertools import product
from r139_gordon1954_exact import Fishery, GRID, NS, BETAS, SCALES, discrete_game, run_study


class Gordon1954OriginalEquations(unittest.TestCase):
    def setUp(self): self.f=Fishery()
    def test_source_eq1_population_identity(self):
        for E in (F(0),F(1),F(8),F(32),F(64)):
            self.assertEqual(self.f.stock(E),self.f.a-self.f.beta*self.f.landings(E))
    def test_source_eq2_landings_identity(self):
        for E in (F(0),F(1),F(8),F(32),F(64)):
            self.assertEqual(self.f.landings(E),self.f.gamma*E*self.f.stock(E))
    def test_eq3_rent_is_net_landings(self):
        for E in (0,1,4,8,16,32):self.assertEqual(self.f.rent(E),self.f.landings(E)-E)
    def test_eq4_social_optimum_marginal_condition(self):self.assertEqual(self.f.marginal_landings(self.f.optimum_effort()),self.f.q)
    def test_optimum_effort_eight(self):self.assertEqual(self.f.optimum_effort(),8)
    def test_open_access_effort_thirty_two(self):self.assertEqual(self.f.open_access_effort(),32)
    def test_optimum_landings_twenty_four(self):self.assertEqual(self.f.landings(8),24)
    def test_open_access_landings_thirty_two(self):self.assertEqual(self.f.landings(32),32)
    def test_optimum_population_three(self):self.assertEqual(self.f.stock(8),3)
    def test_open_access_population_one(self):self.assertEqual(self.f.stock(32),1)
    def test_optimum_rent_sixteen(self):self.assertEqual(self.f.rent(8),16)
    def test_open_access_rent_zero(self):self.assertEqual(self.f.rent(32),0)
    def test_optimum_before_free_entry(self):self.assertLess(self.f.optimum_effort(),self.f.open_access_effort())
    def test_wealth_dissipation_distinct_from_max_landings(self):self.assertGreater(self.f.landings(32),self.f.landings(8))
    def test_average_greater_than_marginal_for_positive_effort(self):
        for E in (1,3,8,32):self.assertGreater(self.f.average_landings(E),self.f.marginal_landings(E))
    def test_avg_equals_marginal_at_zero(self):self.assertEqual(self.f.average_landings(0),self.f.marginal_landings(0))
    def test_social_rent_local_direction(self):
        self.assertLess(self.f.rent(F(15,2)),self.f.rent(8))
        self.assertLess(self.f.rent(F(17,2)),self.f.rent(8))
    def test_open_access_profit_sign_left_and_right(self):
        self.assertGreater(self.f.rent(31),0)
        self.assertLess(self.f.rent(33),0)
    def test_zero_effort_but_nonzero_population(self):self.assertEqual((self.f.landings(0),self.f.stock(0)),(0,9))
    def test_average_limit_when_no_one_fishes(self):self.assertEqual(self.f.average_landings(0),9)
    def test_stock_declines_when_effort_rises(self):self.assertGreater(self.f.stock(8),self.f.stock(32))
    def test_second_derivative_negative_as_secant(self):
        self.assertGreater(self.f.marginal_landings(1),self.f.marginal_landings(8))
    def test_nonrational_h_rejected_for_rational_closed_form(self):
        with self.assertRaises(ValueError):Fishery(a=2).optimum_effort()


class StrictInputAndFiniteGame(unittest.TestCase):
    def setUp(self):self.f=Fishery()
    def test_default_types_are_fraction(self):self.assertIs(type(self.f.a),F)
    def test_negative_parameter_rejected(self):
        for field in ('a','beta','gamma','q'):
            with self.subTest(field=field),self.assertRaises(ValueError):Fishery(**{field:-1})
    def test_zero_parameter_rejected(self):
        for field in ('a','beta','gamma','q'):
            with self.subTest(field=field),self.assertRaises(ValueError):Fishery(**{field:0})
    def test_no_positive_interior_when_production_under_cost(self):
        with self.assertRaises(ValueError):Fishery(a=1,beta=1,gamma=1,q=1)
    def test_float_parameters_rejected(self):
        for field in ('a','beta','gamma','q'):
            with self.subTest(field=field),self.assertRaises(TypeError):Fishery(**{field:1.0})
    def test_bool_parameters_rejected(self):
        for field in ('a','beta','gamma','q'):
            with self.subTest(field=field),self.assertRaises(TypeError):Fishery(**{field:True})
    def test_negative_effort_rejected(self):
        for method in (self.f.landings,self.f.stock,self.f.average_landings,self.f.marginal_landings,self.f.rent):
            with self.subTest(method=method),self.assertRaises(ValueError):method(-1)
    def test_float_effort_rejected(self):
        for method in (self.f.landings,self.f.stock,self.f.average_landings,self.f.marginal_landings,self.f.rent):
            with self.subTest(method=method),self.assertRaises(TypeError):method(1.0)
    def test_bool_effort_rejected(self):
        with self.assertRaises(TypeError):self.f.landings(True)
    def test_private_negative_component_rejected(self):
        with self.assertRaises(ValueError):self.f.private_payoff(1,(1,-2,3))
    def test_private_float_component_rejected(self):
        with self.assertRaises(TypeError):self.f.private_payoff(1,(1,2.0,3))
    def test_invalid_n_rejected(self):
        for n in (0,-1,1.0,True):
            with self.subTest(n=n),self.assertRaises(ValueError):self.f.finite_sym_nash_z_interval(n)
    def test_invalid_steps_rejected(self):
        for n in (0,1,True,F(3)):
            with self.subTest(n=n),self.assertRaises(ValueError):self.f.finite_sym_nash_z_interval(3,n)
    def test_wrong_grid_order_rejected(self):
        for grid in ([2,0],[0,1,1],[-1,0],[1,2.0]):
            with self.subTest(grid=grid),self.assertRaises((TypeError,ValueError)):discrete_game(grid=grid)
    def test_individual_payoff_sum_is_social_rent(self):
        for x in ((0,0,0),(2,4,6),(6,8,8),(16,16,16)):
            self.assertEqual(sum(self.f.private_payoff(e,x) for e in x),self.f.rent(sum(x)))
    def test_individual_payoff_when_zero_effort(self):self.assertEqual(self.f.private_payoff(0,(0,8,8)),0)
    def test_per_effort_tax_at_optimum_for_three(self):self.assertEqual(self.f.optimum_linear_per_effort_fee(3),F(4,3))
    def test_per_effort_tax_at_optimum_for_eight(self):self.assertEqual(self.f.optimum_linear_per_effort_fee(8),F(7,4))
    def test_per_effort_tax_at_optimum_single_user_zero(self):self.assertEqual(self.f.optimum_linear_per_effort_fee(1),0)
    def test_per_effort_fee_exactly_nulls_user_marginal_gain(self):
        E=self.f.optimum_effort()
        A=self.f.average_landings(E)
        Aprime=-self.f.gamma**2*self.f.a*self.f.beta/(1+self.f.gamma*self.f.beta*E)**2
        for n in (1,2,3,4,8):
            t=self.f.optimum_linear_per_effort_fee(n)
            self.assertEqual(A-self.f.q+F(E,n)*Aprime-t,0)
    def test_discrete_profile_count(self):self.assertEqual(discrete_game()['profiles'],729)
    def test_discrete_unilateral_checks(self):self.assertEqual(discrete_game()['unilateral_checks'],17496)
    def test_discrete_ne_are_three_permutations(self):
        actual=discrete_game()
        self.assertEqual(set(actual['equilibria']),set(((6,8,8),(8,6,8),(8,8,6))))
    def test_discrete_eq_rent(self):self.assertEqual(discrete_game()['equilibrium_rents'],[F(110,13)])
    def test_discrete_social_max(self):self.assertEqual(discrete_game()['optimal_rent'],16)
    def test_discrete_social_max_profile_count(self):self.assertEqual(len(discrete_game()['optimal_profiles']),15)
    def test_discrete_private_gain_at_social_max(self):
        baseline=(0,0,8)
        self.assertGreater(self.f.private_payoff(2,(2,0,8)),self.f.private_payoff(0,baseline))
    def test_open_access_limit_bracket_at_n32(self):
        lo,hi=self.f.finite_sym_nash_effort_interval(32)
        self.assertGreater(lo,31)
        self.assertLess(hi,32)
    def test_monotonic_rent_from_n2_to_n32(self):
        earlier=self.f.rent(self.f.finite_sym_nash_effort_interval(2)[0])
        later=self.f.rent(self.f.finite_sym_nash_effort_interval(32)[0])
        self.assertLess(later,earlier)
    def test_bracket_straddles_independently_computed_FOC(self):
        for n in (2,3,8,32):
            low,high=self.f.finite_sym_nash_effort_interval(n)
            def marginal_private(E):
                ap=self.f.average_landings(E)
                der=-self.f.gamma**2*self.f.a*self.f.beta/(1+self.f.gamma*self.f.beta*E)**2
                return ap-self.f.q+E*der/n
            self.assertGreaterEqual(marginal_private(low),0)
            self.assertLessEqual(marginal_private(high),0)
    def test_root_intervals_not_mislabeled_exact_rationals(self):
        lo,hi=self.f.finite_sym_nash_effort_interval(3)
        self.assertLess(lo,hi)
        self.assertLess(hi-lo,F(1,10**20))
    def test_run_reports_no_new_real_empirical(self):
        j=run_study();self.assertEqual((j['E2_new_person_level_predictions'],j['E3_new_historical_probabilistic_predictions']), (0,0))
    def test_run_reproduces_original_equations(self):
        j=run_study();self.assertEqual((j['original_case']['optimum_effort'],j['original_case']['open_access_effort']),('8','32'))
    def test_run_parameter_sweep_count(self):self.assertEqual(run_study()['parameter_sweep_count'],96)
    def test_run_discrete_count(self):
        j=run_study();self.assertEqual((j['discrete_three_player']['profiles'],j['discrete_three_player']['unilateral_deviation_checks']),(729,17496))


def _source_derived_parameter_case(a,beta):
    def test(self):
        f=Fishery(a=a,beta=beta)
        self.assertEqual(f.marginal_landings(f.optimum_effort()),1)
        self.assertEqual(f.rent(f.open_access_effort()),0)
        self.assertGreater(f.rent(f.optimum_effort()),0)
        prior_effort=None
        for n in NS:
            lo,hi=f.finite_sym_nash_effort_interval(n,90)
            if n == 1:self.assertEqual((lo,hi),(f.optimum_effort(),f.optimum_effort()))
            else:
                self.assertLess(f.optimum_effort(),lo)
                self.assertLessEqual(hi,f.open_access_effort())
                self.assertGreater(f.root_poly(n,1+f.gamma*f.beta*hi),-F(1,10**10))
            if prior_effort is not None:self.assertGreater(lo,prior_effort)
            prior_effort=lo
    return test

for _a,_b in product(SCALES,BETAS):
    setattr(StrictInputAndFiniteGame,'test_analytic_12param_a{}_beta{}_{}'.format(_a,_b.numerator,_b.denominator),_source_derived_parameter_case(_a,_b))

if __name__=='__main__':unittest.main()
