"""R139: Gordon 1954 original fisheries equations plus explicitly NEW finite-user CPR games.

Every calculated number is a Fraction unless a boolean/count or formatted rational string.
The source 1954 paper did not develop this n-player proportional-sharing game.
"""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction as F
from itertools import product
from math import isqrt
import json

GRID = tuple(range(0, 17, 2))
SCALES = (4, 9, 16, 25)
BETAS = (F(1, 8), F(1, 4), F(1, 2))
NS = (1, 2, 3, 4, 5, 8, 16, 32)


def valid_fraction(x, positive=False):
    if type(x) not in (int, F):
        raise TypeError('only exact integer or Fraction inputs are allowed')
    if positive and x <= 0:
        raise ValueError('expected a strictly positive parameter')
    return F(x)


@dataclass(frozen=True)
class Fishery:
    a: F = F(9)
    beta: F = F(1, 4)
    gamma: F = F(1)
    q: F = F(1)

    def __post_init__(self):
        for name in ('a','beta','gamma','q'):
            object.__setattr__(self, name, valid_fraction(getattr(self,name), True))
        if self.gamma*self.a <= self.q:
            raise ValueError('positive interior open-access effort requires gamma*a>q')

    @property
    def H(self):
        return self.gamma*self.a/self.q

    def landings(self,E):
        E=valid_fraction(E)
        if E < 0: raise ValueError('effort cannot be negative')
        return self.gamma*self.a*E/(1+self.gamma*self.beta*E)

    def stock(self,E):
        E=valid_fraction(E)
        if E < 0: raise ValueError('effort cannot be negative')
        return self.a/(1+self.gamma*self.beta*E)

    def average_landings(self,E):
        E=valid_fraction(E)
        if E < 0: raise ValueError('effort cannot be negative')
        return self.gamma*self.a/(1+self.gamma*self.beta*E)

    def marginal_landings(self,E):
        E=valid_fraction(E)
        if E < 0: raise ValueError('effort cannot be negative')
        return self.gamma*self.a/(1+self.gamma*self.beta*E)**2

    def rent(self,E):
        return self.landings(E)-self.q*valid_fraction(E)

    def open_access_effort(self):
        return (self.H-1)/(self.gamma*self.beta)

    def optimum_effort(self):
        H=self.H
        up,down=isqrt(H.numerator),isqrt(H.denominator)
        if up*up!=H.numerator or down*down!=H.denominator:
            raise ValueError('exact rational optimum in this implementation requires a rational square H')
        return (F(up,down)-1)/(self.gamma*self.beta)

    def private_payoff(self,e,all_efforts, tax=F(0)):
        e=valid_fraction(e)
        total=F(0)
        for x in all_efforts:
            x=valid_fraction(x)
            if x < 0: raise ValueError('effort must be nonnegative')
            total+=x
        if e < 0: raise ValueError('negative private effort')
        tax=valid_fraction(tax)
        return e*(self.average_landings(total)-self.q-tax)

    def optimum_linear_per_effort_fee(self,n):
        if type(n) is not int or n <=0: raise ValueError('n must be positive integer')
        E=self.optimum_effort()
        minus_AP_prime=self.gamma**2*self.a*self.beta/(1+self.gamma*self.beta*E)**2
        return (1-F(1,n))*E*minus_AP_prime

    def root_poly(self, n, z):
        if type(n) is not int or n <=0:raise ValueError('n positive integer only')
        z=valid_fraction(z)
        return n*z*z-self.H*(n-1)*z-self.H

    def finite_sym_nash_z_interval(self,n,steps=100):
        if type(n) is not int or n<=0: raise ValueError('n positive integer only')
        if type(steps) is not int or steps<2: raise ValueError('steps >=2 integer')
        if n == 1:
            exact_E = self.optimum_effort()
            z = 1 + self.gamma*self.beta*exact_E
            assert self.root_poly(n,z)==0
            return z,z
        lo,hi=F(1),self.H
        assert self.root_poly(n,lo)<0<self.root_poly(n,hi)
        for _ in range(steps):
            mid=(lo+hi)/2
            p=self.root_poly(n,mid)
            if p==0:return mid,mid
            if p<0:lo=mid
            else:hi=mid
        return lo,hi

    def finite_sym_nash_effort_interval(self,n,steps=100):
        lo,hi=self.finite_sym_nash_z_interval(n,steps)
        k=self.gamma*self.beta
        return (lo-1)/k,(hi-1)/k


def discrete_game(fish=Fishery(),grid=GRID):
    if not isinstance(fish,Fishery):raise TypeError('Fishery required')
    if not isinstance(grid,(list,tuple)) or len(grid)<2:raise ValueError('grid must be ordered list or tuple')
    grid=tuple(valid_fraction(x) for x in grid)
    if list(grid)!=sorted(set(grid)) or grid[0]<0:raise ValueError('grid must be sorted, nonnegative, unique')
    equilibria=[]
    optimal=[]
    maxrent=None
    profiles=0
    unilateral_checks=0
    profitable_deviations_total=0
    max_deviation_gain=F(0)
    for profile in product(grid,repeat=3):
        profiles+=1
        E=sum(profile)
        welfare=fish.rent(E)
        if maxrent is None or welfare>maxrent:
            maxrent=welfare
            optimal=[profile]
        elif welfare==maxrent:
            optimal.append(profile)
        is_eq=True
        for i in range(3):
            baseline=fish.private_payoff(profile[i],profile)
            for alternative in grid:
                if alternative==profile[i]:continue
                unilateral_checks+=1
                other=list(profile)
                other[i]=alternative
                payoff=fish.private_payoff(alternative,other)
                if payoff>baseline:
                    is_eq=False
                    profitable_deviations_total+=1
                    if payoff-baseline>max_deviation_gain:
                        max_deviation_gain=payoff-baseline
        if is_eq:equilibria.append(profile)
    return dict(grid_size=len(grid),profiles=profiles,unilateral_checks=unilateral_checks,
                positive_gain_deviation_comparisons=profitable_deviations_total,
                equilibria=equilibria,optimal_profiles=optimal,optimal_rent=maxrent,
                equilibrium_rents=sorted({fish.rent(sum(e)) for e in equilibria}),
                max_gain=max_deviation_gain)


def fracstr(v):return str(v)


def run_study():
    fish=Fishery()
    result=dict(source='Gordon 1954, DOI 10.1086/257497, original printed pp130,131,141,142',
                model_boundary='original Gordon eq1-4; project-created 1954-inspired n-player proportional harvest extension',
                original_case={
                    'a':str(fish.a),'beta':str(fish.beta),'gamma':str(fish.gamma),'q':str(fish.q),
                    'optimum_effort':str(fish.optimum_effort()),
                    'open_access_effort':str(fish.open_access_effort()),
                    'optimum_rent':str(fish.rent(fish.optimum_effort())),
                    'open_access_rent':str(fish.rent(fish.open_access_effort())),
                    'optimum_landings':str(fish.landings(fish.optimum_effort())),
                    'open_access_landings':str(fish.landings(fish.open_access_effort())),
                    'optimum_stock':str(fish.stock(fish.optimum_effort())),
                    'open_access_stock':str(fish.stock(fish.open_access_effort())),
                    'optimum_per_unit_fee_n3':str(fish.optimum_linear_per_effort_fee(3)),
                    'optimum_per_unit_fee_n8':str(fish.optimum_linear_per_effort_fee(8)),
                },
                numerical_fraction_intervals=[],
                parameter_sweep_count=0,
                all_finite_n_root_brackets_verified=True,
                exact_finite_population_threshold_evidence_only=True,
                E2_new_person_level_predictions=0,E3_new_historical_probabilistic_predictions=0,
                R073='FROZEN',PESEN_v0_1='FROZEN')
    base=fish
    for a,beta in product(SCALES,BETAS):
        p=Fishery(a=F(a),beta=beta)
        previous_lo=None
        previous_rent_upper=None
        for n in NS:
            lo,hi=p.finite_sym_nash_effort_interval(n,100)
            Eopt,Eopen=p.optimum_effort(),p.open_access_effort()
            if n==1:assert lo==hi==Eopt
            if n>1:
                assert Eopt<lo<=hi<Eopen
            zlo=1+p.gamma*p.beta*lo
            zhi=1+p.gamma*p.beta*hi
            assert p.root_poly(n,zlo)<=0<=p.root_poly(n,zhi)
            assert hi-lo <= (p.H-1)/(p.gamma*p.beta*2**100)
            if previous_lo is not None:assert lo>previous_lo
            if previous_rent_upper is not None:assert p.rent(lo)<previous_rent_upper
            previous_lo=lo
            previous_rent_upper=p.rent(lo)
            if a==9 and beta==F(1,4):
                result['numerical_fraction_intervals'].append({'n':n,'effort_lo':str(lo),'effort_hi':str(hi),
                 'rent_lo':str(p.rent(hi)),'rent_hi':str(p.rent(lo)),
                 'effort_approx':format(float((lo+hi)/2),'.12f')})
            result['parameter_sweep_count']+=1
    disc=discrete_game()
    result['discrete_three_player']={
        'grid':[str(x) for x in GRID],
        'profiles':disc['profiles'],
        'unilateral_deviation_checks':disc['unilateral_checks'],
        'profitable_deviation_comparisons':disc['positive_gain_deviation_comparisons'],
        'equilibria_count':len(disc['equilibria']),
        'equilibria':[[str(x) for x in e] for e in disc['equilibria']],
        'optimal_count':len(disc['optimal_profiles']),
        'optimal_profile_examples':[[str(x) for x in e] for e in disc['optimal_profiles'][:15]],
        'social_optimal_rent':str(disc['optimal_rent']),
        'equilibrium_rents':[str(x) for x in disc['equilibrium_rents']],
        'max_single_deviation_gain':str(disc['max_gain'])}
    return result


if __name__=='__main__':
    print(json.dumps(run_study(),ensure_ascii=False,sort_keys=True,indent=2))
