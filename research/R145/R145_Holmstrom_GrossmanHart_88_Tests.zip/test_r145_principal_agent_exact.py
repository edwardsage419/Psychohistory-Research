"""Exact R145 unit tests; every generated test is a real unittest method."""
from fractions import Fraction as F
from itertools import permutations
import unittest
import r145_principal_agent_exact as m

class CoreTests(unittest.TestCase):
    def test_01_base_high_normalized(self):self.assertEqual(sum(m.BASE_H),1)
    def test_02_base_low_normalized(self):self.assertEqual(sum(m.BASE_L),1)
    def test_03_red_high_normalized(self):self.assertEqual(sum(m.RED_H),1)
    def test_04_red_low_normalized(self):self.assertEqual(sum(m.RED_L),1)
    def test_05_inf_high_normalized(self):self.assertEqual(sum(m.INF_H),1)
    def test_06_inf_low_normalized(self):self.assertEqual(sum(m.INF_L),1)
    def test_07_red_high_y_marginal(self):self.assertEqual((sum(m.RED_H[:2]),sum(m.RED_H[2:])),m.BASE_H)
    def test_08_red_low_y_marginal(self):self.assertEqual((sum(m.RED_L[:2]),sum(m.RED_L[2:])),m.BASE_L)
    def test_09_inf_high_y_marginal(self):self.assertEqual((sum(m.INF_H[:2]),sum(m.INF_H[2:])),m.BASE_H)
    def test_10_inf_low_y_marginal(self):self.assertEqual((sum(m.INF_L[:2]),sum(m.INF_L[2:])),m.BASE_L)
    def test_11_red_uninformative(self):self.assertTrue(m.monitor_redundant(m.RED_H,m.RED_L))
    def test_12_inf_informative(self):self.assertFalse(m.monitor_redundant(m.INF_H,m.INF_L))
    def test_13_base_KKT(self):self.assertTrue(m.check_kkt(m.BASE_H,m.BASE_L,m.optimal_contract(m.BASE_H,m.BASE_L)))
    def test_14_red_KKT(self):self.assertTrue(m.check_kkt(m.RED_H,m.RED_L,m.optimal_contract(m.RED_H,m.RED_L)))
    def test_15_inf_KKT(self):self.assertTrue(m.check_kkt(m.INF_H,m.INF_L,m.optimal_contract(m.INF_H,m.INF_L)))
    def test_16_exact_output_utilities(self):self.assertEqual(m.optimal_contract(m.BASE_H,m.BASE_L)['utilities'],(F(7,8),F(3,8)))
    def test_17_exact_output_wages(self):self.assertEqual(m.optimal_contract(m.BASE_H,m.BASE_L)['wages'],(F(49,64),F(9,64)))
    def test_18_exact_cost(self):self.assertEqual(m.optimal_contract(m.BASE_H,m.BASE_L)['cost'],F(39,64))
    def test_19_exact_red_equal(self):self.assertEqual(m.optimal_contract(m.RED_H,m.RED_L)['cost'],F(39,64))
    def test_20_red_clone_contract(self):self.assertEqual(m.optimal_contract(m.RED_H,m.RED_L)['utilities'],(F(7,8),F(7,8),F(3,8),F(3,8)))
    def test_21_exact_informative_cost(self):self.assertEqual(m.optimal_contract(m.INF_H,m.INF_L)['cost'],F(5505,9104))
    def test_22_exact_informative_utilities(self):self.assertEqual(m.optimal_contract(m.INF_H,m.INF_L)['utilities'],(F(2043,2276),F(1803,2276),F(555,2276),F(1067,2276)))
    def test_23_exact_info_saving(self):self.assertEqual(m.optimal_contract(m.BASE_H,m.BASE_L)['cost']-m.optimal_contract(m.INF_H,m.INF_L)['cost'],F(171,36416))
    def test_24_first_best_cost(self):self.assertEqual((F(1,2)+F(1,4))**2,F(9,16))
    def test_25_base_premium(self):self.assertEqual(F(39,64)-F(9,16),F(3,64))
    def test_26_base_high_net_profit(self):self.assertEqual(F(3,2)-F(39,64),F(57,64))
    def test_27_low_action_net_profit(self):self.assertEqual(F(1,2)-F(1,4),F(1,4))
    def test_28_choose_high_action(self):self.assertGreater(F(57,64),F(1,4))
    def test_29_IR_binding(self):self.assertEqual(m.optimal_contract(m.BASE_H,m.BASE_L)['ir_lhs'],F(3,4))
    def test_30_IC_binding(self):self.assertEqual(m.optimal_contract(m.BASE_H,m.BASE_L)['ic_lhs'],F(1,4))
    def test_31_zero_cost_flat(self):self.assertEqual(m.optimal_contract(m.BASE_H,m.BASE_L,F(0))['utilities'],(F(1,2),)*2)
    def test_32_zero_cost_no_info_value(self):self.assertEqual(m.optimal_contract(m.BASE_H,m.BASE_L,F(0))['cost'],m.optimal_contract(m.INF_H,m.INF_L,F(0))['cost'])
    def test_33_impossible_effort(self):self.assertIsNone(m.optimal_contract((F(1,2),)*2,(F(1,2),)*2))
    def test_34_impossible_iff_cost_positive(self):self.assertTrue(m.check_kkt((F(1,2),)*2,(F(1,2),)*2,m.optimal_contract((F(1,2),)*2,(F(1,2),)*2,F(0)),F(0)))
    def test_35_source_data_vs_authors(self):self.assertFalse(m.study()['source_original_authors_numerical_cases_reproduced'])
    def test_36_fiscal_costs_separate(self):self.assertEqual(F(m.study()['monitor_fee_sensitivity'][0]['monitor_fee']),F(0))
    def test_37_monitor_fee_64_no_advantage(self):self.assertFalse(next(x['better_than_no_monitor'] for x in m.study()['monitor_fee_sensitivity'] if x['monitor_fee']=='1/64'))
    def test_38_monitor_free_advantage(self):self.assertTrue(next(x['better_than_no_monitor'] for x in m.study()['monitor_fee_sensitivity'] if x['monitor_fee']=='0'))
    def test_39_ic_is_weak_not_strict(self):self.assertFalse(m.study()['strict_IC_guaranteed'])
    def test_40_new_human_zero(self):self.assertEqual(m.study()['new_E2_real_person_predictions'],0)
    def test_41_new_history_zero(self):self.assertEqual(m.study()['new_E3_historical_event_predictions'],0)
    def test_42_negative_disutility_rejected(self):
        with self.assertRaises(ValueError):m.optimal_contract(m.BASE_H,m.BASE_L,F(-1,8))
    def test_43_negative_reservation_rejected(self):
        with self.assertRaises(ValueError):m.optimal_contract(m.BASE_H,m.BASE_L,F(1,4),F(-1,8))
    def test_44_mismatch_states_rejected(self):
        with self.assertRaises(ValueError):m.optimal_contract(m.BASE_H,m.INF_L)
    def test_45_normalization_rejected(self):
        with self.assertRaises(ValueError):m.optimal_contract((F(1,3),F(1,3)),m.BASE_L)
    def test_46_zero_probability_rejected(self):
        with self.assertRaises(ValueError):m.optimal_contract((F(1),F(0)),m.BASE_L)
    def test_47_float_probability_rejected(self):
        with self.assertRaises(TypeError):m.optimal_contract((0.75,0.25),m.BASE_L)
    def test_48_bool_probability_rejected(self):
        with self.assertRaises(TypeError):m.optimal_contract((True,F(0)),m.BASE_L)
    def test_49_float_effort_rejected(self):
        with self.assertRaises(TypeError):m.optimal_contract(m.BASE_H,m.BASE_L,0.25)
    def test_50_bool_reservation_rejected(self):
        with self.assertRaises(TypeError):m.optimal_contract(m.BASE_H,m.BASE_L,F(1,4),True)
    def test_51_float_pretends_cached_integer_rejected(self):
        with self.assertRaises(TypeError):m.optimal_contract((F(1,2),F(1,2)),(1.,0.))
    def test_52_dual_certificate_zero_residual(self):
        s=m.optimal_contract(m.INF_H,m.INF_L)
        self.assertEqual(sum(s['nu_nonnegative']),F(0))
    def test_53_informative_all_positive(self):
        self.assertTrue(all(v>0 for v in m.optimal_contract(m.INF_H,m.INF_L)['utilities']))
    def test_54_jensen_clone(self):
        v=m.optimal_contract(m.RED_H,m.RED_L)['utilities']
        self.assertEqual(v[0],v[1]);self.assertEqual(v[2],v[3])
    def test_55_full_outcome_best_response_independently(self):
        s=m.optimal_contract(m.BASE_H,m.BASE_L)
        self.assertEqual((m.BASE_H[0]-m.BASE_L[0])*(s['utilities'][0]-s['utilities'][1]),F(1,4))
    def test_56_monitor_conditional_likelihood_ratios(self):
        self.assertNotEqual(m.INF_H[0]/m.INF_L[0],m.INF_H[1]/m.INF_L[1])
        self.assertNotEqual(m.INF_H[2]/m.INF_L[2],m.INF_H[3]/m.INF_L[3])
    def test_57_objective_from_wages(self):
        s=m.optimal_contract(m.INF_H,m.INF_L)
        self.assertEqual(sum(x*y for x,y in zip(m.INF_H,s['wages'])),s['cost'])
    def test_58_no_two_state_grid_improvement(self):
        # Independent coarse finite grid; global proof comes from exact KKT.
        optimum=m.optimal_contract(m.BASE_H,m.BASE_L)['cost']
        for a in range(17):
            for b in range(17):
                v0,v1=F(a,8),F(b,8)
                if sum(x*y for x,y in zip(m.BASE_H,(v0,v1))) < F(3,4):continue
                if (m.BASE_H[0]-m.BASE_L[0])*(v0-v1)<F(1,4):continue
                self.assertGreaterEqual(m.BASE_H[0]*v0*v0+m.BASE_H[1]*v1*v1,optimum)
    def test_59_kkt_not_false_certificate(self):
        x=dict(m.optimal_contract(m.BASE_H,m.BASE_L))
        x['mu_ic']=F(0)
        self.assertFalse(m.check_kkt(m.BASE_H,m.BASE_L,x))
    def test_60_serialization_complete(self):
        x=m.study();self.assertEqual(len(x['cost_sensitivity']),4);self.assertEqual(len(x['monitor_fee_sensitivity']),6)

# 24 separately executable signal-cell permutations: exact likelihood/moral hazard should be label-invariant.
def make_permutation_test(perm):
    def test(self):
        ph=tuple(m.INF_H[i] for i in perm)
        pl=tuple(m.INF_L[i] for i in perm)
        sol=m.optimal_contract(ph,pl)
        self.assertIsNotNone(sol)
        self.assertEqual(sol['cost'],F(5505,9104))
        self.assertTrue(m.check_kkt(ph,pl,sol))
    return test
for k,perm in enumerate(permutations(range(4))):
    setattr(CoreTests,'test_61_permutation_%02d'%k,make_permutation_test(perm))

# 4 additional scenario-specific KKT independent tests.
def make_sensitivity_test(cost):
    def test(self):
        b=m.optimal_contract(m.BASE_H,m.BASE_L,cost)
        i=m.optimal_contract(m.INF_H,m.INF_L,cost)
        self.assertTrue(m.check_kkt(m.BASE_H,m.BASE_L,b,cost))
        self.assertTrue(m.check_kkt(m.INF_H,m.INF_L,i,cost))
        self.assertGreaterEqual(b['cost'],i['cost'])
    return test
for k,cost in enumerate((F(0),F(1,8),F(1,4),F(3,8))):
    setattr(CoreTests,'test_85_sensitivity_%02d'%k,make_sensitivity_test(cost))

if __name__=='__main__':unittest.main()
