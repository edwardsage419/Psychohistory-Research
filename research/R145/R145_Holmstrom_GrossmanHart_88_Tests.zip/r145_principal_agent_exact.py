"""R145: exact finite hidden-action moral hazard contracts.

Study-generated pedagogical examples, NOT a re-run of Holmstrom (1979) or
Grossman-Hart (1983) original numerical programs. Python standard library.
"""
from fractions import Fraction as F
from itertools import combinations, product, permutations
from functools import lru_cache
import json

U0=F(1,2)
BASE_H=(F(3,4),F(1,4))
BASE_L=(F(1,4),F(3,4))
RED_H=(F(3,8),F(3,8),F(1,8),F(1,8))
RED_L=(F(1,8),F(1,8),F(3,8),F(3,8))
INF_H=(F(1,2),F(1,4),F(1,16),F(3,16))
INF_L=(F(1,16),F(3,16),F(1,4),F(1,2))


def _validate_probability_distribution(p):
    if not isinstance(p, (tuple,list)) or not p:
        raise ValueError('probabilities must be nonempty tuple/list')
    if any(not isinstance(x,F) or isinstance(x,bool) for x in p):
        raise TypeError('probability entries must be Fraction instances')
    if any(x<=0 for x in p) or sum(p)!=1:
        raise ValueError('probabilities must be positive and sum to one')
    return tuple(p)


def _linear_solve(A,b):
    """Rational square nonsingular linear equation solver."""
    n=len(b)
    if len(A)!=n or any(len(row)!=n for row in A): raise ValueError('square matrix required')
    t=[list(row)+[b[i]] for i,row in enumerate(A)]
    for k in range(n):
        pivot=next((r for r in range(k,n) if t[r][k]),None)
        if pivot is None: return None
        t[k],t[pivot]=t[pivot],t[k]
        mul=t[k][k]
        t[k]=[x/mul for x in t[k]]
        for r in range(n):
            if r==k: continue
            mul=t[r][k]
            if mul:t[r]=[t[r][j]-mul*t[k][j] for j in range(n+1)]
    return tuple(t[i][-1] for i in range(n))


def _optimal_contract_exact(p_high,p_low,cost=F(1,4),reservation=U0):
    n=len(p_high)
    d=tuple(a-b for a,b in zip(p_high,p_low))
    constraints=(tuple(p_high),d)
    targets=(reservation+cost,cost)
    best=None
    for supp_mask in range(1,1<<n):
        S=[i for i in range(n) if supp_mask>>i & 1]
        for active_mask in (1,2,3):
            J=[j for j in range(2) if active_mask>>j & 1]
            # v_i = 1/(2p_i) * sum active lambda_j constraint_j_i.
            M=[[sum(constraints[j][i]*constraints[k][i]/(2*p_high[i]) for i in S) for k in J] for j in J]
            sol=_linear_solve(M,[targets[j] for j in J])
            if sol is None: continue
            mult=[F(0),F(0)]
            for j,val in zip(J,sol):mult[j]=val
            if any(x<0 for x in mult):continue
            v=tuple(sum(mult[j]*constraints[j][i] for j in J)/(2*p_high[i]) if i in S else F(0) for i in range(n))
            if any(v[i]<=0 for i in S):continue
            value=tuple(sum(constraints[j][i]*v[i] for i in range(n)) for j in range(2))
            if any(value[j]<targets[j] for j in range(2)):continue
            if any(mult[j] and value[j]!=targets[j] for j in range(2)):continue
            nu=tuple(2*p_high[i]*v[i]-mult[0]*p_high[i]-mult[1]*d[i] for i in range(n))
            if any(a<0 for a in nu) or any(nu[i]*v[i] for i in range(n)):
                continue
            obj=sum(p_high[i]*v[i]*v[i] for i in range(n))
            cert={"utilities":v,"wages":tuple(x*x for x in v),"ir_lhs":value[0],"ic_lhs":value[1],"cost":obj,
                  "lambda_ir":mult[0],"mu_ic":mult[1],"nu_nonnegative":nu,"support_mask":supp_mask}
            if best is None or obj<best['cost']:best=cert
    return best


def optimal_contract(p_high,p_low,cost=F(1,4),reservation=U0):
    """Exact convex global optimizer, evidenced by KKT primal-dual certificate."""
    a=_validate_probability_distribution(p_high)
    b=_validate_probability_distribution(p_low)
    if len(a)!=len(b):raise ValueError('state count mismatch')
    if not isinstance(cost,F) or not isinstance(reservation,F):raise TypeError('Fraction required')
    if cost<0 or reservation<0:raise ValueError('negative utility or disutility')
    # Validate all inputs BEFORE caching: don't allow Python integer/float/bool aliasing.
    return _optimal_contract_exact(a,b,cost,reservation)


def check_kkt(pH,pL,contract,cost=F(1,4),reservation=U0):
    if contract is None:return False
    v=contract['utilities'];n=len(v);d=tuple(x-y for x,y in zip(pH,pL))
    lam=contract['lambda_ir'];mu=contract['mu_ic'];nu=contract['nu_nonnegative']
    if len(nu)!=n or min(v)<0 or min(nu)<0 or lam<0 or mu<0:return False
    IR=sum(pH[i]*v[i] for i in range(n))
    IC=sum(d[i]*v[i] for i in range(n))
    if IR<reservation+cost or IC<cost:return False
    if lam*(IR-reservation-cost) or mu*(IC-cost):return False
    if any(nu[i]*v[i] for i in range(n)):return False
    if any(2*pH[i]*v[i]-lam*pH[i]-mu*d[i]-nu[i] for i in range(n)):return False
    return sum(pH[i]*v[i]**2 for i in range(n))==contract['cost']


def monitor_redundant(pH,pL):
    return all(pH[2*i]*pL[2*i+1]==pH[2*i+1]*pL[2*i] for i in (0,1))


def _s(s):return str(s) if not isinstance(s,bool) else str(s)


def contract_to_json(sol):
    if sol is None:return {"feasible":False}
    return {"feasible":True,"utilities":list(map(str,sol['utilities'])),"wages":list(map(str,sol['wages'])),
            "expected_wage":str(sol['cost']),"ir_lhs":str(sol['ir_lhs']),"ic_lhs":str(sol['ic_lhs']),
            "lambda_ir":str(sol['lambda_ir']),"mu_ic":str(sol['mu_ic']),
            "nu_nonnegative":list(map(str,sol['nu_nonnegative'])),"support_mask":sol['support_mask']}


def study():
    b=optimal_contract(BASE_H,BASE_L)
    r=optimal_contract(RED_H,RED_L)
    i=optimal_contract(INF_H,INF_L)
    assert check_kkt(BASE_H,BASE_L,b) and check_kkt(RED_H,RED_L,r) and check_kkt(INF_H,INF_L,i)
    assert b['cost']==r['cost']
    assert i['cost']<b['cost']
    fees=[F(0),F(1,64),F(1,32),F(1,16),F(1,8),F(1,4)]
    bf=F(3,2)-b['cost'];lowprofit=F(1,4)
    info=[{'monitor_fee':str(f),'principal_high_net':str(F(3,2)-i['cost']-f),'better_than_no_monitor':(i['cost']+f<b['cost']),
            'better_than_low_effort':(F(3,2)-i['cost']-f>lowprofit)} for f in fees]
    sensitivities=[]
    for effort_cost in (F(0),F(1,8),F(1,4),F(3,8)):
        bb=optimal_contract(BASE_H,BASE_L,effort_cost)
        ii=optimal_contract(INF_H,INF_L,effort_cost)
        assert check_kkt(BASE_H,BASE_L,bb,effort_cost)
        assert check_kkt(INF_H,INF_L,ii,effort_cost)
        sensitivities.append({'effort_cost':str(effort_cost),'base':contract_to_json(bb), 'informative':contract_to_json(ii),
                              'monitor_saving':str(bb['cost']-ii['cost']),
                              'first_best_wage':str((U0+effort_cost)**2),
                              'base_moral_hazard_premium':str(bb['cost']-(U0+effort_cost)**2)})
    impossible=optimal_contract((F(1,2),F(1,2)),(F(1,2),F(1,2)))
    assert impossible is None
    return {'research':'R145','date':'2026-10-20','source_formulation':'Holmstrom (1979) Eq1-3 and Eq13/16-17, Props 3; Grossman Hart (1983) convex fixed-action method',
            'source_original_authors_numerical_cases_reproduced':False,
            'all_probabilities_are_study_constructed':True,'agent_utility':'sqrt(w)-effort_cost','high_effort_cost':'1/4','reservation':'1/2',
            'high_success':'3/4','low_success':'1/4','gross_high_expected_revenue':'3/2',
            'source_contract_output_only':contract_to_json(b),'source_contract_redundant_monitor':contract_to_json(r),
            'source_contract_informative_monitor':contract_to_json(i),
            'redundant_signal_conditionally_uninformative':monitor_redundant(RED_H,RED_L),
            'informative_signal_conditionally_uninformative':monitor_redundant(INF_H,INF_L),
            'monitor_saving':str(b['cost']-i['cost']),
            'first_best_high_wage_cost':'9/16','no_monitor_high_profit':str(bf),
            'low_action_flat_wage_cost':'1/4','low_action_profit':str(lowprofit),
            'monitor_fee_sensitivity':info,'cost_sensitivity':sensitivities,
            'uninformative_output_high_effort_feasible':impossible is not None,
            'weak_IC_high_effort_tie_break_assumed':True,'strict_IC_guaranteed':False,
            'new_E2_real_person_predictions':0,'new_E3_historical_event_predictions':0,
            'R073':'FROZEN','PESEN_v0_1':'FROZEN'}

if __name__=='__main__':
    print(json.dumps(study(),sort_keys=True,indent=2,ensure_ascii=False))
