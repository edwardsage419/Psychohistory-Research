"""R150 project-created aggregate demographic-transition stock mechanism (NOT source author's equations).
Frozen protocol commit: 795ceea8646e475a4683d2a656c9dc7828d5a804.
All values are stylized rational expected-counts, not real populations.
"""
from fractions import Fraction as Q
from itertools import product
import json

YEARS=12
THRESHOLDS=tuple(range(9))
SHOCKS=('NONE','PANDEMIC_YEAR4','INMIGRATION_YEAR4')
INITIAL=Q(1000)
HIGH=Q(1,5)
LOW=Q(1,20)
EXTRA=Q(1,10)


def valid_years(td,tb):
    if type(td) is not int or type(tb) is not int or td not in THRESHOLDS or tb not in THRESHOLDS:
        raise ValueError('transition years must be ordinary integers 0..8')


def valid_inputs(td,tb,shock):
    valid_years(td,tb)
    if type(shock) is not str or shock not in SHOCKS:
        raise ValueError('unknown shock')


def vital(td,tb,year,shock):
    valid_inputs(td,tb,shock)
    if type(year) is not int or not 0<=year<YEARS:
        raise ValueError('calendar step 0..11 required')
    birth=HIGH if year<tb else LOW
    death=HIGH if year<td else LOW
    excess=EXTRA if year==4 and shock=='PANDEMIC_YEAR4' else Q(0)
    immigration=EXTRA if year==4 and shock=='INMIGRATION_YEAR4' else Q(0)
    return birth,death,excess,immigration


def forward(td,tb,shock='NONE'):
    """First implementation: independent separate gross birth/death/migration ledger."""
    valid_inputs(td,tb,shock)
    stock=INITIAL
    history=[]
    for t in range(YEARS):
        b,d,x,m=vital(td,tb,t,shock)
        births=stock*b
        deaths=stock*(d+x)
        immigrants=stock*m
        after=stock+births-deaths+immigrants
        assert stock>=0 and after>=0 and deaths<=stock
        history.append({'t':t,'before':str(stock),'birth_rate':str(b),'death_rate':str(d),
                        'extra_death_rate':str(x),'immigration_rate':str(m),
                        'births':str(births),'deaths':str(deaths),
                        'immigration':str(immigrants),'after':str(after)})
        stock=after
    assert stock==INITIAL+sum((Q(row['births'])-Q(row['deaths'])+Q(row['immigration']) for row in history),Q(0))
    return history


def factors_independent(td,tb,shock):
    """Second implementation: calendar inequality rather than calling `vital` or ledger."""
    valid_inputs(td,tb,shock)
    f=[]
    for t in range(YEARS):
        f.append(Q(1)+(Q(1,5) if t<tb else Q(1,20))
                 -(Q(1,5) if t<td else Q(1,20))
                 -(Q(1,10) if t==4 and shock=='PANDEMIC_YEAR4' else Q(0))
                 +(Q(1,10) if t==4 and shock=='INMIGRATION_YEAR4' else Q(0)))
    return tuple(f)


def independent_product(td,tb,shock='NONE',reverse=False):
    factors=factors_independent(td,tb,shock)
    stock=INITIAL
    for factor in reversed(factors) if reverse else factors:
        stock*=factor
    return stock


def closed_no_shock(td,tb):
    valid_years(td,tb)
    if td<tb:
        return INITIAL*Q(23,20)**(tb-td)
    if td>tb:
        return INITIAL*Q(17,20)**(td-tb)
    return INITIAL


def scenario(td,tb,shock='NONE'):
    history=forward(td,tb,shock)
    end=Q(history[-1]['after'])
    product_endpoint=independent_product(td,tb,shock)
    reverse_endpoint=independent_product(td,tb,shock,reverse=True)
    if end!=product_endpoint or end!=reverse_endpoint:
        raise AssertionError('independent stock check failed')
    if shock=='NONE' and end!=closed_no_shock(td,tb):
        raise AssertionError('closed-form pre-registered threshold result failed')
    return {'td':td,'tb':tb,'shock':shock,
            'classification':'mortality_first' if td<tb else 'fertility_first' if td>tb else 'simultaneous',
            'trajectory':[str(INITIAL)]+[row['after'] for row in history],
            'ledger':history,'final':str(end),'endpoint_product':str(product_endpoint),
            'endpoint_reverse_product':str(reverse_endpoint),
            'total_births':str(sum((Q(row['births']) for row in history),Q(0))),
            'total_deaths':str(sum((Q(row['deaths']) for row in history),Q(0))),
            'total_immigration':str(sum((Q(row['immigration']) for row in history),Q(0)))}


def observational_vital_nonidentification():
    """Distinct vital flows imply identical net growth; no inferred real causal effects."""
    examples=[(Q(1,5),Q(1,5)),(Q(1,20),Q(1,20)),
              (Q(1,5),Q(1,20)),(Q(1,4),Q(1,10))]
    return [{'birth':str(b),'death':str(d),'net':str(b-d),
             'year_one_births':str(INITIAL*b),'year_one_deaths':str(INITIAL*d)} for b,d in examples]


def results():
    all_cases=[scenario(td,tb,s) for s,td,tb in product(SHOCKS,THRESHOLDS,THRESHOLDS)]
    counts={k:sum(c['classification']==k for c in all_cases if c['shock']=='NONE')
            for k in ('mortality_first','fertility_first','simultaneous')}
    return {'research':'R150','date':'2026-10-20','classification':'E1 PROJECT SYNTHETIC, not author numerical reproduction',
            'prescore_commit':'795ceea8646e475a4683d2a656c9dc7828d5a804',
            'source_original_full_text_page_by_page_verified':False,
            'catalogue':'P1/06-008 Demographic Transition Models','thresholds':list(THRESHOLDS),
            'years':YEARS,'cases_count':len(all_cases),'none_shock_order_counts':counts,
            'reversed_timing_example':{'mortality_first':str(closed_no_shock(2,6)),
                                       'fertility_first':str(closed_no_shock(6,2))},
            'vital_rate_observational_equivalence':observational_vital_nonidentification(),
            'all_synthetic_cases':all_cases,'new_E2':0,'new_E3':0,
            'no_age_structure':True,'demographic_momentum_tested':False,
            'authors_original_numeric_data_replayed':False,'R073':'FROZEN','PESEN_v0_1':'FROZEN'}

if __name__=='__main__':
    print(json.dumps(results(),sort_keys=True,ensure_ascii=False,separators=(',',':')))
