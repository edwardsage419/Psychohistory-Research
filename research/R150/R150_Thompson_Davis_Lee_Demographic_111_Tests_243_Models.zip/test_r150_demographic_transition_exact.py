"""Genuine R150 source-bounded exact arithmetic tests; all outcomes are synthetic."""
import unittest
from fractions import Fraction as Q
import r150_demographic_transition_exact as r

class R150(unittest.TestCase):
    def test_01_vital_high_initial(self):
        self.assertEqual(r.vital(2,6,0,'NONE'),(Q(1,5),Q(1,5),Q(0),Q(0)))
    def test_02_mortality_drop(self):
        self.assertEqual(r.vital(2,6,2,'NONE'),(Q(1,5),Q(1,20),Q(0),Q(0)))
    def test_03_fertility_drop(self):
        self.assertEqual(r.vital(2,6,6,'NONE'),(Q(1,20),Q(1,20),Q(0),Q(0)))
    def test_04_early_threshold(self):
        self.assertEqual(r.vital(0,0,0,'NONE')[:2],(Q(1,20),Q(1,20)))
    def test_05_pandemic_extra_death(self):
        self.assertEqual(r.vital(2,6,4,'PANDEMIC_YEAR4')[2],Q(1,10))
    def test_06_immigration_extra(self):
        self.assertEqual(r.vital(2,6,4,'INMIGRATION_YEAR4')[3],Q(1,10))
    def test_07_no_year5_shock(self):
        self.assertEqual(r.vital(2,6,5,'PANDEMIC_YEAR4')[2],0)
    def test_08_deaths_never_exceed_stock(self):
        for s in r.SHOCKS:
            for td in r.THRESHOLDS:
                for tb in r.THRESHOLDS:
                    for x in r.forward(td,tb,s):
                        self.assertLessEqual(Q(x['deaths']),Q(x['before']))
    def test_09_reversal_multiplier(self):
        self.assertEqual(r.closed_no_shock(2,6),Q(1000)*Q(23,20)**4)
        self.assertEqual(r.closed_no_shock(6,2),Q(1000)*Q(17,20)**4)
    def test_10_return_to_low_rate(self):
        for td in r.THRESHOLDS:
            for tb in r.THRESHOLDS:
                self.assertEqual(r.vital(td,tb,9,'NONE')[:2],(Q(1,20),Q(1,20)))
    def test_11_joint_all_equal_stock_constant(self):
        for td in r.THRESHOLDS:
            self.assertEqual(r.scenario(td,td)['trajectory'],['1000']*13)
    def test_12_mortality_first_increases(self):
        for td in r.THRESHOLDS:
            for tb in r.THRESHOLDS:
                if td<tb:self.assertGreater(Q(r.scenario(td,tb)['final']),1000)
    def test_13_fertility_first_decreases(self):
        for td in r.THRESHOLDS:
            for tb in r.THRESHOLDS:
                if td>tb:self.assertLess(Q(r.scenario(td,tb)['final']),1000)
    def test_14_all_cases_count_and_partition(self):
        d=r.results()
        self.assertEqual(d['cases_count'],243)
        self.assertEqual(d['none_shock_order_counts'],{'mortality_first':36,'fertility_first':36,'simultaneous':9})
    def test_15_independent_products_for_every_case(self):
        for shock in r.SHOCKS:
            for td in r.THRESHOLDS:
                for tb in r.THRESHOLDS:
                    s=r.scenario(td,tb,shock)
                    self.assertEqual(s['final'],s['endpoint_product'])
                    self.assertEqual(s['final'],s['endpoint_reverse_product'])
    def test_16_ledger_mass_accounting_for_all(self):
        for shock in r.SHOCKS:
            for td in r.THRESHOLDS:
                for tb in r.THRESHOLDS:
                    ledger=r.forward(td,tb,shock)
                    self.assertEqual(Q(ledger[-1]['after']),Q(1000)+sum((Q(x['births'])-Q(x['deaths'])+Q(x['immigration']) for x in ledger),Q(0)))
    def test_17_one_shock_and_year(self):
        for shock in r.SHOCKS[1:]:
            s=r.forward(2,6,shock)
            self.assertEqual(sum(Q(v['extra_death_rate'])!=0 or Q(v['immigration_rate'])!=0 for v in s),1)
    def test_18_stock_only_not_identify_vital(self):
        a=r.observational_vital_nonidentification()
        self.assertEqual(a[0]['net'],a[1]['net'])
        self.assertNotEqual(a[0]['year_one_births'],a[1]['year_one_births'])
        self.assertEqual(a[2]['net'],a[3]['net'])
        self.assertNotEqual(a[2]['year_one_deaths'],a[3]['year_one_deaths'])
    def test_19_exact_first_year_shock_factor(self):
        base=Q(r.scenario(2,6,'NONE')['final'])
        self.assertEqual(Q(r.scenario(2,6,'PANDEMIC_YEAR4')['final'])/base,Q(21,23))
        self.assertEqual(Q(r.scenario(2,6,'INMIGRATION_YEAR4')['final'])/base,Q(25,23))
    def test_20_no_real_evidence_status(self):
        d=r.results()
        self.assertEqual((d['new_E2'],d['new_E3']),(0,0))
        self.assertFalse(d['demographic_momentum_tested'])
        self.assertFalse(d['authors_original_numeric_data_replayed'])
    def test_21_timelines_len(self):
        self.assertTrue(all(len(x['trajectory'])==13 and len(x['ledger'])==12 for x in r.results()['all_synthetic_cases']))
    def test_22_after_both_threshold_no_shock_stock_frozen(self):
        for td,tb in [(0,0),(2,6),(6,2),(8,8)]:
            x=r.scenario(td,tb)['trajectory']
            self.assertEqual(x[9:], [x[8]]*4)
    def test_23_invalid_bool(self):
        for args in [(True,2),(2,False)]:
            with self.assertRaises(ValueError):r.scenario(*args)
    def test_24_invalid_float(self):
        for args in [(2.0,2),(2,6.0)]:
            with self.assertRaises(ValueError):r.scenario(*args)
    def test_25_invalid_years(self):
        for args in [(-1,2),(2,9),(10,10),(Q(2),6)]:
            with self.assertRaises(ValueError):r.scenario(*args)
    def test_26_invalid_shock(self):
        for s in [None,True,3,'pandemic','INMIGRATION']:
            with self.assertRaises(ValueError):r.scenario(2,6,s)
    def test_27_invalid_calendar_step(self):
        for t in [-1,12,True,1.0]:
            with self.assertRaises(ValueError):r.vital(2,6,t,'NONE')
    def test_28_exact_initial_population(self):
        for shock in r.SHOCKS:
            self.assertEqual(r.scenario(4,8,shock)['trajectory'][0],'1000')
    def test_29_immigration_separate_from_births(self):
        x=r.scenario(2,6,'INMIGRATION_YEAR4')['ledger'][4]
        self.assertEqual(Q(x['immigration']),Q(x['before'])/10)
        self.assertEqual(Q(x['births']),Q(x['before'])/5)
    def test_30_positive_stock(self):
        self.assertTrue(all(Q(t)>0 for s in r.results()['all_synthetic_cases'] for t in s['trajectory']))

# 81 distinct mathematically concrete threshold schedules; each method is a separate real unittest.
def _case(td,tb):
    def check(self):
        s=r.scenario(td,tb)
        self.assertEqual(Q(s['final']),r.closed_no_shock(td,tb))
        self.assertEqual(Q(s['total_births'])-Q(s['total_deaths']),Q(s['final'])-1000)
        self.assertEqual(s['total_immigration'],'0')
    return check
for _td in range(9):
    for _tb in range(9):
        setattr(R150,f'test_schedule_td{_td}_tb{_tb}',_case(_td,_tb))

if __name__=='__main__':unittest.main()
