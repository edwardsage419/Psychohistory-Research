"""R134 exact audit of Taylor (1979), pp.77-78, Eq.(1)-(5).

All payoffs below are independent project examples, not observed populations.
Only Python's standard library is used.
"""
from __future__ import annotations

from fractions import Fraction as F
from itertools import product
from typing import Sequence

ZERO = F(0)
ONE = F(1)
HALF = F(1, 2)


def _fraction(x):
    if not isinstance(x, (int, F)) or isinstance(x, bool):
        raise TypeError("Exact int or Fraction only; floats are rejected")
    return F(x)


def probability(items: Sequence) -> tuple[F, ...]:
    if not isinstance(items, (tuple, list)) or len(items) < 2:
        raise ValueError("Probability vector must have at least two actions")
    xs = tuple(_fraction(x) for x in items)
    if min(xs) < 0 or sum(xs) != ONE:
        raise ValueError("Probability vector must belong to the simplex")
    return xs


def matrix(items: Sequence[Sequence], rows: int, cols: int) -> tuple[tuple[F, ...], ...]:
    if not isinstance(items, (tuple, list)) or len(items) != rows:
        raise ValueError("Wrong matrix row count")
    if any(not isinstance(row, (tuple, list)) or len(row) != cols for row in items):
        raise ValueError("Wrong matrix column count")
    return tuple(tuple(_fraction(x) for x in row) for row in items)


def _matvec(M, vec):
    return tuple(sum((a*b for a,b in zip(row, vec)), ZERO) for row in M)


def _dot(x, y):
    return sum((a*b for a,b in zip(x, y)), ZERO)


def _add(x, y):
    return tuple(a+b for a,b in zip(x, y))


def _minus(x, y):
    return tuple(a-b for a,b in zip(x, y))


def make_game(A, B, C, D):
    """F_i=(Ap+Bq)_i and G_j=(Cp+Dq)_j, Taylor 1979 p77."""
    if not isinstance(A, (tuple, list)) or len(A) < 2:
        raise ValueError("At least two I strategies")
    if not isinstance(D, (tuple, list)) or len(D) < 2:
        raise ValueError("At least two J strategies")
    m, n = len(A), len(D)
    return (matrix(A, m, m), matrix(B, m, n),
            matrix(C, n, m), matrix(D, n, n))


def fitness(game, p, q):
    A,B,C,D=game
    p=probability(p); q=probability(q)
    if len(p)!=len(A) or len(q)!=len(D):
        raise ValueError("Strategy count mismatch")
    return _add(_matvec(A,p),_matvec(B,q)), _add(_matvec(C,p),_matvec(D,q))


def source_eq1_advantage(game, p, q, r, s, eps):
    """Independently evaluate ORIGINAL fitness at the perturbed populations."""
    p=probability(p); q=probability(q)
    r=probability(r); s=probability(s)
    if len(p)!=len(r) or len(q)!=len(s):
        raise ValueError("Mutant and resident dimensions differ")
    eps=_fraction(eps)
    if not ZERO < eps < ONE:
        raise ValueError("Strictly interior epsilon required")
    p_bar=tuple((ONE-eps)*x+eps*z for x,z in zip(p,r))
    q_bar=tuple((ONE-eps)*y+eps*w for y,w in zip(q,s))
    fitI,fitJ=fitness(game,p_bar,q_bar)
    return _dot(p,fitI)+_dot(q,fitJ)-_dot(r,fitI)-_dot(s,fitJ)


def independent_expansion(game,p,q,r,s):
    """Independent matrix quadratic Taylor Eq2/3 algebra: delta(eps)=d0-eps*Q."""
    A,B,C,D=game
    p=probability(p);q=probability(q);r=probability(r);s=probability(s)
    if (len(p),len(q))!=(len(A),len(D)) or len(r)!=len(p) or len(s)!=len(q):
        raise ValueError("Dimensions incompatible")
    u=_minus(r,p);v=_minus(s,q)
    baseI=_add(_matvec(A,p),_matvec(B,q))
    baseJ=_add(_matvec(C,p),_matvec(D,q))
    d0=-_dot(u,baseI)-_dot(v,baseJ)
    Q=_dot(u,_add(_matvec(A,u),_matvec(B,v))) + _dot(v,_add(_matvec(C,u),_matvec(D,v)))
    return d0,Q


def taylor_invasion_for_fixed_mutant(game,p,q,r,s):
    if tuple(probability(p))==tuple(probability(r)) and tuple(probability(q))==tuple(probability(s)):
        raise ValueError("Mutant must differ in at least one type")
    d0,Q=independent_expansion(game,p,q,r,s)
    return d0>0 or (d0==0 and Q<0)


def taylor_eq5_exact_field(game,p,q):
    """First-party p78 Eq.(5) applied separately to two type distributions."""
    p=probability(p);q=probability(q)
    fi,fj=fitness(game,p,q)
    avI=_dot(p,fi);avJ=_dot(q,fj)
    return tuple(x*(f-avI) for x,f in zip(p,fi)), tuple(y*(f-avJ) for y,f in zip(q,fj))


SELF_AND_CROSS = make_game(((0,1),(1,0)), ((2,0),(0,2)),
                           ((2,0),(0,2)), ((0,1),(1,0)))
MATCHING_PENNIES = make_game(((0,0),(0,0)), ((1,-1),(-1,1)),
                             ((-1,1),(1,-1)), ((0,0),(0,0)))
RESIDENT = (HALF,HALF)
MUTANT = (F(3,4), F(1,4))


def reduced_2x2_field(game,x,y):
    """Hand-reduced rival check, independent of general eq5 routine."""
    x=_fraction(x); y=_fraction(y)
    if not ZERO<=x<=ONE or not ZERO<=y<=ONE:
        raise ValueError("Shares must be between 0 and 1")
    A,B,C,D=game
    a=A[0][0]-A[1][0]; b=A[0][1]-A[1][1]
    c=B[0][0]-B[1][0]; d=B[0][1]-B[1][1]
    e=C[0][0]-C[1][0]; f=C[0][1]-C[1][1]
    g=D[0][0]-D[1][0]; h=D[0][1]-D[1][1]
    dx=x*(ONE-x)*(a*x+b*(ONE-x)+c*y+d*(ONE-y))
    dy=y*(ONE-y)*(e*x+f*(ONE-x)+g*y+h*(ONE-y))
    return dx,dy


def zero_sum_field_closed(x,y):
    x=_fraction(x);y=_fraction(y)
    if not ZERO<=x<=ONE or not ZERO<=y<=ONE:
        raise ValueError("Invalid shares")
    return 2*x*(ONE-x)*(2*y-ONE), -2*y*(ONE-y)*(2*x-ONE)


def conserved_H(x,y):
    return x*(ONE-x)*y*(ONE-y)


def conserved_H_derivative_exact(x,y):
    dx,dy=zero_sum_field_closed(x,y)
    return (ONE-2*x)*y*(ONE-y)*dx + x*(ONE-x)*(ONE-2*y)*dy


def _float_rhs(state):
    x,y=state
    return (2*x*(1-x)*(2*y-1), -2*y*(1-y)*(2*x-1))


def rk4_matching_pennies(x0:float,y0:float,T:float,n:int):
    """Float numerical diagnostic only; neither exact invariant nor source software."""
    if not 0<x0<1 or not 0<y0<1 or T<0 or n<1:
        raise ValueError("Interior initial shares, T>=0, n>=1 are required")
    x,y=float(x0),float(y0)
    h=T/n
    for _ in range(n):
        k1=_float_rhs((x,y))
        k2=_float_rhs((x+h*k1[0]/2,y+h*k1[1]/2))
        k3=_float_rhs((x+h*k2[0]/2,y+h*k2[1]/2))
        k4=_float_rhs((x+h*k3[0],y+h*k3[1]))
        x+=h*(k1[0]+2*k2[0]+2*k3[0]+k4[0])/6
        y+=h*(k1[1]+2*k2[1]+2*k3[1]+k4[1])/6
        if not 0<x<1 or not 0<y<1:
            raise ArithmeticError("Integration left the valid interior; no clipping")
    return x,y


def _scaled(M,k):
    return tuple(tuple(k*z for z in row) for row in M)


def exhaustive_linear_identity():
    """81 constructed games x 9 resident pairs x 16 mutants x 3 eps = 34,992 exact checks."""
    baseA,baseB,baseC,baseD=SELF_AND_CROSS
    grids=(F(1,4),HALF,F(3,4))
    mut=(F(0), F(1,4), F(3,4), F(1))
    epss=(F(1,10),F(1,4),F(2,5))
    comparisons=0
    checked_games=0
    for ka,kb,kc,kd in product((-1,0,1),repeat=4):
        game=make_game(_scaled(baseA,ka),_scaled(baseB,kb),
                       _scaled(baseC,kc),_scaled(baseD,kd))
        checked_games+=1
        for x,y in product(grids,repeat=2):
            p=(x,ONE-x);q=(y,ONE-y)
            for rx,sy in product(mut,repeat=2):
                r=(rx,ONE-rx);s=(sy,ONE-sy)
                d0,Q=independent_expansion(game,p,q,r,s)
                for eps in epss:
                    assert source_eq1_advantage(game,p,q,r,s,eps)==d0-eps*Q
                    comparisons+=1
    return {'games':checked_games,'exact_source_vs_quadratic_checks':comparisons}


def exact_results():
    lone_p, lone_q=independent_expansion(SELF_AND_CROSS,RESIDENT,RESIDENT,MUTANT,RESIDENT)
    both_p,both_q=independent_expansion(SELF_AND_CROSS,RESIDENT,RESIDENT,MUTANT,MUTANT)
    xyz=[]
    for x,y in ((F(1,5),F(4,5)),(F(4,5),F(1,5)),(HALF,HALF)):
        dx,dy=zero_sum_field_closed(x,y)
        xyz.append({'x':str(x),'y':str(y),'pooled_z':str((x+y)/2),
                    'pooled_derivative':str((dx+dy)/2),'H':str(conserved_H(x,y))})
    return {'unilateral':{'D0':str(lone_p),'Q':str(lone_q)},
            'joint':{'D0':str(both_p),'Q':str(both_q),'D_epsilon_quarter':str(source_eq1_advantage(SELF_AND_CROSS,RESIDENT,RESIDENT,MUTANT,MUTANT,F(1,4)))},
            'joint_jacobian':[['-1/2','1'],['1','-1/2']],
            'joint_jacobian_eigenvalues':['1/2','-3/2'],
            'matching_pennies':xyz}

if __name__=='__main__':
    print(exhaustive_linear_identity())
    print(exact_results())
