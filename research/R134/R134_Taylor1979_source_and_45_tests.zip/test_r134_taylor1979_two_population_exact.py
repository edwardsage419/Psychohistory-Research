"""Independent unittest review of original Taylor (1979) two-type Equations 1-5."""
import math
import unittest
from fractions import Fraction as F
from itertools import product
import r134_taylor1979_two_population_exact as m


class R134Taylor1979Tests(unittest.TestCase):
    def test_01_original_eq1_nonzero_joint_mutant(self):
        self.assertEqual(m.source_eq1_advantage(m.SELF_AND_CROSS,m.RESIDENT,m.RESIDENT,m.MUTANT,m.MUTANT,F(1,4)),F(-1,16))

    def test_02_source_eq1_and_quadratic_algebra_match(self):
        d,q=m.independent_expansion(m.SELF_AND_CROSS,m.RESIDENT,m.RESIDENT,m.MUTANT,m.MUTANT)
        self.assertEqual((d,q),(F(0),F(1,4)))

    def test_03_single_I_mutant_is_resisted(self):
        d,q=m.independent_expansion(m.SELF_AND_CROSS,m.RESIDENT,m.RESIDENT,m.MUTANT,m.RESIDENT)
        self.assertEqual((d,q),(F(0),F(-1,8)))
        self.assertTrue(m.taylor_invasion_for_fixed_mutant(m.SELF_AND_CROSS,m.RESIDENT,m.RESIDENT,m.MUTANT,m.RESIDENT))

    def test_04_single_J_mutant_is_resisted(self):
        d,q=m.independent_expansion(m.SELF_AND_CROSS,m.RESIDENT,m.RESIDENT,m.RESIDENT,m.MUTANT)
        self.assertEqual((d,q),(F(0),F(-1,8)))
        self.assertTrue(m.taylor_invasion_for_fixed_mutant(m.SELF_AND_CROSS,m.RESIDENT,m.RESIDENT,m.RESIDENT,m.MUTANT))

    def test_05_simultaneous_mutation_is_not_ESS(self):
        self.assertFalse(m.taylor_invasion_for_fixed_mutant(m.SELF_AND_CROSS,m.RESIDENT,m.RESIDENT,m.MUTANT,m.MUTANT))

    def test_06_pure_mutant_changes_amount_positive_sign(self):
        for t in (F(1,100),F(1,10),F(1,2),F(9,10)):
            r=(F(1,2)+t/2,F(1,2)-t/2)
            d,q=m.independent_expansion(m.SELF_AND_CROSS,m.RESIDENT,m.RESIDENT,r,m.RESIDENT)
            self.assertEqual(d,F(0)); self.assertLess(q,0)

    def test_07_any_single_J_mutant_quadratic_formula(self):
        for y in (F(0),F(1,5),F(4,5),F(1)):
            s=(y,1-y)
            d,q=m.independent_expansion(m.SELF_AND_CROSS,m.RESIDENT,m.RESIDENT,m.RESIDENT,s)
            self.assertEqual(q,-2*(y-F(1,2))**2)

    def test_08_any_single_I_mutant_quadratic_formula(self):
        for x in (F(0),F(1,5),F(4,5),F(1)):
            r=(x,1-x)
            d,q=m.independent_expansion(m.SELF_AND_CROSS,m.RESIDENT,m.RESIDENT,r,m.RESIDENT)
            self.assertEqual(q,-2*(x-F(1,2))**2)

    def test_09_jacobian_first_coordinate_derivatives_exact(self):
        h=F(1,100)
        def f(x,y):return m.reduced_2x2_field(m.SELF_AND_CROSS,x,y)[0]
        self.assertEqual((f(F(1,2)+h,F(1,2))-f(F(1,2)-h,F(1,2)))/(2*h),F(-1,2)+2*h*h)
        self.assertEqual((f(F(1,2),F(1,2)+h)-f(F(1,2),F(1,2)-h))/(2*h),F(1))

    def test_10_jacobian_second_coordinate_derivatives_exact(self):
        h=F(1,100)
        def f(x,y):return m.reduced_2x2_field(m.SELF_AND_CROSS,x,y)[1]
        self.assertEqual((f(F(1,2),F(1,2)+h)-f(F(1,2),F(1,2)-h))/(2*h),F(-1,2)+2*h*h)
        self.assertEqual((f(F(1,2)+h,F(1,2))-f(F(1,2)-h,F(1,2)))/(2*h),F(1))

    def test_11_positive_and_negative_jacobian_eigenvalues(self):
        self.assertEqual(F(-1,2)+1,F(1,2));self.assertEqual(F(-1,2)-1,F(-3,2))

    def test_12_own_type_fixed_opponent_is_converging_local(self):
        x,y=m.reduced_2x2_field(m.SELF_AND_CROSS,F(3,5),F(1,2))
        self.assertLess(x,0);self.assertGreater(y,0)  # Eq5 still lets J respond; own-I fixed-q partial is negative

    def test_13_joint_same_side_moves_outward(self):
        x,y=m.reduced_2x2_field(m.SELF_AND_CROSS,F(3,5),F(3,5))
        self.assertGreater(x,0);self.assertGreater(y,0)

    def test_14_joint_opposing_deviations_converge(self):
        x,y=m.reduced_2x2_field(m.SELF_AND_CROSS,F(3,5),F(2,5))
        self.assertLess(x,0);self.assertGreater(y,0)

    def test_15_matching_payoffs_antisymmetric(self):
        A,B,C,D=m.MATCHING_PENNIES
        self.assertTrue(all(z==0 for row in A+D for z in row))
        self.assertTrue(all(C[i][j]==-B[j][i] for i in range(2) for j in range(2)))

    def test_16_independent_closed_matching_equations(self):
        for x,y in product((F(0),F(1,5),F(1,2),F(4,5),F(1)),repeat=2):
            dx,dy=m.zero_sum_field_closed(x,y)
            pp,qq=m.taylor_eq5_exact_field(m.MATCHING_PENNIES,(x,1-x),(y,1-y))
            self.assertEqual((dx,dy),(pp[0],qq[0]))
            self.assertEqual(sum(pp),0);self.assertEqual(sum(qq),0)

    def test_17_matching_H_is_exactly_conserved_by_derivative(self):
        for x,y in product((F(0),F(1,7),F(1,5),F(1,2),F(3,5),F(4,5),F(1)),repeat=2):
            self.assertEqual(m.conserved_H_derivative_exact(x,y),0)

    def test_18_non_equilibrium_matching_H_start(self):
        self.assertEqual(m.conserved_H(F(1,5),F(4,5)),F(16,625))

    def test_19_same_pooled_frequency_opposite_gradients(self):
        a=(F(1,5),F(4,5));b=(F(4,5),F(1,5));
        self.assertEqual(sum(a)/2,sum(b)/2)
        da=sum(m.zero_sum_field_closed(*a))/2
        db=sum(m.zero_sum_field_closed(*b))/2
        self.assertEqual((da,db),(F(24,125),F(-24,125)))

    def test_20_same_pooled_frequency_zero_gradient(self):
        self.assertEqual(sum(m.zero_sum_field_closed(F(1,2),F(1,2))),0)

    def test_21_full_matching_2x2_center_has_imaginary_eigenvalues(self):
        # J = [[0,1],[-1,0]] has characteristic lambda^2 + 1.
        self.assertEqual(0*0-1*(-1),1)
        self.assertEqual(0+0,0)

    def test_22_exact_zero_sum_corner_is_absorbing(self):
        for x,y in product((F(0),F(1)),repeat=2):
            self.assertEqual(m.zero_sum_field_closed(x,y),(0,0))

    def test_23_boundary_population_remains_absent(self):
        pp,qq=m.taylor_eq5_exact_field(m.MATCHING_PENNIES,(F(1),F(0)),(F(1,5),F(4,5)))
        self.assertEqual(pp,(0,0));self.assertEqual(sum(qq),0)

    def test_24_generic_2_by_3_equation(self):
        g=m.make_game(((1,0),(0,1)),((1,2,3),(0,2,4)),
                      ((1,0),(0,1),(2,3)),((1,0,0),(0,1,0),(0,0,1)))
        p=(F(1,3),F(2,3));q=(F(1,4),F(1,4),F(1,2))
        r=(F(3,4),F(1,4));s=(F(1,3),F(2,3),F(0))
        d,Q=m.independent_expansion(g,p,q,r,s)
        for eps in (F(1,10),F(1,5),F(3,5)):
            self.assertEqual(m.source_eq1_advantage(g,p,q,r,s,eps),d-eps*Q)
        dp,dq=m.taylor_eq5_exact_field(g,p,q)
        self.assertEqual((len(dp),len(dq)),(2,3));self.assertEqual(sum(dp),0);self.assertEqual(sum(dq),0)

    def test_25_model_family_exhaustive(self):
        self.assertEqual(m.exhaustive_linear_identity(),{'games':81,'exact_source_vs_quadratic_checks':34992})

    def test_26_three_2x2_prob_grids_general_eq5_vs_reduction(self):
        for g in (m.SELF_AND_CROSS,m.MATCHING_PENNIES):
            for x,y in product((F(0),F(1,7),F(1,4),F(1,2),F(3,4),F(6,7),F(1)),repeat=2):
                dp,dq=m.taylor_eq5_exact_field(g,(x,1-x),(y,1-y))
                self.assertEqual((dp[0],dq[0]),m.reduced_2x2_field(g,x,y))

    def test_27_original_eq1_fully_neutral_alternative_d0_and_Q(self):
        g=m.make_game(((0,0),(0,0)),((0,0),(0,0)),((0,0),(0,0)),((0,0),(0,0)))
        self.assertEqual(m.independent_expansion(g,m.RESIDENT,m.RESIDENT,m.MUTANT,m.MUTANT),(0,0))
        self.assertFalse(m.taylor_invasion_for_fixed_mutant(g,m.RESIDENT,m.RESIDENT,m.MUTANT,m.MUTANT))

    def test_28_positive_common_fitness_shift_invariant(self):
        g=m.SELF_AND_CROSS
        shifted=m.make_game(tuple(tuple(z+3 for z in row) for row in g[0]),g[1],g[2],g[3])
        self.assertEqual(m.independent_expansion(g,m.RESIDENT,m.RESIDENT,m.MUTANT,m.MUTANT),
                         m.independent_expansion(shifted,m.RESIDENT,m.RESIDENT,m.MUTANT,m.MUTANT))

    def test_29_pair_of_population_invariants(self):
        for g in (m.SELF_AND_CROSS,m.MATCHING_PENNIES):
            for x,y in product((F(0),F(1,4),F(1,2),F(3,4),F(1)),repeat=2):
                dp,dq=m.taylor_eq5_exact_field(g,(x,1-x),(y,1-y))
                self.assertEqual(sum(dp),0);self.assertEqual(sum(dq),0)

    def test_30_cannot_identify_same_mutant(self):
        with self.assertRaises(ValueError):
            m.taylor_invasion_for_fixed_mutant(m.SELF_AND_CROSS,m.RESIDENT,m.RESIDENT,m.RESIDENT,m.RESIDENT)

    def test_31_reject_floating_point_fitness(self):
        with self.assertRaises(TypeError):
            m.make_game(((1.0,0),(0,1)),((0,0),(0,0)),((0,0),(0,0)),((1,0),(0,1)))

    def test_32_reject_invalid_negative_probability(self):
        with self.assertRaises(ValueError):m.probability((F(-1,4),F(5,4)))

    def test_33_reject_nonunit_sum(self):
        with self.assertRaises(ValueError):m.probability((F(1,4),F(1,4)))

    def test_34_reject_ragged_matrix(self):
        with self.assertRaises(ValueError):m.make_game(((0,1),(0,)),((0,0),(0,0)),((0,0),(0,0)),((0,0),(0,0)))

    def test_35_reject_wrong_cross_dimensions(self):
        with self.assertRaises(ValueError):m.make_game(((0,1),(0,0)),((0,0,0),(0,0,0)),((0,0),(0,0)),((0,0),(0,0)))

    def test_36_reject_epsilon_endpoints(self):
        for e in (F(0),F(1),F(5,4)):
            with self.assertRaises(ValueError):m.source_eq1_advantage(m.SELF_AND_CROSS,m.RESIDENT,m.RESIDENT,m.MUTANT,m.MUTANT,e)

    def test_37_reject_epsilon_float(self):
        with self.assertRaises(TypeError):m.source_eq1_advantage(m.SELF_AND_CROSS,m.RESIDENT,m.RESIDENT,m.MUTANT,m.MUTANT,.1)

    def test_38_reject_incorrect_mutant_size(self):
        with self.assertRaises(ValueError):m.independent_expansion(m.SELF_AND_CROSS,m.RESIDENT,m.RESIDENT,(F(1),F(0),F(0)),m.RESIDENT)

    def test_39_reject_eq5_invalid_strategy_size(self):
        with self.assertRaises(ValueError):m.taylor_eq5_exact_field(m.SELF_AND_CROSS,(F(1),F(0),F(0)),m.RESIDENT)

    def test_40_reject_rk4_invalid_grid(self):
        with self.assertRaises(ValueError):m.rk4_matching_pennies(.2,.8,10,0)

    def test_41_rk4_conserved_H_error_reduces_with_h(self):
        init_H=float(m.conserved_H(F(1,5),F(4,5)))
        errs=[]
        for n in (40,80,160,320):
            x,y=m.rk4_matching_pennies(.2,.8,12,n)
            errs.append(abs(x*(1-x)*y*(1-y)-init_H))
        self.assertGreater(errs[0],errs[1]);self.assertGreater(errs[1],errs[2]);self.assertGreater(errs[2],errs[3]);self.assertLess(errs[-1],1e-9)

    def test_42_rk4_center_stays_exact_center(self):
        self.assertEqual(m.rk4_matching_pennies(.5,.5,12,120),(.5,.5))

    def test_43_rk4_full_interior_trajectory_remains_valid(self):
        for init in ((.2,.8),(.7,.4),(.35,.25)):
            x,y=m.rk4_matching_pennies(*init,12,320)
            self.assertTrue(0<x<1 and 0<y<1)

    def test_44_results_four_core_strings(self):
        r=m.exact_results()
        self.assertEqual(r['joint']['Q'],'1/4')
        self.assertEqual(r['joint']['D_epsilon_quarter'],'-1/16')
        self.assertEqual(r['matching_pennies'][0]['pooled_derivative'],'24/125')
        self.assertEqual(r['matching_pennies'][1]['pooled_derivative'],'-24/125')

    def test_45_distinct_types_need_not_share_marginal(self):
        g=m.MATCHING_PENNIES
        p,q=(F(1,5),F(4,5)),(F(4,5),F(1,5))
        dp,dq=m.taylor_eq5_exact_field(g,p,q)
        self.assertEqual(dp[0],dq[0])
        self.assertNotEqual(p,q)


if __name__ == '__main__':
    unittest.main()
