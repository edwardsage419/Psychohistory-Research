from fractions import Fraction as F
from itertools import product
from functools import lru_cache
import json
STATES=range(5)
HORIZONS=(1,2,4,8,16)

def prob(s,mode='feedback'):
    if type(s) is not int or s not in STATES: raise ValueError('state')
    if mode not in ('feedback','fixed','frozen'): raise ValueError('mode')
    return F(s+1,6) if mode!='fixed' else F(1,2)

def move(s,k,mode='feedback'):
    if type(k) is not int or k not in (0,1,2):raise ValueError('k')
    if mode=='frozen':return s
    return max(0,s-1) if k==0 else min(4,s+1) if k==2 else s

def kernel(s,mode='feedback'):
    p=prob(s,mode);out={i:F(0) for i in STATES}
    for k,w in ((0,(1-p)**2),(1,2*p*(1-p)),(2,p**2)):
        out[move(s,k,mode)]+=w
    return out

def kernel_independent(s,mode='feedback'):
    p=prob(s,mode);out={i:F(0) for i in STATES}
    for a,b in product((0,1),repeat=2):
        pr=(p if a else 1-p)*(p if b else 1-p)
        out[move(s,a+b,mode)]+=pr
    return out

def evolution(t,mode='feedback',independent=False,do_first=None):
    if type(t) is not int or t<0: raise ValueError('horizon')
    if do_first not in (None,0,2): raise ValueError('do')
    d={s:F(s==2) for s in STATES}; history=[d.copy()]; exp_k=[]
    for j in range(t):
        nxt={s:F(0) for s in STATES}; kmean=F(0)
        for s,weight in d.items():
            p=prob(s,mode)
            if j==0 and do_first is not None:
                nxt[move(s,do_first,mode)]+=weight;kmean+=weight*do_first
            else:
                kmean+=weight*2*p
                row=kernel_independent(s,mode) if independent else kernel(s,mode)
                for dst,v in row.items():nxt[dst]+=weight*v
        d=nxt;history.append(d.copy());exp_k.append(kmean)
        assert sum(d.values())==1
    return {'states':history,'expected_k':exp_k}

@lru_cache(None)
def path_enum(t,mode='feedback'):
    if type(t) is not int or t<0 or t>8:raise ValueError('t')
    @lru_cache(None)
    def walk(s,remaining):
        if not remaining:return tuple(F(i==s) for i in STATES)
        out=[F(0)]*5
        p=prob(s,mode)
        for a,b in product((0,1),repeat=2):
            w=(p if a else 1-p)*(p if b else 1-p)
            tail=walk(move(s,a+b,mode),remaining-1)
            for i in STATES:out[i]+=w*tail[i]
        return tuple(out)
    return dict(zip(STATES,walk(2,t)))

def fmt(x):return str(x)

def main():
    result={'source':'project-defined E1, Giddens/Sewell conceptual analog; not authors numerical equations','horizons':list(HORIZONS),'models':{},'do_effects':{},'all_independent_routes_agree':True,'new_E2':0,'new_E3':0,'R073':'FROZEN','PESEN_v0.1':'FROZEN'}
    for mode in ('feedback','fixed','frozen'):
        result['models'][mode]={}
        for t in HORIZONS:
            a=evolution(t,mode);b=evolution(t,mode,independent=True)
            assert a==b
            if t<=8:assert a['states'][-1]==path_enum(t,mode)
            result['models'][mode][str(t)]={'final_pmf':{str(s):fmt(a['states'][-1][s]) for s in STATES},'expected_final_structure':fmt(sum(F(s)*a['states'][-1][s] for s in STATES)),'expected_actions_A_per_period':[fmt(v) for v in a['expected_k']]}
            plus=evolution(t,mode,do_first=2)['states'][-1];minus=evolution(t,mode,do_first=0)['states'][-1]
            result['do_effects'][f'{mode}/{t}']=fmt(sum(F(s)*(plus[s]-minus[s]) for s in STATES))
    return result
if __name__=='__main__':print(json.dumps(main(),sort_keys=True,indent=2,ensure_ascii=False))
