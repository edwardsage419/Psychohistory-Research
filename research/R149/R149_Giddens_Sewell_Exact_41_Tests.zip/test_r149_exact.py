import unittest
from fractions import Fraction as F
from r149_exact import *
class Tests(unittest.TestCase):
    def test_equal_at_start(self):self.assertEqual(prob(2),F(1,2))
    def test_extremes(self):self.assertEqual((prob(0),prob(4)),(F(1,6),F(5,6)))
    def test_move(self):self.assertEqual((move(2,0),move(2,1),move(2,2)),(1,2,3))
    def test_nonabsorbing(self):self.assertGreater(kernel(0)[1],0);self.assertGreater(kernel(4)[3],0)
    def test_invalids(self):
        for value in (True,2.0,-1,5):
            with self.assertRaises(ValueError):prob(value)
        for k in (True,1.0,-1,3):
            with self.assertRaises(ValueError):move(2,k)
    def test_all_paths(self):
        for m in ('feedback','fixed','frozen'):
            for t in range(9):self.assertEqual(path_enum(t,m),evolution(t,m)['states'][-1])
    def test_symmetric_means(self):
        for m in ('feedback','fixed','frozen'):
            for t in HORIZONS:
                e=evolution(t,m)
                self.assertEqual(sum(F(s)*e['states'][-1][s] for s in STATES),2)
                self.assertTrue(all(k==1 for k in e['expected_k']))
    def test_frozen(self):
        for t in HORIZONS:self.assertEqual(evolution(t,'frozen')['states'][-1][2],1)
    def test_counterfactual(self):
        for m in ('feedback','fixed'):
            for t in HORIZONS:
                p=evolution(t,m,do_first=2)['states'][-1]
                n=evolution(t,m,do_first=0)['states'][-1]
                self.assertGreater(sum(F(s)*(p[s]-n[s]) for s in STATES),0)
    def test_kernels(self):
        for m in ('feedback','fixed','frozen'):
            for s in STATES:
                self.assertEqual(kernel(s,m),kernel_independent(s,m))
                self.assertEqual(sum(kernel(s,m).values()),1)
    def test_output(self):
        x=main();self.assertEqual((x['new_E2'],x['new_E3']),(0,0));self.assertTrue(x['all_independent_routes_agree'])
for mode in ('feedback','fixed','frozen'):
 for state in STATES:
    def fn(self,m=mode,s=state):self.assertEqual(kernel(s,m),kernel_independent(s,m))
    setattr(Tests,f'test_kernel_{mode}_{state}',fn)
for mode in ('feedback','fixed','frozen'):
 for t in HORIZONS:
    def fn(self,m=mode,h=t):
        a=evolution(h,m);b=evolution(h,m,independent=True)
        self.assertEqual(a,b);self.assertEqual(sum(a['states'][-1].values()),1)
    setattr(Tests,f'test_trace_{mode}_{t}',fn)
