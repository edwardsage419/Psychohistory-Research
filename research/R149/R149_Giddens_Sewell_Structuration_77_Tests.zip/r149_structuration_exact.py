"""R149 project-constructed exact structuration feedback, not Giddens/Sewell code.
Prescore freeze GitHub 70b4bcf48ca698a525de0d8d110403f843d84bf5.
"""
from __future__ import annotations
import itertools
import json
from fractions import Fraction as F

Q = (F(0), F(1, 2))
START = (0, 2, 4)
HORIZON = 6


def verify(s: int, q: F, resource: int, feedback: int) -> None:
    if type(s) is not int or s not in range(5):
        raise ValueError('s must be plain integer 0..4')
    if type(q) is not F or q not in Q:
        raise ValueError('q must be Fraction(0) or Fraction(1,2)')
    if type(resource) is not int or resource not in (0, 1):
        raise ValueError('resource must be plain integer 0 or 1')
    if type(feedback) is not int or feedback not in (0, 1):
        raise ValueError('feedback must be plain integer 0 or 1')


def _outcome(s: int, a: int, b: int, feedback: int) -> int:
    return s if not feedback else max(0, min(4, s + (a + b > 1) - (a + b < 1)))


def explicit_kernel(s: int, q: F, resource: int, feedback: int):
    """Implementation A: enumerate Z, A0, A1 elementary worlds."""
    verify(s, q, resource, feedback)
    dist = [F(0)] * 5
    reward = F(0)
    for z in (0, 1):
        pz = q if z else 1 - q
        p = (F(1 + s + resource + z, 8), F(2 + s + z, 8))
        for a in (0, 1):
            for b in (0, 1):
                mass = pz * (p[0] if a else 1-p[0]) * (p[1] if b else 1-p[1])
                dist[_outcome(s, a, b, feedback)] += mass
                reward += mass * (a+b)
    assert sum(dist) == 1
    return tuple(dist), reward


def polynomial_kernel(s: int, q: F, resource: int, feedback: int):
    """Implementation B: independent Poisson-binomial polynomial coefficients."""
    verify(s, q, resource, feedback)
    out = [F(0)] * 5
    expected = F(0)
    for z, weight in ((0, 1-q), (1, q)):
        u = F(1+s+resource+z, 8)
        v = F(2+s+z, 8)
        by_count = ((1-u)*(1-v), u*(1-v)+(1-u)*v, u*v)
        for count, prob in enumerate(by_count):
            state = s if feedback == 0 else max(0, min(4, s + count - 1))
            out[state] += weight*prob
        expected += weight*(u+v)
    assert sum(out) == 1
    return tuple(out), expected


def forward(start: int, q: F, resource: int, feedback: int):
    verify(start, q, resource, feedback)
    current = [F(0)]*5
    current[start] = F(1)
    year_states = [tuple(current)]
    annual = []
    for _ in range(HORIZON):
        new = [F(0)]*5
        reward = F(0)
        for s, mass in enumerate(current):
            if mass == 0:
                continue
            kernel, this_reward = explicit_kernel(s, q, resource, feedback)
            reward += mass * this_reward
            for dest, prob in enumerate(kernel):
                new[dest] += mass*prob
        assert sum(new) == 1
        current = new
        year_states.append(tuple(current))
        annual.append(reward)
    return dict(yearly=tuple(year_states), annual=tuple(annual), total=sum(annual,F(0)),
                final_mean=sum((F(i)*v for i,v in enumerate(current)),F(0)))


def independent_matrix(start: int, q: F, resource: int, feedback: int):
    verify(start,q,resource,feedback)
    matrix = []
    rewards = []
    for s in range(5):
        row,rew=polynomial_kernel(s,q,resource,feedback)
        matrix.append(row)
        rewards.append(rew)
    # repeated row-vector by 5x5 transition matrix, distinct kernel algorithm
    vector = tuple(F(int(i==start)) for i in range(5))
    paths=[vector]
    reward_each=[]
    for _ in range(HORIZON):
        reward_each.append(sum((vector[i]*rewards[i] for i in range(5)),F(0)))
        vector=tuple(sum((vector[i]*matrix[i][j] for i in range(5)),F(0)) for j in range(5))
        paths.append(vector)
    return dict(yearly=tuple(paths),annual=tuple(reward_each),total=sum(reward_each,F(0)),
                final_mean=sum((F(j)*vector[j] for j in range(5)),F(0)))


def exhaust_z_paths(start: int, resource: int, feedback: int):
    """Third path: 64 explicitly fixed shock paths; independent conditional actions."""
    verify(start,F(1,2),resource,feedback)
    totals=[F(0)]*5
    actions=F(0)
    for shocks in itertools.product((0,1),repeat=HORIZON):
        states=[F(0)]*5
        states[start]=1
        this_reward=F(0)
        for z in shocks:
            dst=[F(0)]*5
            for s,mass in enumerate(states):
                if not mass:
                    continue
                p0=F(1+s+resource+z,8)
                p1=F(2+s+z,8)
                probs=((1-p0)*(1-p1),p0*(1-p1)+(1-p0)*p1,p0*p1)
                this_reward += mass*(p0+p1)
                for k,pk in enumerate(probs):
                    nxt=s if not feedback else max(0,min(4,s+k-1))
                    dst[nxt]+=mass*pk
            states=dst
        for s,pk in enumerate(states):
            totals[s]+=pk/F(64)
        actions+=this_reward/F(64)
    assert sum(totals)==1
    return tuple(totals),actions


def direct_actions(initial: int, action_pairs, feedback: int):
    verify(initial,F(0),0,feedback)
    s=initial
    path=[s]
    for pair in action_pairs:
        if len(pair)!=2 or any(type(x) is not int or x not in (0,1) for x in pair):
            raise ValueError('each action pair is two ordinary binary integers')
        s=_outcome(s,pair[0],pair[1],feedback)
        path.append(s)
    return path


def within_year_common_shock_covariance(s: int, resource: int):
    verify(s,F(1,2),resource,0)
    # conditional independence but common Bernoulli shock raises both p's 1/8
    p0=sum((F(1+s+resource+z,8) for z in (0,1)),F(0))/2
    p1=sum((F(2+s+z,8) for z in (0,1)),F(0))/2
    joint=sum((F(1+s+resource+z,8)*F(2+s+z,8) for z in (0,1)),F(0))/2
    return joint-p0*p1


def encode(v):
    if isinstance(v,F):return str(v)
    if isinstance(v,tuple):return [encode(x) for x in v]
    if isinstance(v,list):return [encode(x) for x in v]
    if isinstance(v,dict):return {str(k):encode(x) for k,x in v.items()}
    return v


def results():
    out=[]
    for feedback,q,resource,start in itertools.product((0,1),Q,(0,1),START):
        a=forward(start,q,resource,feedback)
        b=independent_matrix(start,q,resource,feedback)
        assert a==b, (feedback,q,resource,start)
        if q==F(1,2):
            terminal,moment=exhaust_z_paths(start,resource,feedback)
            assert (terminal,moment)==(a['yearly'][-1],a['total'])
        out.append(dict(feedback=feedback,shock=str(q),resource=resource,initial=start,
                        yearly_states=encode(a['yearly']),annual_actions=encode(a['annual']),
                        total_actions=str(a['total']),terminal_mean=str(a['final_mean']),
                        terminal_full_support=str(a['yearly'][-1][4]),
                        changed_structure_probability=str(1-a['yearly'][-1][start]),
                        independent_exact_match=True))
    assert len(out)==24
    seen=set()
    for v in out:
        key=(v['feedback'],v['shock'],v['resource'],v['initial'])
        assert key not in seen
        seen.add(key)
    return dict(
        model='Project constructed finite structuration toy, NOT Giddens or Sewell numerical code',
        primary_sources={'Giddens1984':'The Constitution of Society (1984), University of California Press edition original book table of contents',
                        'Sewell1992':'10.1086/229967 original publisher abstract and original scanned first-page index'},
        source_authors_numerical_models_reproduced=False,
        source_papers_original_full_pdf_visually_read=False,
        prescore_commit='70b4bcf48ca698a525de0d8d110403f843d84bf5',
        horizon=HORIZON,exact_scenarios=24,shock_histories_per_half_shock_scenario=64,
        direct_order_witness={'up_then_down':direct_actions(0,((1,1),(0,0)),1),
                              'down_then_up':direct_actions(0,((0,0),(1,1)),1),
                              'frozen_up_then_down':direct_actions(0,((1,1),(0,0)),0)},
        common_shock_action_covariance=str(within_year_common_shock_covariance(2,0)),
        scenario_results=out,
        new_E2_human_scores=0,new_E3_historical_forecasts=0,R073='FROZEN',PESEN_v0_1='FROZEN')


if __name__=='__main__':
    print(json.dumps(results(),ensure_ascii=False,sort_keys=True,separators=(',',':')))
