"""R149 true unittest: enumerations are separate test methods, no synthetic test count inflation."""
import json
import unittest
from fractions import Fraction as F
from pathlib import Path
import r149_structuration_exact as m


class BaseTests(unittest.TestCase):
    def test_all_cases(self):
        self.assertEqual(len(m.results()['scenario_results']),24)
    def test_shock_covariance(self):
        self.assertEqual(m.within_year_common_shock_covariance(2,0),F(1,256))
    def test_shock_covariance_edge_zero(self):
        self.assertEqual(m.within_year_common_shock_covariance(0,0),F(1,256))
    def test_shock_covariance_edge_four(self):
        self.assertEqual(m.within_year_common_shock_covariance(4,1),F(1,256))
    def test_order_up_then_down(self):
        self.assertEqual(m.direct_actions(0,((1,1),(0,0)),1),[0,1,0])
    def test_order_down_then_up(self):
        self.assertEqual(m.direct_actions(0,((0,0),(1,1)),1),[0,0,1])
    def test_order_action_counts_same(self):
        self.assertEqual(sum(sum(x) for x in ((1,1),(0,0))),sum(sum(x) for x in ((0,0),(1,1))))
    def test_order_frozen(self):
        self.assertEqual(m.direct_actions(0,((0,0),(1,1)),0),[0,0,0])
    def test_same_actions_at_upper_boundary(self):
        self.assertEqual(m.direct_actions(4,((1,1),(0,0)),1),[4,4,3])
    def test_reinforce_at_lower_boundary(self):
        self.assertEqual(m.direct_actions(0,((1,1),),1),[0,1])
    def test_depress_at_lower_boundary(self):
        self.assertEqual(m.direct_actions(0,((0,0),),1),[0,0])
    def test_frozen_any_sequence(self):
        self.assertEqual(m.direct_actions(3,((1,1),(0,0),(1,0)),0),[3]*4)
    def test_prior_period_only(self):
        dist,r=m.explicit_kernel(0,F(0),0,1)
        self.assertEqual(r,F(3,8))
    def test_no_float(self):
        with self.assertRaises(ValueError):m.explicit_kernel(1,0.5,0,1)
    def test_no_bool_q(self):
        with self.assertRaises(ValueError):m.explicit_kernel(1,False,0,1)
    def test_no_int_q(self):
        with self.assertRaises(ValueError):m.explicit_kernel(1,0,0,1)
    def test_no_negative_s(self):
        with self.assertRaises(ValueError):m.explicit_kernel(-1,F(0),0,1)
    def test_no_s_five(self):
        with self.assertRaises(ValueError):m.explicit_kernel(5,F(0),0,1)
    def test_no_bool_s(self):
        with self.assertRaises(ValueError):m.explicit_kernel(True,F(0),0,1)
    def test_no_float_s(self):
        with self.assertRaises(ValueError):m.explicit_kernel(2.0,F(0),0,1)
    def test_no_r_two(self):
        with self.assertRaises(ValueError):m.explicit_kernel(1,F(0),2,1)
    def test_no_bool_r(self):
        with self.assertRaises(ValueError):m.explicit_kernel(1,F(0),False,1)
    def test_no_float_r(self):
        with self.assertRaises(ValueError):m.explicit_kernel(1,F(0),0.0,1)
    def test_no_mode_two(self):
        with self.assertRaises(ValueError):m.explicit_kernel(1,F(0),0,2)
    def test_no_bool_mode(self):
        with self.assertRaises(ValueError):m.explicit_kernel(1,F(0),0,True)
    def test_no_bad_action_length(self):
        with self.assertRaises(ValueError):m.direct_actions(1,((1,),),1)
    def test_no_bool_action(self):
        with self.assertRaises(ValueError):m.direct_actions(1,((True,0),),1)
    def test_no_nonbinary_action(self):
        with self.assertRaises(ValueError):m.direct_actions(1,((2,0),),1)
    def test_nondegenerate_action_probabilities(self):
        for s in range(5):
            for z in (0,1):
                for resource in (0,1):
                    for prob in (F(1+s+resource+z,8),F(2+s+z,8)):
                        self.assertTrue(0<prob<1)
    def test_resource_conditional_increment(self):
        for s in range(5):
            for z in (0,1):
                self.assertEqual(F(1+s+1+z,8)-F(1+s+0+z,8),F(1,8))
    def test_each_period_yearly_states(self):
        v=m.forward(2,F(1,2),1,1)
        self.assertEqual(len(v['yearly']),7)
        self.assertTrue(all(len(x)==5 and sum(x)==1 for x in v['yearly']))
    def test_each_period_annual_moments(self):
        v=m.forward(2,F(1,2),1,1)
        self.assertEqual(len(v['annual']),6)
        self.assertEqual(sum(v['annual']),v['total'])
    def test_frozen_not_exogenous_feedback(self):
        for s in (0,2,4):
            v=m.forward(s,F(1,2),0,0)
            self.assertTrue(all(v['yearly'][k][s]==1 for k in range(7)))
    def test_fixed_s_two_resource_zero_total(self):
        self.assertEqual(m.forward(2,F(1,2),0,0)['total'],F(6))
    def test_fixed_s_two_resource_one_total(self):
        self.assertEqual(m.forward(2,F(1,2),1,0)['total'],F(27,4))
    def test_feedback_could_reduce_actions(self):
        a=m.forward(2,F(0),0,1)['total']
        b=m.forward(2,F(0),0,0)['total']
        self.assertLess(a,b)
    def test_feedback_could_increase_actions(self):
        a=m.forward(0,F(0),1,1)['total']
        b=m.forward(0,F(0),1,0)['total']
        self.assertGreater(a,b)
    def test_feedback_could_equal_actions(self):
        self.assertEqual(m.forward(2,F(0),1,1)['total'],m.forward(2,F(0),1,0)['total'])
    def test_json_reproducibility(self):
        saved=json.loads((Path(__file__).parent/'R149_EXACT_RESULTS.json').read_text())
        self.assertEqual(m.results(),saved)
    def test_source_is_not_original_equations(self):
        self.assertFalse(m.results()['source_authors_numerical_models_reproduced'])
    def test_real_evidence_zero(self):
        d=m.results()
        self.assertEqual((d['new_E2_human_scores'],d['new_E3_historical_forecasts']),(0,0))


class CaseTests(unittest.TestCase):
    pass


def case_test(feedback,q,resource,start):
    def t(self):
        a=m.forward(start,q,resource,feedback)
        b=m.independent_matrix(start,q,resource,feedback)
        self.assertEqual(a,b)
        self.assertEqual(sum(a['yearly'][-1]),1)
        self.assertEqual(sum(a['annual']),a['total'])
        self.assertTrue(all(sum(year)==1 for year in a['yearly']))
        if feedback==0:
            self.assertEqual(a['yearly'][-1][start],1)
        self.assertTrue(F(0)<=a['total']<=F(12))
    return t


def shock_test(feedback,resource,start):
    def t(self):
        a=m.forward(start,F(1,2),resource,feedback)
        end,reward=m.exhaust_z_paths(start,resource,feedback)
        self.assertEqual((end,reward),(a['yearly'][-1],a['total']))
    return t

for fb in (0,1):
    for q in (F(0),F(1,2)):
        for r in (0,1):
            for s in m.START:
                setattr(CaseTests,f'test_case_feedback_{fb}_q_{int(q*2)}_resource_{r}_start_{s}',case_test(fb,q,r,s))
for fb in (0,1):
    for r in (0,1):
        for s in m.START:
            setattr(CaseTests,f'test_64_shocks_feedback_{fb}_resource_{r}_start_{s}',shock_test(fb,r,s))

if __name__=='__main__':
    unittest.main()
